package defpackage;

/* loaded from: GLLib.jar:ASprite.class */
public class ASprite {
    static final short BSPRITE_v003 = 991;
    static final short BSPRITE_v004 = 1247;
    static final short BSPRITE_v005 = 1503;
    static final short SUPPORTED_VERSION = 1503;
    static final int BS_MODULES = 1;
    static final int BS_MODULES_XY = 2;
    static final int BS_MODULES_IMG = 4;
    static final int BS_MODULES_WH_SHORT = 16;
    static final int BS_MODULES_XY_SHORT = 32;
    static final int BS_MODULES_USAGE = 64;
    static final int BS_IMAGE_SIZE_INT = 128;
    static final int BS_FM_OFF_SHORT = 1024;
    static final int BS_NFM_1_BYTE = 2048;
    static final int BS_SKIP_FRAME_RC = 4096;
    static final int BS_FRAME_COLL_RC = 8192;
    static final int BS_FM_PALETTE = 16384;
    static final int BS_FRAME_RECTS = 32768;
    static final int BS_ANIMS = 65536;
    static final int BS_NO_AF_START = 131072;
    static final int BS_AF_OFF_SHORT = 262144;
    static final int BS_NAF_1_BYTE = 524288;
    static final int BS_MODULE_IMAGES_FX = 8388608;
    static final int BS_MODULE_IMAGES = 16777216;
    static final int BS_PNG_CRC = 33554432;
    static final int BS_KEEP_PAL = 67108864;
    static final int BS_TRANSP_FIRST = 134217728;
    static final int BS_TRANSP_LAST = 268435456;
    static final int BS_SINGLE_IMAGE = 536870912;
    static final int BS_MODULE_USAGE = 1073741824;
    static final int BS_GIF_HEADER = Integer.MIN_VALUE;
    static final int BS_DEFAULT_DOJA = -2130640575;
    static final int BS_DEFAULT_MIDP2 = 16843009;
    static final int BS_DEFAULT_NOKIA = 16843009;
    static final int BS_DEFAULT_MIDP1 = 65795;
    static final int BS_DEFAULT_MIDP1b = 50397441;
    static final int BS_DEFAULT_MIDP1c = 536936707;
    static final short PIXEL_FORMAT_8888 = -30584;
    static final short PIXEL_FORMAT_4444 = 17476;
    static final short PIXEL_FORMAT_1555 = 21781;
    static final short PIXEL_FORMAT_0565 = 25861;
    static final short ENCODE_FORMAT_I2 = 512;
    static final short ENCODE_FORMAT_I4 = 1024;
    static final short ENCODE_FORMAT_I16 = 5632;
    static final short ENCODE_FORMAT_I256 = 22018;
    static final short ENCODE_FORMAT_I64RLE = 25840;
    static final short ENCODE_FORMAT_I127RLE = 10225;
    static final short ENCODE_FORMAT_I256RLE = 22258;
    static final short ENCODE_FORMAT_A256_I64RLE = -22976;
    static final short ENCODE_FORMAT_A256_I127RLE = -24281;
    static final short ENCODE_FORMAT_A256_I256RLE = -23978;
    static final byte FLAG_FLIP_X = 1;
    static final byte FLAG_FLIP_Y = 2;
    static final byte FLAG_ROT_90 = 4;
    static final byte FLAG_USER0 = 16;
    static final byte FLAG_USER1 = 32;
    static final byte FLAG_HYPER_FM = 16;
    static final int FLAG_INDEX_EX_MASK = 192;
    static final int INDEX_MASK = 1023;
    static final int INDEX_EX_MASK = 768;
    static final int INDEX_EX_SHIFT = 2;
    static final byte FLAG_OFFSET_FM = 16;
    static final byte FLAG_OFFSET_AF = 32;
    static final int OPERATION_DRAW = 0;
    static final int OPERATION_COMPUTERECT = 1;
    static final int OPERATION_RECORD = 2;
    static final int OPERATION_MARK = 3;
    static final int RESIZE_NONE = 0;
    static final int RESIZE_CREATERGB = 1;
    static final int RESIZE_DRAW_ON_MUTABLE = 2;
    static final int RESIZE_NOT_CACHED = 3;
    static final int MD_IMAGE = 0;
    static final int MD_RECT = 1;
    static final int MD_FILL_RECT = 2;
    static final int MD_ARC = 3;
    static final int MD_FILL_ARC = 4;
    static final int MD_MARKER = 5;
    static final int MD_TRIANGLE = 6;
    static final int MD_FILL_TRIANGLE = 7;
    static final int MAX_TRANSFORMATION_FLAGS = 8;
    static final int FLAG_USE_CACHE_RGB = 1;
    public static final int BLOCK_INFO_SIZE = 11;
    public static final int PNG_INFO_SIZE = 57;
    public static final int HEADER_LEVEL0_MAX_WBITS = 30938;
    public static final int BASE = 65521;
    public static final int NMAX = 5552;
    static byte[] _buffer_index;
    static byte[] _png_index;
    static byte[] _png_result;
    static int _png_size;
    static int _png_start_crc;
    static int mod;
    public static final int CRC32_POLYNOMIAL = -306674912;
    static int currentChunkType;
    int _cur_pal;
    static final int SCALE_SHIFT = 16;
    static final int RESIZE_REF_240x320 = 0;
    static final int RESIZE_REF_176x220 = 1;
    static final int RESIZE_REF_240x256 = 2;
    static int mResizeRef;
    static boolean s_bBilinear;
    static boolean s_bAspectRatio;
    int wRef;
    int hRef;
    int wTarget;
    int hTarget;
    int xRatio;
    int yRatio;
    static short[][] _poolCacheStack;
    static int[] _poolCacheStackIndex;
    static int[] _poolCacheStackMax;
    static ASprite[][] _poolCacheSprites;
    private byte[] _palBlend_ModuleState;
    static int _text_w;
    static int _text_h;
    static byte[] s_MapChar;
    private short[][] _pMapCharShort;
    private short _nDivider;
    private int _nLineSpacing;
    private int _nFontHeight;
    private int _nFontAscent;
    private int _nFontDescent;
    private int _nSpaceWidth;
    private int _nCharSpacing;
    private int _nLineHeight;
    static short[] _warpTextInfo;
    private static final int WRAP_TEXT_FORMATTING_MASK_PALETTE = 4095;
    private static final int WRAP_TEXT_FORMATTING_FLAG_IS_BOLD = 4096;
    private static final int WRAP_TEXT_FORMATTING_FLAG_IS_UNDERLINED = 8192;
    static int _index1;
    static int _index2;
    static int _indexMax;
    int _old_pal;
    static final int k_itoa_buffer_size = 33;
    static char[] _itoa_buffer;
    public static final int PAL_ORIGINAL = -1;
    public static final int PAL_INVISIBLE = 0;
    public static final int PAL_RED_YELLOW = 1;
    public static final int PAL_BLUE_CYAN = 2;
    public static final int PAL_GREEN = 3;
    public static final int PAL_GREY = 4;
    public static final int PAL_BLEND_BLACK = 5;
    Object[][] _aryPrecomputedImages;
    short[][] _aryPrecomputedX;
    short[][] _aryPrecomputedY;
    short[][] _aryPrecomputedSizeX;
    short[][] _aryPrecomputedSizeY;
    short[][] _aryPrecomputedImgX;
    short[][] _aryPrecomputedImgY;
    int[][] _aryPrecomputedFlags;
    static int record_index;
    static int record_frame;
    static int _operation;
    static int[] temp_int;
    static short[] temp_short;
    static byte[] temp_byte;
    static int[] transform_int;
    static short[] transform_short;
    int _nModules;
    byte[] _modules_x_byte;
    byte[] _modules_y_byte;
    short[] _modules_x_short;
    short[] _modules_y_short;
    short[] _modules_w_scaled;
    short[] _modules_h_scaled;
    short[] _modules_w_short;
    short[] _modules_h_short;
    byte[] _modules_w_byte;
    byte[] _modules_h_byte;
    short[] _modules_extra_info;
    short[] _modules_extra_pointer;
    byte[] _frames_nfm;
    short[] _frames_fm_start;
    byte[] _frames_rc;
    short[] _frames_rc_short;
    byte[] _frames_col;
    short[] _frames_col_short;
    byte[] _frames_rects;
    short[] _frames_rects_short;
    short[] _frames_rects_start;
    byte[] _fmodules;
    byte[] _fmodules_id;
    short[] _fmodules_ox_short;
    short[] _fmodules_oy_short;
    byte[] _fmodules_ox_byte;
    byte[] _fmodules_oy_byte;
    byte[] _fmodules_pal;
    byte[] _fmodules_flags;
    byte[] _anims_naf;
    short[] _anims_af_start;
    byte[] _aframes;
    byte[] _aframes_frame;
    byte[] _aframes_time;
    short[] _aframes_ox_short;
    short[] _aframes_oy_short;
    byte[] _aframes_ox_byte;
    byte[] _aframes_oy_byte;
    byte[] _aframes_flags;
    short[][] _map;
    private int _cur_map;
    int[] _w_pos;
    int[] _header_size;
    byte[][] _gifHeader;
    byte[] _modules_data;
    short[] _modules_data_off_short;
    int[] _modules_data_off_int;
    int _bs_flags;
    short[][] _pal_short;
    int[][] _pal_int;
    byte[][] _transp;
    byte[] _pal_data;
    int _palettes;
    int _colors;
    private int _crt_pal;
    boolean _alpha;
    boolean _multiAlpha;
    int _flags;
    short _data_format;
    int _i64rle_color_mask;
    int _i64rle_color_bits;
    boolean _bTraceNow;
    static Graphics _graphics;
    short[][][] _modules_image_shortAAA;
    Image[][][] _module_image_imageAAA;
    int[][][] _module_image_intAAA;
    Image[][] _module_image_imageAA;
    Image[] _main_image;
    int[] _PNG_packed_PLTE_CRC;
    int[] _PNG_packed_tRNS_CRC;
    int[] _PNG_packed_IHDR_CRC;
    int[] _PNG_packed_IDAT_ADLER;
    int[] _PNG_packed_IDAT_CRC;
    static int _images_count;
    static int _images_size;
    static int mem;
    static final int[] midp2_flags;
    byte[] _module_types;
    byte[] _module_colors_byte;
    int[] _module_colors_int;
    byte[] _modules_usage;
    static int s_resizeType;
    static int _rectX1;
    static int _rectY1;
    static int _rectX2;
    static int _rectY2;
    static int[] s_rc;
    static boolean s_gcEnabled;
    protected static final byte[] MAGIC = {-119, 80, 78, 71, 13, 10, 26, 10};
    protected static final byte[] IHDR = {73, 72, 68, 82};
    protected static final byte[] PLTE = {80, 76, 84, 69};
    protected static final byte[] tRNS = {116, 82, 78, 83};
    protected static final byte[] IDAT = {73, 68, 65, 84};
    protected static final byte[] IEND = {73, 69, 78, 68};
    protected static final byte[] INFO32 = {8, 6, 0, 0, 0};
    protected static final byte[] INFO8 = {8, 3, 0, 0, 0};
    protected static final byte[] MAGIC_IEND = {0, 0, 0, 0, 73, 69, 78, 68, -82, 66, 96, -126};
    static final byte[] MAGIC_IDAT_h = {120, -100, 1};
    static final int BS_FRAMES = 256;
    public static int[] crcTable = new int[BS_FRAMES];
    boolean mResizeCorrectY = false;
    int _cur_pool = -1;
    private int _palBlend_srcA = -1;
    private int _palBlend_srcB = -1;
    private int _palBlend_dest = -1;
    private int _palBlend_current = -1;
    private boolean _palBlend_UseOneColor = false;
    private byte[] _pMapChar = s_MapChar;
    private boolean _bUnderline = false;
    private boolean _bBold = false;
    private int[] nALetterRect = new int[4];

    static void DrawLine(Graphics g, int x1, int y1, int x2, int y2, int color, int radius, int initial) {
        int ix = 0;
        int iy = 0;
        int old_color = g.getColor();
        g.setColor(color);
        int currX = x1;
        int currY = y1;
        int dx = x2 - x1;
        int dy = y2 - y1;
        if (dx >= 0) {
            ix = 1;
        }
        if (dx < 0) {
            ix = -1;
            dx = Math.abs(dx);
        }
        if (dy >= 0) {
            iy = 1;
        }
        if (dy < 0) {
            iy = -1;
            dy = Math.abs(dy);
        }
        int dx2 = dx * 2;
        int dy2 = dy * 2;
        int dist = 0;
        int maxdist = (5 - initial) * radius;
        if (dx > dy) {
            int err = dy2 - dx;
            for (int i = 0; i <= dx; i++) {
                if (dist == maxdist) {
                    if (!GLLibConfig.sprite_fillRoundRectBug) {
                        g.fillRoundRect(currX - radius, currY - radius, radius * 2, radius * 2, 30, 30);
                    } else {
                        g.fillRect(currX - radius, (currY - radius) + 1, radius << 1, (radius << 1) - 2);
                        g.fillRect((currX - radius) + 1, currY - radius, (radius << 1) - 2, radius << 1);
                    }
                }
                dist += (ix * ix) + (iy * iy);
                if (dist > 6 * radius) {
                    dist = 0;
                }
                if (err >= 0) {
                    err -= dx2;
                    currY += iy;
                }
                err += dy2;
                currX += ix;
            }
        } else {
            int err2 = dx2 - dy;
            for (int i2 = 0; i2 <= dy; i2++) {
                if (dist == maxdist) {
                    if (!GLLibConfig.sprite_fillRoundRectBug) {
                        g.fillRoundRect(currX - radius, currY - radius, radius * 2, radius * 2, 30, 30);
                    } else {
                        g.fillRect(currX - radius, (currY - radius) + 1, radius << 1, (radius << 1) - 2);
                        g.fillRect((currX - radius) + 1, currY - radius, (radius << 1) - 2, radius << 1);
                    }
                }
                dist += (ix * ix) + (iy * iy);
                if (dist > 6 * radius) {
                    dist = 0;
                }
                if (err2 >= 0) {
                    err2 -= dy2;
                    currX += ix;
                }
                err2 += dx2;
                currY += iy;
            }
        }
        g.setColor(old_color);
    }

    void unload() {
        if (GLLibConfig.sprite_useModuleXYShort) {
            this._modules_y_short = null;
            this._modules_x_short = null;
        } else {
            this._modules_x_byte = null;
            this._modules_y_byte = null;
        }
        if (GLLibConfig.sprite_useModuleWHShort) {
            this._modules_w_short = null;
            this._modules_h_short = null;
        } else {
            this._modules_w_byte = null;
            this._modules_h_byte = null;
        }
        this._frames_nfm = null;
        this._frames_fm_start = null;
        this._frames_rc = null;
        this._frames_rc_short = null;
        this._frames_col = null;
        this._frames_col_short = null;
        this._frames_rects = null;
        this._frames_rects_short = null;
        this._frames_rects_start = null;
        this._fmodules = null;
        this._anims_naf = null;
        this._anims_af_start = null;
        this._aframes = null;
        if (this._map != null) {
            for (int i = 0; i < this._map.length; i++) {
                this._map[i] = null;
            }
        }
        if (GLLibConfig.sprite_useNokiaUI) {
            if (this._pal_short != null) {
                for (int i2 = 0; i2 < this._pal_short.length; i2++) {
                    this._pal_short[i2] = null;
                }
            }
        } else if (GLLibConfig.sprite_useCreateRGB && this._pal_int != null) {
            for (int i3 = 0; i3 < this._pal_int.length; i3++) {
                this._pal_int[i3] = null;
            }
        }
        if (this._transp != null) {
            for (int i4 = 0; i4 < this._transp.length; i4++) {
                this._transp[i4] = null;
            }
        }
        this._pal_data = null;
        this._modules_data = null;
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            this._modules_data_off_short = null;
        } else {
            this._modules_data_off_int = null;
        }
        if (GLLibConfig.sprite_useNokiaUI) {
            if (this._modules_image_shortAAA != null) {
                for (int i5 = 0; i5 < this._modules_image_shortAAA.length; i5++) {
                    this._modules_image_shortAAA[i5] = (short[][]) null;
                }
            }
        } else if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
            if (this._module_image_intAAA != null) {
                for (int i6 = 0; i6 < this._module_image_intAAA.length; i6++) {
                    this._module_image_intAAA[i6] = (int[][]) null;
                }
            }
        } else if (this._module_image_imageAA != null) {
            for (int i7 = 0; i7 < this._module_image_imageAA.length; i7++) {
                this._module_image_imageAA[i7] = null;
            }
        }
        this._main_image = null;
        this._PNG_packed_PLTE_CRC = null;
        this._PNG_packed_tRNS_CRC = null;
        this._PNG_packed_IHDR_CRC = null;
        this._PNG_packed_IDAT_ADLER = null;
        this._PNG_packed_IDAT_CRC = null;
    }

    void Load(byte[] file, int offset) {
        Load(file, offset, 16777215, 1, null);
    }

    void Load(byte[] file, int offset, int pal_flags, int tr_flags) {
        if (GLLibConfig.sprite_useDynamicPng) {
            Load(file, offset, pal_flags, tr_flags, null);
        }
    }

    void Load(byte[] file, int offset, Image sprImage) {
        if (GLLibConfig.sprite_useExternImage) {
            Load(file, offset, 16777215, 1, sprImage);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v108, types: [short[]] */
    /* JADX WARN: Type inference failed for: r0v117, types: [short[]] */
    private int LoadModules(int offset, byte[] file) {
        int nSize;
        int offset2 = offset + 1;
        int i = file[offset] & 255;
        int offset3 = offset2 + 1;
        this._nModules = (short) (i + ((file[offset2] & 255) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println(new StringBuffer().append("nModules = ").append(this._nModules).toString());
        }
        if (this._nModules > 0) {
            if (GLLibConfig.sprite_useModuleXYShort && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 32) != 0)) {
                this._modules_x_short = new short[this._nModules];
                this._modules_y_short = new short[this._nModules];
            } else if (GLLibConfig.sprite_useModuleXY && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 2) != 0)) {
                this._modules_x_byte = new byte[this._nModules];
                this._modules_y_byte = new byte[this._nModules];
            }
            if (GLLibConfig.sprite_useModuleWHShort) {
                this._modules_w_short = new short[this._nModules];
                this._modules_h_short = new short[this._nModules];
            } else {
                this._modules_w_byte = new byte[this._nModules];
                this._modules_h_byte = new byte[this._nModules];
            }
            int tmpExtraInfoCount = 0;
            int tmpExtraInfoSize = 0;
            short[][] tmpExtraInfo = (short[][]) null;
            if (GLLibConfig.sprite_useMultipleModuleTypes) {
                this._module_types = new byte[this._nModules];
                if (GLLibConfig.sprite_useModuleColorAsByte) {
                    this._module_colors_byte = new byte[this._nModules];
                } else {
                    this._module_colors_int = new int[this._nModules];
                }
            }
            boolean bLoadAModuleColor = false;
            boolean bLoadAModulePosition = false;
            boolean bLoadAModuleSize = false;
            for (int i2 = 0; i2 < this._nModules; i2++) {
                boolean bLoadAModuleArc = false;
                boolean bLoadAModuleTriangle = false;
                if (GLLibConfig.sprite_useMultipleModuleTypes) {
                    if ((file[offset3] & 255) == 0) {
                        offset3++;
                        this._module_types[i2] = 0;
                        bLoadAModuleColor = false;
                        bLoadAModulePosition = true;
                        bLoadAModuleSize = true;
                    } else if ((file[offset3] & 255) == 255) {
                        offset3++;
                        this._module_types[i2] = 1;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = true;
                    } else if ((file[offset3] & 255) == 254) {
                        offset3++;
                        this._module_types[i2] = 2;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = true;
                    } else if ((file[offset3] & 255) == 253) {
                        offset3++;
                        this._module_types[i2] = 5;
                        bLoadAModuleColor = false;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = true;
                    } else if ((file[offset3] & 255) == 252) {
                        offset3++;
                        this._module_types[i2] = 3;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = true;
                        bLoadAModuleArc = true;
                    } else if ((file[offset3] & 255) == 251) {
                        offset3++;
                        this._module_types[i2] = 4;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = true;
                        bLoadAModuleArc = true;
                    } else if ((file[offset3] & 255) == 250) {
                        offset3++;
                        this._module_types[i2] = 6;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = false;
                        bLoadAModuleTriangle = true;
                    } else if ((file[offset3] & 255) == 249) {
                        offset3++;
                        this._module_types[i2] = 7;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = false;
                        bLoadAModuleTriangle = true;
                    }
                } else if ((file[offset3] & 255) == 0) {
                    offset3++;
                    bLoadAModuleColor = false;
                    bLoadAModulePosition = true;
                    bLoadAModuleSize = true;
                }
                if (GLLibConfig.sprite_useMultipleModuleTypes && bLoadAModuleColor) {
                    if (GLLibConfig.sprite_useModuleColorAsByte) {
                        this._module_colors_byte[i2] = file[offset3];
                        offset3 = offset3 + 1 + 3;
                    } else {
                        int i3 = offset3;
                        int offset4 = offset3 + 1;
                        int offset5 = offset4 + 1;
                        int i4 = (file[i3] & 255) + ((file[offset4] & 255) << 8);
                        int offset6 = offset5 + 1;
                        int i5 = i4 + ((file[offset5] & 255) << 16);
                        offset3 = offset6 + 1;
                        this._module_colors_int[i2] = i5 + ((file[offset6] & 255) << 24);
                    }
                }
                if (bLoadAModulePosition) {
                    if (GLLibConfig.sprite_useModuleXYShort && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 32) != 0)) {
                        int i6 = offset3;
                        int offset7 = offset3 + 1;
                        int offset8 = offset7 + 1;
                        this._modules_x_short[i2] = (short) ((file[i6] & 255) + ((file[offset7] & 255) << 8));
                        int offset9 = offset8 + 1;
                        int i7 = file[offset8] & 255;
                        offset3 = offset9 + 1;
                        this._modules_y_short[i2] = (short) (i7 + ((file[offset9] & 255) << 8));
                    } else if (GLLibConfig.sprite_useModuleXY && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 2) != 0)) {
                        int i8 = offset3;
                        int offset10 = offset3 + 1;
                        this._modules_x_byte[i2] = file[i8];
                        offset3 = offset10 + 1;
                        this._modules_y_byte[i2] = file[offset10];
                    }
                }
                if (bLoadAModuleSize) {
                    if (GLLibConfig.sprite_useModuleWHShort) {
                        if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 16) == 0) {
                            int i9 = offset3;
                            int offset11 = offset3 + 1;
                            this._modules_w_short[i2] = (short) (file[i9] & 255);
                            offset3 = offset11 + 1;
                            this._modules_h_short[i2] = (short) (file[offset11] & 255);
                        } else {
                            int i10 = offset3;
                            int offset12 = offset3 + 1;
                            int offset13 = offset12 + 1;
                            this._modules_w_short[i2] = (short) ((file[i10] & 255) + ((file[offset12] & 255) << 8));
                            int offset14 = offset13 + 1;
                            int i11 = file[offset13] & 255;
                            offset3 = offset14 + 1;
                            this._modules_h_short[i2] = (short) (i11 + ((file[offset14] & 255) << 8));
                        }
                    } else {
                        int i12 = offset3;
                        int offset15 = offset3 + 1;
                        this._modules_w_byte[i2] = file[i12];
                        offset3 = offset15 + 1;
                        this._modules_h_byte[i2] = file[offset15];
                    }
                }
                if (GLLibConfig.sprite_useMultipleModuleTypes) {
                    if (bLoadAModuleArc) {
                        if (tmpExtraInfo == null) {
                            tmpExtraInfo = new short[this._nModules];
                        }
                        int i13 = offset3;
                        int offset16 = offset3 + 1;
                        int offset17 = offset16 + 1;
                        int offset18 = offset17 + 1;
                        int i14 = file[offset17] & 255;
                        offset3 = offset18 + 1;
                        short[] aShort = {(short) ((file[i13] & 255) + ((file[offset16] & 255) << 8)), (short) (i14 + ((file[offset18] & 255) << 8))};
                        tmpExtraInfo[i2] = aShort;
                        tmpExtraInfoCount++;
                        tmpExtraInfoSize += 2;
                    }
                    if (bLoadAModuleTriangle) {
                        if (tmpExtraInfo == null) {
                            tmpExtraInfo = new short[this._nModules];
                        }
                        int i15 = offset3;
                        int offset19 = offset3 + 1;
                        int offset20 = offset19 + 1;
                        int offset21 = offset20 + 1;
                        int i16 = file[offset20] & 255;
                        int offset22 = offset21 + 1;
                        int offset23 = offset22 + 1;
                        int i17 = file[offset22] & 255;
                        int offset24 = offset23 + 1;
                        int offset25 = offset24 + 1;
                        int i18 = file[offset24] & 255;
                        offset3 = offset25 + 1;
                        short[] aShort2 = {(short) ((file[i15] & 255) + ((file[offset19] & 255) << 8)), (short) (i16 + ((file[offset21] & 255) << 8)), (short) (i17 + ((file[offset23] & 255) << 8)), (short) (i18 + ((file[offset25] & 255) << 8))};
                        tmpExtraInfo[i2] = aShort2;
                        tmpExtraInfoCount++;
                        tmpExtraInfoSize += 4;
                    }
                }
            }
            if (GLLibConfig.sprite_useMultipleModuleTypes) {
                if (tmpExtraInfoCount > 0) {
                    this._modules_extra_info = new short[tmpExtraInfoSize];
                    this._modules_extra_pointer = new short[tmpExtraInfoCount << 1];
                    int xCount = 0;
                    short xOffset = 0;
                    short s = 0;
                    while (true) {
                        short m = s;
                        if (m >= this._nModules) {
                            break;
                        }
                        if (this._module_types[m] == 3 || this._module_types[m] == 4) {
                            nSize = 2;
                        } else if (this._module_types[m] == 6 || this._module_types[m] == 7) {
                            nSize = 4;
                        } else {
                            nSize = -1;
                        }
                        if (nSize > 0) {
                            this._modules_extra_pointer[(xCount << 1) + 0] = m;
                            this._modules_extra_pointer[(xCount << 1) + 1] = xOffset;
                            for (int x = 0; x < nSize; x++) {
                                this._modules_extra_info[xOffset] = tmpExtraInfo[m][x];
                                xOffset = (short) (xOffset + 1);
                            }
                            tmpExtraInfo[m] = null;
                            xCount++;
                        }
                        s = (short) (m + 1);
                    }
                }
            }
        }
        if (GLLibConfig.sprite_useModuleUsageFromSprite) {
            this._modules_usage = new byte[this._nModules];
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("Module usage... offset = ").append(offset3).append(" _nModules = ").append(this._nModules).toString());
            }
            if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_MODULE_USAGE) != 0) {
                System.arraycopy(file, offset3, this._modules_usage, 0, this._nModules);
                offset3 += this._nModules;
            }
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("...Module usage");
            }
        }
        return offset3;
    }

    private int LoadFModules(int offset, byte[] file) {
        int offset2;
        int offset3 = offset + 1;
        int i = file[offset] & 255;
        int offset4 = offset3 + 1;
        int nFModules = (short) (i + ((file[offset3] & 255) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println(new StringBuffer().append("nFModules = ").append(nFModules).toString());
        }
        if (nFModules > 0) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                this._fmodules = new byte[nFModules << 2];
                System.arraycopy(file, offset4, this._fmodules, 0, this._fmodules.length);
                offset4 += this._fmodules.length;
            } else {
                this._fmodules_id = new byte[nFModules];
                if (GLLibConfig.sprite_useFMOffShort) {
                    this._fmodules_ox_short = new short[nFModules];
                    this._fmodules_oy_short = new short[nFModules];
                } else {
                    this._fmodules_ox_byte = new byte[nFModules];
                    this._fmodules_oy_byte = new byte[nFModules];
                }
                this._fmodules_flags = new byte[nFModules];
                if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_FM_PALETTE) != 0)) {
                    this._fmodules_pal = new byte[nFModules];
                }
                for (int i2 = 0; i2 < nFModules; i2++) {
                    int i3 = offset4;
                    int offset5 = offset4 + 1;
                    this._fmodules_id[i2] = file[i3];
                    if (GLLibConfig.sprite_useFMOffShort) {
                        if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 1024) == 0) {
                            this._fmodules_ox_short[i2] = file[offset5];
                            offset2 = offset5 + 1 + 1;
                            this._fmodules_oy_short[i2] = file[r7];
                        } else {
                            int offset6 = offset5 + 1;
                            int i4 = file[offset5] & 255;
                            int offset7 = offset6 + 1;
                            this._fmodules_ox_short[i2] = (short) (i4 + ((file[offset6] & 255) << 8));
                            int offset8 = offset7 + 1;
                            int i5 = file[offset7] & 255;
                            offset2 = offset8 + 1;
                            this._fmodules_oy_short[i2] = (short) (i5 + ((file[offset8] & 255) << 8));
                        }
                    } else {
                        int offset9 = offset5 + 1;
                        this._fmodules_ox_byte[i2] = file[offset5];
                        offset2 = offset9 + 1;
                        this._fmodules_oy_byte[i2] = file[offset9];
                    }
                    if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_FM_PALETTE) != 0)) {
                        int i6 = offset2;
                        offset2++;
                        this._fmodules_pal[i2] = file[i6];
                    }
                    int i7 = offset2;
                    offset4 = offset2 + 1;
                    this._fmodules_flags[i2] = file[i7];
                }
            }
        }
        return offset4;
    }

    private int LoadFrames(int offset, byte[] file) {
        if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & BS_FRAME_RECTS) != 0) {
            int offset2 = offset + 1;
            int i = file[offset] & 255;
            int offset3 = offset2 + 1;
            int nRects = (short) (i + ((file[offset2] & 255) << 8));
            if ((this._bs_flags & 1024) == 0) {
                this._frames_rects = new byte[nRects << 2];
                System.arraycopy(file, offset3, this._frames_rects, 0, nRects << 2);
                offset = offset3 + (nRects << 2);
            } else {
                this._frames_rects_short = new short[nRects << 2];
                offset = readArray2Short(file, offset3, this._frames_rects_short, 0, nRects << 2, false, false);
            }
        }
        int i2 = offset;
        int offset4 = offset + 1;
        int offset5 = offset4 + 1;
        int nFrames = (short) ((file[i2] & 255) + ((file[offset4] & 255) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println(new StringBuffer().append("nFrames = ").append(nFrames).append("    @ offset ").append(offset5 - 2).toString());
        }
        if (nFrames > 0) {
            this._frames_nfm = new byte[nFrames];
            this._frames_fm_start = new short[nFrames];
            short frame_start = 0;
            if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & BS_FRAME_RECTS) != 0) {
                this._frames_rects_start = new short[nFrames + 1];
            }
            short frames_rects_offset = 0;
            for (int i3 = 0; i3 < nFrames; i3++) {
                if (GLLibConfig.sprite_debugLoading) {
                    System.out.println(new StringBuffer().append("    ").append(i3).append("    @ offset ").append(offset5).toString());
                }
                int i4 = offset5;
                offset5++;
                this._frames_nfm[i3] = file[i4];
                if (!GLLibConfig.sprite_alwaysBsNfm1Byte) {
                    offset5++;
                    byte b = file[offset5];
                }
                if (GLLibConfig.sprite_alwaysBsNoFmStart) {
                    this._frames_fm_start[i3] = frame_start;
                    frame_start = (short) (frame_start + (this._frames_nfm[i3] & 255));
                } else {
                    int i5 = offset5;
                    int offset6 = offset5 + 1;
                    offset5 = offset6 + 1;
                    this._frames_fm_start[i3] = (short) ((file[i5] & 255) + ((file[offset6] & 255) << 8));
                }
                if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & BS_FRAME_RECTS) != 0 && (this._bs_flags & BS_FRAME_RECTS) != 0) {
                    this._frames_rects_start[i3] = frames_rects_offset;
                    int i6 = offset5;
                    offset5++;
                    frames_rects_offset = (short) (frames_rects_offset + file[i6]);
                }
            }
            if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & BS_FRAME_RECTS) != 0) {
                this._frames_rects_start[this._frames_rects_start.length - 1] = frames_rects_offset;
            }
            if (!GLLibConfig.sprite_alwaysBsSkipFrameRc) {
                if (GLLibConfig.sprite_usePrecomputedFrameRect) {
                    int nFrames4 = nFrames << 2;
                    if ((this._bs_flags & 1024) == 0) {
                        this._frames_rc = new byte[nFrames4];
                        for (int i7 = 0; i7 < nFrames4; i7++) {
                            int i8 = offset5;
                            offset5++;
                            this._frames_rc[i7] = file[i8];
                        }
                    } else {
                        this._frames_rc_short = new short[nFrames4];
                        for (int i9 = 0; i9 < nFrames4; i9++) {
                            int i10 = offset5;
                            int offset7 = offset5 + 1;
                            offset5 = offset7 + 1;
                            this._frames_rc_short[i9] = (short) ((file[i10] & 255) + ((file[offset7] & 255) << 8));
                        }
                    }
                } else if ((this._bs_flags & 1024) == 0) {
                    offset5 += nFrames << 2;
                } else {
                    offset5 += nFrames << 3;
                }
            } else if (GLLibConfig.sprite_usePrecomputedFrameRect) {
            }
            if (GLLibConfig.sprite_useFrameCollRC && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 8192) != 0)) {
                int nFrames42 = nFrames << 2;
                if ((this._bs_flags & 1024) == 0) {
                    this._frames_col = new byte[nFrames42];
                    for (int i11 = 0; i11 < nFrames42; i11++) {
                        int i12 = offset5;
                        offset5++;
                        this._frames_col[i11] = file[i12];
                    }
                } else {
                    this._frames_col_short = new short[nFrames42];
                    for (int i13 = 0; i13 < nFrames42; i13++) {
                        int i14 = offset5;
                        int offset8 = offset5 + 1;
                        offset5 = offset8 + 1;
                        this._frames_col_short[i13] = (short) ((file[i14] & 255) + ((file[offset8] & 255) << 8));
                    }
                }
            }
        }
        return offset5;
    }

    private int LoadAFrames(int offset, byte[] file) {
        int offset2;
        int offset3 = offset + 1;
        int i = file[offset] & 255;
        int offset4 = offset3 + 1;
        int nAFrames = (short) (i + ((file[offset3] & 255) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println(new StringBuffer().append("nAFrames = ").append(nAFrames).toString());
        }
        if (nAFrames > 0) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                this._aframes = new byte[nAFrames * 5];
                System.arraycopy(file, offset4, this._aframes, 0, this._aframes.length);
                offset4 += this._aframes.length;
            } else {
                this._aframes_frame = new byte[nAFrames];
                this._aframes_time = new byte[nAFrames];
                if (GLLibConfig.sprite_useAfOffShort) {
                    this._aframes_ox_short = new short[nAFrames];
                    this._aframes_oy_short = new short[nAFrames];
                } else {
                    this._aframes_ox_byte = new byte[nAFrames];
                    this._aframes_oy_byte = new byte[nAFrames];
                }
                this._aframes_flags = new byte[nAFrames];
                for (int i2 = 0; i2 < nAFrames; i2++) {
                    int i3 = offset4;
                    int offset5 = offset4 + 1;
                    this._aframes_frame[i2] = file[i3];
                    int offset6 = offset5 + 1;
                    this._aframes_time[i2] = file[offset5];
                    if (GLLibConfig.sprite_useAfOffShort) {
                        if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & BS_AF_OFF_SHORT) == 0) {
                            this._aframes_ox_short[i2] = file[offset6];
                            offset2 = offset6 + 1 + 1;
                            this._aframes_oy_short[i2] = file[r7];
                        } else {
                            int offset7 = offset6 + 1;
                            int i4 = file[offset6] & 255;
                            int offset8 = offset7 + 1;
                            this._aframes_ox_short[i2] = (short) (i4 + ((file[offset7] & 255) << 8));
                            int offset9 = offset8 + 1;
                            int i5 = file[offset8] & 255;
                            offset2 = offset9 + 1;
                            this._aframes_oy_short[i2] = (short) (i5 + ((file[offset9] & 255) << 8));
                        }
                    } else {
                        int offset10 = offset6 + 1;
                        this._aframes_ox_byte[i2] = file[offset6];
                        offset2 = offset10 + 1;
                        this._aframes_oy_byte[i2] = file[offset10];
                    }
                    int i6 = offset2;
                    offset4 = offset2 + 1;
                    this._aframes_flags[i2] = file[i6];
                }
            }
        }
        return offset4;
    }

    private int LoadAnims(int offset, byte[] file) {
        int offset2 = offset + 1;
        int i = file[offset] & 255;
        int offset3 = offset2 + 1;
        int nAnims = (short) (i + ((file[offset2] & 255) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println(new StringBuffer().append("nAnims = ").append(nAnims).toString());
        }
        if (nAnims > 0) {
            this._anims_naf = new byte[nAnims];
            this._anims_af_start = new short[nAnims];
            short af_start = 0;
            for (int i2 = 0; i2 < nAnims; i2++) {
                int i3 = offset3;
                offset3++;
                this._anims_naf[i2] = file[i3];
                if (!GLLibConfig.sprite_alwaysBsNfm1Byte) {
                    offset3++;
                    byte b = file[offset3];
                }
                if (GLLibConfig.sprite_alwaysBsNoAfStart) {
                    this._anims_af_start[i2] = af_start;
                    af_start = (short) (af_start + this._anims_naf[i2]);
                } else {
                    int i4 = offset3;
                    int offset4 = offset3 + 1;
                    offset3 = offset4 + 1;
                    this._anims_af_start[i2] = (short) ((file[i4] & 255) + ((file[offset4] & 255) << 8));
                }
            }
        }
        return offset3;
    }

    /* JADX WARN: Type inference failed for: r1v26, types: [short[], short[][]] */
    void Load(byte[] file, int offset, int pal_flags, int tr_flags, Image sprImage) {
        int offset2;
        if (file == null) {
            return;
        }
        try {
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("ASprite.Load(").append(file.length).append(" bytes, ").append(offset).append(")...").append(this).toString());
            }
            if (!GLLibConfig.sprite_useDeactivateSystemGc && s_gcEnabled) {
                System.gc();
            }
            int offset3 = offset + 1;
            int i = file[offset] & 255;
            int offset4 = offset3 + 1;
            short bs_version = (short) (i + ((file[offset3] & 255) << 8));
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("bs_version = 0x").append(Integer.toHexString(bs_version)).toString());
            }
            int offset5 = offset4 + 1;
            int i2 = file[offset4] & 255;
            int offset6 = offset5 + 1;
            int i3 = i2 + ((file[offset5] & 255) << 8);
            int offset7 = offset6 + 1;
            int i4 = i3 + ((file[offset6] & 255) << 16);
            int offset8 = offset7 + 1;
            this._bs_flags = i4 + ((file[offset7] & 255) << 24);
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("bs_flags = 0x").append(Integer.toHexString(this._bs_flags)).toString());
            }
            if (GLLibConfig.sprite_useNonInterlaced) {
                offset2 = LoadAnims_NI(LoadAFrames_NI(LoadFrames_NI(LoadFModules_NI(LoadModules_NI(offset8, file), file), file), file), file);
            } else {
                offset2 = LoadAnims(LoadAFrames(LoadFrames(LoadFModules(LoadModules(offset8, file), file), file), file), file);
            }
            if (this._nModules <= 0) {
                if (GLLibConfig.sprite_debugErrors) {
                    System.out.println(new StringBuffer().append("WARNING: sprite with num modules = ").append(this._nModules).toString());
                }
                if (!GLLibConfig.sprite_useDeactivateSystemGc && s_gcEnabled) {
                    System.gc();
                    return;
                }
                return;
            }
            if (GLLibConfig.sprite_ModuleMapping_useModuleImages && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_MODULE_IMAGES) != 0)) {
                offset2 = LoadData_useModuleImages(offset2, file, pal_flags, tr_flags);
            }
            if (GLLibConfig.sprite_useSingleImageForAllModules && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_SINGLE_IMAGE) != 0)) {
                LoadData_useSingleImages(offset2, file, pal_flags, tr_flags);
            }
            if (GLLibConfig.sprite_useExternImage) {
                this._main_image = new Image[GLLibConfig.MAX_SPRITE_PALETTES];
                this._main_image[0] = sprImage;
            }
            if (GLLibConfig.sprite_useModuleMapping) {
                this._map = new short[GLLibConfig.MAX_MODULE_MAPPINGS];
                this._cur_map = -1;
            }
            if (GLLibConfig.sprite_useDynamicPng && !GLLibConfig.sprite_usePrecomputedCRC) {
                if (GLLibConfig.sprite_useNokiaUI) {
                    this._pal_short = (short[][]) null;
                } else {
                    this._pal_int = (int[][]) null;
                }
            }
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("--- ok");
            }
            if (!GLLibConfig.sprite_useDeactivateSystemGc && s_gcEnabled) {
                System.gc();
            }
        } catch (Throwable e) {
            if (GLLibConfig.sprite_debugErrors) {
                GLLib.Dbg(new StringBuffer().append("ASprite.Load().").append(e).toString());
            }
        }
    }

    void FreeCacheData() {
        if (GLLibConfig.sprite_useDynamicPng) {
            return;
        }
        if (GLLibConfig.sprite_useSingleImageForAllModules) {
            if (GLLibConfig.sprite_debugUsedMemory) {
                _images_count--;
                _images_size -= this._modules_data.length;
            }
            if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_SINGLE_IMAGE) != 0) {
                this._pal_data = null;
            }
        }
        this._modules_data = null;
        this._pal_short = (short[][]) null;
        this._pal_int = (int[][]) null;
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            this._modules_data_off_short = null;
        } else {
            this._modules_data_off_int = null;
        }
        if (!GLLibConfig.sprite_useDeactivateSystemGc && s_gcEnabled) {
            System.gc();
        }
    }

    private byte[] GetModulesUsage(int tr_flags) {
        short nFrames;
        short nAnims;
        int af_flags;
        int fr;
        if (GLLibConfig.sprite_useDynamicPng && !GLLibConfig.sprite_useModuleUsageFromSprite) {
            int nModules = this._nModules;
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                if (this._fmodules != null) {
                }
            } else if (this._fmodules_id != null) {
            }
            if (this._frames_nfm != null) {
                nFrames = (short) this._frames_nfm.length;
            } else {
                nFrames = 0;
            }
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                if (this._aframes != null) {
                }
            } else if (this._aframes_frame != null) {
            }
            if (this._anims_naf != null) {
                nAnims = (short) this._anims_naf.length;
            } else {
                nAnims = 0;
            }
            byte[] mods_usg = new byte[nModules];
            for (int fr2 = 0; fr2 < nFrames; fr2++) {
                GetModulesUsageInFrame(fr2, 0, tr_flags, mods_usg);
            }
            for (int anim = 0; anim < nAnims; anim++) {
                short s = this._anims_af_start[anim];
                for (int afr_idx = 0; afr_idx < this._anims_naf[anim]; afr_idx++) {
                    int afr = afr_idx + s;
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        af_flags = this._aframes[(afr * 5) + 4] & 255;
                        fr = this._aframes[afr * 5] & 255;
                    } else {
                        af_flags = this._aframes_flags[afr] & 255;
                        fr = this._aframes_frame[afr] & 255;
                    }
                    if (GLLibConfig.sprite_useIndexExAframes) {
                        fr |= (af_flags & FLAG_INDEX_EX_MASK) << 2;
                    }
                    GetModulesUsageInFrame(fr, af_flags, tr_flags, mods_usg);
                }
            }
            for (int mod2 = 0; mod2 < nModules; mod2++) {
                int i = mod2;
                mods_usg[i] = (byte) (mods_usg[i] | ((byte) tr_flags));
            }
            return mods_usg;
        }
        return null;
    }

    private void GetModulesUsageInFrame(int fr, int af_flags, int tr_flags, byte[] mods_usg) {
        int fm_flags;
        int mod2;
        if (GLLibConfig.sprite_useDynamicPng && !GLLibConfig.sprite_useModuleUsageFromSprite) {
            int fmod_off = this._frames_fm_start[fr] & 65535;
            for (int fmod_idx = 0; fmod_idx < this._frames_nfm[fr]; fmod_idx++) {
                int fmod = fmod_off + fmod_idx;
                if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                    fm_flags = this._fmodules[(fmod * 4) + 3] & 255;
                    mod2 = this._fmodules[fmod * 4] & 255;
                } else {
                    fm_flags = this._fmodules_flags[fmod] & 255;
                    mod2 = this._fmodules_id[fmod] & 255;
                }
                if (GLLibConfig.sprite_useIndexExFmodules) {
                    mod2 |= (fm_flags & FLAG_INDEX_EX_MASK) << 2;
                }
                for (int k = 0; k < GLLibConfig.MAX_FLIP_COUNT; k++) {
                    if ((tr_flags & (1 << k)) != 0) {
                        int tmp_flags = af_flags ^ k;
                        if (mod2 < mods_usg.length) {
                            int i = mod2;
                            mods_usg[i] = (byte) (mods_usg[i] | (1 << ((fm_flags ^ tmp_flags) & 7)));
                        }
                    }
                }
            }
        }
    }

    void SetModuleMapping(int map, byte[] mmp) {
        if (GLLibConfig.sprite_useModuleMapping) {
            if (this._map[map] == null) {
                this._map[map] = new short[this._nModules];
                for (int i = 0; i < this._nModules; i++) {
                    this._map[map][i] = (short) i;
                }
            }
            if (mmp == null) {
                return;
            }
            int off = 0;
            while (off < mmp.length) {
                int i2 = off;
                int off2 = off + 1;
                int off3 = off2 + 1;
                int i1 = (mmp[i2] & 255) + ((mmp[off2] & 255) << 8);
                int off4 = off3 + 1;
                int i3 = mmp[off3] & 255;
                off = off4 + 1;
                int i22 = i3 + ((mmp[off4] & 255) << 8);
                this._map[map][i1] = (short) i22;
            }
        }
    }

    void SetCurrentMMapping(int map) {
        if (GLLibConfig.sprite_useModuleMapping) {
            this._cur_map = map;
        }
    }

    int GetCurrentMMapping() {
        if (GLLibConfig.sprite_useModuleMapping) {
            return this._cur_map;
        }
        return -1;
    }

    int GetAFrameTime(int anim, int aframe) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            return this._aframes[((this._anims_af_start[anim] + aframe) * 5) + 1] & 255;
        }
        return this._aframes_time[this._anims_af_start[anim] + aframe] & 255;
    }

    int GetAFrameFlags(int anim, int aframe) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            return this._aframes[((this._anims_af_start[anim] + aframe) * 5) + 4] & 15;
        }
        return this._aframes_flags[this._anims_af_start[anim] + aframe] & 15;
    }

    int GetAFrames(int anim) {
        return this._anims_naf[anim] & 255;
    }

    int GetFModules(int frame) {
        return this._frames_nfm[frame] & 255;
    }

    int GetModuleType(int module) {
        if (GLLibConfig.sprite_useMultipleModuleTypes) {
            return this._module_types[module];
        }
        return 0;
    }

    int GetModuleX(int module) {
        if (GLLibConfig.sprite_useModuleXYShort && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 32) != 0)) {
            return this._modules_x_short[module] & 65535;
        }
        if (!GLLibConfig.sprite_useModuleXY) {
            return 0;
        }
        if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 2) != 0) {
            return this._modules_x_byte[module] & 255;
        }
        return 0;
    }

    int GetModuleY(int module) {
        if (GLLibConfig.sprite_useModuleXYShort && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 32) != 0)) {
            return this._modules_y_short[module] & 65535;
        }
        if (!GLLibConfig.sprite_useModuleXY) {
            return 0;
        }
        if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 2) != 0) {
            return this._modules_y_byte[module] & 255;
        }
        return 0;
    }

    int GetModuleWidth(int module) {
        if (GLLibConfig.sprite_useResize && s_resizeType != 0) {
            return this._modules_w_scaled[module] & 65535;
        }
        if (GLLibConfig.sprite_useModuleWHShort) {
            return this._modules_w_short[module] & 65535;
        }
        return this._modules_w_byte[module] & 255;
    }

    int GetModuleHeight(int module) {
        if (GLLibConfig.sprite_useResize && s_resizeType != 0) {
            return this._modules_h_scaled[module] & 65535;
        }
        if (GLLibConfig.sprite_useModuleWHShort) {
            return this._modules_h_short[module] & 65535;
        }
        return this._modules_h_byte[module] & 255;
    }

    int GetModuleWidthOrg(int module) {
        if (GLLibConfig.sprite_useModuleWHShort) {
            return this._modules_w_short[module] & 65535;
        }
        return this._modules_w_byte[module] & 255;
    }

    int GetModuleHeightOrg(int module) {
        if (GLLibConfig.sprite_useModuleWHShort) {
            return this._modules_h_short[module] & 65535;
        }
        return this._modules_h_byte[module] & 255;
    }

    int GetAFramesOX(int v) {
        if (GLLibConfig.sprite_useAfOffShort) {
            return this._aframes_ox_short[v];
        }
        return this._aframes_ox_byte[v];
    }

    int GetAFramesOX(int anim, int aframe) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            int off = (this._anims_af_start[anim] + aframe) * 5;
            return this._aframes[off + 2];
        }
        int off2 = this._anims_af_start[anim] + aframe;
        return GetAFramesOX(off2);
    }

    int GetAFramesOY(int v) {
        if (GLLibConfig.sprite_useAfOffShort) {
            return this._aframes_oy_short[v];
        }
        return this._aframes_oy_byte[v];
    }

    int GetAFramesOY(int anim, int aframe) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            int off = (this._anims_af_start[anim] + aframe) * 5;
            return this._aframes[off + 3];
        }
        int off2 = this._anims_af_start[anim] + aframe;
        return GetAFramesOY(off2);
    }

    int GetFModuleOX(int v) {
        if (GLLibConfig.sprite_useFMOffShort) {
            return this._fmodules_ox_short[v];
        }
        return this._fmodules_ox_byte[v];
    }

    int GetFModuleOY(int v) {
        if (GLLibConfig.sprite_useFMOffShort) {
            return this._fmodules_oy_short[v];
        }
        return this._fmodules_oy_byte[v];
    }

    int GetFrameWidth(int frame) {
        if (GLLibConfig.sprite_usePrecomputedFrameRect) {
            if ((this._bs_flags & 1024) == 0) {
                return this._frames_rc[(frame << 2) + 2] & 255;
            }
            return this._frames_rc_short[(frame << 2) + 2] & 65535;
        }
        GetFrameRect(s_rc, frame, 0, 0, 0);
        return s_rc[2] - s_rc[0];
    }

    int GetFrameHeight(int frame) {
        if (GLLibConfig.sprite_usePrecomputedFrameRect) {
            if ((this._bs_flags & 1024) == 0) {
                return this._frames_rc[(frame << 2) + 3] & 255;
            }
            return this._frames_rc_short[(frame << 2) + 3] & 65535;
        }
        GetFrameRect(s_rc, frame, 0, 0, 0);
        return s_rc[3] - s_rc[1];
    }

    int GetFrameMinX(int frame) {
        if (GLLibConfig.sprite_usePrecomputedFrameRect) {
            if ((this._bs_flags & 1024) == 0) {
                return this._frames_rc[(frame << 2) + 0];
            }
            return this._frames_rc_short[(frame << 2) + 0];
        }
        GetFrameRect(s_rc, frame, 0, 0, 0);
        return s_rc[0];
    }

    int GetFrameMinY(int frame) {
        if (GLLibConfig.sprite_usePrecomputedFrameRect) {
            if ((this._bs_flags & 1024) == 0) {
                return this._frames_rc[(frame << 2) + 1];
            }
            return this._frames_rc_short[(frame << 2) + 1];
        }
        GetFrameRect(s_rc, frame, 0, 0, 0);
        return s_rc[1];
    }

    int GetFrameModule(int frame, int fmodule) {
        int fm_flags;
        int index;
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            int off = (this._frames_fm_start[frame] + fmodule) << 2;
            fm_flags = this._fmodules[off + 3] & 255;
            index = this._fmodules[off] & 255;
        } else {
            int off2 = this._frames_fm_start[frame] + fmodule;
            fm_flags = this._fmodules_flags[off2] & 255;
            index = this._fmodules_id[off2] & 255;
        }
        if (GLLibConfig.sprite_useIndexExFmodules) {
            index |= (fm_flags & FLAG_INDEX_EX_MASK) << 2;
        }
        return index;
    }

    int GetFrameModuleFlags(int frame, int fmodule) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            int off = (this._frames_fm_start[frame] + fmodule) << 2;
            return this._fmodules[off + 3] & 255;
        }
        return this._fmodules_flags[this._frames_fm_start[frame] + fmodule] & 255;
    }

    int GetFrameModulePalette(int frame, int fmodule) {
        int pal;
        int offset;
        if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_FM_PALETTE) != 0)) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                offset = (this._frames_fm_start[frame] + fmodule) << 2;
            } else {
                offset = this._frames_fm_start[frame] + fmodule;
            }
            pal = this._fmodules_pal[offset];
        } else {
            pal = GetCurrentPalette();
        }
        return pal;
    }

    int GetFrameModuleX(int frame, int fmodule) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            int off = (this._frames_fm_start[frame] + fmodule) << 2;
            return this._fmodules[off + 1];
        }
        return GetFModuleOX(this._frames_fm_start[frame] + fmodule);
    }

    int GetFrameModuleY(int frame, int fmodule) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            int off = (this._frames_fm_start[frame] + fmodule) << 2;
            return this._fmodules[off + 2];
        }
        return GetFModuleOY(this._frames_fm_start[frame] + fmodule);
    }

    int GetFrameModuleWidth(int frame, int fmodule) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            int off = (this._frames_fm_start[frame] + fmodule) << 2;
            int index = this._fmodules[off] & 255;
            return GetModuleWidth(index);
        }
        int index2 = this._fmodules_id[this._frames_fm_start[frame] + fmodule] & 255;
        return GetModuleWidth(index2);
    }

    int GetFrameModuleHeight(int frame, int fmodule) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            int off = (this._frames_fm_start[frame] + fmodule) << 2;
            int index = this._fmodules[off] & 255;
            return GetModuleHeight(index);
        }
        int index2 = this._fmodules_id[this._frames_fm_start[frame] + fmodule] & 255;
        return GetModuleHeight(index2);
    }

    int GetFrames() {
        return this._frames_nfm.length;
    }

    int GetAnimFrame(int anim, int aframe) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            int off = (this._anims_af_start[anim] + aframe) * 5;
            int frame = this._aframes[off] & 255;
            if (GLLibConfig.sprite_useIndexExAframes) {
                frame |= (this._aframes[off + 4] & FLAG_INDEX_EX_MASK) << 2;
            }
            return frame;
        }
        int off2 = this._anims_af_start[anim] + aframe;
        int frame2 = this._aframes_frame[off2] & 255;
        if (GLLibConfig.sprite_useIndexExAframes) {
            frame2 |= (this._aframes_flags[off2] & FLAG_INDEX_EX_MASK) << 2;
        }
        return frame2;
    }

    void GetAFrameRect(int[] rc, int anim, int aframe, int posX, int posY, int flags) {
        _rectX1 = Integer.MAX_VALUE;
        _rectY1 = Integer.MAX_VALUE;
        _rectX2 = BS_GIF_HEADER;
        _rectY2 = BS_GIF_HEADER;
        _operation = 1;
        PaintAFrame(null, anim, aframe, posX, posY, flags);
        _operation = 0;
        rc[0] = _rectX1;
        rc[1] = _rectY1;
        rc[2] = _rectX2;
        rc[3] = _rectY2;
    }

    void GetFrameRect(int[] rc, int frame, int posX, int posY, int flags, int hx, int hy) {
        GetFrameRect(rc, frame, posX, posY, flags);
    }

    void GetFrameRect(int[] rc, int frame, int posX, int posY, int flags) {
        _rectX1 = Integer.MAX_VALUE;
        _rectY1 = Integer.MAX_VALUE;
        _rectX2 = BS_GIF_HEADER;
        _rectY2 = BS_GIF_HEADER;
        _operation = 1;
        PaintFrame(null, frame, posX, posY, flags);
        _operation = 0;
        rc[0] = _rectX1;
        rc[1] = _rectY1;
        rc[2] = _rectX2;
        rc[3] = _rectY2;
    }

    void GetFModuleRect(int[] rc, int frame, int fmodule, int posX, int posY, int flags, int hx, int hy) {
        _rectX1 = Integer.MAX_VALUE;
        _rectY1 = Integer.MAX_VALUE;
        _rectX2 = BS_GIF_HEADER;
        _rectY2 = BS_GIF_HEADER;
        _operation = 1;
        PaintFModule(null, frame, fmodule, posX, posY, flags);
        _operation = 0;
        rc[0] = _rectX1;
        rc[1] = _rectY1;
        rc[2] = _rectX2;
        rc[3] = _rectY2;
    }

    void GetModuleRect(int[] rc, int module, int posX, int posY, int flags) {
        _rectX1 = Integer.MAX_VALUE;
        _rectY1 = Integer.MAX_VALUE;
        _rectX2 = BS_GIF_HEADER;
        _rectY2 = BS_GIF_HEADER;
        _operation = 1;
        PaintModule(null, module, posX, posY, flags);
        _operation = 0;
        rc[0] = _rectX1;
        rc[1] = _rectY1;
        rc[2] = _rectX2;
        rc[3] = _rectY2;
    }

    Image GetModuleImage(int nModule, int nPalette) {
        if (this._module_image_imageAA != null && nPalette >= 0 && nPalette < this._module_image_imageAA.length && this._module_image_imageAA[nPalette] != null && nModule >= 0 && nModule < this._module_image_imageAA[nPalette].length) {
            return this._module_image_imageAA[nPalette][nModule];
        }
        if (this._module_image_imageAAA != null && nPalette >= 0 && nPalette < this._module_image_imageAAA.length && this._module_image_imageAAA[nPalette] != null && nModule >= 0 && nModule < this._module_image_imageAAA[nPalette].length) {
            return this._module_image_imageAAA[nPalette][nModule][0];
        }
        return null;
    }

    Object GetModuleData(int nModule, int nPalette) {
        if (this._modules_image_shortAAA != null && this._modules_image_shortAAA[nPalette] != null) {
            return this._modules_image_shortAAA[nPalette][nModule];
        }
        return null;
    }

    Object GetPalette(int nPalette) {
        if (nPalette >= 0 && nPalette < this._palettes) {
            if (GLLibConfig.sprite_useNokiaUI) {
                if (this._pal_short != null && nPalette < this._pal_short.length) {
                    return this._pal_short[nPalette];
                }
                return null;
            }
            if (this._pal_int != null && nPalette < this._pal_int.length) {
                return this._pal_int[nPalette];
            }
            return null;
        }
        return null;
    }

    int GetModuleCount() {
        return this._nModules;
    }

    int CountFrameModules(int frame) {
        int fm_flags;
        int index;
        int count = GetFModules(frame);
        int realcount = count;
        for (int fmodule = 0; fmodule < count; fmodule++) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                int off = (this._frames_fm_start[frame] + fmodule) << 2;
                fm_flags = this._fmodules[off + 3] & 255;
                index = this._fmodules[off] & 255;
            } else {
                int off2 = this._frames_fm_start[frame] + fmodule;
                fm_flags = this._fmodules_flags[off2] & 255;
                index = this._fmodules_id[off2] & 255;
            }
            if ((fm_flags & 16) != 0) {
                realcount = (realcount - 1) + CountFrameModules(index);
            }
        }
        return realcount;
    }

    private int getStartModuleData(int module, int transf) {
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            return this._modules_data_off_short[module] & 65535;
        }
        return this._modules_data_off_int[module];
    }

    private int getLenModuleData(int m, int transf) {
        return GLLibConfig.sprite_useModuleDataOffAsShort ? m + 1 == this._modules_data_off_short.length ? (this._modules_data.length - this._modules_data_off_short[m]) & 65535 : ((this._modules_data_off_short[m] & 65535) - this._modules_data_off_short[m]) & 65535 : m + 1 == this._modules_data_off_int.length ? this._modules_data.length - this._modules_data_off_int[m] : this._modules_data_off_int[m] - this._modules_data_off_int[m];
    }

    int GetFrameCount() {
        if (this._frames_nfm == null) {
            return 0;
        }
        return this._frames_nfm.length;
    }

    int[] GetFrameMarkers(int frame) {
        int fm_flags;
        int index;
        int fm_flags2;
        int index2;
        if (GLLibConfig.sprite_useMultipleModuleTypes) {
            int count = GetFModules(frame);
            int countMarker = 0;
            for (int fmodule = 0; fmodule < count; fmodule++) {
                if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                    int off = (this._frames_fm_start[frame] + fmodule) << 2;
                    fm_flags2 = this._fmodules[off + 3] & 255;
                    index2 = this._fmodules[off] & 255;
                } else {
                    int off2 = this._frames_fm_start[frame] + fmodule;
                    fm_flags2 = this._fmodules_flags[off2] & 255;
                    index2 = this._fmodules_id[off2] & 255;
                }
                if ((fm_flags2 & 16) == 0 && this._module_types[index2] == 5) {
                    countMarker++;
                }
            }
            if (countMarker > 0) {
                int[] res = new int[countMarker << 1];
                int pos = 0;
                for (int fmodule2 = 0; fmodule2 < count; fmodule2++) {
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        int off3 = (this._frames_fm_start[frame] + fmodule2) << 2;
                        fm_flags = this._fmodules[off3 + 3] & 255;
                        index = this._fmodules[off3] & 255;
                    } else {
                        int off4 = this._frames_fm_start[frame] + fmodule2;
                        fm_flags = this._fmodules_flags[off4] & 255;
                        index = this._fmodules_id[off4] & 255;
                    }
                    if ((fm_flags & 16) == 0 && this._module_types[index] == 5) {
                        res[pos] = GetFrameModuleX(frame, fmodule2);
                        res[pos + 1] = GetFrameModuleY(frame, fmodule2);
                        pos += 2;
                    }
                }
                return res;
            }
            return null;
        }
        return null;
    }

    int GetFrameRectCount(int frame) {
        if (GLLibConfig.sprite_useFrameRects && this._frames_rects_start != null) {
            return this._frames_rects_start[frame + 1] - this._frames_rects_start[frame];
        }
        return 0;
    }

    void GetFrameRect(int frame, int rectIndex, int[] rect, int flags) {
        if (GLLibConfig.sprite_useFrameRects && this._frames_rects_start != null && rect != null) {
            short s = this._frames_rects_start[frame];
            int nCount = this._frames_rects_start[frame + 1] - s;
            if (nCount > 0 && rectIndex < nCount) {
                int nStart = (s + rectIndex) << 2;
                if (GLLibConfig.sprite_useFMOffShort && (this._bs_flags & 1024) != 0) {
                    if (this._frames_rects_short != null) {
                        rect[0] = this._frames_rects_short[nStart + 0];
                        rect[1] = this._frames_rects_short[nStart + 1];
                        rect[2] = this._frames_rects_short[nStart + 2] & 65535;
                        rect[3] = this._frames_rects_short[nStart + 3] & 65535;
                    }
                } else if (this._frames_rects != null) {
                    rect[0] = this._frames_rects[nStart + 0];
                    rect[1] = this._frames_rects[nStart + 1];
                    rect[2] = this._frames_rects[nStart + 2] & 255;
                    rect[3] = this._frames_rects[nStart + 3] & 255;
                }
                if ((flags & 1) != 0) {
                    rect[0] = (-rect[0]) - rect[2];
                }
                if ((flags & 2) != 0) {
                    rect[1] = (-rect[1]) - rect[3];
                    return;
                }
                return;
            }
            rect[0] = 0;
            rect[1] = 0;
            rect[2] = 0;
            rect[3] = 0;
        }
    }

    void GetAFrameRect(int anim, int aframe, int rectIndex, int[] rect, int flags) {
        if (GLLibConfig.sprite_useFrameRects) {
            GetAFrameRect(anim, aframe, rectIndex, rect, flags, false);
        }
    }

    void GetAFrameRect(int anim, int aframe, int rectIndex, int[] rect, int flags, boolean useAFrameOffsets) {
        if (GLLibConfig.sprite_useFrameRects) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                int off = (this._anims_af_start[anim] + aframe) * 5;
                int frame = this._aframes[off] & 255;
                if (GLLibConfig.sprite_useIndexExAframes) {
                    frame |= (this._aframes[off + 4] & FLAG_INDEX_EX_MASK) << 2;
                }
                GetFrameRect(frame, rectIndex, rect, flags ^ (this._aframes[off + 4] & 15));
                if (useAFrameOffsets) {
                    rect[0] = rect[0] + this._aframes[off + 2];
                    rect[1] = rect[1] + this._aframes[off + 3];
                    return;
                }
                return;
            }
            int off2 = this._anims_af_start[anim] + aframe;
            int frame2 = this._aframes_frame[off2] & 255;
            if (GLLibConfig.sprite_useIndexExAframes) {
                frame2 |= (this._aframes_flags[off2] & FLAG_INDEX_EX_MASK) << 2;
            }
            GetFrameRect(frame2, rectIndex, rect, flags ^ (this._aframes_flags[off2] & 15));
            if (useAFrameOffsets) {
                rect[0] = rect[0] + GetAFramesOX(off2);
                rect[1] = rect[1] + GetAFramesOY(off2);
            }
        }
    }

    public static int[] GetPixelBuffer_int(int[] buffer) {
        if (buffer != temp_int) {
            if (temp_int == null) {
                temp_int = new int[GLLibConfig.TMP_BUFFER_SIZE];
            }
            return temp_int;
        }
        if (buffer != transform_int) {
            if (transform_int == null) {
                transform_int = new int[GLLibConfig.TMP_BUFFER_SIZE];
            }
            return transform_int;
        }
        return null;
    }

    public static short[] GetPixelBuffer_short(short[] buffer) {
        if (buffer != temp_short) {
            if (temp_short == null) {
                temp_short = new short[GLLibConfig.TMP_BUFFER_SIZE];
            }
            return temp_short;
        }
        if (buffer != transform_short) {
            if (transform_short == null) {
                transform_short = new short[GLLibConfig.TMP_BUFFER_SIZE];
            }
            return transform_short;
        }
        return null;
    }

    void SetUseCacheRGB(boolean p_useCacheRGB) {
        if (GLLibConfig.sprite_useManualCacheRGBArrays) {
            if (p_useCacheRGB) {
                this._flags |= 1;
            } else {
                this._flags &= -2;
            }
        }
    }

    static void EnableGC(boolean enableGC) {
        s_gcEnabled = enableGC;
    }

    static void SetGraphics(Graphics g1) {
    }

    final void PaintAFrame(Graphics g, int anim, int aframe, int posX, int posY, int flags) {
        PaintAFrame(g, anim, aframe, posX, posY, flags, 0, 0);
    }

    void PaintAFrame(Graphics g, int anim, int aframe, int posX, int posY, int flags, int hx, int hy) {
        int hx2;
        int hy2;
        int hx3;
        int hy3;
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            int off = (this._anims_af_start[anim] + aframe) * 5;
            int frame = this._aframes[off] & 255;
            if (GLLibConfig.sprite_useIndexExAframes) {
                frame |= (this._aframes[off + 4] & FLAG_INDEX_EX_MASK) << 2;
            }
            if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                hx3 = (flags & 1) != 0 ? hx + this._aframes[off + 2] : hx - this._aframes[off + 2];
                hy3 = (flags & 2) != 0 ? hy + this._aframes[off + 3] : hy - this._aframes[off + 3];
            } else {
                hx3 = hx - this._aframes[off + 2];
                hy3 = hy - this._aframes[off + 3];
            }
            PaintFrame(g, frame, posX - hx3, posY - hy3, flags ^ (this._aframes[off + 4] & 15), hx3, hy3);
            return;
        }
        int off2 = this._anims_af_start[anim] + aframe;
        int frame2 = this._aframes_frame[off2] & 255;
        if (GLLibConfig.sprite_useIndexExAframes) {
            frame2 |= (this._aframes_flags[off2] & FLAG_INDEX_EX_MASK) << 2;
        }
        if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
            hx2 = (flags & 1) != 0 ? hx + GetAFramesOX(off2) : hx - GetAFramesOX(off2);
            hy2 = (flags & 2) != 0 ? hy + GetAFramesOY(off2) : hy - GetAFramesOY(off2);
        } else {
            hx2 = hx - GetAFramesOX(off2);
            hy2 = hy - GetAFramesOY(off2);
        }
        PaintFrame(g, frame2, posX - hx2, posY - hy2, flags ^ (this._aframes_flags[off2] & 15), hx2, hy2);
    }

    final void PaintFrame(Graphics g, int frame, int posX, int posY, int flags) {
        PaintFrame(g, frame, posX, posY, flags, 0, 0);
    }

    void PaintFrame(Graphics g, int frame, int posX, int posY, int flags, int hx, int hy) {
        int nFModules = this._frames_nfm[frame] & 255;
        for (int fmodule = 0; fmodule < nFModules; fmodule++) {
            PaintFModule(g, frame, fmodule, posX, posY, flags, hx, hy);
        }
    }

    void PaintFModule(Graphics g, int frame, int fmodule, int posX, int posY, int flags) {
        PaintFModule(g, frame, fmodule, posX, posY, flags, 0, 0);
    }

    void PaintFModule(Graphics g, int frame, int fmodule, int posX, int posY, int flags, int hx, int hy) {
        int off;
        int fm_flags;
        int index;
        int offsetY;
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            off = (this._frames_fm_start[frame] + fmodule) << 2;
            fm_flags = this._fmodules[off + 3] & 255;
            index = this._fmodules[off] & 255;
        } else {
            off = this._frames_fm_start[frame] + fmodule;
            fm_flags = this._fmodules_flags[off] & 255;
            index = this._fmodules_id[off] & 255;
        }
        if (GLLibConfig.sprite_useIndexExFmodules) {
            index |= (fm_flags & FLAG_INDEX_EX_MASK) << 2;
        }
        if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_FM_PALETTE) != 0)) {
            this._crt_pal = this._fmodules_pal[off] & 255;
        }
        int originalIndex = index;
        if (GLLibConfig.sprite_useModuleMapping && ((!GLLibConfig.sprite_useHyperFM || (fm_flags & 16) == 0) && this._cur_map >= 0)) {
            index = this._map[this._cur_map][index];
        }
        int offsetX = 0;
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfRot && (flags & 4) != 0) {
                if (GLLibConfig.sprite_useHyperFM && (fm_flags & 16) != 0) {
                    if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                        offsetY = (flags & 1) != 0 ? -this._fmodules[off + 1] : this._fmodules[off + 1];
                        offsetX = (flags & 2) != 0 ? -this._fmodules[off + 2] : this._fmodules[off + 2];
                    } else {
                        offsetY = this._fmodules[off + 1];
                        offsetX = this._fmodules[off + 2];
                    }
                } else if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                    offsetY = (flags & 1) != 0 ? -(this._fmodules[off + 1] + GetModuleWidth(index)) : this._fmodules[off + 1];
                    offsetX = (flags & 2) != 0 ? -(this._fmodules[off + 2] + GetModuleHeight(index)) : this._fmodules[off + 2];
                } else {
                    byte b = this._fmodules[off + 1];
                    offsetY = this._fmodules[off + 2];
                }
            } else if (GLLibConfig.sprite_useHyperFM && (fm_flags & 16) != 0) {
                if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                    offsetX = (flags & 1) != 0 ? -this._fmodules[off + 1] : this._fmodules[off + 1];
                    offsetY = (flags & 2) != 0 ? -this._fmodules[off + 2] : this._fmodules[off + 2];
                } else {
                    offsetX = this._fmodules[off + 1];
                    offsetY = this._fmodules[off + 2];
                }
            } else if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                offsetX = (flags & 1) != 0 ? -(this._fmodules[off + 1] + GetModuleWidth(index)) : this._fmodules[off + 1];
                offsetY = (flags & 2) != 0 ? -(this._fmodules[off + 2] + GetModuleHeight(index)) : this._fmodules[off + 2];
            } else {
                offsetX = this._fmodules[off + 1];
                offsetY = this._fmodules[off + 2];
            }
        } else if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfRot && (flags & 4) != 0) {
            if (GLLibConfig.sprite_useHyperFM && (fm_flags & 16) != 0) {
                if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                    offsetY = (flags & 1) != 0 ? -GetFModuleOX(off) : GetFModuleOX(off);
                    offsetX = (flags & 2) != 0 ? -GetFModuleOY(off) : GetFModuleOY(off);
                } else {
                    offsetY = GetFModuleOX(off);
                    offsetX = GetFModuleOY(off);
                }
            } else if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                offsetY = (flags & 1) != 0 ? -(GetFModuleOX(off) + GetModuleWidth(index)) : GetFModuleOX(off);
                offsetX = (flags & 2) != 0 ? -(GetFModuleOY(off) + GetModuleHeight(index)) : GetFModuleOY(off);
            } else {
                offsetY = GetFModuleOX(off);
                offsetX = GetFModuleOY(off);
            }
        } else if (GLLibConfig.sprite_useHyperFM && (fm_flags & 16) != 0) {
            if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                if ((flags & 1) != 0) {
                    offsetX = -GetFModuleOX(off);
                } else {
                    offsetX = GetFModuleOX(off);
                }
                offsetY = (flags & 2) != 0 ? -GetFModuleOY(off) : GetFModuleOY(off);
            } else {
                offsetX = GetFModuleOX(off);
                offsetY = GetFModuleOY(off);
            }
        } else if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
            if ((flags & 1) != 0) {
                offsetX = -(GetFModuleOX(off) + GetModuleWidth(index));
            } else {
                offsetX = GetFModuleOX(off);
            }
            offsetY = (flags & 2) != 0 ? -(GetFModuleOY(off) + GetModuleHeight(index)) : GetFModuleOY(off);
        } else {
            offsetX = GetFModuleOX(off);
            offsetY = GetFModuleOY(off);
        }
        if (GLLibConfig.pfx_useSpriteEffectScale && (GLLib.m_PFX_type & ENCODE_FORMAT_I2) != 0) {
            int percent = GLLib.m_PFX_params[9][1];
            offsetX = (percent * offsetX) / 100;
            offsetY = (percent * offsetY) / 100;
        }
        int posX2 = posX + offsetX;
        int posY2 = posY + offsetY;
        if (GLLibConfig.sprite_useHyperFM && (fm_flags & 16) != 0) {
            PaintFrame(g, index, posX2, posY2, flags ^ (fm_flags & 15), hx, hy);
        } else {
            PaintModule(g, originalIndex, posX2, posY2, flags ^ (fm_flags & 15));
        }
    }

    void RenderTilesetEffect(Graphics g, int moduleID, Image img, int effectType, int posX, int posY, int w, int h, int flag) {
        if (GLLibConfig.tileset_usePixelEffects) {
            if (img == null) {
            }
            int[] buffer = GetPixelBuffer_int(null);
            img.getRGB(buffer, 0, w, posX, posY, w, h);
            RenderTilesetEffect(g, moduleID, buffer, effectType, posX, posY, w, h, flag);
        }
    }

    void RenderTilesetEffect(Graphics g, int moduleID, int[] buffer, int effectType, int posX, int posY, int w, int h, int flag) {
        if (GLLibConfig.tileset_usePixelEffects) {
            if (this._module_image_intAAA == null || this._module_image_intAAA[0] == null) {
            }
            int[] modulePixels = this._module_image_intAAA[0][moduleID];
            if (modulePixels == null) {
            }
            int[] output = GLLib.PFX_ProcessPixelEffect(modulePixels, buffer, posX, posY, w, h, flag, effectType == 2, effectType == 3, false);
            GLLib.DrawRGB(g, output, 0, w, posX, posY, w, h, false);
        }
    }

    void PaintFrameScaled(Graphics g, int frame, int posX, int posY, int flags, int scale) {
        if (GLLibConfig.pfx_useSpriteEffects && GLLibConfig.pfx_useSpriteEffectScale) {
            GLLib.PFX_EnableEffect(9);
            GLLib.PFX_SetParam(9, 1, scale);
            PaintFrame(g, frame, posX, posY, flags, 0, 0);
            GLLib.PFX_DisableEffect(9);
        }
    }

    void PaintFrameBlended(Graphics g, int frame, int posX, int posY, int flags, int alpha) {
        if (GLLibConfig.pfx_useSpriteEffects && GLLibConfig.pfx_useSpriteEffectBlend) {
            GLLib.PFX_EnableEffect(8);
            GLLib.PFX_SetParam(8, 1, alpha);
            PaintFrame(g, frame, posX, posY, flags, 0, 0);
            GLLib.PFX_DisableEffect(8);
        }
    }

    private int LoadModules_NI(int offset, byte[] file) {
        int offset2 = offset + 1;
        int i = file[offset] & 255;
        int offset3 = offset2 + 1;
        this._nModules = (short) (i + ((file[offset2] & 255) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println(new StringBuffer().append("nModules = ").append(this._nModules).toString());
        }
        if (this._nModules > 0) {
            if (GLLibConfig.sprite_useModuleXYShort && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 32) != 0)) {
                this._modules_x_short = new short[this._nModules];
                this._modules_y_short = new short[this._nModules];
            } else if (GLLibConfig.sprite_useModuleXY && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 2) != 0)) {
                this._modules_x_byte = new byte[this._nModules];
                this._modules_y_byte = new byte[this._nModules];
            }
            if (GLLibConfig.sprite_useModuleWHShort) {
                this._modules_w_short = new short[this._nModules];
                this._modules_h_short = new short[this._nModules];
            } else {
                this._modules_w_byte = new byte[this._nModules];
                this._modules_h_byte = new byte[this._nModules];
            }
            if (GLLibConfig.sprite_useMultipleModuleTypes) {
                this._module_types = new byte[this._nModules];
                if (GLLibConfig.sprite_useModuleColorAsByte) {
                    this._module_colors_byte = new byte[this._nModules];
                } else {
                    this._module_colors_int = new int[this._nModules];
                }
            }
            if (GLLibConfig.sprite_useMultipleModuleTypes && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 4) != 0)) {
                System.arraycopy(file, offset3, this._module_types, 0, this._nModules);
                offset3 += this._nModules;
            }
            if (GLLibConfig.sprite_useModuleXYShort && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 32) != 0)) {
                offset3 = readArray2Short(file, readArray2Short(file, offset3, this._modules_x_short, 0, this._nModules, false, false), this._modules_y_short, 0, this._nModules, false, false);
            } else if (GLLibConfig.sprite_useModuleXY && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 2) != 0)) {
                System.arraycopy(file, offset3, this._modules_x_byte, 0, this._nModules);
                int offset4 = offset3 + this._nModules;
                System.arraycopy(file, offset4, this._modules_y_byte, 0, this._nModules);
                offset3 = offset4 + this._nModules;
            }
            if (GLLibConfig.sprite_useModuleWHShort) {
                if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 16) == 0) {
                    offset3 = readArray2Short(file, readArray2Short(file, offset3, this._modules_w_short, 0, this._nModules, true, true), this._modules_h_short, 0, this._nModules, true, true);
                } else {
                    offset3 = readArray2Short(file, readArray2Short(file, offset3, this._modules_w_short, 0, this._nModules, false, false), this._modules_h_short, 0, this._nModules, false, false);
                }
            } else {
                System.arraycopy(file, offset3, this._modules_w_byte, 0, this._nModules);
                int offset5 = offset3 + this._nModules;
                System.arraycopy(file, offset5, this._modules_h_byte, 0, this._nModules);
                offset3 = offset5 + this._nModules;
            }
        }
        if (GLLibConfig.sprite_useModuleUsageFromSprite) {
            this._modules_usage = new byte[this._nModules];
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("Module usage... offset = ").append(offset3).append(" _nModules = ").append(this._nModules).toString());
            }
            if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_MODULE_USAGE) != 0) {
                System.arraycopy(file, offset3, this._modules_usage, 0, this._nModules);
                offset3 += this._nModules;
            }
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("...Module usage");
            }
        }
        return offset3;
    }

    private int LoadFModules_NI(int offset, byte[] file) {
        int offset2;
        int offset3 = offset + 1;
        int i = file[offset] & 255;
        int offset4 = offset3 + 1;
        int nFModules = (short) (i + ((file[offset3] & 255) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println(new StringBuffer().append("nFModules = ").append(nFModules).toString());
        }
        if (nFModules > 0) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                this._fmodules = new byte[nFModules << 2];
                offset4 = readByteArrayNi(file, readByteArrayNi(file, readByteArrayNi(file, readByteArrayNi(file, offset4, this._fmodules, nFModules, 0, 4), this._fmodules, nFModules, 1, 4), this._fmodules, nFModules, 2, 4), this._fmodules, nFModules, 3, 4);
            } else {
                this._fmodules_id = new byte[nFModules];
                if (GLLibConfig.sprite_useFMOffShort) {
                    this._fmodules_ox_short = new short[nFModules];
                    this._fmodules_oy_short = new short[nFModules];
                } else {
                    this._fmodules_ox_byte = new byte[nFModules];
                    this._fmodules_oy_byte = new byte[nFModules];
                }
                this._fmodules_flags = new byte[nFModules];
                System.arraycopy(file, offset4, this._fmodules_id, 0, nFModules);
                int offset5 = offset4 + nFModules;
                if (GLLibConfig.sprite_useFMOffShort) {
                    if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 1024) == 0) {
                        offset2 = readArray2Short(file, readArray2Short(file, offset5, this._fmodules_ox_short, 0, nFModules, true, false), this._fmodules_oy_short, 0, nFModules, true, false);
                    } else {
                        offset2 = readArray2Short(file, readArray2Short(file, offset5, this._fmodules_ox_short, 0, nFModules, false, false), this._fmodules_oy_short, 0, nFModules, false, false);
                    }
                } else {
                    System.arraycopy(file, offset5, this._fmodules_ox_byte, 0, nFModules);
                    int offset6 = offset5 + nFModules;
                    System.arraycopy(file, offset6, this._fmodules_oy_byte, 0, nFModules);
                    offset2 = offset6 + nFModules;
                }
                if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_FM_PALETTE) != 0)) {
                    this._fmodules_pal = new byte[nFModules];
                    System.arraycopy(file, offset2, this._fmodules_pal, 0, nFModules);
                    offset2 += nFModules;
                }
                System.arraycopy(file, offset2, this._fmodules_flags, 0, nFModules);
                offset4 = offset2 + nFModules;
            }
        }
        return offset4;
    }

    private int LoadFrames_NI(int offset, byte[] file) {
        if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & BS_FRAME_RECTS) != 0) {
            int offset2 = offset + 1;
            int i = file[offset] & 255;
            int offset3 = offset2 + 1;
            int nRects = (short) (i + ((file[offset2] & 255) << 8));
            if ((this._bs_flags & 1024) == 0) {
                this._frames_rects = new byte[nRects << 2];
                System.arraycopy(file, offset3, this._frames_rects, 0, nRects << 2);
                offset = offset3 + (nRects << 2);
            } else {
                this._frames_rects_short = new short[nRects << 2];
                offset = readArray2Short(file, offset3, this._frames_rects_short, 0, nRects << 2, false, false);
            }
        }
        int i2 = offset;
        int offset4 = offset + 1;
        int offset5 = offset4 + 1;
        int nFrames = (short) ((file[i2] & 255) + ((file[offset4] & 255) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println(new StringBuffer().append("nFrames = ").append(nFrames).toString());
        }
        if (nFrames > 0) {
            this._frames_nfm = new byte[nFrames];
            this._frames_fm_start = new short[nFrames];
            short frame_start = 0;
            if (!GLLibConfig.sprite_alwaysBsNfm1Byte) {
                System.arraycopy(file, offset5, this._frames_nfm, 0, nFrames);
                offset5 += nFrames;
            } else {
                System.arraycopy(file, offset5, this._frames_nfm, 0, nFrames);
                offset5 += nFrames;
            }
            if (GLLibConfig.sprite_alwaysBsNoFmStart) {
                for (int i3 = 0; i3 < nFrames; i3++) {
                    this._frames_fm_start[i3] = frame_start;
                    frame_start = (short) (frame_start + (this._frames_nfm[i3] & 255));
                }
            } else {
                offset5 = readArray2Short(file, offset5, this._frames_fm_start, 0, nFrames, false, false);
            }
            if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & BS_FRAME_RECTS) != 0) {
                this._frames_rects_start = new short[nFrames + 1];
                short frames_rects_offset = 0;
                for (int i4 = 0; i4 < nFrames; i4++) {
                    this._frames_rects_start[i4] = frames_rects_offset;
                    int i5 = offset5;
                    offset5++;
                    frames_rects_offset = (short) (frames_rects_offset + file[i5]);
                }
                this._frames_rects_start[this._frames_rects_start.length - 1] = frames_rects_offset;
            }
            if (!GLLibConfig.sprite_alwaysBsSkipFrameRc) {
                if (GLLibConfig.sprite_usePrecomputedFrameRect) {
                    int nFrames4 = nFrames << 2;
                    if ((this._bs_flags & 1024) == 0) {
                        this._frames_rc = new byte[nFrames4];
                        offset5 = readByteArrayNi(file, readByteArrayNi(file, readByteArrayNi(file, readByteArrayNi(file, offset5, this._frames_rc, nFrames, 0, 4), this._frames_rc, nFrames, 1, 4), this._frames_rc, nFrames, 2, 4), this._frames_rc, nFrames, 3, 4);
                    }
                } else if ((this._bs_flags & 1024) == 0) {
                    offset5 += nFrames << 2;
                } else {
                    offset5 += nFrames << 3;
                }
            } else if (GLLibConfig.sprite_usePrecomputedFrameRect) {
            }
            if (GLLibConfig.sprite_useFrameCollRC && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 8192) != 0)) {
                int nFrames42 = nFrames << 2;
                if ((this._bs_flags & 1024) == 0) {
                    this._frames_col = new byte[nFrames42];
                    offset5 = readByteArrayNi(file, readByteArrayNi(file, readByteArrayNi(file, readByteArrayNi(file, offset5, this._frames_col, nFrames, 0, 4), this._frames_col, nFrames, 1, 4), this._frames_col, nFrames, 2, 4), this._frames_col, nFrames, 3, 4);
                }
            }
        }
        return offset5;
    }

    private int LoadAFrames_NI(int offset, byte[] file) {
        int offset2;
        int offset3 = offset + 1;
        int i = file[offset] & 255;
        int offset4 = offset3 + 1;
        int nAFrames = (short) (i + ((file[offset3] & 255) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println(new StringBuffer().append("nAFrames = ").append(nAFrames).toString());
        }
        if (nAFrames > 0) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                this._aframes = new byte[nAFrames * 5];
                offset4 = readByteArrayNi(file, readByteArrayNi(file, readByteArrayNi(file, readByteArrayNi(file, readByteArrayNi(file, offset4, this._aframes, nAFrames, 0, 5), this._aframes, nAFrames, 1, 5), this._aframes, nAFrames, 2, 5), this._aframes, nAFrames, 3, 5), this._aframes, nAFrames, 4, 5);
            } else {
                this._aframes_frame = new byte[nAFrames];
                this._aframes_time = new byte[nAFrames];
                if (GLLibConfig.sprite_useAfOffShort) {
                    this._aframes_ox_short = new short[nAFrames];
                    this._aframes_oy_short = new short[nAFrames];
                } else {
                    this._aframes_ox_byte = new byte[nAFrames];
                    this._aframes_oy_byte = new byte[nAFrames];
                }
                this._aframes_flags = new byte[nAFrames];
                System.arraycopy(file, offset4, this._aframes_frame, 0, nAFrames);
                int offset5 = offset4 + nAFrames;
                System.arraycopy(file, offset5, this._aframes_time, 0, nAFrames);
                int offset6 = offset5 + nAFrames;
                if (GLLibConfig.sprite_useAfOffShort) {
                    if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & BS_AF_OFF_SHORT) == 0) {
                        offset2 = readArray2Short(file, readArray2Short(file, offset6, this._aframes_ox_short, 0, nAFrames, true, false), this._aframes_oy_short, 0, nAFrames, true, false);
                    } else {
                        offset2 = readArray2Short(file, readArray2Short(file, offset6, this._aframes_ox_short, 0, nAFrames, false, false), this._aframes_oy_short, 0, nAFrames, false, false);
                    }
                } else {
                    System.arraycopy(file, offset6, this._aframes_ox_byte, 0, nAFrames);
                    int offset7 = offset6 + nAFrames;
                    System.arraycopy(file, offset7, this._aframes_oy_byte, 0, nAFrames);
                    offset2 = offset7 + nAFrames;
                }
                System.arraycopy(file, offset2, this._aframes_flags, 0, nAFrames);
                offset4 = offset2 + nAFrames;
            }
        }
        return offset4;
    }

    private int LoadAnims_NI(int offset, byte[] file) {
        int offset2 = offset + 1;
        int i = file[offset] & 255;
        int offset3 = offset2 + 1;
        int nAnims = (short) (i + ((file[offset2] & 255) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println(new StringBuffer().append("nAnims = ").append(nAnims).toString());
        }
        if (nAnims > 0) {
            this._anims_naf = new byte[nAnims];
            this._anims_af_start = new short[nAnims];
            short af_start = 0;
            if (!GLLibConfig.sprite_alwaysBsNfm1Byte) {
                System.arraycopy(file, offset3, this._anims_naf, 0, nAnims);
                offset3 += nAnims;
            } else {
                System.arraycopy(file, offset3, this._anims_naf, 0, nAnims);
                offset3 += nAnims;
            }
            if (GLLibConfig.sprite_alwaysBsNoAfStart) {
                for (int i2 = 0; i2 < nAnims; i2++) {
                    this._anims_af_start[i2] = af_start;
                    af_start = (short) (af_start + this._anims_naf[i2]);
                }
            } else {
                offset3 = readArray2Short(file, offset3, this._anims_af_start, 0, nAnims, false, false);
            }
        }
        return offset3;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v111, types: [Image[], Image[][]] */
    /* JADX WARN: Type inference failed for: r1v16, types: [int[], int[][]] */
    /* JADX WARN: Type inference failed for: r1v278, types: [Image[][], Image[][][]] */
    /* JADX WARN: Type inference failed for: r1v413, types: [short[], short[][]] */
    private int LoadData_useModuleImages(int offset, byte[] file, int pal_flags, int tr_flags) {
        int offset2;
        int size;
        int offset3;
        int size2;
        int offset4;
        int size3;
        int offset5;
        int size4;
        if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_MODULE_IMAGES) != 0) {
            if (offset >= file.length) {
                return offset;
            }
            int offset6 = offset + 1;
            int i = file[offset] & 255;
            int offset7 = offset6 + 1;
            short _pixel_format = (short) (i + ((file[offset6] & 255) << 8));
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("_pixel_format = 0x").append(Integer.toHexString(_pixel_format)).toString());
            }
            int offset8 = offset7 + 1;
            this._palettes = file[offset7] & 255;
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("_palettes = ").append(this._palettes).toString());
            }
            int offset9 = offset8 + 1;
            this._colors = file[offset8] & 255;
            if ((GLLibConfig.sprite_useEncodeFormatI256 || GLLibConfig.sprite_useEncodeFormatI256RLE || GLLibConfig.sprite_useEncodeFormatA256_I256RLE) && this._colors == 0) {
                this._colors = BS_FRAMES;
            }
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("colors = ").append(this._colors).toString());
            }
            if (GLLibConfig.sprite_useNokiaUI) {
                if (this._pal_short == null) {
                    this._pal_short = new short[GLLibConfig.MAX_SPRITE_PALETTES];
                }
            } else if (this._pal_int == null) {
                this._pal_int = new int[GLLibConfig.MAX_SPRITE_PALETTES];
            }
            for (int p = 0; p < this._palettes; p++) {
                if (GLLibConfig.sprite_useDynamicPng && (pal_flags & (1 << p)) == 0) {
                    offset9 += _pixel_format == PIXEL_FORMAT_8888 ? this._colors * 4 : this._colors * 2;
                } else {
                    if (GLLibConfig.sprite_useNokiaUI) {
                        this._pal_short[p] = new short[this._colors];
                    } else {
                        this._pal_int[p] = new int[this._colors];
                    }
                    if (GLLibConfig.sprite_usePixelFormat8888 && _pixel_format == PIXEL_FORMAT_8888) {
                        for (int c = 0; c < this._colors; c++) {
                            if (GLLibConfig.sprite_useNokiaUI) {
                                int i2 = offset9;
                                int offset10 = offset9 + 1;
                                int offset11 = offset10 + 1;
                                int _4444 = ((file[i2] & 240) >> 4) + (file[offset10] & 240);
                                int offset12 = offset11 + 1;
                                int _44442 = _4444 + ((file[offset11] & 240) << 4);
                                offset9 = offset12 + 1;
                                int _44443 = _44442 + ((file[offset12] & 240) << 8);
                                if ((_44443 & 61440) != 61440) {
                                    this._alpha = true;
                                    if ((_44443 & 61440) != 0) {
                                        this._multiAlpha = true;
                                    }
                                }
                                this._pal_short[p][c] = (short) (_44443 & 65535);
                            } else {
                                int i3 = offset9;
                                int offset13 = offset9 + 1;
                                int offset14 = offset13 + 1;
                                int i4 = (file[i3] & 255) + ((file[offset13] & 255) << 8);
                                int offset15 = offset14 + 1;
                                int i5 = i4 + ((file[offset14] & 255) << 16);
                                offset9 = offset15 + 1;
                                int _8888 = i5 + ((file[offset15] & 255) << 24);
                                if ((_8888 & (-16777216)) != -16777216) {
                                    this._alpha = true;
                                    if ((_8888 & (-16777216)) != 0) {
                                        this._multiAlpha = true;
                                    }
                                }
                                this._pal_int[p][c] = _8888;
                            }
                        }
                    } else if (GLLibConfig.sprite_usePixelFormat4444 && _pixel_format == PIXEL_FORMAT_4444) {
                        for (int c2 = 0; c2 < this._colors; c2++) {
                            int i6 = offset9;
                            int offset16 = offset9 + 1;
                            offset9 = offset16 + 1;
                            int _44444 = (short) ((file[i6] & 255) + ((file[offset16] & 255) << 8));
                            if ((_44444 & 61440) != 61440) {
                                this._alpha = true;
                                if ((_44444 & 61440) != 0) {
                                    this._multiAlpha = true;
                                }
                            }
                            if (GLLibConfig.sprite_useNokiaUI) {
                                this._pal_short[p][c2] = (short) (_44444 & 65535);
                            } else {
                                this._pal_int[p][c2] = ((_44444 & 61440) << 16) | ((_44444 & 61440) << 12) | ((_44444 & 3840) << 12) | ((_44444 & 3840) << 8) | ((_44444 & 240) << 8) | ((_44444 & 240) << 4) | ((_44444 & 15) << 4) | (_44444 & 15);
                            }
                        }
                    } else if (GLLibConfig.sprite_usePixelFormat1555 && _pixel_format == PIXEL_FORMAT_1555) {
                        for (int c3 = 0; c3 < this._colors; c3++) {
                            int i7 = offset9;
                            int offset17 = offset9 + 1;
                            offset9 = offset17 + 1;
                            int _1555 = (short) ((file[i7] & 255) + ((file[offset17] & 255) << 8));
                            int a = -16777216;
                            if ((_1555 & BS_FRAME_RECTS) != BS_FRAME_RECTS) {
                                a = 0;
                                this._alpha = true;
                            }
                            if (GLLibConfig.sprite_useNokiaUI) {
                                int tmp_col = a | ((_1555 & 31744) << 9) | ((_1555 & 992) << 6) | ((_1555 & 31) << 3);
                                this._pal_short[p][c3] = (short) ((((tmp_col >> 24) & 240) << 8) | (((tmp_col >> 16) & 240) << 4) | ((tmp_col >> 8) & 240) | ((tmp_col & 240) >> 4));
                            } else {
                                this._pal_int[p][c3] = a | ((_1555 & 31744) << 9) | ((_1555 & 992) << 6) | ((_1555 & 31) << 3);
                            }
                        }
                    } else if (GLLibConfig.sprite_usePixelFormat0565 && _pixel_format == PIXEL_FORMAT_0565) {
                        for (int c4 = 0; c4 < this._colors; c4++) {
                            int i8 = offset9;
                            int offset18 = offset9 + 1;
                            offset9 = offset18 + 1;
                            int _0565 = (short) ((file[i8] & 255) + ((file[offset18] & 255) << 8));
                            int a2 = -16777216;
                            if ((_0565 & 65535) == 63519) {
                                a2 = 0;
                                this._alpha = true;
                            }
                            if (GLLibConfig.sprite_useNokiaUI) {
                                int tmp_col2 = a2 | ((_0565 & 63488) << 8) | ((_0565 & 2016) << 5) | ((_0565 & 31) << 3);
                                this._pal_short[p][c4] = (short) ((((tmp_col2 >> 24) & 240) << 8) | (((tmp_col2 >> 16) & 240) << 4) | ((tmp_col2 >> 8) & 240) | ((tmp_col2 & 240) >> 4));
                            } else {
                                this._pal_int[p][c4] = a2 | ((_0565 & 63488) << 8) | ((_0565 & 2016) << 5) | ((_0565 & 31) << 3);
                            }
                        }
                    }
                }
            }
            int i9 = offset9;
            int offset19 = offset9 + 1;
            offset = offset19 + 1;
            this._data_format = (short) ((file[i9] & 255) + ((file[offset19] & 255) << 8));
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("_data_format = 0x").append(Integer.toHexString(this._data_format)).toString());
            }
            if ((GLLibConfig.sprite_useEncodeFormatA256_I64RLE && this._data_format == ENCODE_FORMAT_A256_I64RLE) || ((GLLibConfig.sprite_useEncodeFormatA256_I127RLE && this._data_format == ENCODE_FORMAT_A256_I127RLE) || (GLLibConfig.sprite_useEncodeFormatA256_I256RLE && this._data_format == ENCODE_FORMAT_A256_I256RLE))) {
                this._alpha = true;
                this._multiAlpha = true;
            }
            if ((GLLibConfig.sprite_useEncodeFormatI64RLE || GLLibConfig.sprite_useEncodeFormatA256_I64RLE) && (this._data_format == ENCODE_FORMAT_I64RLE || this._data_format == ENCODE_FORMAT_A256_I64RLE)) {
                int clrs = this._colors - 1;
                this._i64rle_color_mask = 1;
                this._i64rle_color_bits = 0;
                while (clrs != 0) {
                    clrs >>= 1;
                    this._i64rle_color_mask <<= 1;
                    this._i64rle_color_bits++;
                }
                this._i64rle_color_mask--;
            }
            if (this._nModules > 0) {
                if (GLLibConfig.sprite_useDynamicPng) {
                    if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                        if (!GLLibConfig.sprite_useOperationMark && GLLibConfig.sprite_debugLoading) {
                            System.out.println("GLLibConfig.sprite_useOperationMark = true must be defined!");
                        }
                        MarkTransformedModules(true, tr_flags);
                        if (this._module_image_imageAAA == null) {
                            this._module_image_imageAAA = new Image[this._palettes][];
                        }
                    } else if (this._module_image_imageAA == null) {
                        this._module_image_imageAA = new Image[this._palettes];
                    }
                    for (int p2 = 0; p2 < this._palettes; p2++) {
                        if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                            if ((pal_flags & (1 << p2)) != 0 && this._module_image_imageAAA[p2] == null) {
                                this._module_image_imageAAA[p2] = new Image[this._nModules];
                                for (int q = 0; q < this._nModules; q++) {
                                    int flip_max = 1;
                                    for (int r = 0; r < GLLibConfig.MAX_FLIP_COUNT; r++) {
                                        if (GLLibConfig.sprite_useModuleUsageFromSprite && (this._modules_usage[q] & (1 << r)) != 0) {
                                            flip_max = r + 1;
                                        }
                                    }
                                    this._module_image_imageAAA[p2][q] = new Image[flip_max];
                                }
                            }
                        } else if ((pal_flags & (1 << p2)) != 0 && this._module_image_imageAA[p2] == null) {
                            this._module_image_imageAA[p2] = new Image[this._nModules];
                        }
                    }
                    if (GLLibConfig.sprite_usePrecomputedCRC) {
                        if (GLLibConfig.sprite_debugLoading) {
                            System.out.println("LoadData with sprite_usePrecomputedCRC");
                        }
                        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                            this._modules_data_off_short = new short[this._nModules];
                        } else {
                            this._modules_data_off_int = new int[this._nModules];
                        }
                        int len = 0;
                        for (int m = 0; m < this._nModules; m++) {
                            if ((this._bs_flags & BS_IMAGE_SIZE_INT) != 0) {
                                int i10 = offset;
                                int offset20 = offset + 1;
                                int offset21 = offset20 + 1;
                                int i11 = (file[i10] & 255) + ((file[offset20] & 255) << 8);
                                int offset22 = offset21 + 1;
                                int i12 = i11 + ((file[offset21] & 255) << 16);
                                offset5 = offset22 + 1;
                                size4 = i12 + ((file[offset22] & 255) << 24);
                            } else {
                                int i13 = offset;
                                int offset23 = offset + 1;
                                offset5 = offset23 + 1;
                                size4 = (short) ((file[i13] & 255) + ((file[offset23] & 255) << 8));
                            }
                            if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                                this._modules_data_off_short[m] = (short) len;
                            } else {
                                this._modules_data_off_int[m] = len;
                            }
                            len += size4;
                            offset = offset5 + size4;
                        }
                        offset = offset;
                        this._modules_data = new byte[len];
                        for (int m2 = 0; m2 < this._nModules; m2++) {
                            if ((this._bs_flags & BS_IMAGE_SIZE_INT) != 0) {
                                int i14 = offset;
                                int offset24 = offset + 1;
                                int offset25 = offset24 + 1;
                                int i15 = (file[i14] & 255) + ((file[offset24] & 255) << 8);
                                int offset26 = offset25 + 1;
                                int i16 = i15 + ((file[offset25] & 255) << 16);
                                offset4 = offset26 + 1;
                                size3 = i16 + ((file[offset26] & 255) << 24);
                            } else {
                                int i17 = offset;
                                int offset27 = offset + 1;
                                offset4 = offset27 + 1;
                                size3 = (short) ((file[i17] & 255) + ((file[offset27] & 255) << 8));
                            }
                            if (GLLibConfig.sprite_debugLoading) {
                                System.out.println(new StringBuffer().append("module[").append(m2).append("] size = ").append(size3).toString());
                            }
                            System.arraycopy(file, offset4, this._modules_data, getStartModuleData(m2, 0), size3);
                            offset = offset4 + size3;
                        }
                        if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_PNG_CRC) != 0) {
                            this._PNG_packed_PLTE_CRC = new int[this._palettes];
                            this._PNG_packed_tRNS_CRC = new int[this._palettes];
                            this._PNG_packed_IHDR_CRC = new int[this._nModules];
                            this._PNG_packed_IDAT_ADLER = new int[this._nModules];
                            this._PNG_packed_IDAT_CRC = new int[this._nModules];
                            for (int p3 = 0; p3 < this._palettes; p3++) {
                                int i18 = offset;
                                int offset28 = offset + 1;
                                int offset29 = offset28 + 1;
                                int i19 = (file[i18] & 255) + ((file[offset28] & 255) << 8);
                                int offset30 = offset29 + 1;
                                int i20 = i19 + ((file[offset29] & 255) << 16);
                                offset = offset30 + 1;
                                this._PNG_packed_PLTE_CRC[p3] = i20 + ((file[offset30] & 255) << 24);
                            }
                            for (int p4 = 0; p4 < this._palettes; p4++) {
                                int i21 = offset;
                                int offset31 = offset + 1;
                                int offset32 = offset31 + 1;
                                int i22 = (file[i21] & 255) + ((file[offset31] & 255) << 8);
                                int offset33 = offset32 + 1;
                                int i23 = i22 + ((file[offset32] & 255) << 16);
                                offset = offset33 + 1;
                                this._PNG_packed_tRNS_CRC[p4] = i23 + ((file[offset33] & 255) << 24);
                            }
                            for (int m3 = 0; m3 < this._nModules; m3++) {
                                int i24 = offset;
                                int offset34 = offset + 1;
                                int offset35 = offset34 + 1;
                                int i25 = (file[i24] & 255) + ((file[offset34] & 255) << 8);
                                int offset36 = offset35 + 1;
                                int i26 = i25 + ((file[offset35] & 255) << 16);
                                offset = offset36 + 1;
                                this._PNG_packed_IHDR_CRC[m3] = i26 + ((file[offset36] & 255) << 24);
                            }
                            for (int m4 = 0; m4 < this._nModules; m4++) {
                                int i27 = offset;
                                int offset37 = offset + 1;
                                int offset38 = offset37 + 1;
                                int i28 = (file[i27] & 255) + ((file[offset37] & 255) << 8);
                                int offset39 = offset38 + 1;
                                int i29 = i28 + ((file[offset38] & 255) << 16);
                                offset = offset39 + 1;
                                this._PNG_packed_IDAT_ADLER[m4] = i29 + ((file[offset39] & 255) << 24);
                            }
                            for (int m5 = 0; m5 < this._nModules; m5++) {
                                int i30 = offset;
                                int offset40 = offset + 1;
                                int offset41 = offset40 + 1;
                                int i31 = (file[i30] & 255) + ((file[offset40] & 255) << 8);
                                int offset42 = offset41 + 1;
                                int i32 = i31 + ((file[offset41] & 255) << 16);
                                offset = offset42 + 1;
                                this._PNG_packed_IDAT_CRC[m5] = i32 + ((file[offset42] & 255) << 24);
                            }
                        }
                    } else {
                        if (GLLibConfig.sprite_debugLoading) {
                            System.out.println("LoadData WITHOUT sprite_usePrecomputedCRC");
                        }
                        for (int p5 = 0; p5 < this._palettes; p5++) {
                            if ((pal_flags & (1 << p5)) != 0) {
                                boolean bSkipPalette = false;
                                offset = offset;
                                for (int mod2 = 0; mod2 < this._nModules; mod2++) {
                                    int i33 = offset;
                                    int offset43 = offset + 1;
                                    int offset44 = offset43 + 1;
                                    int mod_dim = (short) ((file[i33] & 255) + ((file[offset43] & 255) << 8));
                                    int sizeX = GetModuleWidth(mod2);
                                    int sizeY = GetModuleHeight(mod2);
                                    byte[] image_data = null;
                                    if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                                        for (int k = 0; k < GLLibConfig.MAX_FLIP_COUNT && k < this._module_image_imageAAA[p5][mod2].length; k++) {
                                            if ((!GLLibConfig.sprite_useModuleUsageFromSprite || ((1 << k) & this._modules_usage[mod2]) != 0) && this._module_image_imageAAA[p5][mod2][k] == null) {
                                                if (image_data == null) {
                                                    image_data = DecodeImage_byte(file, offset44, sizeX, sizeY);
                                                }
                                                if (GLLibConfig.sprite_useBugFixImageOddSize) {
                                                    sizeX += sizeX % 2;
                                                    sizeY += sizeY % 2;
                                                }
                                                this._module_image_imageAAA[p5][mod2][k] = BuildPNG8(p5, bSkipPalette, image_data, sizeX, sizeY, k);
                                                bSkipPalette = true;
                                            }
                                        }
                                    } else if (this._module_image_imageAA[p5][mod2] == null) {
                                        if (0 == 0) {
                                            image_data = DecodeImage_byte(file, offset44, sizeX, sizeY);
                                        }
                                        if (GLLibConfig.sprite_useBugFixImageOddSize) {
                                            sizeX += sizeX % 2;
                                            sizeY += sizeY % 2;
                                        }
                                        this._module_image_imageAA[p5][mod2] = BuildPNG8(p5, bSkipPalette, image_data, sizeX, sizeY, 0);
                                        bSkipPalette = true;
                                    }
                                    offset = offset44 + mod_dim;
                                }
                            }
                        }
                    }
                } else {
                    if (GLLibConfig.sprite_debugLoading) {
                        System.out.println("LoadData: Loading Module Offsets");
                    }
                    if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                        this._modules_data_off_short = new short[this._nModules];
                    } else {
                        this._modules_data_off_int = new int[this._nModules];
                    }
                    int len2 = 0;
                    for (int m6 = 0; m6 < this._nModules; m6++) {
                        if ((this._bs_flags & BS_IMAGE_SIZE_INT) != 0) {
                            int i34 = offset;
                            int offset45 = offset + 1;
                            int offset46 = offset45 + 1;
                            int i35 = (file[i34] & 255) + ((file[offset45] & 255) << 8);
                            int offset47 = offset46 + 1;
                            int i36 = i35 + ((file[offset46] & 255) << 16);
                            offset3 = offset47 + 1;
                            size2 = i36 + ((file[offset47] & 255) << 24);
                        } else {
                            int i37 = offset;
                            int offset48 = offset + 1;
                            offset3 = offset48 + 1;
                            size2 = (short) ((file[i37] & 255) + ((file[offset48] & 255) << 8));
                        }
                        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                            this._modules_data_off_short[m6] = (short) len2;
                        } else {
                            this._modules_data_off_int[m6] = len2;
                        }
                        len2 += size2;
                        offset = offset3 + size2;
                    }
                    if (GLLibConfig.sprite_debugLoading) {
                        System.out.println("LoadData: Loading Module Data");
                    }
                    offset = offset;
                    this._modules_data = new byte[len2];
                    for (int m7 = 0; m7 < this._nModules; m7++) {
                        if ((this._bs_flags & BS_IMAGE_SIZE_INT) != 0) {
                            int i38 = offset;
                            int offset49 = offset + 1;
                            int offset50 = offset49 + 1;
                            int i39 = (file[i38] & 255) + ((file[offset49] & 255) << 8);
                            int offset51 = offset50 + 1;
                            int i40 = i39 + ((file[offset50] & 255) << 16);
                            offset2 = offset51 + 1;
                            size = i40 + ((file[offset51] & 255) << 24);
                        } else {
                            int i41 = offset;
                            int offset52 = offset + 1;
                            offset2 = offset52 + 1;
                            size = (short) ((file[i41] & 255) + ((file[offset52] & 255) << 8));
                        }
                        if (GLLibConfig.sprite_debugLoading) {
                            System.out.println(new StringBuffer().append("module[").append(m7).append("] size = ").append(size).toString());
                        }
                        System.arraycopy(file, offset2, this._modules_data, getStartModuleData(m7, 0), size);
                        offset = offset2 + size;
                    }
                }
            }
        }
        return offset;
    }

    /* JADX WARN: Type inference failed for: r1v37, types: [Image[], Image[][]] */
    /* JADX WARN: Type inference failed for: r1v73, types: [Image[][], Image[][][]] */
    private int LoadData_useSingleImages(int offset, byte[] file, int pal_flags, int tr_flags) {
        int offset2;
        if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_SINGLE_IMAGE) != 0) {
            int offset3 = offset + 1;
            int i = file[offset] & 255;
            int offset4 = offset3 + 1;
            int size = (short) (i + ((file[offset3] & 255) << 8));
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("png size = ").append(size).toString());
            }
            int image_offset = 0;
            if (GLLibConfig.sprite_useDynamicPng) {
                this._modules_data = file;
                image_offset = offset4;
                offset2 = offset4 + size;
            } else {
                this._modules_data = new byte[size];
                System.arraycopy(file, offset4, this._modules_data, 0, size);
                offset2 = offset4 + size;
            }
            int i2 = offset2;
            int offset5 = offset2 + 1;
            this._palettes = file[i2] & 255;
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("_palettes = ").append(this._palettes).toString());
            }
            int offset6 = offset5 + 1;
            this._colors = file[offset5] & 255;
            if (this._colors == 0) {
                this._colors = BS_FRAMES;
            }
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("colors = ").append(this._colors).toString());
            }
            int _PLTE_size = (this._colors * 3) + 4;
            int _TRNS_size = this._colors + 4;
            int pal_size = _PLTE_size + _TRNS_size;
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println(new StringBuffer().append("pal_size = ").append(pal_size).toString());
            }
            this._pal_data = new byte[this._palettes * pal_size];
            System.arraycopy(this._modules_data, 41 + image_offset, this._pal_data, 0, _PLTE_size);
            System.arraycopy(this._modules_data, 41 + _PLTE_size + 8 + image_offset, this._pal_data, _PLTE_size, _TRNS_size);
            System.arraycopy(file, offset6, this._pal_data, pal_size, (this._palettes - 1) * pal_size);
            offset = offset6 + ((this._palettes - 1) * pal_size);
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("...read pal data");
            }
            if (GLLibConfig.sprite_useDynamicPng) {
                if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                    this._module_image_imageAAA = new Image[this._palettes][];
                } else {
                    this._module_image_imageAA = new Image[this._palettes];
                }
                for (int p = 0; p < this._palettes; p++) {
                    if ((pal_flags & (1 << p)) != 0) {
                        System.arraycopy(this._pal_data, p * (_PLTE_size + _TRNS_size), this._modules_data, 41 + image_offset, _PLTE_size);
                        System.arraycopy(this._pal_data, (p * (_PLTE_size + _TRNS_size)) + _PLTE_size, this._modules_data, 41 + _PLTE_size + 8 + image_offset, _TRNS_size);
                        if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                            this._module_image_imageAAA[p] = new Image[1][1];
                            this._module_image_imageAAA[p][0][0] = GLLib.CreateImage(this._modules_data, image_offset, size);
                            if (GLLibConfig.sprite_debugUsedMemory) {
                                _images_count++;
                                _images_size += this._module_image_imageAAA[p][0][0].getWidth() * this._module_image_imageAAA[p][0][0].getHeight();
                            }
                        } else {
                            this._module_image_imageAA[p] = new Image[1];
                            this._module_image_imageAA[p][0] = GLLib.CreateImage(this._modules_data, image_offset, size);
                            if (GLLibConfig.sprite_debugUsedMemory) {
                                _images_count++;
                                _images_size += this._module_image_imageAA[p][0].getWidth() * this._module_image_imageAA[p][0].getHeight();
                            }
                        }
                    }
                }
                this._pal_data = null;
                this._modules_data = null;
            }
        }
        return offset;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v122, types: [Image[], Image[][]] */
    /* JADX WARN: Type inference failed for: r1v156, types: [Image[][], Image[][][]] */
    /* JADX WARN: Type inference failed for: r1v174, types: [short[][], short[][][]] */
    /* JADX WARN: Type inference failed for: r1v2, types: [int[][], int[][][]] */
    /* JADX WARN: Type inference failed for: r1v5, types: [Image[], Image[][]] */
    void BuildCacheImages(int pal, int m1, int m2, int pal_copy) {
        int[] image_data;
        if (GLLibConfig.sprite_useNokiaUI) {
            if (this._modules_image_shortAAA == null) {
                this._modules_image_shortAAA = new short[this._palettes][];
            }
            if (this._modules_image_shortAAA[pal] == null) {
                this._modules_image_shortAAA[pal] = new short[this._nModules];
            }
        } else if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
            if (this._module_image_intAAA == null) {
                this._module_image_intAAA = new int[this._palettes][];
            }
        } else if (this._module_image_imageAA == null) {
            this._module_image_imageAA = new Image[this._palettes];
        }
        if (GLLibConfig.sprite_useDynamicPng) {
            if (GLLibConfig.sprite_usePrecomputedCRC) {
                if (GLLibConfig.sprite_debugLoading) {
                    System.out.println(new StringBuffer().append("BuildCacheImages(").append(pal).append(", ").append(m1).append(", ").append(m2).append(", ").append(pal_copy).append(")... ").append(this).toString());
                }
                if (this._nModules == 0) {
                    return;
                }
                if (m2 == -1) {
                    m2 = this._nModules - 1;
                }
                if (GLLibConfig.sprite_useLoadImageWithoutTransf || !(GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                    if (this._module_image_imageAA == null) {
                        this._module_image_imageAA = new Image[this._palettes];
                    }
                    if (this._module_image_imageAA[pal] == null) {
                        this._module_image_imageAA[pal] = new Image[this._nModules];
                    }
                } else {
                    if (this._module_image_imageAAA == null) {
                        this._module_image_imageAAA = new Image[this._palettes][];
                    }
                    if (this._module_image_imageAAA[pal] == null) {
                        this._module_image_imageAAA[pal] = new Image[this._nModules][1];
                    }
                }
                if (pal_copy < 0) {
                    int old_pal = this._crt_pal;
                    this._crt_pal = pal;
                    if (!GLLibConfig.sprite_useDeactivateSystemGc && s_gcEnabled) {
                        System.gc();
                    }
                    if (GLLibConfig.sprite_useLoadImageWithoutTransf || !(GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                        for (int i = m1; i <= m2; i++) {
                            if (!GLLibConfig.sprite_useMultipleModuleTypes || this._module_types[i] == 0) {
                                if (GLLibConfig.sprite_debugLoading) {
                                    System.out.println(new StringBuffer().append(" Caching image for module ").append(i).toString());
                                }
                                if (GetModuleWidth(i) > 0 && GetModuleHeight(i) > 0) {
                                    this._module_image_imageAA[pal][i] = BuildPNG8(this._crt_pal, false, i, GetModuleWidth(i), GetModuleHeight(i), 0);
                                }
                            }
                        }
                    } else {
                        for (int i2 = m1; i2 <= m2; i2++) {
                            if (!GLLibConfig.sprite_useMultipleModuleTypes || this._module_types[i2] == 0) {
                                if (GLLibConfig.sprite_debugLoading) {
                                    System.out.println(new StringBuffer().append(" Caching image for module ").append(i2).toString());
                                }
                                if (GetModuleWidth(i2) > 0 && GetModuleHeight(i2) > 0) {
                                    this._module_image_imageAAA[pal][i2][0] = BuildPNG8(this._crt_pal, false, i2, GetModuleWidth(i2), GetModuleHeight(i2), 0);
                                }
                            }
                        }
                    }
                    if (!GLLibConfig.sprite_useDeactivateSystemGc && s_gcEnabled) {
                        System.gc();
                    }
                    this._crt_pal = old_pal;
                } else if (GLLibConfig.sprite_useLoadImageWithoutTransf || !(GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                    for (int i3 = m1; i3 <= m2; i3++) {
                        this._module_image_imageAA[pal][i3] = this._module_image_imageAA[pal_copy][i3];
                    }
                } else {
                    for (int i4 = m1; i4 <= m2; i4++) {
                        this._module_image_imageAAA[pal][i4] = this._module_image_imageAAA[pal_copy][i4];
                    }
                }
                if (GLLibConfig.sprite_useDeactivateSystemGc || !s_gcEnabled) {
                    return;
                }
                System.gc();
                return;
            }
            return;
        }
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println(new StringBuffer().append("BuildCacheImages(").append(pal).append(", ").append(m1).append(", ").append(m2).append(", ").append(pal_copy).append(")... ").append(this).toString());
        }
        if (this._nModules == 0) {
            return;
        }
        if (m2 == -1) {
            m2 = this._nModules - 1;
        }
        if (GLLibConfig.sprite_ModuleMapping_useModuleImages && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_MODULE_IMAGES) != 0)) {
            if (!GLLibConfig.sprite_useNokiaUI) {
                if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
                    if (this._module_image_intAAA[pal] == null) {
                        this._module_image_intAAA[pal] = new int[this._nModules];
                    }
                } else if (this._module_image_imageAA[pal] == null) {
                    this._module_image_imageAA[pal] = new Image[this._nModules];
                }
                if (pal_copy >= 0) {
                    for (int i5 = m1; i5 <= m2; i5++) {
                        if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
                            this._module_image_intAAA[pal][i5] = this._module_image_intAAA[pal_copy][i5];
                        } else {
                            this._module_image_imageAA[pal][i5] = this._module_image_imageAA[pal_copy][i5];
                        }
                    }
                } else {
                    int old_pal2 = this._crt_pal;
                    this._crt_pal = pal;
                    if (!GLLibConfig.sprite_useDeactivateSystemGc && s_gcEnabled) {
                        System.gc();
                    }
                    for (int i6 = m1; i6 <= m2; i6++) {
                        if ((!GLLibConfig.sprite_useModuleUsageFromSprite || this._modules_usage == null || this._modules_usage[i6] != 0) && (!GLLibConfig.sprite_useMultipleModuleTypes || this._module_types[i6] == 0)) {
                            if (GLLibConfig.sprite_debugLoading) {
                                System.out.println(new StringBuffer().append(" Caching image for module ").append(i6).toString());
                            }
                            int sizeX = GetModuleWidth(i6);
                            int sizeY = GetModuleHeight(i6);
                            if (sizeX > 0 && sizeY > 0 && (image_data = DecodeImage_int(i6)) != null) {
                                boolean bAlpha = false;
                                int size = sizeX * sizeY;
                                int ii = 0;
                                while (true) {
                                    if (ii >= size) {
                                        break;
                                    }
                                    if ((image_data[ii] & (-16777216)) != -16777216) {
                                        bAlpha = true;
                                        break;
                                    }
                                    ii++;
                                }
                                if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
                                    if (this._module_image_intAAA[pal][i6] == null || this._module_image_intAAA[pal][i6].length != size) {
                                        this._module_image_intAAA[pal][i6] = new int[size];
                                    }
                                    System.arraycopy(image_data, 0, this._module_image_intAAA[pal][i6], 0, size);
                                } else {
                                    this._module_image_imageAA[pal][i6] = GLLib.CreateRGBImage(image_data, sizeX, sizeY, bAlpha);
                                }
                                if (GLLibConfig.sprite_debugUsedMemory) {
                                    _images_count++;
                                    _images_size += size;
                                }
                            }
                        }
                    }
                    if (!GLLibConfig.sprite_useDeactivateSystemGc && s_gcEnabled) {
                        System.gc();
                    }
                    this._crt_pal = old_pal2;
                }
            } else if (pal_copy >= 0) {
                for (int i7 = m1; i7 <= m2; i7++) {
                    this._modules_image_shortAAA[pal][i7] = this._modules_image_shortAAA[pal_copy][i7];
                }
            } else {
                int old_pal3 = this._crt_pal;
                this._crt_pal = pal;
                if (!GLLibConfig.sprite_useDeactivateSystemGc && s_gcEnabled) {
                    System.gc();
                }
                for (int i8 = m1; i8 <= m2; i8++) {
                    if ((!GLLibConfig.sprite_useModuleUsageFromSprite || this._modules_usage == null || this._modules_usage[i8] != 0) && (!GLLibConfig.sprite_useMultipleModuleTypes || this._module_types[i8] == 0)) {
                        if (GLLibConfig.sprite_debugLoading) {
                            System.out.println(new StringBuffer().append(" Caching image for module ").append(i8).toString());
                        }
                        int sizeX2 = GetModuleWidth(i8);
                        int sizeY2 = GetModuleHeight(i8);
                        if (sizeX2 > 0 && sizeY2 > 0) {
                            short[] backupTemp = temp_short;
                            try {
                                try {
                                    int dim = (sizeX2 * (sizeY2 + 1)) + 10;
                                    temp_short = new short[dim];
                                    short[] image_data2 = DecodeImage_short(i8);
                                    if (image_data2 == null) {
                                        temp_short = backupTemp;
                                    } else {
                                        this._modules_image_shortAAA[pal][i8] = image_data2;
                                        temp_short = backupTemp;
                                    }
                                } catch (Throwable th) {
                                    temp_short = backupTemp;
                                    throw th;
                                }
                            } catch (Throwable e) {
                                e.printStackTrace();
                                temp_short = backupTemp;
                            }
                        }
                    }
                }
                if (!GLLibConfig.sprite_useDeactivateSystemGc && s_gcEnabled) {
                    System.gc();
                }
                this._crt_pal = old_pal3;
            }
        }
        if (GLLibConfig.sprite_useSingleImageForAllModules && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_SINGLE_IMAGE) != 0)) {
            try {
                if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
                    if (this._module_image_intAAA[pal] == null) {
                        this._module_image_intAAA[pal] = new int[1];
                    }
                } else if (this._module_image_imageAA[pal] == null) {
                    this._module_image_imageAA[pal] = new Image[1];
                }
                int _PLTE_size = (this._colors * 3) + 4;
                int _TRNS_size = this._colors + 4;
                System.arraycopy(this._pal_data, pal * (_PLTE_size + _TRNS_size), this._modules_data, 41, _PLTE_size);
                System.arraycopy(this._pal_data, (pal * (_PLTE_size + _TRNS_size)) + _PLTE_size, this._modules_data, 41 + _PLTE_size + 8, _TRNS_size);
                if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
                    this._module_image_intAAA[pal][0] = new int[this._modules_data.length];
                    System.arraycopy(this._modules_data, 0, this._module_image_intAAA[pal][0], 0, this._modules_data.length);
                    if (GLLibConfig.sprite_debugUsedMemory) {
                        _images_count++;
                        _images_size += this._modules_data.length;
                    }
                } else {
                    this._module_image_imageAA[pal][0] = GLLib.CreateImage(this._modules_data, 0, this._modules_data.length);
                    if (GLLibConfig.sprite_debugUsedMemory) {
                        _images_count++;
                        _images_size += this._module_image_imageAA[pal][0].getWidth() * this._module_image_imageAA[pal][0].getHeight();
                    }
                }
            } catch (Throwable e2) {
                GLLib.Dbg(new StringBuffer().append("exception ").append(e2).toString());
            }
        }
        if (GLLibConfig.sprite_useDeactivateSystemGc || !s_gcEnabled) {
            return;
        }
        System.gc();
    }

    void BuildFrameCacheImages(int palette, int frame) {
        int numModules = GetFModules(frame);
        for (int m = 0; m < numModules; m++) {
            int moduleId = GetFrameModule(frame, m);
            int fm_flags = GetFrameModuleFlags(frame, m);
            if (GLLibConfig.sprite_useHyperFM && (fm_flags & 16) != 0) {
                BuildFrameCacheImages(palette, moduleId);
            } else {
                int modulePal = palette;
                if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_FM_PALETTE) != 0)) {
                    modulePal = GetFrameModulePalette(frame, m);
                }
                if (GetModuleImage(moduleId, modulePal) == null) {
                    BuildCacheImages(modulePal, moduleId, moduleId, -1);
                }
            }
        }
    }

    void BuildAnimCacheImages(int palette, int anim) {
        int numFrames = GetAFrames(anim);
        for (int f = 0; f < numFrames; f++) {
            int frameId = GetAnimFrame(anim, f);
            BuildFrameCacheImages(palette, frameId);
        }
    }

    void SetModuleImage(Image pImg, int nModule, int nPalette) {
        if (this._module_image_imageAA != null) {
            if (nPalette >= 0 && nPalette < this._module_image_imageAA.length && this._module_image_imageAA[nPalette] != null && nModule >= 0 && nModule < this._module_image_imageAA[nPalette].length) {
                this._module_image_imageAA[nPalette][nModule] = pImg;
                return;
            }
            return;
        }
        if (this._module_image_imageAAA != null && nPalette >= 0 && nPalette < this._module_image_imageAAA.length && this._module_image_imageAAA[nPalette] != null && nModule >= 0 && nModule < this._module_image_imageAAA[nPalette].length) {
            this._module_image_imageAAA[nPalette][nModule][0] = pImg;
        }
    }

    void SetModuleImagesArray(Object pData) {
        if (GLLibConfig.sprite_useNokiaUI) {
            this._modules_image_shortAAA = (short[][][]) pData;
        } else if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
            this._module_image_intAAA = (int[][][]) pData;
        } else {
            this._module_image_imageAA = (Image[][]) pData;
        }
    }

    Object GetModuleImagesArray() {
        if (GLLibConfig.sprite_useNokiaUI) {
            return this._modules_image_shortAAA;
        }
        if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
            return this._module_image_intAAA;
        }
        return this._module_image_imageAA;
    }

    void SetModuleImagesArray(ASprite sprite) {
        if (GLLibConfig.sprite_useManualCacheRGBArrays) {
        }
        SetModuleImagesArray(sprite.GetModuleImagesArray());
    }

    void FreeModuleImage(int nPal, int nMod) {
        if (GLLibConfig.sprite_useNokiaUI) {
            if (this._modules_image_shortAAA != null && nPal < this._modules_image_shortAAA.length) {
                if (nMod == -1) {
                    this._modules_image_shortAAA[nPal] = (short[][]) null;
                    return;
                } else {
                    if (this._modules_image_shortAAA[nPal] != null) {
                        this._modules_image_shortAAA[nPal][nMod] = null;
                        return;
                    }
                    return;
                }
            }
            return;
        }
        if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
            if (this._module_image_intAAA != null && nPal < this._module_image_intAAA.length) {
                if (nMod == -1) {
                    this._module_image_intAAA[nPal] = (int[][]) null;
                    return;
                } else {
                    if (this._module_image_intAAA[nPal] != null) {
                        this._module_image_intAAA[nPal][nMod] = null;
                        return;
                    }
                    return;
                }
            }
            return;
        }
        if (GLLibConfig.sprite_useDynamicPng) {
            if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                if (this._module_image_imageAAA != null && nPal < this._module_image_imageAAA.length) {
                    if (nMod == -1) {
                        this._module_image_imageAAA[nPal] = (Image[][]) null;
                        return;
                    } else {
                        if (this._module_image_imageAAA[nPal] != null) {
                            this._module_image_imageAAA[nPal][nMod] = null;
                            return;
                        }
                        return;
                    }
                }
                return;
            }
            if (this._module_image_imageAA != null && nPal < this._module_image_imageAA.length) {
                if (nMod == -1) {
                    this._module_image_imageAA[nPal] = null;
                    return;
                } else {
                    if (this._module_image_imageAA[nPal] != null) {
                        this._module_image_imageAA[nPal][nMod] = null;
                        return;
                    }
                    return;
                }
            }
            return;
        }
        if (this._module_image_imageAA != null && nPal < this._module_image_imageAA.length) {
            if (nMod == -1) {
                this._module_image_imageAA[nPal] = null;
            } else if (this._module_image_imageAA[nPal] != null) {
                this._module_image_imageAA[nPal][nMod] = null;
            }
        }
    }

    void FreeFrameCacheImages(int palette, int frame) {
        int numModules = GetFModules(frame);
        for (int m = 0; m < numModules; m++) {
            int moduleId = GetFrameModule(frame, m);
            int fm_flags = GetFrameModuleFlags(frame, m);
            if (GLLibConfig.sprite_useHyperFM && (fm_flags & 16) != 0) {
                FreeFrameCacheImages(palette, moduleId);
            } else {
                int modulePal = palette;
                if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_FM_PALETTE) != 0)) {
                    modulePal = GetFrameModulePalette(frame, m);
                }
                if (GetModuleImage(moduleId, modulePal) != null) {
                    FreeModuleImage(modulePal, moduleId);
                }
            }
        }
    }

    void FreeAnimCacheImages(int palette, int anim) {
        int numFrames = GetAFrames(anim);
        for (int f = 0; f < numFrames; f++) {
            int frameId = GetAnimFrame(anim, f);
            FreeFrameCacheImages(palette, frameId);
        }
    }

    void FreeMemory() {
        if (GLLibConfig.sprite_usePrecomputedCRC) {
            if (GLLibConfig.sprite_useNokiaUI) {
                this._pal_short = (short[][]) null;
            } else {
                this._pal_int = (int[][]) null;
            }
            this._transp = (byte[][]) null;
            this._modules_data = null;
            if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                this._modules_data_off_short = null;
            } else {
                this._modules_data_off_int = null;
            }
            this._PNG_packed_PLTE_CRC = null;
            this._PNG_packed_IHDR_CRC = null;
            this._PNG_packed_IDAT_CRC = null;
            this._PNG_packed_IDAT_ADLER = null;
            this._PNG_packed_tRNS_CRC = null;
            if (GLLibConfig.sprite_useMultipleModuleTypes) {
                this._module_types = null;
                if (GLLibConfig.sprite_useModuleColorAsByte) {
                    this._module_colors_byte = null;
                } else {
                    this._module_colors_int = null;
                }
            }
        }
    }

    private int GetModuleExtraInfoOffset(int module) {
        if (this._modules_extra_pointer != null) {
            for (int i = 0; i < this._modules_extra_pointer.length; i += 2) {
                if (this._modules_extra_pointer[i] == module) {
                    return this._modules_extra_pointer[i + 1];
                }
            }
            return -1;
        }
        return -1;
    }

    void PaintModule(Graphics g, int module, int posX, int posY, int flags) {
        int nTmpFlag;
        if (GLLibConfig.sprite_useModuleMapping && this._cur_map >= 0) {
            module = this._map[this._cur_map][module];
        }
        int sizeX = GetModuleWidth(module);
        int sizeY = GetModuleHeight(module);
        int noneRotatedSizeX = GetModuleWidth(module);
        int noneRotatedSizeY = GetModuleHeight(module);
        if ((flags & 4) != 0) {
            sizeX = sizeY;
            sizeY = sizeX;
        }
        if (GLLibConfig.sprite_useMultipleModuleTypes && this._module_types[module] != 0 && g != null) {
            if (GLLibConfig.sprite_useModuleColorAsByte) {
                g.setColor(this._module_colors_byte[module]);
            } else {
                g.setColor(this._module_colors_int[module]);
            }
            switch (this._module_types[module]) {
                case 1:
                    g.drawRect(posX, posY, sizeX, sizeY);
                    break;
                case 2:
                    if (GLLibConfig.sprite_useModuleColorAsByte) {
                        g.fillRect(posX, posY, sizeX, sizeY);
                        break;
                    } else if ((this._module_colors_int[module] & (-16777216)) == -16777216 || (this._module_colors_int[module] & (-16777216)) == 0) {
                        g.fillRect(posX, posY, sizeX, sizeY);
                        break;
                    } else {
                        GLLib.AlphaRect_SetColor(this._module_colors_int[module]);
                        GLLib.AlphaRect_Draw(g, posX, posY, sizeX, sizeY);
                        break;
                    }
                    break;
                case 3:
                case 4:
                    int nOffset = GetModuleExtraInfoOffset(module);
                    if (nOffset != -1) {
                        short s = this._modules_extra_info[nOffset + 0];
                        short s2 = this._modules_extra_info[nOffset + 1];
                        if (this._module_types[module] == 3) {
                            g.drawArc(posX, posY, GetModuleWidth(module), GetModuleHeight(module), s, s2);
                            break;
                        } else {
                            g.fillArc(posX, posY, GetModuleWidth(module), GetModuleHeight(module), s, s2);
                            break;
                        }
                    }
                    break;
                case 6:
                case 7:
                    int nOffset2 = GetModuleExtraInfoOffset(module);
                    if (nOffset2 != -1) {
                        short s3 = this._modules_extra_info[nOffset2 + 0];
                        short s4 = this._modules_extra_info[nOffset2 + 1];
                        short s5 = this._modules_extra_info[nOffset2 + 2];
                        short s6 = this._modules_extra_info[nOffset2 + 3];
                        if (this._module_types[module] == 6) {
                            g.drawLine(posX, posY, posX + s3, posY + s4);
                            g.drawLine(posX + s3, posY + s4, posX + s5, posY + s6);
                            g.drawLine(posX, posY, posX + s5, posY + s6);
                            break;
                        } else {
                            g.fillTriangle(posX, posY, posX + s3, posY + s4, posX + s5, posY + s6);
                            break;
                        }
                    }
                    break;
            }
            return;
        }
        if (GLLibConfig.sprite_useOperationMark && _operation == 3) {
            byte[] bArr = this._modules_usage;
            int i = module;
            bArr[i] = (byte) (bArr[i] | (1 << (flags & 7)));
            return;
        }
        if (GLLibConfig.sprite_useOperationRect) {
            if (_operation == 1) {
                if (posX < _rectX1) {
                    _rectX1 = posX;
                }
                if (posY < _rectY1) {
                    _rectY1 = posY;
                }
                if (posX + sizeX > _rectX2) {
                    _rectX2 = posX + sizeX;
                }
                if (posY + sizeY > _rectY2) {
                    _rectY2 = posY + sizeY;
                    return;
                }
                return;
            }
        } else if (_operation == 1) {
        }
        if (GLLibConfig.sprite_useDynamicPaletteBlendingCache && this._crt_pal == this._palBlend_dest && this._palBlend_ModuleState != null && this._palBlend_ModuleState[module] != ((byte) this._palBlend_current)) {
            boolean saveTmp = s_gcEnabled;
            s_gcEnabled = false;
            BuildCacheImages(this._crt_pal, module, module, -1);
            s_gcEnabled = saveTmp;
            this._palBlend_ModuleState[module] = (byte) this._palBlend_current;
        }
        if (GLLibConfig.sprite_useDynamicPng) {
            if ((flags & 4) != 0) {
                int tmp = sizeX;
                sizeX = sizeY;
                sizeY = tmp;
            }
            if (GLLibConfig.sprite_useSingleImageForAllModules && (this._bs_flags & BS_SINGLE_IMAGE) != 0) {
                if (sizeX <= 0 || sizeY <= 0) {
                    return;
                }
                int cx = g.getClipX();
                int cy = g.getClipY();
                int cw = g.getClipWidth();
                int ch = g.getClipHeight();
                int new_cx = posX;
                int new_cy = posY;
                int new_endcx = posX + sizeX;
                int new_endcy = posY + sizeY;
                if (posX < cx) {
                    new_cx = cx;
                }
                if (posY < cy) {
                    new_cy = cy;
                }
                if (new_endcx > cx + cw) {
                    new_endcx = cx + cw;
                }
                if (new_endcy > cy + ch) {
                    new_endcy = cy + ch;
                }
                if (!GLLibConfig.sprite_fpsRegion) {
                    g.setClip(new_cx, new_cy, new_endcx - new_cx, new_endcy - new_cy);
                }
                if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                    if (GLLibConfig.sprite_useModuleXY) {
                        if (CheckOperation(this._module_image_imageAAA[this._crt_pal][0][0], posX, posY, sizeX, sizeY, 0, this._modules_x_byte[module] & 255, this._modules_y_byte[module] & 255)) {
                            g.drawImage(this._module_image_imageAAA[this._crt_pal][0][0], posX - (this._modules_x_byte[module] & 255), posY - (this._modules_y_byte[module] & 255), 0);
                        }
                    } else if (GLLibConfig.sprite_useModuleXYShort && CheckOperation(this._module_image_imageAAA[this._crt_pal][0][0], posX, posY, sizeX, sizeY, 0, this._modules_x_short[module], this._modules_y_short[module])) {
                        g.drawImage(this._module_image_imageAAA[this._crt_pal][0][0], posX - this._modules_x_short[module], posY - this._modules_y_short[module], 0);
                    }
                } else if (!GLLibConfig.sprite_fpsRegion) {
                    if (GLLibConfig.sprite_useModuleXY) {
                        if (CheckOperation(this._module_image_imageAA[this._crt_pal][0], posX, posY, sizeX, sizeY, 0, this._modules_x_byte[module] & 255, this._modules_y_byte[module] & 255)) {
                            g.drawImage(this._module_image_imageAA[this._crt_pal][0], posX - (this._modules_x_byte[module] & 255), posY - (this._modules_y_byte[module] & 255), 0);
                        }
                    } else if (GLLibConfig.sprite_useModuleXYShort && CheckOperation(this._module_image_imageAA[this._crt_pal][0], posX, posY, sizeX, sizeY, 0, this._modules_x_short[module], this._modules_y_short[module])) {
                        g.drawImage(this._module_image_imageAA[this._crt_pal][0], posX - this._modules_x_short[module], posY - this._modules_y_short[module], 0);
                    }
                } else if (GLLibConfig.sprite_useModuleXY) {
                    if (CheckOperation(this._module_image_imageAA[this._crt_pal][0], posX, posY, sizeX, sizeY, 0, this._modules_x_byte[module] & 255, this._modules_y_byte[module] & 255) && !GLLibConfig.sprite_drawRegionFlippedBug) {
                        g.drawRegion(this._module_image_imageAA[this._crt_pal][0], this._modules_x_byte[module] & 255, this._modules_y_byte[module] & 255, sizeX, sizeY, 0, posX, posY, 0);
                    }
                } else if (GLLibConfig.sprite_useModuleXYShort && CheckOperation(this._module_image_imageAA[this._crt_pal][0], posX, posY, sizeX, sizeY, 0, this._modules_x_short[module], this._modules_y_short[module]) && !GLLibConfig.sprite_drawRegionFlippedBug) {
                    g.drawRegion(this._module_image_imageAA[this._crt_pal][0], this._modules_x_short[module], this._modules_y_short[module], sizeX, sizeY, 0, posX, posY, 0);
                }
                if (!GLLibConfig.sprite_fpsRegion) {
                    g.setClip(cx, cy, cw, ch);
                    return;
                }
                return;
            }
            if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                if (GLLibConfig.sprite_usePrecomputedCRC && GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & BS_PNG_CRC) != 0) {
                    nTmpFlag = 0;
                } else {
                    nTmpFlag = flags;
                }
                Image img = null;
                if (nTmpFlag < this._module_image_imageAAA[this._crt_pal][module].length) {
                    img = this._module_image_imageAAA[this._crt_pal][module][nTmpFlag];
                }
                if (img == null) {
                    img = BuildPNG8(this._crt_pal, false, module, sizeX, sizeY, nTmpFlag);
                }
                if (CheckOperation(img, posX, posY, sizeX, sizeY, 0, 0, 0)) {
                    g.drawImage(img, posX, posY, 0);
                    return;
                }
                return;
            }
            if (GLLibConfig.sprite_usePrecomputedCRC && GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & BS_PNG_CRC) != 0) {
                Image img2 = this._module_image_imageAA[this._crt_pal][module];
                if (img2 == null) {
                    img2 = BuildPNG8(this._crt_pal, false, module, sizeX, sizeY, 0);
                }
                if (CheckOperation(img2, posX, posY, sizeX, sizeY, 0, 0, 0)) {
                    g.drawImage(img2, posX, posY, 0);
                    return;
                }
                return;
            }
            if (GLLibConfig.sprite_useLoadImageWithoutTransf) {
                if (CheckOperation(this._module_image_imageAA[this._crt_pal][module], posX, posY, sizeX, sizeY, midp2_flags[flags & 7], 0, 0)) {
                    if (midp2_flags[flags & 7] == 0) {
                        g.drawImage(this._module_image_imageAA[this._crt_pal][module], posX, posY, 0);
                        return;
                    } else {
                        if (!GLLibConfig.sprite_drawRegionFlippedBug) {
                            g.drawRegion(this._module_image_imageAA[this._crt_pal][module], 0, 0, sizeX, sizeY, midp2_flags[flags & 7], posX, posY, 0);
                            return;
                        }
                        return;
                    }
                }
                return;
            }
            if (CheckOperation(this._module_image_imageAA[this._crt_pal][module], posX, posY, sizeX, sizeY, 0, 0, 0)) {
                g.drawImage(this._module_image_imageAA[this._crt_pal][module], posX, posY, 0);
                return;
            }
            return;
        }
        if (sizeX <= 0 || sizeY <= 0) {
            return;
        }
        if (!GLLibConfig.sprite_useSkipFastVisibilityTest && g != null) {
            int cx2 = g.getClipX();
            int cy2 = g.getClipY();
            int cw2 = g.getClipWidth();
            int ch2 = g.getClipHeight();
            if (posX + sizeX < cx2 || posY + sizeY < cy2 || posX >= cx2 + cw2 || posY >= cy2 + ch2) {
                return;
            }
        }
        int[] img_intA = null;
        Image img_image = null;
        if (GLLibConfig.sprite_useSingleImageForAllModules && ((!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_SINGLE_IMAGE) != 0) && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_SINGLE_IMAGE) != 0))) {
            if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
                if (this._module_image_intAAA == null || this._module_image_intAAA[this._crt_pal] == null) {
                    BuildCacheImages(this._crt_pal, 0, 0, 0);
                }
                if (CheckOperation(this._module_image_intAAA[this._crt_pal][0], posX, posY, sizeX, sizeY, 0, 0, 0)) {
                    GLLib.DrawRGB(g, this._module_image_intAAA[this._crt_pal][0], 0, sizeX, posX, posY, sizeX, sizeY, this._alpha);
                }
            } else {
                if (this._module_image_imageAA == null || this._module_image_imageAA[this._crt_pal] == null) {
                    BuildCacheImages(this._crt_pal, 0, 0, 0);
                }
                int img_x = 0;
                int img_y = 0;
                if (GLLibConfig.sprite_useModuleXYShort && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 32) != 0)) {
                    img_x = this._modules_x_short[module];
                    img_y = this._modules_y_short[module];
                } else if (GLLibConfig.sprite_useModuleXY && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 2) != 0)) {
                    img_x = this._modules_x_byte[module] & 255;
                    img_y = this._modules_y_byte[module] & 255;
                }
                if (GLLibConfig.sprite_useCacheFlipXY) {
                    int selected = midp2_flags[flags & 7];
                    if (selected > 2) {
                        selected = 0;
                    }
                    img_image = this._module_image_imageAA[this._crt_pal][selected];
                    if (midp2_flags[flags & 7] == 2) {
                        img_x = img_image.getWidth() - (img_x + sizeX);
                    } else if (midp2_flags[flags & 7] == 1) {
                        img_y = img_image.getHeight() - (img_y + sizeY);
                    }
                } else {
                    img_image = this._module_image_imageAA[this._crt_pal][0];
                }
                if (GLLibConfig.sprite_useDrawRegionClipping) {
                    int cx3 = g.getClipX();
                    int cy3 = g.getClipY();
                    int cw3 = g.getClipWidth();
                    int ch3 = g.getClipHeight();
                    int new_cx2 = posX;
                    int new_cy2 = posY;
                    int new_endcx2 = posX + sizeX;
                    int new_endcy2 = posY + sizeY;
                    if (posX < cx3) {
                        new_cx2 = cx3;
                    }
                    if (posY < cy3) {
                        new_cy2 = cy3;
                    }
                    if (new_endcx2 > cx3 + cw3) {
                        new_endcx2 = cx3 + cw3;
                    }
                    if (new_endcy2 > cy3 + ch3) {
                        new_endcy2 = cy3 + ch3;
                    }
                    g.setClip(new_cx2, new_cy2, new_endcx2 - new_cx2, new_endcy2 - new_cy2);
                    if (CheckOperation(img_image, posX, posY, sizeX, sizeY, 0, img_x, img_y)) {
                        g.drawImage(img_image, posX - img_x, posY - img_y, 0);
                    }
                    g.setClip(cx3, cy3, cw3, ch3);
                } else if (CheckOperation(img_image, posX, posY, sizeX, sizeY, midp2_flags[flags & 7], img_x, img_y) && !GLLibConfig.sprite_drawRegionFlippedBug) {
                    g.drawRegion(img_image, img_x, img_y, sizeX, sizeY, midp2_flags[flags & 7], posX, posY, 0);
                }
            }
        }
        if (GLLibConfig.sprite_useExternImage) {
            if (this._main_image != null && this._main_image[this._crt_pal] != null) {
                img_image = this._main_image[this._crt_pal];
            }
            if (img_image != null) {
                int img_x2 = 0;
                int img_y2 = 0;
                if (GLLibConfig.sprite_useModuleXY) {
                    img_x2 = this._modules_x_byte[module] & 255;
                    img_y2 = this._modules_y_byte[module] & 255;
                } else if (GLLibConfig.sprite_useModuleXYShort) {
                    img_x2 = this._modules_x_short[module];
                    img_y2 = this._modules_y_short[module];
                }
                if (CheckOperation(img_image, posX, posY, sizeX, sizeY, midp2_flags[flags & 7], img_x2, img_y2) && !GLLibConfig.sprite_drawRegionFlippedBug) {
                    g.drawRegion(img_image, img_x2, img_y2, sizeX, sizeY, midp2_flags[flags & 7], posX, posY, 0);
                }
            }
        }
        if (GLLibConfig.sprite_ModuleMapping_useModuleImages) {
            if ((!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_MODULE_IMAGES) != 0) && !GLLibConfig.sprite_useNokiaUI) {
                if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & BS_MODULE_IMAGES) != 0) {
                    if (this._module_image_imageAA != null && this._module_image_imageAA[this._crt_pal] != null) {
                        img_image = this._module_image_imageAA[this._crt_pal][module];
                    }
                    if (this._module_image_intAAA != null && this._module_image_intAAA[this._crt_pal] != null) {
                        img_intA = this._module_image_intAAA[this._crt_pal][module];
                    }
                    if (GLLibConfig.sprite_useDynamicPng && GLLibConfig.sprite_usePrecomputedCRC) {
                        if (img_image == null) {
                            img_image = BuildPNG8(this._crt_pal, false, DecodeImage_byte(module), sizeX, sizeY, 0);
                            if (GLLibConfig.sprite_debugUsedMemory) {
                                _images_count++;
                                _images_size += img_image.getWidth() * img_image.getHeight();
                            }
                        }
                        if (img_image == null) {
                            return;
                        }
                        if (CheckOperation(img_image, posX, posY, img_image.getWidth(), img_image.getHeight(), 0, 0, 0)) {
                            g.drawImage(img_image, posX, posY, 0);
                            return;
                        }
                        return;
                    }
                    boolean hasAlpha = this._alpha;
                    if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
                        if (img_intA == null) {
                            img_intA = DecodeImage_int(module);
                        }
                        if (GLLibConfig.pfx_useSpriteEffects && (GLLib.m_PFX_type & GLPixEffects.k_EFFECTS_SPRITE_MASK) != 0) {
                            img_intA = GLLib.PFX_ProcessSpriteEffects(img_intA, posX, posY, noneRotatedSizeX, noneRotatedSizeY, flags, hasAlpha, this._multiAlpha);
                            hasAlpha = GLLib.m_PFX_hasAlpha;
                            sizeX = GLLib.m_PFX_sizeX;
                            sizeY = GLLib.m_PFX_sizeY;
                        } else if (flags != 0) {
                            img_intA = TransformRGB(img_intA, sizeX, sizeY, flags);
                        }
                        if (CheckOperation(img_intA, posX, posY, sizeX, sizeY, 0, 0, 0)) {
                            GLLib.DrawRGB(g, img_intA, 0, sizeX, posX, posY, sizeX, sizeY, hasAlpha);
                            return;
                        }
                        return;
                    }
                    if (img_image == null) {
                        int[] image_data = DecodeImage_int(module);
                        if (image_data == null) {
                            if (GLLibConfig.sprite_debugErrors) {
                                System.out.println("DecodeImage() FAILED !");
                                return;
                            }
                            return;
                        }
                        if (GLLibConfig.sprite_RGBArraysUseDrawRGB || (GLLibConfig.pfx_useSpriteEffects && (GLLib.m_PFX_type & GLPixEffects.k_EFFECTS_SPRITE_MASK) != 0)) {
                            if (GLLibConfig.pfx_useSpriteEffects && (GLLib.m_PFX_type & GLPixEffects.k_EFFECTS_SPRITE_MASK) != 0) {
                                image_data = GLLib.PFX_ProcessSpriteEffects(image_data, posX, posY, noneRotatedSizeX, noneRotatedSizeY, flags, hasAlpha, this._multiAlpha);
                                hasAlpha = GLLib.m_PFX_hasAlpha;
                                sizeX = GLLib.m_PFX_sizeX;
                                sizeY = GLLib.m_PFX_sizeY;
                            } else if (flags != 0) {
                                image_data = TransformRGB(image_data, sizeX, sizeY, flags);
                            }
                            GLLib.DrawRGB(g, image_data, 0, sizeX, posX, posY, sizeX, sizeY, hasAlpha);
                            return;
                        }
                        if ((flags & 4) != 0) {
                            img_image = GLLib.CreateRGBImage(image_data, sizeY, sizeX, this._alpha);
                        } else {
                            img_image = GLLib.CreateRGBImage(image_data, sizeX, sizeY, this._alpha);
                        }
                    }
                    if (GLLibConfig.pfx_useSpriteEffects && (GLLib.m_PFX_type & GLPixEffects.k_EFFECTS_SPRITE_MASK) != 0) {
                        int[] image_data2 = GLLib.PFX_ProcessSpriteEffects(img_image, posX, posY, noneRotatedSizeX, noneRotatedSizeY, flags, hasAlpha, this._multiAlpha);
                        boolean hasAlpha2 = GLLib.m_PFX_hasAlpha;
                        int sizeX2 = GLLib.m_PFX_sizeX;
                        GLLib.DrawRGB(g, image_data2, 0, sizeX2, posX, posY, sizeX2, GLLib.m_PFX_sizeY, hasAlpha2);
                        return;
                    }
                    int sizeX3 = img_image.getWidth();
                    int sizeY2 = img_image.getHeight();
                    UpdatePoolCache(module, img_image);
                    if (CheckOperation(img_image, posX, posY, sizeX3, sizeY2, midp2_flags[flags & 7], 0, 0)) {
                        if (midp2_flags[flags & 7] == 0) {
                            g.drawImage(img_image, posX, posY, 0);
                        } else if (!GLLibConfig.sprite_drawRegionFlippedBug) {
                            g.drawRegion(img_image, 0, 0, sizeX3, sizeY2, midp2_flags[flags & 7], posX, posY, 0);
                        }
                    }
                }
            }
        }
    }

    static {
        InitCrcTable();
        mResizeRef = 0;
        _index1 = -1;
        _index2 = -1;
        _indexMax = -1;
        record_index = -1;
        record_frame = -1;
        _operation = 0;
        mem = 0;
        midp2_flags = new int[]{0, 2, 1, 3, 5, 7, 4, 6};
        s_rc = new int[4];
        s_gcEnabled = true;
    }

    private static void InitCrcTable() {
        int i;
        if (GLLibConfig.sprite_useDynamicPng) {
            _png_result = new byte[GLLibConfig.PNG_BUFFER_SIZE];
            for (int i2 = 0; i2 < BS_FRAMES; i2++) {
                int crc = i2;
                for (int j = 8; j > 0; j--) {
                    if ((crc & 1) == 1) {
                        i = (crc >>> 1) ^ CRC32_POLYNOMIAL;
                    } else {
                        i = crc >>> 1;
                    }
                    crc = i;
                }
                crcTable[i2] = crc;
            }
        }
    }

    private static void PutArray(byte[] array) {
        if (GLLibConfig.sprite_useDynamicPng) {
            System.arraycopy(array, 0, _png_result, _png_size, array.length);
            _png_size += array.length;
        }
    }

    private static void PutInt(int n) {
        if (GLLibConfig.sprite_useDynamicPng) {
            byte[] bArr = _png_result;
            int i = _png_size;
            _png_size = i + 1;
            bArr[i] = (byte) ((n >> 24) & 255);
            byte[] bArr2 = _png_result;
            int i2 = _png_size;
            _png_size = i2 + 1;
            bArr2[i2] = (byte) ((n >> 16) & 255);
            byte[] bArr3 = _png_result;
            int i3 = _png_size;
            _png_size = i3 + 1;
            bArr3[i3] = (byte) ((n >> 8) & 255);
            byte[] bArr4 = _png_result;
            int i4 = _png_size;
            _png_size = i4 + 1;
            bArr4[i4] = (byte) (n & 255);
        }
    }

    private void BeginChunk(byte[] name, int len) {
        if (GLLibConfig.sprite_useDynamicPng) {
            PutInt(len);
            _png_start_crc = _png_size;
            PutArray(name);
        }
    }

    private void EndChunk() {
        if (GLLibConfig.sprite_useDynamicPng) {
            if (GLLibConfig.sprite_usePrecomputedCRC) {
                if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & BS_PNG_CRC) == 0) {
                    PutInt(Crc32(_png_result, _png_start_crc, _png_size - _png_start_crc, 0));
                } else {
                    switch (currentChunkType) {
                        case 0:
                            PutInt(this._PNG_packed_IHDR_CRC[mod]);
                            break;
                        case 1:
                            PutInt(this._PNG_packed_PLTE_CRC[this._cur_pal]);
                            break;
                        case 2:
                            PutInt(this._PNG_packed_tRNS_CRC[this._cur_pal]);
                            break;
                        case 3:
                            PutInt(this._PNG_packed_IDAT_CRC[mod]);
                            break;
                    }
                }
                currentChunkType++;
                return;
            }
            PutInt(Crc32(_png_result, _png_start_crc, _png_size - _png_start_crc, 0));
        }
    }

    private Image BuildPNG8(int pal, boolean bPalInited, int module, int width, int height, int flags) {
        if (GLLibConfig.sprite_useDynamicPng) {
            mod = module;
            return BuildPNG8(pal, bPalInited, DecodeImage_byte(module), width, height, flags);
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private Image BuildPNG8(int pal, boolean bPalInited, byte[] data, int width, int height, int flags) {
        int ssize;
        short s;
        if (GLLibConfig.sprite_useDynamicPng) {
            if (GLLibConfig.sprite_usePrecomputedCRC) {
                this._cur_pal = pal;
                currentChunkType = 0;
            }
            int i = _png_size;
            if (width == 0 || height == 0) {
                return null;
            }
            if (GLLibConfig.sprite_useTransfRot && (flags & 4) != 0) {
                width = height;
                height = width;
            }
            _png_size = 0;
            PutArray(MAGIC);
            BeginChunk(IHDR, 13);
            PutInt(width);
            PutInt(height);
            PutArray(INFO8);
            EndChunk();
            if (bPalInited) {
                if (GLLibConfig.sprite_useNokiaUI) {
                    _png_size += 12 + (this._pal_short[pal].length * 3);
                    if (this._alpha) {
                        _png_size += 12 + this._pal_short[pal].length;
                    }
                } else {
                    _png_size += 12 + (this._pal_int[pal].length * 3);
                    if (this._alpha) {
                        _png_size += 12 + this._pal_int[pal].length;
                    }
                }
                if (GLLibConfig.sprite_usePrecomputedCRC) {
                    currentChunkType++;
                    currentChunkType++;
                }
            } else {
                if (GLLibConfig.sprite_useNokiaUI) {
                    ssize = this._pal_short[pal].length;
                } else {
                    ssize = this._pal_int[pal].length;
                }
                BeginChunk(PLTE, ssize * 3);
                for (int i2 = 0; i2 < ssize; i2++) {
                    if (GLLibConfig.sprite_useNokiaUI) {
                        s = this._pal_short[pal][i2];
                    } else {
                        s = this._pal_int[pal][i2];
                    }
                    int pixel = s;
                    byte[] bArr = _png_result;
                    int i3 = _png_size;
                    _png_size = i3 + 1;
                    bArr[i3] = (byte) ((pixel & 16711680) >>> 16);
                    byte[] bArr2 = _png_result;
                    int i4 = _png_size;
                    _png_size = i4 + 1;
                    bArr2[i4] = (byte) ((pixel & 65280) >>> 8);
                    byte[] bArr3 = _png_result;
                    int i5 = _png_size;
                    _png_size = i5 + 1;
                    bArr3[i5] = (byte) (pixel & 255);
                }
                EndChunk();
                if (this._alpha) {
                    BeginChunk(tRNS, ssize);
                    for (int i6 = 0; i6 < ssize; i6++) {
                        if (GLLibConfig.sprite_useNokiaUI) {
                            byte[] bArr4 = _png_result;
                            int i7 = _png_size;
                            _png_size = i7 + 1;
                            bArr4[i7] = (byte) ((this._pal_short[pal][i6] & (-16777216)) >>> 24);
                        } else {
                            byte[] bArr5 = _png_result;
                            int i8 = _png_size;
                            _png_size = i8 + 1;
                            bArr5[i8] = (byte) ((this._pal_int[pal][i6] & (-16777216)) >>> 24);
                        }
                    }
                    EndChunk();
                }
            }
            int data_size = (width * height) + height;
            BeginChunk(IDAT, data_size + 11);
            System.arraycopy(MAGIC_IDAT_h, 0, _png_result, _png_size, 3);
            _png_size += 3;
            byte[] bArr6 = _png_result;
            int i9 = _png_size;
            _png_size = i9 + 1;
            bArr6[i9] = (byte) (data_size & 255);
            byte[] bArr7 = _png_result;
            int i10 = _png_size;
            _png_size = i10 + 1;
            bArr7[i10] = (byte) ((data_size & 65280) >> 8);
            byte[] bArr8 = _png_result;
            int i11 = _png_size;
            _png_size = i11 + 1;
            bArr8[i11] = (byte) ((data_size ^ (-1)) & 255);
            byte[] bArr9 = _png_result;
            int i12 = _png_size;
            _png_size = i12 + 1;
            bArr9[i12] = (byte) (((data_size ^ (-1)) & 65280) >> 8);
            int start_block = _png_size;
            switch (flags & 7) {
                case 0:
                    for (int j = 0; j < height; j++) {
                        byte[] bArr10 = _png_result;
                        int i13 = _png_size;
                        _png_size = i13 + 1;
                        bArr10[i13] = 0;
                        System.arraycopy(data, j * width, _png_result, _png_size, width);
                        _png_size += width;
                    }
                    break;
                case 1:
                    if (GLLibConfig.sprite_useTransfFlip) {
                        for (int j2 = 0; j2 < height; j2++) {
                            int offset = (j2 + 1) * width;
                            byte[] bArr11 = _png_result;
                            int i14 = _png_size;
                            _png_size = i14 + 1;
                            bArr11[i14] = 0;
                            for (int i15 = 0; i15 < width; i15++) {
                                byte[] bArr12 = _png_result;
                                int i16 = _png_size;
                                _png_size = i16 + 1;
                                offset--;
                                bArr12[i16] = data[offset];
                            }
                        }
                        break;
                    }
                    break;
                case 2:
                    if (GLLibConfig.sprite_useTransfFlip) {
                        for (int j3 = 0; j3 < height; j3++) {
                            byte[] bArr13 = _png_result;
                            int i17 = _png_size;
                            _png_size = i17 + 1;
                            bArr13[i17] = 0;
                            System.arraycopy(data, ((height - j3) - 1) * width, _png_result, _png_size, width);
                            _png_size += width;
                        }
                        break;
                    }
                    break;
                case 3:
                    if (GLLibConfig.sprite_useTransfFlip) {
                        for (int j4 = 0; j4 < height; j4++) {
                            int offset2 = (height - j4) * width;
                            byte[] bArr14 = _png_result;
                            int i18 = _png_size;
                            _png_size = i18 + 1;
                            bArr14[i18] = 0;
                            for (int i19 = 0; i19 < width; i19++) {
                                byte[] bArr15 = _png_result;
                                int i20 = _png_size;
                                _png_size = i20 + 1;
                                offset2--;
                                bArr15[i20] = data[offset2];
                            }
                        }
                        break;
                    }
                    break;
                case 4:
                    if (GLLibConfig.sprite_useTransfRot) {
                        for (int j5 = 0; j5 < height; j5++) {
                            byte[] bArr16 = _png_result;
                            int i21 = _png_size;
                            _png_size = i21 + 1;
                            bArr16[i21] = 0;
                            for (int i22 = 0; i22 < width; i22++) {
                                byte[] bArr17 = _png_result;
                                int i23 = _png_size;
                                _png_size = i23 + 1;
                                bArr17[i23] = data[(((width - 1) - i22) * height) + j5];
                            }
                        }
                        break;
                    }
                    break;
                case 5:
                    if (GLLibConfig.sprite_useTransfRot && GLLibConfig.sprite_useTransfFlip) {
                        for (int j6 = 0; j6 < height; j6++) {
                            byte[] bArr18 = _png_result;
                            int i24 = _png_size;
                            _png_size = i24 + 1;
                            bArr18[i24] = 0;
                            for (int i25 = 0; i25 < width; i25++) {
                                byte[] bArr19 = _png_result;
                                int i26 = _png_size;
                                _png_size = i26 + 1;
                                bArr19[i26] = data[(((width - 1) - i25) * height) + ((height - 1) - j6)];
                            }
                        }
                        break;
                    }
                    break;
                case 6:
                    if (GLLibConfig.sprite_useTransfRot && GLLibConfig.sprite_useTransfFlip) {
                        for (int j7 = 0; j7 < height; j7++) {
                            byte[] bArr20 = _png_result;
                            int i27 = _png_size;
                            _png_size = i27 + 1;
                            bArr20[i27] = 0;
                            for (int i28 = 0; i28 < width; i28++) {
                                byte[] bArr21 = _png_result;
                                int i29 = _png_size;
                                _png_size = i29 + 1;
                                bArr21[i29] = data[(i28 * height) + j7];
                            }
                        }
                        break;
                    }
                    break;
                case 7:
                    if (GLLibConfig.sprite_useTransfRot && GLLibConfig.sprite_useTransfFlip) {
                        for (int j8 = 0; j8 < height; j8++) {
                            byte[] bArr22 = _png_result;
                            int i30 = _png_size;
                            _png_size = i30 + 1;
                            bArr22[i30] = 0;
                            for (int i31 = 0; i31 < width; i31++) {
                                byte[] bArr23 = _png_result;
                                int i32 = _png_size;
                                _png_size = i32 + 1;
                                bArr23[i32] = data[(i31 * height) + ((height - 1) - j8)];
                            }
                        }
                        break;
                    }
                    break;
            }
            if (GLLibConfig.sprite_usePrecomputedCRC) {
                if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & BS_PNG_CRC) == 0) {
                    long adler = Adler32(1L, _png_result, start_block, data_size);
                    PutInt((int) adler);
                } else {
                    PutInt(this._PNG_packed_IDAT_ADLER[mod]);
                }
            } else {
                long adler2 = Adler32(1L, _png_result, start_block, data_size);
                PutInt((int) adler2);
            }
            EndChunk();
            PutArray(MAGIC_IEND);
            return GLLib.CreateImage(_png_result, 0, _png_size);
        }
        return null;
    }

    public static int Crc32(byte[] buffer, int start, int count, int crc) {
        if (GLLibConfig.sprite_useDynamicPng) {
            int i = crc;
            int i2 = -1;
            while (true) {
                int crc2 = i ^ i2;
                int i3 = count;
                count = i3 - 1;
                if (i3 != 0) {
                    int i4 = start;
                    start++;
                    i = crcTable[(crc2 ^ buffer[i4]) & 255];
                    i2 = crc2 >>> 8;
                } else {
                    return crc2 ^ (-1);
                }
            }
        } else {
            return 0;
        }
    }

    private static long Adler32(long adler, byte[] buf, int index, int len) {
        if (GLLibConfig.sprite_useDynamicPng) {
            long s1 = adler & 65535;
            long j = (adler >> 16) & 65535;
            while (true) {
                long s2 = j;
                if (len > 0) {
                    int k = len < 5552 ? len : NMAX;
                    len -= k;
                    while (true) {
                        int i = k;
                        k = i - 1;
                        if (i > 0) {
                            int i2 = index;
                            index++;
                            s1 += buf[i2] & 255;
                            s2 += s1;
                        }
                    }
                    s1 %= 65521;
                    j = s2 % 65521;
                } else {
                    return (s2 << 16) | s1;
                }
            }
        } else {
            return 0L;
        }
    }

    private int[] DecodeImageAndResize(int module) {
        int[] img_data = DecodeImage_int(module);
        if (s_resizeType == 2) {
        }
        return Resize(null, img_data, GetModuleWidthOrg(module), GetModuleHeightOrg(module), this._modules_w_scaled[module], this._modules_h_scaled[module]);
    }

    private int[] Resize(Graphics g, int[] bTemp, int nTempWidth, int nTempHeight, int nWidth, int nHeight) {
        return bTemp;
    }

    public void SetResizeParameters(int spriteId, int resizeMode, boolean correctY) {
        s_bBilinear = true;
        s_bAspectRatio = true;
        this.mResizeCorrectY = correctY;
        if (mResizeRef == 0) {
            this.wRef = 240;
            this.hRef = 320;
        } else if (mResizeRef == 1) {
            this.wRef = 176;
            this.hRef = 220;
        } else if (mResizeRef == 2) {
            this.wRef = 280;
            this.hRef = 320;
        } else {
            this.wRef = 176;
            this.hRef = 220;
        }
        this.wTarget = GLLib.GetScreenWidth();
        this.hTarget = GLLib.GetScreenHeight();
        s_resizeType = resizeMode;
        if (s_bAspectRatio) {
            this.xRatio = (this.wTarget << 16) / this.wRef;
            this.yRatio = (this.hTarget << 16) / this.hRef;
        }
    }

    public int scaleX(int x) {
        int retVal;
        if (s_bAspectRatio && this.yRatio > this.xRatio) {
            retVal = (x * this.yRatio) >> 16;
        } else {
            retVal = (x * this.wTarget) / this.wRef;
        }
        if (retVal == 0) {
            if (x < 0) {
                return -1;
            }
            if (x > 0) {
                return 1;
            }
        }
        return retVal;
    }

    public int scaleY(int y) {
        int retVal;
        if (s_bAspectRatio && this.xRatio > this.yRatio) {
            retVal = (y * this.xRatio) >> 16;
        } else {
            retVal = (y * this.hTarget) / this.hRef;
        }
        if (retVal == 0) {
            if (y < 0) {
                return -1;
            }
            if (y > 0) {
                return 1;
            }
        }
        return retVal;
    }

    public void ResizeCoords() {
        this._modules_w_scaled = new short[this._nModules];
        this._modules_h_scaled = new short[this._nModules];
        for (int i = 0; i < this._nModules; i++) {
            this._modules_w_scaled[i] = (short) scaleX(GetModuleWidthOrg(i));
            this._modules_h_scaled[i] = (short) scaleY(GetModuleHeightOrg(i));
        }
        for (int frame = 0; frame < this._frames_nfm.length; frame++) {
            int nFModules = this._frames_nfm[frame] & 255;
            for (int fmodule = 0; fmodule < nFModules; fmodule++) {
                if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                    int off = (this._frames_fm_start[frame] + fmodule) * 5;
                    this._fmodules[off + 1] = (byte) scaleX(this._fmodules[off + 1]);
                    this._fmodules[off + 2] = (byte) scaleY(this._fmodules[off + 2]);
                } else {
                    int off2 = this._frames_fm_start[frame] + fmodule;
                    if (GLLibConfig.sprite_useAfOffShort) {
                        this._fmodules_ox_short[off2] = (short) scaleX(this._fmodules_ox_short[off2]);
                        this._fmodules_oy_short[off2] = (short) scaleY(this._fmodules_oy_short[off2]);
                    } else {
                        this._fmodules_ox_byte[off2] = (byte) scaleX(this._fmodules_ox_byte[off2]);
                        this._fmodules_oy_byte[off2] = (byte) scaleY(this._fmodules_oy_byte[off2]);
                    }
                }
            }
        }
        if (this.mResizeCorrectY) {
            for (int frame2 = 0; frame2 < this._frames_nfm.length; frame2++) {
                int nFModules2 = this._frames_nfm[frame2] & 255;
                for (int fmodule2 = 1; fmodule2 < nFModules2; fmodule2++) {
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        int off3 = ((this._frames_fm_start[frame2] + fmodule2) - 1) * 5;
                        this._fmodules[((this._frames_fm_start[frame2] + fmodule2) * 5) + 2] = (byte) (this._fmodules[off3 + 2] + this._modules_h_scaled[this._fmodules[off3]]);
                    } else {
                        int off4 = (this._frames_fm_start[frame2] + fmodule2) - 1;
                        int off1 = this._frames_fm_start[frame2] + fmodule2;
                        if (GLLibConfig.sprite_useAfOffShort) {
                            this._fmodules_oy_short[off1] = (short) (this._fmodules_oy_short[off4] + this._modules_h_scaled[this._fmodules_id[off4]]);
                        } else {
                            this._fmodules_oy_byte[off1] = (byte) (this._fmodules_oy_byte[off4] + this._modules_h_scaled[this._fmodules_id[off4]]);
                        }
                    }
                }
            }
        }
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [short[], short[][]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [ASprite[], ASprite[][]] */
    public static void InitCachePool(int poolCount) {
        if (GLLibConfig.sprite_useCachePool) {
            _poolCacheStack = new short[poolCount];
            _poolCacheSprites = new ASprite[poolCount];
            _poolCacheStackIndex = new int[poolCount];
            _poolCacheStackMax = new int[poolCount];
        }
    }

    public static void InitPoolSize(int poolIndex, int size) {
        if (GLLibConfig.sprite_useCachePool) {
            _poolCacheStackMax[poolIndex] = size;
            _poolCacheStack[poolIndex] = new short[size];
            _poolCacheSprites[poolIndex] = new ASprite[size];
            for (int i = 0; i < _poolCacheStack[poolIndex].length; i++) {
                _poolCacheStack[poolIndex][i] = -1;
            }
        }
    }

    public static void ResetCachePool(int poolIndex) {
        if (GLLibConfig.sprite_useCachePool) {
            _poolCacheStack[poolIndex] = null;
            _poolCacheSprites[poolIndex] = null;
            _poolCacheStackIndex[poolIndex] = 0;
            _poolCacheStackMax[poolIndex] = 0;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10, types: [short[][], short[][][]] */
    /* JADX WARN: Type inference failed for: r1v3, types: [Image[], Image[][]] */
    public void SetPool(int poolIndex) {
        if (GLLibConfig.sprite_useCachePool) {
            this._cur_pool = poolIndex;
            if (!GLLibConfig.sprite_useDynamicPng) {
                if (GLLibConfig.sprite_useNokiaUI) {
                    if (this._modules_image_shortAAA == null) {
                        this._modules_image_shortAAA = new short[this._palettes][];
                        for (int i = 0; i < this._palettes; i++) {
                            this._modules_image_shortAAA[i] = new short[this._nModules];
                        }
                        return;
                    }
                    return;
                }
                if (!GLLibConfig.sprite_useCacheRGBArrays && !GLLibConfig.sprite_RGBArraysUseDrawRGB) {
                    if ((!GLLibConfig.sprite_useManualCacheRGBArrays || (this._flags & 1) == 0) && this._module_image_imageAA == null) {
                        this._module_image_imageAA = new Image[this._palettes];
                        for (int i2 = 0; i2 < this._palettes; i2++) {
                            this._module_image_imageAA[i2] = new Image[this._nModules];
                        }
                    }
                }
            }
        }
    }

    private void UpdatePoolCache(int module, Object cached) {
        ASprite sprite;
        if (GLLibConfig.sprite_useCachePool && this._cur_pool >= 0) {
            if (GLLibConfig.sprite_useNokiaUI) {
                if (this._modules_image_shortAAA[this._crt_pal][module] != null) {
                    return;
                }
            } else if (this._module_image_imageAA[this._crt_pal][module] != null) {
                return;
            }
            int cur_index = _poolCacheStackIndex[this._cur_pool];
            short s = _poolCacheStack[this._cur_pool][cur_index];
            int img_pal = s >> 10;
            int img_module = s & INDEX_MASK;
            if (s >= 0 && (sprite = _poolCacheSprites[this._cur_pool][cur_index]) != null) {
                if (GLLibConfig.sprite_useNokiaUI) {
                    sprite._modules_image_shortAAA[img_pal][img_module] = null;
                } else {
                    sprite._module_image_imageAA[img_pal][img_module] = null;
                }
            }
            short fake_module = (short) ((module & INDEX_MASK) + (this._crt_pal << 10));
            _poolCacheStack[this._cur_pool][cur_index] = fake_module;
            _poolCacheSprites[this._cur_pool][cur_index] = this;
            _poolCacheStackIndex[this._cur_pool] = (_poolCacheStackIndex[this._cur_pool] + 1) % _poolCacheStackMax[this._cur_pool];
            if (GLLibConfig.sprite_useNokiaUI) {
                this._modules_image_shortAAA[this._crt_pal][module] = (short[]) cached;
            } else {
                this._module_image_imageAA[this._crt_pal][module] = (Image) cached;
            }
        }
    }

    int PaletteBlending_InitStatic(int paletteA, int paletteB, int initBlend, boolean cacheImages, boolean useColor) {
        this._palBlend_UseOneColor = useColor;
        this._palBlend_srcA = paletteA;
        this._palBlend_srcB = paletteB;
        this._palBlend_dest = AllocateExtraPalette();
        PaletteBlending_SetBlend(initBlend);
        if (cacheImages) {
            BuildCacheImages(this._palBlend_dest, 0, -1, -1);
        }
        return this._palBlend_dest;
    }

    int PaletteBlending_InitDynamic(int paletteA, int paletteB, int initBlend, boolean cacheImages, boolean useColor) {
        PaletteBlending_InitStatic(paletteA, paletteB, initBlend, cacheImages, useColor);
        if (GLLibConfig.sprite_useDynamicPaletteBlendingCache) {
            this._palBlend_ModuleState = new byte[this._nModules];
            if (cacheImages) {
                for (int i = 0; i < this._nModules; i++) {
                    this._palBlend_ModuleState[i] = (byte) this._palBlend_current;
                }
            }
        }
        return this._palBlend_dest;
    }

    void PaletteBlending_SetBlend(int blendValue) {
        int blendValue2 = blendValue < 0 ? 0 : blendValue > 255 ? 255 : blendValue;
        if (blendValue2 != this._palBlend_current) {
            PaletteBlending_BuildPalette(blendValue2);
            this._palBlend_current = blendValue2;
        }
    }

    int PaletteBlending_GetBlend() {
        return this._palBlend_current;
    }

    void PaletteBlending_SynchCache() {
        if (GLLibConfig.sprite_useDynamicPaletteBlendingCache) {
            int first = -1;
            int last = -1;
            for (int i = 0; i <= this._nModules; i++) {
                if (i < this._nModules && this._palBlend_ModuleState[i] != ((byte) this._palBlend_current)) {
                    this._palBlend_ModuleState[i] = (byte) this._palBlend_current;
                    if (first == -1) {
                        first = i;
                    }
                    last = i;
                } else if (first != -1) {
                    BuildCacheImages(this._crt_pal, first, last, -1);
                    first = -1;
                    last = -1;
                }
            }
        }
    }

    void PaletteBlending_ReleaseDynamic() {
        if (GLLibConfig.sprite_useDynamicPaletteBlendingCache) {
            this._palBlend_ModuleState = null;
        }
    }

    boolean PaletteBlending_BuildPalette(int blendValue) {
        return PaletteBlending_BuildPalette(blendValue, this._palBlend_srcA, this._palBlend_srcB, this._palBlend_dest, this._palBlend_UseOneColor);
    }

    boolean PaletteBlending_BuildPalette(int blendValue, int paletteA, int paletteB, int paletteResult, boolean useOneColor) {
        if (!GLLibConfig.sprite_useNokiaUI) {
            if (!useOneColor) {
            }
            boolean bAlpha = false;
            int[] palA = this._pal_int[paletteA];
            int[] palR = this._pal_int[paletteResult];
            if (!useOneColor) {
                int[] palB = this._pal_int[paletteB];
                for (int i = 0; i < this._colors; i++) {
                    if ((palA[i] & 16777215) == 16711935) {
                        bAlpha = true;
                        palR[i] = 16711935;
                    } else {
                        int palAval = palA[i] & 255;
                        int palBval = palB[i] & 255;
                        int blend = palAval + (((palBval - palAval) * blendValue) >> 8);
                        palR[i] = blend;
                        int palAval2 = (palA[i] & 65280) >> 8;
                        int palBval2 = (palB[i] & 65280) >> 8;
                        int blend2 = palAval2 + (((palBval2 - palAval2) * blendValue) >> 8);
                        int i2 = i;
                        palR[i2] = palR[i2] | (blend2 << 8);
                        int palAval3 = (palA[i] & 16711680) >> 16;
                        int palBval3 = (palB[i] & 16711680) >> 16;
                        int blend3 = palAval3 + (((palBval3 - palAval3) * blendValue) >> 8);
                        int i3 = i;
                        palR[i3] = palR[i3] | (blend3 << 16);
                        int palAval4 = ((palA[i] & (-16777216)) >> 24) & 255;
                        int palBval4 = ((palB[i] & (-16777216)) >> 24) & 255;
                        int blend4 = palAval4 + (((palBval4 - palAval4) * blendValue) >> 8);
                        int i4 = i;
                        palR[i4] = palR[i4] | (blend4 << 24);
                        if (blend4 != 255) {
                            bAlpha = true;
                        }
                    }
                }
            } else {
                for (int i5 = 0; i5 < this._colors; i5++) {
                    if ((palA[i5] & 16777215) == 16711935) {
                        bAlpha = true;
                        palR[i5] = 16711935;
                    } else {
                        int palAval5 = palA[i5] & 255;
                        int palBval5 = paletteB & 255;
                        int blend5 = palAval5 + (((palBval5 - palAval5) * blendValue) >> 8);
                        palR[i5] = blend5;
                        int palAval6 = (palA[i5] & 65280) >> 8;
                        int palBval6 = (paletteB & 65280) >> 8;
                        int blend6 = palAval6 + (((palBval6 - palAval6) * blendValue) >> 8);
                        int i6 = i5;
                        palR[i6] = palR[i6] | (blend6 << 8);
                        int palAval7 = (palA[i5] & 16711680) >> 16;
                        int palBval7 = (paletteB & 16711680) >> 16;
                        int blend7 = palAval7 + (((palBval7 - palAval7) * blendValue) >> 8);
                        int i7 = i5;
                        palR[i7] = palR[i7] | (blend7 << 16);
                        int palAval8 = ((palA[i5] & (-16777216)) >> 24) & 255;
                        int palBval8 = ((paletteB & (-16777216)) >> 24) & 255;
                        int blend8 = palAval8 + (((palBval8 - palAval8) * blendValue) >> 8);
                        int i8 = i5;
                        palR[i8] = palR[i8] | (blend8 << 24);
                        if (blend8 != 255) {
                            bAlpha = true;
                        }
                    }
                }
            }
            return bAlpha || this._alpha;
        }
        return false;
    }

    Object DecodeImage(int module) {
        if (GLLibConfig.sprite_useCreateRGB) {
            return DecodeImage_int(module);
        }
        if (GLLibConfig.sprite_useNokiaUI) {
            return DecodeImage_short(module);
        }
        return DecodeImage_byte(module);
    }

    private int[] DecodeImage_int(int module) {
        if (GLLibConfig.sprite_useCreateRGB) {
            if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                if (this._modules_data_off_short == null) {
                    return null;
                }
            } else if (this._modules_data_off_int == null) {
                return null;
            }
            if (this._modules_data == null) {
                return null;
            }
            if (GLLibConfig.sprite_useResize && s_resizeType != 0 && (this._modules_w_scaled[module] != GetModuleWidthOrg(module) || this._modules_h_scaled[module] != GetModuleHeightOrg(module))) {
                return DecodeImageAndResize(module);
            }
            DecodeImage_Algorithm(this._modules_data, getStartModuleData(module, 0), GetModuleWidth(module), GetModuleHeight(module));
            return temp_int;
        }
        return null;
    }

    private short[] DecodeImage_short(int module) {
        if (GLLibConfig.sprite_useNokiaUI) {
            if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                if (this._modules_data_off_short == null) {
                    return null;
                }
            } else if (this._modules_data_off_int == null) {
                return null;
            }
            if (this._modules_data == null) {
                return null;
            }
            DecodeImage_Algorithm(this._modules_data, getStartModuleData(module, 0), GetModuleWidth(module), GetModuleHeight(module));
            return temp_short;
        }
        return null;
    }

    private byte[] DecodeImage_byte(int module) {
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            if (this._modules_data_off_short == null) {
                return null;
            }
        } else if (this._modules_data_off_int == null) {
            return null;
        }
        if (this._modules_data == null) {
            return null;
        }
        DecodeImage_Algorithm(this._modules_data, getStartModuleData(module, 0), GetModuleWidth(module), GetModuleHeight(module));
        return temp_byte;
    }

    private byte[] DecodeImage_byte(byte[] image, int offset, int sizeX, int sizeY) {
        DecodeImage_Algorithm(image, offset, sizeX, sizeY);
        return temp_byte;
    }

    private void DecodeImage_Algorithm(byte[] image, int si, int sizeX, int sizeY) {
        int di = 0;
        int ds = sizeX * sizeY;
        if (GLLibConfig.sprite_useCreateRGB) {
            if (temp_int == null) {
                temp_int = new int[GLLibConfig.TMP_BUFFER_SIZE];
            }
        } else if (GLLibConfig.sprite_useNokiaUI) {
            if (temp_short == null) {
                temp_short = new short[GLLibConfig.TMP_BUFFER_SIZE];
            }
        } else if (temp_byte == null) {
            temp_byte = new byte[GLLibConfig.TMP_BUFFER_SIZE];
        }
        short[] pal_short = null;
        int[] pal_int = null;
        if (GLLibConfig.sprite_useNokiaUI) {
            if (this._pal_short == null) {
                return;
            } else {
                pal_short = this._pal_short[this._crt_pal];
            }
        }
        if (GLLibConfig.sprite_useCreateRGB) {
            if (this._pal_int == null) {
                return;
            } else {
                pal_int = this._pal_int[this._crt_pal];
            }
        }
        int clr_int = 0;
        short clr_short = 0;
        byte clr_byte = 0;
        if (GLLibConfig.sprite_useEncodeFormatI64RLE && this._data_format == ENCODE_FORMAT_I64RLE) {
            while (di < ds) {
                int i = si;
                si++;
                int c = image[i] & 255;
                if (GLLibConfig.sprite_useCreateRGB) {
                    clr_int = pal_int[c & this._i64rle_color_mask];
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    clr_short = pal_short[c & this._i64rle_color_mask];
                } else {
                    clr_byte = (byte) (c & this._i64rle_color_mask);
                }
                int c2 = c >> this._i64rle_color_bits;
                while (true) {
                    int i2 = c2;
                    c2 = i2 - 1;
                    if (i2 >= 0) {
                        if (GLLibConfig.sprite_useCreateRGB) {
                            int i3 = di;
                            di++;
                            temp_int[i3] = clr_int;
                        } else if (GLLibConfig.sprite_useNokiaUI) {
                            int i4 = di;
                            di++;
                            temp_short[i4] = clr_short;
                        } else {
                            int i5 = di;
                            di++;
                            temp_byte[i5] = clr_byte;
                        }
                    }
                }
            }
        } else if (GLLibConfig.sprite_useEncodeFormatI127RLE && this._data_format == ENCODE_FORMAT_I127RLE) {
            while (di < ds) {
                int i6 = si;
                si++;
                int c3 = image[i6] & 255;
                if (c3 > 127) {
                    si++;
                    int c22 = image[si] & 255;
                    if (GLLibConfig.sprite_useCreateRGB) {
                        clr_int = pal_int[c22];
                    } else if (GLLibConfig.sprite_useNokiaUI) {
                        clr_short = pal_short[c22];
                    } else {
                        clr_byte = (byte) c22;
                    }
                    int c4 = c3 - 128;
                    while (true) {
                        int i7 = c4;
                        c4 = i7 - 1;
                        if (i7 > 0) {
                            if (GLLibConfig.sprite_useCreateRGB) {
                                int i8 = di;
                                di++;
                                temp_int[i8] = clr_int;
                            } else if (GLLibConfig.sprite_useNokiaUI) {
                                int i9 = di;
                                di++;
                                temp_short[i9] = clr_short;
                            } else {
                                int i10 = di;
                                di++;
                                temp_byte[i10] = clr_byte;
                            }
                        }
                    }
                } else if (GLLibConfig.sprite_useCreateRGB) {
                    int i11 = di;
                    di++;
                    temp_int[i11] = pal_int[c3];
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    int i12 = di;
                    di++;
                    temp_short[i12] = pal_short[c3];
                } else {
                    int i13 = di;
                    di++;
                    temp_byte[i13] = (byte) c3;
                }
            }
        } else if (GLLibConfig.sprite_useEncodeFormatI256RLE && this._data_format == ENCODE_FORMAT_I256RLE) {
            while (di < ds) {
                int i14 = si;
                si++;
                int c5 = image[i14] & 255;
                if (c5 > 127) {
                    int c6 = c5 - 128;
                    while (true) {
                        int i15 = c6;
                        c6 = i15 - 1;
                        if (i15 > 0) {
                            if (GLLibConfig.sprite_useCreateRGB) {
                                int i16 = di;
                                di++;
                                int i17 = si;
                                si++;
                                temp_int[i16] = pal_int[image[i17] & 255];
                            } else if (GLLibConfig.sprite_useNokiaUI) {
                                int i18 = di;
                                di++;
                                int i19 = si;
                                si++;
                                temp_short[i18] = pal_short[image[i19] & 255];
                            } else {
                                int i20 = di;
                                di++;
                                int i21 = si;
                                si++;
                                temp_byte[i20] = (byte) (image[i21] & 255);
                            }
                        }
                    }
                } else {
                    if (GLLibConfig.sprite_useCreateRGB) {
                        si++;
                        clr_int = pal_int[image[si] & 255];
                    } else if (GLLibConfig.sprite_useNokiaUI) {
                        si++;
                        clr_short = pal_short[image[si] & 255];
                    } else {
                        si++;
                        clr_byte = (byte) (image[si] & 255);
                    }
                    while (true) {
                        int i22 = c5;
                        c5 = i22 - 1;
                        if (i22 > 0) {
                            if (GLLibConfig.sprite_useCreateRGB) {
                                int i23 = di;
                                di++;
                                temp_int[i23] = clr_int;
                            } else if (GLLibConfig.sprite_useNokiaUI) {
                                int i24 = di;
                                di++;
                                temp_short[i24] = clr_short;
                            } else {
                                int i25 = di;
                                di++;
                                temp_byte[i25] = clr_byte;
                            }
                        }
                    }
                }
            }
        } else if (GLLibConfig.sprite_useEncodeFormatI16 && this._data_format == ENCODE_FORMAT_I16) {
            while (di < ds) {
                int i26 = si;
                si++;
                byte b = image[i26];
                if (GLLibConfig.sprite_useCreateRGB) {
                    int i27 = di;
                    int di2 = di + 1;
                    temp_int[i27] = pal_int[(b >> 4) & 15];
                    di = di2 + 1;
                    temp_int[di2] = pal_int[b & 15];
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    int i28 = di;
                    int di3 = di + 1;
                    temp_short[i28] = pal_short[(b >> 4) & 15];
                    di = di3 + 1;
                    temp_short[di3] = pal_short[b & 15];
                } else {
                    int i29 = di;
                    int di4 = di + 1;
                    temp_byte[i29] = (byte) ((b >> 4) & 15);
                    di = di4 + 1;
                    temp_byte[di4] = (byte) (b & 15);
                }
            }
        } else if (GLLibConfig.sprite_useEncodeFormatI4 && this._data_format == 1024) {
            while (di < ds) {
                int i30 = si;
                si++;
                byte b2 = image[i30];
                if (GLLibConfig.sprite_useCreateRGB) {
                    int i31 = di;
                    int di5 = di + 1;
                    temp_int[i31] = pal_int[(b2 >> 6) & 3];
                    int di6 = di5 + 1;
                    temp_int[di5] = pal_int[(b2 >> 4) & 3];
                    int di7 = di6 + 1;
                    temp_int[di6] = pal_int[(b2 >> 2) & 3];
                    di = di7 + 1;
                    temp_int[di7] = pal_int[b2 & 3];
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    int i32 = di;
                    int di8 = di + 1;
                    temp_short[i32] = pal_short[(b2 >> 6) & 3];
                    int di9 = di8 + 1;
                    temp_short[di8] = pal_short[(b2 >> 4) & 3];
                    int di10 = di9 + 1;
                    temp_short[di9] = pal_short[(b2 >> 2) & 3];
                    di = di10 + 1;
                    temp_short[di10] = pal_short[b2 & 3];
                } else {
                    int i33 = di;
                    int di11 = di + 1;
                    temp_byte[i33] = (byte) ((b2 >> 6) & 3);
                    int di12 = di11 + 1;
                    temp_byte[di11] = (byte) ((b2 >> 4) & 3);
                    int di13 = di12 + 1;
                    temp_byte[di12] = (byte) ((b2 >> 2) & 3);
                    di = di13 + 1;
                    temp_byte[di13] = (byte) (b2 & 3);
                }
            }
        } else if (GLLibConfig.sprite_useEncodeFormatI2 && this._data_format == ENCODE_FORMAT_I2) {
            while (di < ds) {
                int i34 = si;
                si++;
                byte b3 = image[i34];
                if (GLLibConfig.sprite_useCreateRGB) {
                    int i35 = di;
                    int di14 = di + 1;
                    temp_int[i35] = pal_int[(b3 >> 7) & 1];
                    int di15 = di14 + 1;
                    temp_int[di14] = pal_int[(b3 >> 6) & 1];
                    int di16 = di15 + 1;
                    temp_int[di15] = pal_int[(b3 >> 5) & 1];
                    int di17 = di16 + 1;
                    temp_int[di16] = pal_int[(b3 >> 4) & 1];
                    int di18 = di17 + 1;
                    temp_int[di17] = pal_int[(b3 >> 3) & 1];
                    int di19 = di18 + 1;
                    temp_int[di18] = pal_int[(b3 >> 2) & 1];
                    int di20 = di19 + 1;
                    temp_int[di19] = pal_int[(b3 >> 1) & 1];
                    di = di20 + 1;
                    temp_int[di20] = pal_int[b3 & 1];
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    int i36 = di;
                    int di21 = di + 1;
                    temp_short[i36] = pal_short[(b3 >> 7) & 1];
                    int di22 = di21 + 1;
                    temp_short[di21] = pal_short[(b3 >> 6) & 1];
                    int di23 = di22 + 1;
                    temp_short[di22] = pal_short[(b3 >> 5) & 1];
                    int di24 = di23 + 1;
                    temp_short[di23] = pal_short[(b3 >> 4) & 1];
                    int di25 = di24 + 1;
                    temp_short[di24] = pal_short[(b3 >> 3) & 1];
                    int di26 = di25 + 1;
                    temp_short[di25] = pal_short[(b3 >> 2) & 1];
                    int di27 = di26 + 1;
                    temp_short[di26] = pal_short[(b3 >> 1) & 1];
                    di = di27 + 1;
                    temp_short[di27] = pal_short[b3 & 1];
                } else {
                    int i37 = di;
                    int di28 = di + 1;
                    temp_byte[i37] = (byte) ((b3 >> 7) & 1);
                    int di29 = di28 + 1;
                    temp_byte[di28] = (byte) ((b3 >> 6) & 1);
                    int di30 = di29 + 1;
                    temp_byte[di29] = (byte) ((b3 >> 5) & 1);
                    int di31 = di30 + 1;
                    temp_byte[di30] = (byte) ((b3 >> 4) & 1);
                    int di32 = di31 + 1;
                    temp_byte[di31] = (byte) ((b3 >> 3) & 1);
                    int di33 = di32 + 1;
                    temp_byte[di32] = (byte) ((b3 >> 2) & 1);
                    int di34 = di33 + 1;
                    temp_byte[di33] = (byte) ((b3 >> 1) & 1);
                    di = di34 + 1;
                    temp_byte[di34] = (byte) (b3 & 1);
                }
            }
        } else if (GLLibConfig.sprite_useEncodeFormatI256 && this._data_format == ENCODE_FORMAT_I256) {
            while (di < ds) {
                if (GLLibConfig.sprite_useCreateRGB) {
                    int i38 = di;
                    di++;
                    int i39 = si;
                    si++;
                    temp_int[i38] = pal_int[image[i39] & 255];
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    int i40 = di;
                    di++;
                    int i41 = si;
                    si++;
                    temp_short[i40] = pal_short[image[i41] & 255];
                } else {
                    int i42 = di;
                    di++;
                    int i43 = si;
                    si++;
                    temp_byte[i42] = (byte) (image[i43] & 255);
                }
            }
        } else if (GLLibConfig.sprite_useEncodeFormatA256_I64RLE && this._data_format == ENCODE_FORMAT_A256_I64RLE) {
            while (di < ds) {
                int i44 = si;
                si++;
                int c7 = image[i44] & 255;
                if (GLLibConfig.sprite_useCreateRGB) {
                    clr_int = pal_int[c7 & this._i64rle_color_mask];
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    clr_short = pal_short[c7 & this._i64rle_color_mask];
                } else {
                    clr_byte = (byte) (c7 & this._i64rle_color_mask);
                }
                int c8 = c7 >> this._i64rle_color_bits;
                while (true) {
                    int i45 = c8;
                    c8 = i45 - 1;
                    if (i45 >= 0) {
                        if (GLLibConfig.sprite_useCreateRGB) {
                            int i46 = di;
                            di++;
                            temp_int[i46] = clr_int;
                        } else if (GLLibConfig.sprite_useNokiaUI) {
                            int i47 = di;
                            di++;
                            temp_short[i47] = clr_short;
                        } else {
                            int i48 = di;
                            di++;
                            temp_byte[i48] = clr_byte;
                        }
                    }
                }
            }
            int di35 = 0;
            while (di35 < ds) {
                int i49 = si;
                si++;
                int a = image[i49] & 255;
                if (a == 254) {
                    int si2 = si + 1;
                    int n = image[si] & 255;
                    si = si2 + 1;
                    int a2 = image[si2] & 255;
                    while (true) {
                        int i50 = n;
                        n = i50 - 1;
                        if (i50 > 0) {
                            if (GLLibConfig.sprite_useCreateRGB) {
                                temp_int[di35] = (a2 << 24) | (temp_int[di35] & 16777215);
                                di35++;
                            } else if (GLLibConfig.sprite_useNokiaUI) {
                                temp_short[di35] = (short) (((a2 & 240) << 8) | (temp_short[di35] & WRAP_TEXT_FORMATTING_MASK_PALETTE));
                                di35++;
                            }
                        }
                    }
                } else if (GLLibConfig.sprite_useCreateRGB) {
                    temp_int[di35] = (a << 24) | (temp_int[di35] & 16777215);
                    di35++;
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    temp_short[di35] = (short) (((a & 240) << 8) | (temp_short[di35] & WRAP_TEXT_FORMATTING_MASK_PALETTE));
                    di35++;
                }
            }
        } else if (GLLibConfig.sprite_useEncodeFormatA256_I127RLE && this._data_format == ENCODE_FORMAT_A256_I127RLE) {
            while (di < ds) {
                int i51 = si;
                si++;
                int c9 = image[i51] & 255;
                if (c9 > 127) {
                    si++;
                    int c23 = image[si] & 255;
                    if (GLLibConfig.sprite_useCreateRGB) {
                        clr_int = pal_int[c23];
                    } else if (GLLibConfig.sprite_useNokiaUI) {
                        clr_short = pal_short[c23];
                    } else {
                        clr_byte = (byte) c23;
                    }
                    int c10 = c9 - 128;
                    while (true) {
                        int i52 = c10;
                        c10 = i52 - 1;
                        if (i52 > 0) {
                            if (GLLibConfig.sprite_useCreateRGB) {
                                int i53 = di;
                                di++;
                                temp_int[i53] = clr_int;
                            } else if (GLLibConfig.sprite_useNokiaUI) {
                                int i54 = di;
                                di++;
                                temp_short[i54] = clr_short;
                            } else {
                                int i55 = di;
                                di++;
                                temp_byte[i55] = clr_byte;
                            }
                        }
                    }
                } else if (GLLibConfig.sprite_useCreateRGB) {
                    int i56 = di;
                    di++;
                    temp_int[i56] = pal_int[c9];
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    int i57 = di;
                    di++;
                    temp_short[i57] = pal_short[c9];
                } else {
                    int i58 = di;
                    di++;
                    temp_byte[i58] = (byte) c9;
                }
            }
            int di36 = 0;
            while (di36 < ds) {
                int i59 = si;
                si++;
                int a3 = image[i59] & 255;
                if (a3 == 254) {
                    int si3 = si + 1;
                    int n2 = image[si] & 255;
                    si = si3 + 1;
                    int a4 = image[si3] & 255;
                    while (true) {
                        int i60 = n2;
                        n2 = i60 - 1;
                        if (i60 > 0) {
                            if (GLLibConfig.sprite_useCreateRGB) {
                                temp_int[di36] = (a4 << 24) | (temp_int[di36] & 16777215);
                                di36++;
                            } else if (GLLibConfig.sprite_useNokiaUI) {
                                temp_short[di36] = (short) (((a4 & 240) << 8) | (temp_short[di36] & WRAP_TEXT_FORMATTING_MASK_PALETTE));
                                di36++;
                            }
                        }
                    }
                } else if (GLLibConfig.sprite_useCreateRGB) {
                    temp_int[di36] = (a3 << 24) | (temp_int[di36] & 16777215);
                    di36++;
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    temp_short[di36] = (short) (((a3 & 240) << 8) | (temp_short[di36] & WRAP_TEXT_FORMATTING_MASK_PALETTE));
                    di36++;
                }
            }
        } else if (GLLibConfig.sprite_useEncodeFormatA256_I256RLE && this._data_format == ENCODE_FORMAT_A256_I256RLE) {
            while (di < ds) {
                int i61 = si;
                si++;
                int c11 = image[i61] & 255;
                if (c11 > 127) {
                    int c12 = c11 - 128;
                    while (true) {
                        int i62 = c12;
                        c12 = i62 - 1;
                        if (i62 > 0) {
                            if (GLLibConfig.sprite_useCreateRGB) {
                                int i63 = di;
                                di++;
                                int i64 = si;
                                si++;
                                temp_int[i63] = pal_int[image[i64] & 255];
                            } else if (GLLibConfig.sprite_useNokiaUI) {
                                int i65 = di;
                                di++;
                                int i66 = si;
                                si++;
                                temp_short[i65] = pal_short[image[i66] & 255];
                            } else {
                                int i67 = di;
                                di++;
                                int i68 = si;
                                si++;
                                temp_byte[i67] = (byte) (image[i68] & 255);
                            }
                        }
                    }
                } else {
                    if (GLLibConfig.sprite_useCreateRGB) {
                        si++;
                        clr_int = pal_int[image[si] & 255];
                    } else if (GLLibConfig.sprite_useNokiaUI) {
                        si++;
                        clr_short = pal_short[image[si] & 255];
                    } else {
                        si++;
                        clr_byte = (byte) (image[si] & 255);
                    }
                    while (true) {
                        int i69 = c11;
                        c11 = i69 - 1;
                        if (i69 > 0) {
                            if (GLLibConfig.sprite_useCreateRGB) {
                                int i70 = di;
                                di++;
                                temp_int[i70] = clr_int;
                            } else if (GLLibConfig.sprite_useNokiaUI) {
                                int i71 = di;
                                di++;
                                temp_short[i71] = clr_short;
                            } else {
                                int i72 = di;
                                di++;
                                temp_byte[i72] = clr_byte;
                            }
                        }
                    }
                }
            }
            int di37 = 0;
            while (di37 < ds) {
                int i73 = si;
                si++;
                int a5 = image[i73] & 255;
                if (a5 == 254) {
                    int si4 = si + 1;
                    int n3 = image[si] & 255;
                    si = si4 + 1;
                    int a6 = image[si4] & 255;
                    while (true) {
                        int i74 = n3;
                        n3 = i74 - 1;
                        if (i74 > 0) {
                            if (GLLibConfig.sprite_useCreateRGB) {
                                temp_int[di37] = (a6 << 24) | (temp_int[di37] & 16777215);
                                di37++;
                            } else if (GLLibConfig.sprite_useNokiaUI) {
                                temp_short[di37] = (short) (((a6 & 240) << 8) | (temp_short[di37] & WRAP_TEXT_FORMATTING_MASK_PALETTE));
                                di37++;
                            }
                        }
                    }
                } else if (GLLibConfig.sprite_useCreateRGB) {
                    temp_int[di37] = (a5 << 24) | (temp_int[di37] & 16777215);
                    di37++;
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    temp_short[di37] = (short) (((a5 & 240) << 8) | (temp_short[di37] & WRAP_TEXT_FORMATTING_MASK_PALETTE));
                    di37++;
                }
            }
        }
        if (GLLibConfig.sprite_useBugFixImageOddSize) {
            if (GLLibConfig.sprite_useCreateRGB) {
                clr_int = 0;
                int color = 0;
                while (true) {
                    if (color >= this._pal_int[0].length) {
                        break;
                    }
                    if ((this._pal_int[0][color] >> 24) != 0) {
                        color++;
                    } else {
                        clr_int = color;
                        break;
                    }
                }
            } else if (GLLibConfig.sprite_useNokiaUI) {
                clr_short = 0;
                int color2 = 0;
                while (true) {
                    if (color2 >= this._pal_short[0].length) {
                        break;
                    }
                    if ((this._pal_short[0][color2] >> 24) != 0) {
                        color2++;
                    } else {
                        clr_short = (short) color2;
                        break;
                    }
                }
            } else {
                clr_byte = 0;
                int color3 = 0;
                while (true) {
                    if (color3 >= this._pal_int[0].length) {
                        break;
                    }
                    if ((this._pal_int[0][color3] >> 24) != 0) {
                        color3++;
                    } else {
                        clr_byte = (byte) color3;
                        break;
                    }
                }
            }
            int newSizeX = sizeX + (sizeX % 2);
            int newSizeY = sizeY + (sizeY % 2);
            if (newSizeY != sizeY) {
                for (int x = 0; x < newSizeX; x++) {
                    if (GLLibConfig.sprite_useCreateRGB) {
                        temp_int[(sizeY * newSizeX) + x] = clr_int;
                    } else if (GLLibConfig.sprite_useNokiaUI) {
                        temp_short[(sizeY * newSizeX) + x] = clr_short;
                    } else {
                        temp_byte[(sizeY * newSizeX) + x] = clr_byte;
                    }
                }
            }
            for (int y = sizeY - 1; y >= 0; y--) {
                if (GLLibConfig.sprite_useCreateRGB) {
                    System.arraycopy(temp_int, sizeX * y, temp_int, newSizeX * y, sizeX);
                    if (newSizeX != sizeX) {
                        temp_int[(y * newSizeX) + sizeX] = clr_int;
                    }
                } else if (GLLibConfig.sprite_useNokiaUI) {
                    System.arraycopy(temp_short, sizeX * y, temp_short, newSizeX * y, sizeX);
                    if (newSizeX != sizeX) {
                        temp_short[(y * newSizeX) + sizeX] = clr_short;
                    }
                } else {
                    System.arraycopy(temp_byte, sizeX * y, temp_byte, newSizeX * y, sizeX);
                    if (newSizeX != sizeX) {
                        temp_byte[(y * newSizeX) + sizeX] = clr_byte;
                    }
                }
            }
        }
    }

    void DecodeImageToByteArray(byte[] dest, int module, boolean img2dRGBA, boolean half) {
        int bytesPerPixel;
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            if (this._modules_data_off_short == null) {
                return;
            }
        } else if (this._modules_data_off_int == null) {
            return;
        }
        if (this._modules_data == null) {
            return;
        }
        int sizeX = GetModuleWidth(module);
        int sizeY = GetModuleHeight(module);
        if (dest == null) {
            return;
        }
        if (img2dRGBA) {
            bytesPerPixel = 4;
        } else {
            bytesPerPixel = 3;
        }
        DecodeImage_Algorithm(this._modules_data, getStartModuleData(module, 0), sizeX, sizeY);
        if (GLLibConfig.sprite_useCreateRGB) {
            byte[] img_data = new byte[sizeX * sizeY * bytesPerPixel];
            for (int j = 0; j < sizeY; j++) {
                for (int i = 0; i < sizeX; i++) {
                    int off = i + (j * sizeX);
                    img_data[(off * bytesPerPixel) + 0] = (byte) ((temp_int[off] >> 0) & 255);
                    img_data[(off * bytesPerPixel) + 1] = (byte) ((temp_int[off] >> 8) & 255);
                    img_data[(off * bytesPerPixel) + 2] = (byte) ((temp_int[off] >> 16) & 255);
                    if (bytesPerPixel == 4) {
                        img_data[(off * bytesPerPixel) + 3] = (byte) ((temp_int[off] >> 24) & 255);
                    }
                }
            }
            if (temp_int == null) {
                temp_int = new int[GLLibConfig.TMP_BUFFER_SIZE];
            }
            int width = sizeX >> 1;
            int height = sizeY >> 1;
            int a0 = 0;
            int a1 = 0;
            int a2 = 0;
            int a3 = 0;
            int di = 0;
            if (half) {
                for (int j2 = 0; j2 < height; j2++) {
                    for (int i2 = 0; i2 < width; i2++) {
                        int idx = (j2 * 2 * bytesPerPixel * sizeX) + (i2 * 2 * bytesPerPixel);
                        int r0 = img_data[idx] & 255;
                        int g0 = img_data[idx + 1] & 255;
                        int b0 = img_data[idx + 2] & 255;
                        if (bytesPerPixel == 4) {
                            a0 = img_data[idx + 3] & 255;
                        }
                        int idx2 = idx + bytesPerPixel;
                        int r1 = img_data[idx2] & 255;
                        int g1 = img_data[idx2 + 1] & 255;
                        int b1 = img_data[idx2 + 2] & 255;
                        if (bytesPerPixel == 4) {
                            a1 = img_data[idx2 + 3] & 255;
                        }
                        int idx3 = (((j2 * 2) + 1) * bytesPerPixel * sizeX) + (i2 * 2 * bytesPerPixel);
                        int r2 = img_data[idx3] & 255;
                        int g2 = img_data[idx3 + 1] & 255;
                        int b2 = img_data[idx3 + 2] & 255;
                        if (bytesPerPixel == 4) {
                            a2 = img_data[idx3 + 3] & 255;
                        }
                        int idx4 = idx3 + bytesPerPixel;
                        int r3 = img_data[idx4] & 255;
                        int g3 = img_data[idx4 + 1] & 255;
                        int b3 = img_data[idx4 + 2] & 255;
                        if (bytesPerPixel == 4) {
                            a3 = img_data[idx4 + 3] & 255;
                        }
                        int r = (((r0 + r1) + r2) + r3) >> 2;
                        int gr = (((g0 + g1) + g2) + g3) >> 2;
                        int b = (((b0 + b1) + b2) + b3) >> 2;
                        int a = (((a0 + a1) + a2) + a3) >> 2;
                        int i3 = di;
                        int di2 = di + 1;
                        img_data[i3] = (byte) (r & 255);
                        int di3 = di2 + 1;
                        img_data[di2] = (byte) (gr & 255);
                        di = di3 + 1;
                        img_data[di3] = (byte) (b & 255);
                        if (bytesPerPixel == 4) {
                            di++;
                            img_data[di] = (byte) (a & 255);
                        }
                    }
                }
            }
        }
    }

    public static void SetTempBuffer(Object pArray) {
        if (pArray instanceof int[]) {
            temp_int = (int[]) pArray;
        } else if (pArray instanceof short[]) {
            temp_short = (short[]) pArray;
        } else {
            temp_byte = (byte[]) pArray;
        }
    }

    static int GetCurrentStringWidth() {
        return _text_w;
    }

    static int GetCurrentStringHeight() {
        return _text_h;
    }

    static void SetCharMapStatic(byte[] pNewMap) {
        s_MapChar = pNewMap;
    }

    byte[] GetCharMap() {
        return this._pMapChar;
    }

    short[][] GetCharMapShort() {
        return this._pMapCharShort;
    }

    void SetCharMap(byte[] pNewMap) {
        if (!GLLibConfig.sprite_newTextRendering) {
            this._pMapChar = pNewMap;
            SetLineSpacingToDefault();
            SetSpaceWidthToDefault();
            SetLineHeightToDefault();
            SetCharSpacingToDefault();
        }
    }

    /* JADX WARN: Type inference failed for: r1v4, types: [short[], short[][]] */
    void SetCharMap(short[] pNewMap) {
        if (GLLibConfig.sprite_newTextRendering) {
            this._nDivider = pNewMap[0];
            this._pMapCharShort = new short[this._nDivider];
            int index = 1;
            for (int i = 0; i < this._nDivider; i++) {
                this._pMapCharShort[i] = new short[2];
                int i2 = index;
                int index2 = index + 1;
                this._pMapCharShort[i][0] = pNewMap[i2];
                index = index2 + 1;
                this._pMapCharShort[i][1] = pNewMap[index2];
            }
            int i3 = index;
            while (i3 < pNewMap.length) {
                int i4 = i3;
                int i5 = i3 + 1;
                short s = pNewMap[i4];
                i3 = i5 + 1;
                short s2 = pNewMap[i5];
                short[] newEntry = new short[(s2 * 2) + 2];
                newEntry[0] = this._pMapCharShort[s][0];
                newEntry[1] = this._pMapCharShort[s][1];
                for (int j = 0; j < s2; j++) {
                    int i6 = i3;
                    int i7 = i3 + 1;
                    newEntry[(j * 2) + 2] = pNewMap[i6];
                    i3 = i7 + 1;
                    newEntry[(j * 2) + 3] = pNewMap[i7];
                }
                this._pMapCharShort[s] = newEntry;
            }
            SetDefaultFontMetrics();
        }
    }

    int GetCharFrame(int c) {
        if (GLLibConfig.sprite_debugErrors && GLLibConfig.sprite_newTextRendering && this._pMapCharShort == null) {
            System.out.println("ERROR: _pMapCharShort is null!!! Did you set the Char Map?");
        }
        int index = c % this._nDivider;
        if (this._pMapCharShort[index][0] == c) {
            return this._pMapCharShort[index][1];
        }
        int i = 2;
        int length = this._pMapCharShort[index].length;
        while (i < length && this._pMapCharShort[index][i] != c) {
            i += 2;
        }
        if (i >= length) {
            if (GLLibConfig.sprite_debugErrors) {
                System.out.println(new StringBuffer().append("Character not available: char value = ").append(c).append(" and actual char = '").append((char) c).append("'").toString());
                return 1;
            }
            return 1;
        }
        return this._pMapCharShort[index][i + 1];
    }

    void SetDefaultFontMetrics() {
        this._nFontAscent = -GetFrameModuleY(0, 0);
        this._nFontDescent = GetFrameModuleY(0, 1);
        SetLineSpacingToDefault();
        this._nFontHeight = this._nFontAscent + this._nFontDescent;
        SetSpaceWidthToDefault();
    }

    int GetLineSpacing() {
        return this._nLineSpacing;
    }

    void SetLineSpacing(int spacing) {
        this._nLineSpacing = spacing;
    }

    void SetLineSpacingToDefault() {
        if (GLLibConfig.sprite_newTextRendering) {
            this._nLineSpacing = GetFrameModuleY(0, 2) - GetFrameModuleY(0, 1);
        } else {
            this._nLineSpacing = GetModuleHeight(0) >> 1;
        }
    }

    int GetFontHeight() {
        if (GLLibConfig.sprite_newTextRendering) {
            return this._nFontHeight;
        }
        if (GLLibConfig.sprite_useModuleWHShort) {
            return this._modules_h_short[0] & 255;
        }
        return this._modules_h_byte[0] & 255;
    }

    final int GetSpaceWidth() {
        return this._nSpaceWidth;
    }

    final void SetSpaceWidth(int spacing) {
        this._nSpaceWidth = spacing;
    }

    void SetSpaceWidthToDefault() {
        if (GLLibConfig.sprite_newTextRendering) {
            this._nSpaceWidth = GetFrameModuleX(GetCharFrame(32), 0);
        } else {
            this._nSpaceWidth = GetModuleWidth(0);
        }
    }

    final int GetCharSpacing() {
        return this._nCharSpacing;
    }

    final void SetCharSpacing(int spacing) {
        this._nCharSpacing = spacing;
    }

    void SetCharSpacingToDefault() {
        if (GLLibConfig.sprite_newTextRendering) {
            this._nCharSpacing = 0;
        } else if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            this._nCharSpacing = this._fmodules[1];
        } else {
            this._nCharSpacing = GetFModuleOX(0);
        }
    }

    final int GetLineHeight() {
        if (GLLibConfig.sprite_newTextRendering) {
            return this._nFontHeight;
        }
        return this._nLineHeight;
    }

    final void SetLineHeight(int nHeight) {
        this._nLineHeight = nHeight;
    }

    void SetLineHeightToDefault() {
        if (GLLibConfig.sprite_newTextRendering) {
            this._nLineHeight = (-GetFrameModuleY(0, 0)) + GetFrameModuleY(0, 1);
        } else {
            this._nLineHeight = GetModuleHeight(0);
        }
    }

    final boolean GetUnderline() {
        return this._bUnderline;
    }

    final void SetUnderline(boolean bUnderline) {
        this._bUnderline = bUnderline;
    }

    final boolean GetBold() {
        return this._bBold;
    }

    final void SetBold(boolean bBold) {
        this._bBold = bBold;
    }

    final int GetTextHeight(int numLines) {
        return (numLines * GetLineHeight()) + ((numLines - 1) * GetLineSpacing());
    }

    short[] WraptextB(String s, int width, int height) {
        int c;
        int m;
        int charSize;
        if (_warpTextInfo == null) {
            _warpTextInfo = new short[GLLibConfig.MAX_WRAP_TEXT_INFO];
        }
        int str_len = s.length();
        int GetModuleWidth = (str_len * GetModuleWidth(1)) / width;
        short lineSize = 0;
        short cnt = 1;
        short lastSpacePos = 0;
        boolean lastSpaceBold = this._bBold;
        boolean lastSpaceUnder = this._bUnderline;
        int lastSpacePal = this._crt_pal;
        boolean bSpaceFound = false;
        short distFromLastSpacePos = 0;
        boolean bold = this._bBold;
        boolean under = this._bUnderline;
        int pal = this._crt_pal;
        int LastLineFormat = 0;
        if (GLLibConfig.sprite_bufferTextPageFormatting) {
            int LastLineFormat2 = pal & WRAP_TEXT_FORMATTING_MASK_PALETTE;
            LastLineFormat = LastLineFormat2 | (bold ? 4096 : 0) | (under ? 8192 : 0);
        }
        int lines = 0;
        for (int i = 0; i < str_len; i++) {
            if (s.charAt(i) == 10) {
                lines++;
            }
        }
        int i2 = 0;
        while (i2 < str_len) {
            int c2 = s.charAt(i2);
            if (c2 == 32) {
                lineSize = (short) (lineSize + GetSpaceWidth());
                lastSpacePos = (short) i2;
                lastSpaceBold = bold;
                bSpaceFound = true;
                distFromLastSpacePos = 0;
                if (GLLibConfig.sprite_bufferTextPageFormatting) {
                    lastSpaceUnder = under;
                    lastSpacePal = pal;
                }
                if (lineSize > width) {
                    bSpaceFound = false;
                    int pos = lastSpacePos;
                    while (pos >= 0 && s.charAt(pos) == ' ') {
                        pos--;
                        lineSize = (short) (lineSize - GetSpaceWidth());
                    }
                    while (lastSpacePos < str_len && s.charAt(lastSpacePos) == ' ') {
                        lastSpacePos = (short) (lastSpacePos + 1);
                    }
                    lastSpacePos = (short) (lastSpacePos - 1);
                    i2 = lastSpacePos;
                    bold = lastSpaceBold;
                    short cnt2 = (short) (cnt + 1);
                    _warpTextInfo[cnt] = (short) (lastSpacePos + 1);
                    cnt = (short) (cnt2 + 1);
                    _warpTextInfo[cnt2] = (short) (lineSize - 0);
                    if (GLLibConfig.sprite_bufferTextPageFormatting) {
                        cnt = (short) (cnt + 1);
                        _warpTextInfo[cnt] = (short) LastLineFormat;
                        under = lastSpaceUnder;
                        pal = lastSpacePal;
                        int LastLineFormat3 = lastSpacePal & WRAP_TEXT_FORMATTING_MASK_PALETTE;
                        LastLineFormat = LastLineFormat3 | (lastSpaceBold ? 4096 : 0) | (lastSpaceUnder ? 8192 : 0);
                    }
                    lineSize = 0;
                }
            } else if (GLLibConfig.sprite_fontBackslashChangePalette && c2 == 92) {
                i2++;
                int c22 = s.charAt(i2);
                if (c22 == 94) {
                    bold = !bold;
                } else if (GLLibConfig.sprite_bufferTextPageFormatting) {
                    if (c22 == 95) {
                        under = !under;
                    } else {
                        int c3 = (c22 & 255) - 48;
                        if (c3 < this._palettes) {
                            pal = c3;
                        }
                    }
                }
            } else if (c2 == 10) {
                short cnt3 = (short) (cnt + 1);
                _warpTextInfo[cnt] = (short) i2;
                cnt = (short) (cnt3 + 1);
                _warpTextInfo[cnt3] = lineSize;
                lineSize = 0;
                distFromLastSpacePos = 0;
                if (GLLibConfig.sprite_bufferTextPageFormatting) {
                    cnt = (short) (cnt + 1);
                    _warpTextInfo[cnt] = (short) LastLineFormat;
                    int LastLineFormat4 = pal & WRAP_TEXT_FORMATTING_MASK_PALETTE;
                    LastLineFormat = LastLineFormat4 | (bold ? 4096 : 0) | (under ? 8192 : 0);
                }
            } else {
                if (c2 < 32) {
                    if (c2 == 1) {
                        i2++;
                    } else if (c2 == 2) {
                        i2++;
                        c = s.charAt(i2);
                    }
                } else if (GLLibConfig.sprite_newTextRendering) {
                    c = GetCharFrame(c2);
                } else {
                    c = this._pMapChar[c2] & 255;
                }
                if (GLLibConfig.sprite_newTextRendering) {
                    if (c > GetFrameCount()) {
                        if (GLLibConfig.sprite_debugErrors) {
                            System.out.println(new StringBuffer().append("Character not available: c = ").append(c).toString());
                        }
                        c = 0;
                    }
                    charSize = GetFrameModuleX(c, 0) + GetCharSpacing();
                } else if (GLLibConfig.sprite_fontUseOneFramePerLetter) {
                    GetFrameRect(this.nALetterRect, c, 0, 0, 0);
                    int charSize2 = this.nALetterRect[2] - this.nALetterRect[0];
                    charSize = charSize2 + GetCharSpacing();
                } else {
                    if (c >= GetFModules(0)) {
                        if (GLLibConfig.sprite_debugErrors) {
                            System.out.println(new StringBuffer().append("Character not available: c = ").append(c).toString());
                        }
                        c = 0;
                    }
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        m = this._fmodules[c << 2] & 255;
                    } else {
                        m = this._fmodules_id[c] & 255;
                    }
                    if (m >= this._nModules) {
                        if (GLLibConfig.sprite_debugErrors) {
                            System.out.println(new StringBuffer().append("Character module not available: c = ").append(c).append("  m = ").append(m >> 1).toString());
                        }
                        m = 0;
                        c = 0;
                    }
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        charSize = (GetModuleWidth(m) - this._fmodules[(c << 2) + 1]) + GetCharSpacing();
                    } else {
                        charSize = (GetModuleWidth(m) - GetFModuleOX(c)) + GetCharSpacing();
                    }
                }
                if (bold) {
                    charSize++;
                }
                distFromLastSpacePos = (short) (distFromLastSpacePos + charSize);
                lineSize = (short) (lineSize + charSize);
                if (lineSize > width && bSpaceFound) {
                    bSpaceFound = false;
                    int pos2 = lastSpacePos;
                    while (pos2 >= 0 && s.charAt(pos2) == ' ') {
                        pos2--;
                        lineSize = (short) (lineSize - GetSpaceWidth());
                    }
                    short cnt4 = (short) (cnt + 1);
                    _warpTextInfo[cnt] = (short) (lastSpacePos + 1);
                    cnt = (short) (cnt4 + 1);
                    _warpTextInfo[cnt4] = (short) (lineSize - distFromLastSpacePos);
                    if (GLLibConfig.sprite_bufferTextPageFormatting) {
                        cnt = (short) (cnt + 1);
                        _warpTextInfo[cnt] = (short) LastLineFormat;
                        under = lastSpaceUnder;
                        pal = lastSpacePal;
                        int LastLineFormat5 = lastSpacePal & WRAP_TEXT_FORMATTING_MASK_PALETTE;
                        LastLineFormat = LastLineFormat5 | (lastSpaceBold ? 4096 : 0) | (lastSpaceUnder ? 8192 : 0);
                    }
                    lineSize = 0;
                    i2 = lastSpacePos;
                    bold = lastSpaceBold;
                }
            }
            i2++;
        }
        if (lineSize != 0) {
            short cnt5 = (short) (cnt + 1);
            _warpTextInfo[cnt] = (short) str_len;
            cnt = (short) (cnt5 + 1);
            _warpTextInfo[cnt5] = lineSize;
            if (GLLibConfig.sprite_bufferTextPageFormatting) {
                cnt = (short) (cnt + 1);
                _warpTextInfo[cnt] = (short) LastLineFormat;
            }
        }
        if (GLLibConfig.sprite_bufferTextPageFormatting) {
            _warpTextInfo[0] = (short) (cnt / 3);
        } else {
            _warpTextInfo[0] = (short) (cnt / 2);
        }
        return _warpTextInfo;
    }

    /* JADX WARN: Multi-variable type inference failed */
    static int GetPageCharSize(short[] info, int i, int maxLines) {
        int startIndex;
        int endIndex;
        int startLine = i < 0 ? (short) 0 : i > info[0] ? info[0] : i;
        int maxLines2 = maxLines < 0 ? 0 : maxLines > info[0] - startLine ? info[0] - startLine : maxLines;
        if (GLLibConfig.sprite_bufferTextPageFormatting) {
            startIndex = startLine == 0 ? (short) 0 : info[(3 * startLine) - 2];
            endIndex = info[(3 * ((startLine + maxLines2) - 1)) + 1];
        } else {
            startIndex = startLine == 0 ? (short) 0 : info[(2 * startLine) - 1];
            endIndex = info[(2 * ((startLine + maxLines2) - 1)) + 1];
        }
        return endIndex - startIndex;
    }

    byte[] TextFitToFixedWidth(byte[] str, int text_w) {
        String s = TextFitToFixedWidth(new String(str), text_w);
        return s.getBytes();
    }

    String TextFitToFixedWidth(String str, int text_w) {
        short s;
        String string_ret = "";
        int lastEnter = 0;
        short[] ret = WraptextB(str, text_w, 0);
        for (int i = 0; i < ret[0]; i++) {
            if (lastEnter != 0 && str.charAt(lastEnter) != '\n') {
                string_ret = new StringBuffer().append(string_ret).append("\n").toString();
            }
            if (GLLibConfig.sprite_bufferTextPageFormatting) {
                string_ret = new StringBuffer().append(string_ret).append(str.substring(lastEnter, ret[(3 * i) + 1])).toString();
                s = ret[(3 * i) + 1];
            } else {
                string_ret = new StringBuffer().append(string_ret).append(str.substring(lastEnter, ret[(i << 1) + 1])).toString();
                s = ret[(i << 1) + 1];
            }
            lastEnter = s;
        }
        return string_ret;
    }

    void DrawPageB(Graphics g, String s, short[] info, int x, int y, int startLine, int maxLines, int anchor) {
        DrawPageB(g, s, info, x, y, startLine, maxLines, anchor, -1);
    }

    void DrawPageB(Graphics g, String s, short[] info, int x, int y, int startLine, int maxLines, int anchor, int maxChars) {
        short s2 = info[0];
        int maxchar = GetLineHeight();
        if (maxLines == -1) {
            maxLines = s2;
        }
        if (startLine + maxLines > s2) {
            maxLines = s2 - startLine;
        }
        int th = GetLineSpacing() + maxchar;
        if ((anchor & 32) != 0) {
            y -= th * (maxLines - 1);
        } else if ((anchor & 2) != 0) {
            y -= (th * (maxLines - 1)) >> 1;
        }
        this._old_pal = this._crt_pal;
        boolean old_bold = this._bBold;
        boolean old_underline = this._bUnderline;
        if (maxChars >= 0) {
            if (GLLibConfig.sprite_bufferTextPageFormatting) {
                _indexMax = startLine > 0 ? info[((startLine - 1) * 3) + 1] : (short) 0;
            } else {
                _indexMax = startLine > 0 ? info[((startLine - 1) * 2) + 1] : (short) 0;
            }
            _indexMax += maxChars;
        }
        int j = startLine;
        for (int k = 0; j < s2 && k <= maxLines - 1; k++) {
            if (GLLibConfig.sprite_bufferTextPageFormatting) {
                _index1 = j > 0 ? info[((j - 1) * 3) + 1] : (short) 0;
                _index2 = info[(j * 3) + 1];
            } else {
                _index1 = j > 0 ? info[((j - 1) * 2) + 1] : (short) 0;
                _index2 = info[(j * 2) + 1];
            }
            if (_index1 < s.length() && s.charAt(_index1) == '\n') {
                _index1++;
            }
            int xx = x;
            int yy = y + (k * th);
            if ((anchor & 43) != 0) {
                if (GLLibConfig.sprite_bufferTextPageFormatting) {
                    if ((anchor & 8) != 0) {
                        xx -= info[((j + 1) * 3) - 1];
                    } else if ((anchor & 1) != 0) {
                        xx -= info[((j + 1) * 3) - 1] >> 1;
                    }
                } else if ((anchor & 8) != 0) {
                    xx -= info[(j + 1) * 2];
                } else if ((anchor & 1) != 0) {
                    xx -= info[(j + 1) * 2] >> 1;
                }
                if ((anchor & 32) != 0) {
                    yy = GLLibConfig.sprite_newTextRendering ? yy - GetLineHeight() : yy - GetModuleHeight(1);
                } else if ((anchor & 2) != 0) {
                    yy = GLLibConfig.sprite_newTextRendering ? yy - (GetLineHeight() >> 1) : yy - (GetModuleHeight(1) >> 1);
                }
            }
            if (GLLibConfig.sprite_bufferTextPageFormatting) {
                short s3 = info[(j + 1) * 3];
                this._bBold = (s3 & 4096) != 0;
                this._bUnderline = (s3 & 8192) != 0;
                SetCurrentPalette(s3 & WRAP_TEXT_FORMATTING_MASK_PALETTE);
            }
            DrawString(g, s, xx, yy, 0, false);
            j++;
        }
        _index1 = -1;
        _index2 = -1;
        _indexMax = -1;
        this._crt_pal = this._old_pal;
        if (GLLibConfig.sprite_bufferTextPageFormatting) {
            this._bBold = old_bold;
            this._bUnderline = old_underline;
        }
        if (GLLibConfig.sprite_useDrawStringSleep) {
            try {
                Thread.sleep(GLLibConfig.SLEEP_DRAWSTRINGB);
            } catch (Throwable th2) {
            }
        }
    }

    static void SetSubString(int i1, int i2) {
        _index1 = i1;
        _index2 = i2;
    }

    void UpdateStringSize(byte[] bs) {
        UpdateStringSize(new String(bs));
    }

    void UpdateStringSize(String s) {
        UpdateStringOrCharsSize(s, null);
    }

    void UpdateStringOrCharsSize(String s, char[] charBuff) {
        int index2;
        int c;
        int m;
        if (s == null && charBuff == null) {
            return;
        }
        _text_w = 0;
        _text_h = GetLineHeight();
        int tw = 0;
        boolean isDrawString = s != null;
        int index1 = _index1 >= 0 ? _index1 : 0;
        if (isDrawString) {
            index2 = _index2 >= 0 ? _index2 : s.length();
        } else {
            index2 = _index2 >= 0 ? _index2 : charBuff.length;
        }
        boolean bold = this._bBold;
        int i = index1;
        while (i < index2) {
            int c2 = isDrawString ? s.charAt(i) : charBuff[i];
            if (GLLibConfig.sprite_fontBackslashChangePalette && c2 == 92) {
                i++;
                if ((isDrawString ? s.charAt(i) : charBuff[i]) == '^') {
                    bold = !bold;
                }
            } else {
                if (c2 > 32) {
                    if (GLLibConfig.sprite_newTextRendering) {
                        c = GetCharFrame(c2);
                    } else {
                        if (GLLibConfig.sprite_debugErrors && this._pMapChar == null) {
                            System.out.println("ERROR: _pMapChar is null !!!");
                        }
                        c = this._pMapChar[c2] & 255;
                    }
                } else if (c2 == 32) {
                    tw += GetSpaceWidth();
                } else if (c2 == 10) {
                    if (tw > _text_w) {
                        _text_w = tw;
                    }
                    tw = 0;
                    _text_h += GetLineSpacing() + GetLineHeight();
                } else if (c2 == 1) {
                    i++;
                } else if (c2 == 2) {
                    i++;
                    c = isDrawString ? s.charAt(i) : charBuff[i];
                }
                if (GLLibConfig.sprite_newTextRendering) {
                    if (GLLibConfig.sprite_debugErrors && c > GetFrameCount()) {
                        System.out.println(new StringBuffer().append("Character not available: c = ").append(c).toString());
                        c = 0;
                    }
                    tw += GetFrameModuleX(c, 0);
                } else if (GLLibConfig.sprite_fontUseOneFramePerLetter) {
                    GetFrameRect(this.nALetterRect, c, 0, 0, 0);
                    tw = tw + (this.nALetterRect[2] - this.nALetterRect[0]) + GetCharSpacing();
                } else {
                    if (GLLibConfig.sprite_debugErrors && c >= GetFModules(0)) {
                        System.out.println(new StringBuffer().append("Character not available: c = ").append(c).toString());
                        c = 0;
                    }
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        m = this._fmodules[c << 2] & 255;
                    } else {
                        m = this._fmodules_id[c] & 255;
                    }
                    if (GLLibConfig.sprite_debugErrors && m >= this._nModules) {
                        System.out.println(new StringBuffer().append("Character module not available: c = ").append(c).append("  m = ").append(m).toString());
                        m = 0;
                        c = 0;
                    }
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        tw += GetModuleWidth(m) + this._fmodules[(c << 2) + 1] + GetCharSpacing();
                    } else {
                        tw += GetModuleWidth(m) + GetFModuleOX(c) + GetCharSpacing();
                    }
                }
                if (bold) {
                    tw++;
                }
            }
            i++;
        }
        if (tw > _text_w) {
            _text_w = tw;
        }
        if (GLLibConfig.sprite_newTextRendering) {
            if (_text_w > 0) {
                _text_w -= GetCharSpacing();
            }
        } else if (GLLibConfig.sprite_useSingleArrayForFMAF && _text_w > 0) {
            _text_w -= this._fmodules[1];
        } else if (_text_w > 0) {
            _text_w -= GetCharSpacing();
        }
    }

    void DrawString(Graphics g, byte[] bs, int x, int y, int anchor, int maxIndex) {
        _indexMax = maxIndex;
        DrawString(g, new String(bs), x, y, anchor, true);
        _indexMax = -1;
    }

    void DrawString(Graphics g, String s, int x, int y, int anchor, int maxIndex) {
        _indexMax = maxIndex;
        DrawString(g, s, x, y, anchor, true);
        _indexMax = -1;
    }

    void DrawString(Graphics g, byte[] bs, int x, int y, int anchor) {
        DrawString(g, new String(bs), x, y, anchor, true);
    }

    void DrawString(Graphics g, String s, int x, int y, int anchor) {
        DrawString(g, s, x, y, anchor, true);
    }

    void DrawString(Graphics g, byte[] bs, int x, int y, int anchor, boolean restorecol) {
        DrawString(g, new String(bs), x, y, anchor, restorecol);
    }

    void DrawString(Graphics g, String s, int x, int y, int anchor, boolean restorecol) {
        DrawStringOrChars(g, s, null, x, y, anchor, restorecol);
    }

    void DrawStringOrChars(Graphics g, String s, char[] charBuff, int x, int y, int anchor, boolean restorecol) {
        int y2;
        int index2;
        int c;
        int um;
        int m;
        int um2;
        if (s == null && charBuff == null) {
            return;
        }
        if (GLLibConfig.sprite_newTextRendering) {
            y2 = y + this._nFontAscent;
        } else {
            if (GLLibConfig.sprite_fontUseOneFramePerLetter) {
            }
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                y2 = y - this._fmodules[2];
            } else {
                y2 = y - GetFModuleOY(0);
            }
        }
        boolean isDrawString = s != null;
        UpdateStringOrCharsSize(s, charBuff);
        if ((anchor & 43) != 0) {
            if ((anchor & 8) != 0) {
                x -= _text_w;
            } else if ((anchor & 1) != 0) {
                x -= _text_w >> 1;
            }
            if ((anchor & 32) != 0) {
                y2 -= _text_h;
            } else if ((anchor & 2) != 0) {
                y2 -= _text_h >> 1;
            }
        }
        int xx = x;
        int yy = y2;
        if (restorecol) {
            this._old_pal = this._crt_pal;
        }
        int index1 = _index1 >= 0 ? _index1 : 0;
        if (isDrawString) {
            index2 = _index2 >= 0 ? _index2 : s.length();
        } else {
            index2 = _index2 >= 0 ? _index2 : charBuff.length;
        }
        if (_indexMax >= 0 && index2 > _indexMax) {
            index2 = _indexMax;
        }
        int i = index1;
        while (i < index2) {
            int c2 = isDrawString ? s.charAt(i) : charBuff[i];
            if (GLLibConfig.sprite_fontBackslashChangePalette && c2 == 92) {
                i++;
                int c22 = isDrawString ? s.charAt(i) : charBuff[i];
                if (c22 == 95) {
                    this._bUnderline = !this._bUnderline;
                } else if (c22 == 94) {
                    this._bBold = !this._bBold;
                } else {
                    SetCurrentPalette((c22 & 255) - 48);
                }
            } else {
                if (c2 > 32) {
                    if (GLLibConfig.sprite_newTextRendering) {
                        c = GetCharFrame(c2);
                    } else {
                        if (GLLibConfig.sprite_debugErrors && this._pMapChar == null) {
                            System.out.println("ERROR: _pMapChar is null !!!");
                        }
                        c = this._pMapChar[c2] & 255;
                    }
                } else if (c2 == 32) {
                    if (this._bUnderline) {
                        if (GLLibConfig.sprite_newTextRendering) {
                            int uc = GetCharFrame(95);
                            int ux = xx + ((GetSpaceWidth() - GetFrameModuleX(uc, 0)) >> 1);
                            PaintFrame(g, uc, ux, yy, 0);
                        } else if (GLLibConfig.sprite_fontUseOneFramePerLetter) {
                            int uc2 = this._pMapChar[95] & 255;
                            GetFrameRect(this.nALetterRect, uc2, 0, 0, 0);
                            int ux2 = xx + ((GetSpaceWidth() - this.nALetterRect[2]) >> 1);
                            PaintFrame(g, uc2, ux2, yy, 0, 0, 0);
                        } else {
                            int uc3 = this._pMapChar[95] & 255;
                            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                                um = this._fmodules[uc3 << 2] & 255;
                            } else {
                                um = this._fmodules_id[uc3] & 255;
                            }
                            int ux3 = xx + ((GetSpaceWidth() - GetModuleWidth(um)) >> 1);
                            PaintFModule(g, 0, uc3, ux3, yy, 0, 0, 0);
                        }
                    }
                    xx += GetSpaceWidth();
                } else if (c2 == 10) {
                    xx = x;
                    yy += GetLineSpacing() + GetLineHeight();
                } else if (c2 == 1) {
                    i++;
                    int c23 = isDrawString ? s.charAt(i) : charBuff[i];
                    if (c23 < this._palettes) {
                        SetCurrentPalette(c23);
                    }
                    if (c23 == 255) {
                        this._crt_pal = this._old_pal;
                    }
                } else if (c2 == 2) {
                    i++;
                    c = isDrawString ? s.charAt(i) : charBuff[i];
                }
                if (GLLibConfig.sprite_debugErrors) {
                    if (GLLibConfig.sprite_newTextRendering) {
                        if (c > GetFrameCount()) {
                            System.out.println(new StringBuffer().append("Character not available: c = ").append(c).toString());
                            c = 0;
                        }
                    } else if (c >= GetFModules(0)) {
                        System.out.println(new StringBuffer().append("Character not available: c = ").append(c).toString());
                        c = 0;
                    }
                }
                if (GLLibConfig.sprite_newTextRendering) {
                    PaintFrame(g, c, xx, yy, 0);
                    if (this._bUnderline) {
                        int uc4 = GetCharFrame(95);
                        int ux4 = xx + ((GetFrameModuleX(c, 0) - GetFrameModuleX(uc4, 0)) >> 1);
                        PaintFrame(g, uc4, ux4, yy, 0);
                    }
                    if (this._bBold) {
                        xx++;
                        PaintFrame(g, c, xx, yy, 0);
                    }
                    xx += GetFrameModuleX(c, 0) + GetCharSpacing();
                } else if (GLLibConfig.sprite_fontUseOneFramePerLetter) {
                    if (this._bUnderline && GLLibConfig.sprite_fontUseOneFramePerLetter) {
                        int uc5 = this._pMapChar[95] & 255;
                        GetFrameRect(this.nALetterRect, uc5, 0, 0, 0);
                        int ux5 = xx + ((GetSpaceWidth() - this.nALetterRect[2]) >> 1);
                        PaintFrame(g, uc5, ux5, yy, 0, 0, 0);
                    }
                    PaintFrame(g, c, xx, yy, 0, 0, 0);
                    GetFrameRect(this.nALetterRect, c, 0, 0, 0);
                    xx = xx + (this.nALetterRect[2] - this.nALetterRect[0]) + GetCharSpacing();
                } else {
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        m = this._fmodules[c << 2] & 255;
                    } else {
                        m = this._fmodules_id[c] & 255;
                    }
                    if (GLLibConfig.sprite_debugErrors && m >= this._nModules) {
                        System.out.println(new StringBuffer().append("Character module not available: c = ").append(c).append("  m = ").append(m).toString());
                        m = 0;
                        c = 0;
                    }
                    if (this._bUnderline) {
                        int uc6 = this._pMapChar[95] & 255;
                        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                            um2 = this._fmodules[uc6 << 2] & 255;
                        } else {
                            um2 = this._fmodules_id[uc6] & 255;
                        }
                        int ux6 = xx + ((GetModuleWidth(m) - GetModuleWidth(um2)) >> 1);
                        PaintFModule(g, 0, uc6, ux6, yy, 0, 0, 0);
                    }
                    PaintFModule(g, 0, c, xx, yy, 0, 0, 0);
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        xx += GetModuleWidth(m) + this._fmodules[(c << 2) + 1] + GetCharSpacing();
                    } else {
                        xx += GetModuleWidth(m) + GetFModuleOX(c) + GetCharSpacing();
                    }
                }
            }
            i++;
        }
        if (restorecol) {
            this._crt_pal = this._old_pal;
        }
    }

    static int StringTokenize(String s, int index1, int index2, char token, int[] indices) {
        int lines = 0;
        indices[0] = index1 - 1;
        for (int i = index1; i < index2; i++) {
            if (s.charAt(i) == token) {
                lines++;
                indices[lines] = i;
            }
        }
        int lines2 = lines + 1;
        indices[lines2] = index2;
        return lines2;
    }

    void DrawPage(Graphics g, byte[] s, int x, int y, int anchor) {
        DrawPage(g, new String(s), x, y, anchor, 0, s.length);
    }

    void DrawPage(Graphics g, String s, int x, int y, int anchor) {
        DrawPage(g, s, x, y, anchor, 0, s.length());
    }

    void DrawPage(Graphics g, String s, int x, int y, int anchor, int start, int end) {
        int[] off = new int[100];
        int lines = StringTokenize(s, start, end, '\n', off);
        int th = GetLineSpacing() + GetLineHeight();
        if ((anchor & 32) != 0) {
            y -= th * (lines - 1);
        } else if ((anchor & 2) != 0) {
            y -= (th * (lines - 1)) >> 1;
        }
        for (int j = 0; j < lines; j++) {
            _index1 = off[j] + 1;
            _index2 = off[j + 1];
            DrawString(g, s, x, y + (j * th), anchor, false);
        }
        _index1 = -1;
        _index2 = -1;
    }

    int getCharSize(char c) {
        if (c == ' ') {
            return GetSpaceWidth();
        }
        if (GLLibConfig.sprite_newTextRendering) {
            return GetFrameModuleX(GetCharFrame(c), 0);
        }
        if (this._pMapChar != null && c > ' ' && c < this._pMapChar.length) {
            int i = this._pMapChar[c] & 255;
            return (GetModuleWidth(this._fmodules[i << 2] & 255) & 255) + this._fmodules[(i << 2) + 1] + this._fmodules[1];
        }
        return 0;
    }

    void DrawNumber(Graphics g, int num, int minDigit, int x, int y, int anchor) {
        DrawNumber(g, num, 10, minDigit, x, y, anchor, true);
    }

    void DrawNumber(Graphics g, int num, int radix, int minDigit, int x, int y, int anchor, boolean restorecol) {
        int charPos = GetChars(_itoa_buffer, num, radix, minDigit);
        int oldIndex1 = _index1;
        int oldIndex2 = _index2;
        SetSubString(charPos, 33);
        DrawStringOrChars(g, null, _itoa_buffer, x, y, anchor, restorecol);
        SetSubString(oldIndex1, oldIndex2);
    }

    static int GetChars(char[] charBuf, int i, int radix, int minDigit) {
        if (charBuf == null) {
            _itoa_buffer = new char[33];
            charBuf = _itoa_buffer;
        }
        int len = charBuf.length;
        int charPos = len - 1;
        boolean negative = i < 0;
        if (!negative) {
            i = -i;
        }
        while (i <= (-radix)) {
            int i2 = charPos;
            charPos = i2 - 1;
            charBuf[i2] = (char) (48 - (i % radix));
            i /= radix;
        }
        charBuf[charPos] = (char) (48 - i);
        while (len - charPos < minDigit) {
            charPos--;
            charBuf[charPos] = '0';
        }
        if (negative) {
            charPos--;
            charBuf[charPos] = '-';
        }
        return charPos;
    }

    void UpdateNumberSize(int num, int radix, int minDigit) {
        int charPos = GetChars(_itoa_buffer, num, radix, minDigit);
        int oldIndex1 = _index1;
        int oldIndex2 = _index2;
        SetSubString(charPos, 33);
        UpdateStringOrCharsSize(null, _itoa_buffer);
        SetSubString(oldIndex1, oldIndex2);
    }

    void SetCurrentPalette(int pal) {
        if (pal >= this._palettes || pal < 0) {
            return;
        }
        this._crt_pal = pal;
    }

    int GetCurrentPalette() {
        return this._crt_pal;
    }

    static int[] GenPalette(int type, int[] pal) {
        if (type < 0) {
            return pal;
        }
        if (type == 0) {
            return null;
        }
        int[] new_pal = new int[pal.length];
        if ((GLLibConfig.sprite_useGenPalette & 2) != 0 && type == 1) {
            for (int i = 0; i < pal.length; i++) {
                new_pal[i] = (pal[i] | 16724736) & (-256);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 4) != 0 && type == 2) {
            for (int i2 = 0; i2 < pal.length; i2++) {
                new_pal[i2] = (pal[i2] | 13311) & (-16711681);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 8) != 0 && type == 3) {
            for (int i3 = 0; i3 < pal.length; i3++) {
                new_pal[i3] = (pal[i3] | 0) & (-16711936);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 16) != 0 && type == 4) {
            for (int i4 = 0; i4 < pal.length; i4++) {
                int a = pal[i4] & (-16777216);
                int r = (pal[i4] & 16711680) >> 16;
                int g = (pal[i4] & 65280) >> 8;
                int b = pal[i4] & 255;
                new_pal[i4] = a | (((r + 255) >> 1) << 16) | ((g >> 1) << 8) | (b >> 1);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 32) != 0 && type == 5) {
            for (int i5 = 0; i5 < pal.length; i5++) {
                int a2 = pal[i5] & (-16777216);
                int r2 = (pal[i5] & 16515072) >> 2;
                int g2 = (pal[i5] & 64512) >> 2;
                int b2 = (pal[i5] & 252) >> 2;
                new_pal[i5] = a2 | r2 | g2 | b2;
            }
        }
        return new_pal;
    }

    static short[] GenPalette(int type, short[] pal) {
        if (type < 0) {
            return pal;
        }
        if (type == 0) {
            return null;
        }
        short[] new_pal = new short[pal.length];
        if ((GLLibConfig.sprite_useGenPalette & 2) != 0 && type == 1) {
            for (int i = 0; i < pal.length; i++) {
                new_pal[i] = (short) ((pal[i] | 3888) & 65520);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 4) != 0 && type == 2) {
            for (int i2 = 0; i2 < pal.length; i2++) {
                new_pal[i2] = (short) ((pal[i2] | 63) & 61695);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 8) != 0 && type == 3) {
            for (int i3 = 0; i3 < pal.length; i3++) {
                new_pal[i3] = (short) ((pal[i3] | 0) & 61680);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 16) != 0 && type == 4) {
            for (int i4 = 0; i4 < pal.length; i4++) {
                int a = pal[i4] & 61440;
                int r = (pal[i4] & 3840) >> 8;
                int g = (pal[i4] & 240) >> 4;
                int b = pal[i4] & 15;
                new_pal[i4] = (short) (a | (((r + 15) >> 1) << 8) | ((g >> 1) << 4) | (b >> 1));
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 32) != 0 && type == 5) {
            for (int i5 = 0; i5 < pal.length; i5++) {
                int a2 = pal[i5] & 61440;
                int r2 = (pal[i5] & 3840) >> 2;
                int g2 = (pal[i5] & 240) >> 2;
                int b2 = (pal[i5] & 15) >> 2;
                new_pal[i5] = (short) (a2 | r2 | g2 | b2);
            }
        }
        return new_pal;
    }

    void ModifyPaletteAlpha(int palNb, int alpha) {
        if (GLLibConfig.sprite_useNokiaUI) {
            int alpha2 = (alpha >> 4) & 255;
            for (int i = 0; i < this._pal_short[palNb].length; i++) {
                if ((this._pal_short[palNb][i] & WRAP_TEXT_FORMATTING_MASK_PALETTE) != 3855 && (this._pal_short[palNb][i] >> 12) != 0) {
                    this._pal_short[palNb][i] = (short) (((alpha2 & 15) << 12) | (this._pal_short[palNb][i] & WRAP_TEXT_FORMATTING_MASK_PALETTE));
                }
            }
            return;
        }
        int alpha3 = alpha & 255;
        for (int i2 = 0; i2 < this._pal_int[palNb].length; i2++) {
            if ((this._pal_int[palNb][i2] & 16777215) != 16711935 && (this._pal_int[palNb][i2] >> 24) != 0) {
                this._pal_int[palNb][i2] = ((alpha3 & 255) << 24) | (this._pal_int[palNb][i2] & 16777215);
            }
        }
    }

    void ModifyPalette(int palNb, int color) {
        this._alpha = true;
        if (GLLibConfig.sprite_useNokiaUI) {
            int color2 = color & WRAP_TEXT_FORMATTING_MASK_PALETTE;
            int _4444 = (color2 & 240) >> 4;
            int _44442 = _4444 + ((color2 & 61440) >> 8) + ((color2 & 15728640) >> 12);
            for (int i = 0; i < this._pal_short[palNb].length; i++) {
                if ((this._pal_short[palNb][i] & WRAP_TEXT_FORMATTING_MASK_PALETTE) != 3855 && (this._pal_short[palNb][i] >> 12) != 0) {
                    this._pal_short[palNb][i] = (short) (((this._pal_short[palNb][i] & 15) << 12) | _44442);
                }
            }
            return;
        }
        int color3 = color & 16777215;
        for (int i2 = 0; i2 < this._pal_int[palNb].length; i2++) {
            if ((this._pal_int[palNb][i2] & 16777215) != 16711935 && (this._pal_int[palNb][i2] >> 24) != 0) {
                this._pal_int[palNb][i2] = ((this._pal_int[palNb][i2] & 255) << 24) | color3;
            }
        }
    }

    void ModifyPaletteAlphaUsingAltPalette(int p_iPaletteID, int p_iAlphaPaletteID) {
        this._alpha = true;
        this._multiAlpha = true;
        if (GLLibConfig.sprite_useNokiaUI) {
            for (int i = 0; i < this._pal_short[p_iPaletteID].length; i++) {
                if ((this._pal_short[p_iPaletteID][i] & WRAP_TEXT_FORMATTING_MASK_PALETTE) != 3855 && (this._pal_short[p_iPaletteID][i] >> 12) != 0) {
                    short[] sArr = this._pal_short[p_iPaletteID];
                    int i2 = i;
                    sArr[i2] = (short) (sArr[i2] & WRAP_TEXT_FORMATTING_MASK_PALETTE);
                    short[] sArr2 = this._pal_short[p_iPaletteID];
                    int i3 = i;
                    sArr2[i3] = (short) (sArr2[i3] | ((this._pal_short[p_iAlphaPaletteID][i] & 3840) << 4));
                }
            }
            return;
        }
        for (int i4 = 0; i4 < this._pal_int[p_iPaletteID].length; i4++) {
            if ((this._pal_int[p_iPaletteID][i4] & 16777215) != 16711935 && (this._pal_int[p_iPaletteID][i4] >> 24) != 0) {
                int[] iArr = this._pal_int[p_iPaletteID];
                int i5 = i4;
                iArr[i5] = iArr[i5] & 16777215;
                int[] iArr2 = this._pal_int[p_iPaletteID];
                int i6 = i4;
                iArr2[i6] = iArr2[i6] | ((this._pal_int[p_iAlphaPaletteID][i4] & 16711680) << 8);
            }
        }
    }

    void ModifyPaletteAlphaUsingLastPalette(int p_iPaletteID) {
        ModifyPaletteAlphaUsingAltPalette(p_iPaletteID, this._palettes - 1);
    }

    /* JADX WARN: Type inference failed for: r1v14, types: [Image[], Image[][]] */
    /* JADX WARN: Type inference failed for: r1v23, types: [short[][], short[][][]] */
    /* JADX WARN: Type inference failed for: r1v7, types: [int[][], int[][][]] */
    int AllocateExtraPalette() {
        this._pal_int[this._palettes] = new int[this._colors];
        this._palettes++;
        if (GLLibConfig.sprite_useNokiaUI) {
            if (this._modules_image_shortAAA != null) {
                short[][][] temp = this._modules_image_shortAAA;
                this._modules_image_shortAAA = new short[this._palettes][];
                for (int i = 0; i < this._palettes - 1; i++) {
                    this._modules_image_shortAAA[i] = temp[i];
                }
            }
        } else if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
            if (this._module_image_intAAA != null) {
                int[][][] temp2 = this._module_image_intAAA;
                this._module_image_intAAA = new int[this._palettes][];
                for (int i2 = 0; i2 < this._palettes - 1; i2++) {
                    this._module_image_intAAA[i2] = temp2[i2];
                }
            }
        } else if (this._module_image_imageAA != null) {
            Image[][] temp3 = this._module_image_imageAA;
            this._module_image_imageAA = new Image[this._palettes];
            for (int i3 = 0; i3 < this._palettes - 1; i3++) {
                this._module_image_imageAA[i3] = temp3[i3];
            }
        }
        return this._palettes - 1;
    }

    private void MarkTransformedModules(boolean bUsedByFrames, int tr_flags) {
        if (GLLibConfig.sprite_useModuleUsageFromSprite && GLLibConfig.sprite_useOperationMark) {
            if (tr_flags != 0) {
                this._modules_usage = new byte[this._nModules];
                for (int i = 0; i < this._nModules; i++) {
                    this._modules_usage[i] = (byte) tr_flags;
                }
            }
            if (this._frames_nfm == null) {
                return;
            }
            _operation = 3;
            int num_frames = this._frames_nfm.length;
            int num_anims = this._anims_naf == null ? 0 : this._anims_naf.length;
            if (GLLibConfig.sprite_useModuleMapping) {
                int old_mmapping = GetCurrentMMapping();
                for (int mm = -1; mm < GLLibConfig.MAX_MODULE_MAPPINGS; mm++) {
                    if (mm < 0 || this._map[mm] != null) {
                        SetCurrentMMapping(mm);
                        if (bUsedByFrames) {
                            for (int frame = 0; frame < num_frames; frame++) {
                                PaintFrame(null, frame, 0, 0, 0);
                            }
                        }
                        for (int anim = 0; anim < num_anims; anim++) {
                            int nfrms = GetAFrames(anim);
                            for (int frm = 0; frm < nfrms; frm++) {
                                PaintAFrame(null, anim, frm, 0, 0, 0);
                            }
                        }
                    }
                }
                SetCurrentMMapping(old_mmapping);
            } else {
                if (bUsedByFrames) {
                    for (int frame2 = 0; frame2 < num_frames; frame2++) {
                        PaintFrame(null, frame2, 0, 0, 0);
                    }
                }
                for (int anim2 = 0; anim2 < num_anims; anim2++) {
                    int nfrms2 = GetAFrames(anim2);
                    for (int frm2 = 0; frm2 < nfrms2; frm2++) {
                        PaintAFrame(null, anim2, frm2, 0, 0, 0);
                    }
                }
            }
            _operation = 0;
        }
    }

    private boolean RectOperation(int posX, int posY, int sizeX, int sizeY) {
        if (GLLibConfig.sprite_useOperationRect && _operation == 1) {
            if (posX < _rectX1) {
                _rectX1 = posX;
            }
            if (posY < _rectY1) {
                _rectY1 = posY;
            }
            if (posX + sizeX > _rectX2) {
                _rectX2 = posX + sizeX;
            }
            if (posY + sizeY > _rectY2) {
                _rectY2 = posY + sizeY;
                return true;
            }
            return true;
        }
        return false;
    }

    private boolean MarkOperation(int module, int flags) {
        if (GLLibConfig.sprite_useOperationMark && _operation == 3) {
            byte[] bArr = this._modules_usage;
            bArr[module] = (byte) (bArr[module] | (1 << (flags & 7)));
            return true;
        }
        return false;
    }

    private boolean CheckOperation(Object img, int posX, int posY, int sizeX, int sizeY, int flg, int ImgX, int ImgY) {
        if (img == null) {
            return false;
        }
        if (!GLLibConfig.sprite_useOperationRecord || _operation == 0) {
            return true;
        }
        if (_operation == 2) {
            this._aryPrecomputedImages[record_frame][record_index] = img;
            this._aryPrecomputedX[record_frame][record_index] = (short) posX;
            this._aryPrecomputedY[record_frame][record_index] = (short) posY;
            this._aryPrecomputedSizeX[record_frame][record_index] = (short) sizeX;
            this._aryPrecomputedSizeY[record_frame][record_index] = (short) sizeY;
            this._aryPrecomputedFlags[record_frame][record_index] = flg;
            if (!GLLibConfig.sprite_ModuleMapping_useModuleImages) {
                this._aryPrecomputedImgX[record_frame][record_index] = (short) ImgX;
                this._aryPrecomputedImgY[record_frame][record_index] = (short) ImgY;
            }
            record_index++;
            return false;
        }
        return false;
    }

    void PaintPrecomputedFrame(Graphics g, int x, int y, int frame) {
        PaintPrecomputedFrame1(g, x, y, frame);
    }

    void PrecomputeAllFrames(Graphics g) {
        int numfr = this._frames_nfm.length;
        for (int i = 0; i < numfr; i++) {
            PrecomputeFrame(g, i, 0);
        }
    }

    /* JADX WARN: Type inference failed for: r1v11, types: [java.lang.Object[], java.lang.Object[][]] */
    /* JADX WARN: Type inference failed for: r1v13, types: [short[], short[][]] */
    /* JADX WARN: Type inference failed for: r1v15, types: [short[], short[][]] */
    /* JADX WARN: Type inference failed for: r1v17, types: [short[], short[][]] */
    /* JADX WARN: Type inference failed for: r1v19, types: [short[], short[][]] */
    /* JADX WARN: Type inference failed for: r1v21, types: [int[], int[][]] */
    /* JADX WARN: Type inference failed for: r1v23, types: [short[], short[][]] */
    /* JADX WARN: Type inference failed for: r1v25, types: [short[], short[][]] */
    void PrecomputeFrame(Graphics g, int frame, int flags) {
        if (GLLibConfig.sprite_useOperationRecord) {
            if (this._aryPrecomputedImages == null) {
                int numfr = this._frames_nfm.length;
                this._aryPrecomputedImages = new Object[numfr];
                this._aryPrecomputedX = new short[numfr];
                this._aryPrecomputedY = new short[numfr];
                this._aryPrecomputedSizeX = new short[numfr];
                this._aryPrecomputedSizeY = new short[numfr];
                this._aryPrecomputedFlags = new int[numfr];
                if (!GLLibConfig.sprite_ModuleMapping_useModuleImages) {
                    this._aryPrecomputedImgX = new short[numfr];
                    this._aryPrecomputedImgY = new short[numfr];
                }
            }
            int nmodules = CountFrameModules(frame);
            this._aryPrecomputedImages[frame] = new Object[nmodules];
            this._aryPrecomputedX[frame] = new short[nmodules];
            this._aryPrecomputedY[frame] = new short[nmodules];
            this._aryPrecomputedSizeX[frame] = new short[nmodules];
            this._aryPrecomputedSizeY[frame] = new short[nmodules];
            this._aryPrecomputedFlags[frame] = new int[nmodules];
            if (!GLLibConfig.sprite_ModuleMapping_useModuleImages) {
                this._aryPrecomputedImgX[frame] = new short[nmodules];
                this._aryPrecomputedImgY[frame] = new short[nmodules];
            }
            record_frame = frame;
            record_index = 0;
            _operation = 2;
            PaintFrame(g, frame, 0, 0, flags);
            _operation = 0;
            record_frame = -1;
            record_index = -1;
        }
    }

    private void PaintPrecomputedFrame1(Graphics g, int x, int y, int frame) {
        if (GLLibConfig.sprite_useOperationRecord) {
            if (this._aryPrecomputedImages == null || this._aryPrecomputedImages[frame] == null) {
                PaintFrame(g, frame, x, y, 0);
                return;
            }
            int len = this._aryPrecomputedImages[frame].length;
            for (int i = 0; i < len; i++) {
                if (this._aryPrecomputedImages[frame][i] == null) {
                    g.setColor(16711680);
                    g.fillRect(this._aryPrecomputedX[frame][i] + x, this._aryPrecomputedY[frame][i] + y, this._aryPrecomputedSizeX[frame][i], this._aryPrecomputedSizeY[frame][i]);
                } else {
                    Object img = this._aryPrecomputedImages[frame][i];
                    int x1 = this._aryPrecomputedX[frame][i] + x;
                    int y1 = this._aryPrecomputedY[frame][i] + y;
                    short s = this._aryPrecomputedSizeX[frame][i];
                    short s2 = this._aryPrecomputedSizeY[frame][i];
                    int flg = this._aryPrecomputedFlags[frame][i];
                    if (GLLibConfig.sprite_useCacheRGBArrays || (GLLibConfig.sprite_useManualCacheRGBArrays && (this._flags & 1) != 0)) {
                        if (!GLLibConfig.sprite_ModuleMapping_useModuleImages) {
                            short s3 = this._aryPrecomputedImgX[frame][i];
                            short s4 = this._aryPrecomputedImgY[frame][i];
                            int cx = g.getClipX();
                            int cy = g.getClipY();
                            int cw = g.getClipWidth();
                            int ch = g.getClipHeight();
                            int new_cx = x1;
                            int new_cy = y1;
                            int new_endcx = x1 + s;
                            int new_endcy = y1 + s2;
                            if (x1 < cx) {
                                new_cx = cx;
                            }
                            if (y1 < cy) {
                                new_cy = cy;
                            }
                            if (new_endcx > cx + cw) {
                                new_endcx = cx + cw;
                            }
                            if (new_endcy > cy + ch) {
                                new_endcy = cy + ch;
                            }
                            g.setClip(new_cx, new_cy, new_endcx - new_cx, new_endcy - new_cy);
                            GLLib.DrawRGB(g, (int[]) img, 0, s, x1 - s3, y1 - s4, s, s2, this._alpha);
                            g.setClip(cx, cy, cw, ch);
                        } else {
                            GLLib.DrawRGB(g, (int[]) img, 0, s, x1, y1, s, s2, this._alpha);
                        }
                    } else if (!GLLibConfig.sprite_ModuleMapping_useModuleImages) {
                        short s5 = this._aryPrecomputedImgX[frame][i];
                        short s6 = this._aryPrecomputedImgY[frame][i];
                        if (flg == 0) {
                            int cx2 = g.getClipX();
                            int cy2 = g.getClipY();
                            int cw2 = g.getClipWidth();
                            int ch2 = g.getClipHeight();
                            int new_cx2 = x1;
                            int new_cy2 = y1;
                            int new_endcx2 = x1 + s;
                            int new_endcy2 = y1 + s2;
                            if (x1 < cx2) {
                                new_cx2 = cx2;
                            }
                            if (y1 < cy2) {
                                new_cy2 = cy2;
                            }
                            if (new_endcx2 > cx2 + cw2) {
                                new_endcx2 = cx2 + cw2;
                            }
                            if (new_endcy2 > cy2 + ch2) {
                                new_endcy2 = cy2 + ch2;
                            }
                            g.setClip(new_cx2, new_cy2, new_endcx2 - new_cx2, new_endcy2 - new_cy2);
                            g.drawImage((Image) img, x1 - s5, y1 - s6, 0);
                            g.setClip(cx2, cy2, cw2, ch2);
                        } else if (!GLLibConfig.sprite_drawRegionFlippedBug) {
                            g.drawRegion((Image) img, s5, s6, s, s2, flg, x1, y1, 0);
                        }
                    } else if (flg == 0) {
                        g.drawImage((Image) img, x1, y1, 0);
                    } else if (!GLLibConfig.sprite_drawRegionFlippedBug) {
                        g.drawRegion((Image) img, 0, 0, s, s2, flg, x1, y1, 0);
                    }
                }
            }
        }
    }

    private int readByteArrayNi(byte[] file, int offset, byte[] data, int data_len, int module_off, int module_size) {
        for (int i = 0; i < data_len; i++) {
            int i2 = offset;
            offset++;
            data[(i * module_size) + module_off] = file[i2];
        }
        return offset;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v5, types: [int] */
    /* JADX WARN: Type inference failed for: r2v9 */
    private int readArray2Short(byte[] bArr, int i, short[] sArr, int i2, int i3, boolean z, boolean z2) {
        int i4;
        for (int i5 = 0; i5 < i3; i5++) {
            int i6 = i5 + i2;
            if (z) {
                int i7 = i;
                i++;
                i4 = bArr[i7];
            } else {
                int i8 = i;
                int i9 = i + 1;
                i = i9 + 1;
                i4 = ((bArr[i8] ? 1 : 0) & 255) + (((bArr[i9] ? 1 : 0) & 255) << 8);
            }
            sArr[i6] = (short) i4;
        }
        return i;
    }

    static int[] TransformRGB(int[] image_data, int sizeX, int sizeY, int flags) {
        if ((flags & 7) == 0) {
            return image_data;
        }
        int[] output = GetPixelBuffer_int(image_data);
        int pointer = 0;
        switch (flags & 7) {
            case 1:
                for (int j = 0; j < sizeY; j++) {
                    int offset = (j + 1) * sizeX;
                    for (int i = 0; i < sizeX; i++) {
                        int i2 = pointer;
                        pointer++;
                        offset--;
                        output[i2] = image_data[offset];
                    }
                }
                break;
            case 2:
                for (int j2 = 0; j2 < sizeY; j2++) {
                    System.arraycopy(image_data, ((sizeY - j2) - 1) * sizeX, output, pointer, sizeX);
                    pointer += sizeX;
                }
                break;
            case 3:
                for (int j3 = 0; j3 < sizeY; j3++) {
                    int offset2 = (sizeY - j3) * sizeX;
                    for (int i3 = 0; i3 < sizeX; i3++) {
                        int i4 = pointer;
                        pointer++;
                        offset2--;
                        output[i4] = image_data[offset2];
                    }
                }
                break;
            case 4:
                for (int j4 = 0; j4 < sizeY; j4++) {
                    for (int i5 = 0; i5 < sizeX; i5++) {
                        int i6 = pointer;
                        pointer++;
                        output[i6] = image_data[(((sizeX - 1) - i5) * sizeY) + j4];
                    }
                }
                break;
            case 5:
                for (int j5 = 0; j5 < sizeY; j5++) {
                    for (int i7 = 0; i7 < sizeX; i7++) {
                        int i8 = pointer;
                        pointer++;
                        output[i8] = image_data[(((sizeX - 1) - i7) * sizeY) + ((sizeY - 1) - j5)];
                    }
                }
                break;
            case 6:
                for (int j6 = 0; j6 < sizeY; j6++) {
                    for (int i9 = 0; i9 < sizeX; i9++) {
                        int i10 = pointer;
                        pointer++;
                        output[i10] = image_data[(i9 * sizeY) + j6];
                    }
                }
                break;
            case 7:
                for (int j7 = 0; j7 < sizeY; j7++) {
                    for (int i11 = 0; i11 < sizeX; i11++) {
                        int i12 = pointer;
                        pointer++;
                        output[i12] = image_data[(i11 * sizeY) + ((sizeY - 1) - j7)];
                    }
                }
                break;
        }
        return output;
    }

    static short[] TransformRGB(short[] image_data, int sizeX, int sizeY, int flags) {
        return image_data;
    }

    ASprite() {
    }
}
