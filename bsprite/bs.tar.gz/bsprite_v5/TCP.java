package defpackage;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;

/* loaded from: GLLib.jar:TCP.class */
public class TCP extends Thread {
    public boolean m_connected;
    public String m_bErrorString;
    private TCPRecv m_receiveThread;
    protected Vector incomingQueue;
    protected Vector outgoingQueue;
    protected byte[] outgoing_data_on_receive_connection;
    protected String url;
    protected StreamConnection connection = null;
    protected InputStream istream = null;
    protected OutputStream ostream = null;
    protected StreamConnection receive_connection = null;
    protected InputStream receive_istream = null;
    protected OutputStream receive_ostream = null;
    public boolean m_bError = false;

    /* loaded from: GLLib.jar:TCP$TCPRecv.class */
    private class TCPRecv extends Thread {
        private InputStream is;
        private Vector v;
        private boolean m_running;
        private byte[] localReceiveBuffer = new byte[255];
        private int len;
        private int receiveBufferOffset;
        private byte[] receiveBufferQueue;
        private final TCP this$0;

        public TCPRecv(TCP this$0, InputStream inputstream, Vector vector) {
            this.this$0 = this$0;
            this.is = inputstream;
            this.v = vector;
        }

        void recvBytes() {
            this.len = -2;
            try {
                this.len = this.is.read(this.localReceiveBuffer);
            } catch (Exception e) {
                this.this$0.m_bError = true;
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    this.this$0.m_bErrorString = new StringBuffer().append("Recv th: ").append(e.getMessage() == null ? e.toString() : e.getMessage()).toString();
                }
                this.m_running = false;
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    System.out.println(new StringBuffer().append("TCP: recv exception: ").append(e.toString()).toString());
                    e.printStackTrace();
                }
            }
            if (this.len <= 0) {
                this.m_running = false;
                return;
            }
            byte[] retbuf = new byte[(this.len + this.receiveBufferQueue.length) - this.receiveBufferOffset];
            System.arraycopy(this.receiveBufferQueue, this.receiveBufferOffset, retbuf, 0, this.receiveBufferQueue.length - this.receiveBufferOffset);
            System.arraycopy(this.localReceiveBuffer, 0, retbuf, this.receiveBufferQueue.length - this.receiveBufferOffset, this.len);
            this.receiveBufferOffset = 0;
            this.receiveBufferQueue = retbuf;
            Thread.yield();
        }

        int getByte() {
            while (this.m_running && this.receiveBufferQueue.length - this.receiveBufferOffset < 1) {
                recvBytes();
            }
            if (!this.m_running) {
                return -1;
            }
            byte[] bArr = this.receiveBufferQueue;
            int i = this.receiveBufferOffset;
            this.receiveBufferOffset = i + 1;
            return bArr[i];
        }

        byte[] getBytes(int length) {
            while (this.m_running && this.receiveBufferQueue.length - this.receiveBufferOffset < length) {
                recvBytes();
            }
            byte[] retval = new byte[length];
            System.arraycopy(this.receiveBufferQueue, this.receiveBufferOffset, retval, 0, length);
            this.receiveBufferOffset += length;
            return retval;
        }

        @Override // java.lang.Thread
        public void start() {
            this.m_running = true;
            super.start();
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            this.receiveBufferQueue = new byte[0];
            this.receiveBufferOffset = 0;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("TCPRecv: Starting receiver");
            }
            while (this.m_running) {
                int packetlength = getByte();
                if (packetlength == -1) {
                    this.m_running = false;
                } else {
                    if (packetlength < 0) {
                        packetlength += 256;
                    }
                    byte[] packet = getBytes(packetlength);
                    synchronized (this.v) {
                        this.v.addElement(packet);
                    }
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        System.out.println(new StringBuffer().append("TCPRecv: Received ").append(packetlength).append(" bytes packet:").append(new String(packet)).toString());
                    }
                    Thread.yield();
                }
            }
        }
    }

    public TCP(String url) {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            this.m_bErrorString = null;
            if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
                System.out.println("Using dual connection tcp");
            } else {
                System.out.println("Using single connection tcp");
            }
        }
        this.incomingQueue = new Vector();
        this.outgoingQueue = new Vector();
        this.url = url;
        if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
            this.outgoing_data_on_receive_connection = null;
        }
    }

    public void sendPacket(byte[] data) {
        synchronized (this.outgoingQueue) {
            this.outgoingQueue.addElement(data);
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("Adding packet to outgoing queue");
            }
        }
    }

    public void sendEstablishConnectionPackageOnReceive(byte[] data) {
        if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
            this.outgoing_data_on_receive_connection = data;
        } else {
            sendPacket(data);
        }
    }

    public byte[] recvPacket() {
        byte[] returndata = null;
        synchronized (this.incomingQueue) {
            if (this.incomingQueue.size() > 0) {
                returndata = (byte[]) this.incomingQueue.firstElement();
                this.incomingQueue.removeElementAt(0);
            }
        }
        return returndata;
    }

    public void connect() {
        if (!this.m_connected) {
            try {
                new Thread(this).start();
            } catch (Exception e) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    System.out.println(new StringBuffer().append("TCP: connect exception: ").append(e.toString()).toString());
                    e.printStackTrace();
                }
            }
        }
    }

    public void disconnect() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            System.out.println("disconnecting tcp ... ");
        }
        this.m_connected = false;
    }

    private void cleanup() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            System.out.println("cleanup tcp .. ");
        }
        if (this.m_receiveThread != null) {
            this.m_receiveThread.m_running = false;
        }
        try {
            if (this.istream != null) {
                this.istream.close();
            }
        } catch (Exception e) {
        }
        try {
            if (this.ostream != null) {
                this.ostream.close();
            }
        } catch (Exception e2) {
        }
        try {
            if (this.connection != null) {
                this.connection.close();
            }
        } catch (Exception e3) {
        }
        this.istream = null;
        this.ostream = null;
        this.connection = null;
        if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
            try {
                if (this.receive_istream != null) {
                    this.receive_istream.close();
                }
            } catch (Exception e4) {
            }
            try {
                if (this.receive_ostream != null) {
                    this.receive_ostream.close();
                }
            } catch (Exception e5) {
            }
            try {
                if (this.receive_connection != null) {
                    this.receive_connection.close();
                }
            } catch (Exception e6) {
            }
            this.receive_istream = null;
            this.receive_ostream = null;
            this.receive_connection = null;
        }
        synchronized (this.outgoingQueue) {
            while (this.outgoingQueue.size() > 0) {
                this.outgoingQueue.removeElementAt(0);
            }
        }
        synchronized (this.incomingQueue) {
            while (this.incomingQueue.size() > 0) {
                this.incomingQueue.removeElementAt(0);
            }
        }
        try {
            this.m_receiveThread.join();
        } catch (Exception e7) {
        }
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        byte[] packet;
        this.m_connected = false;
        this.m_bError = false;
        try {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println(new StringBuffer().append("TCP: Opening connection to ").append(this.url).toString());
            }
            this.connection = Connector.open(this.url);
            if (this.connection == null) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    this.m_bErrorString = new StringBuffer().append("StreamConnection.open to ").append(this.url).toString();
                }
                this.m_bError = true;
                return;
            }
            if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    System.out.println(new StringBuffer().append("TCP: Opening receive connection to ").append(this.url).toString());
                }
                this.receive_connection = Connector.open(this.url);
                if (this.receive_connection == null) {
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        this.m_bErrorString = new StringBuffer().append("StreamConnection.open to ").append(this.url).toString();
                    }
                    this.m_bError = true;
                    return;
                }
            }
            this.ostream = null;
            if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
                this.receive_ostream = null;
            }
            try {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    System.out.println("TCP: Opening output stream");
                }
                this.ostream = this.connection.openOutputStream();
                if (this.ostream == null) {
                    this.m_bError = true;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        this.m_bErrorString = new StringBuffer().append("StreamConnection.openOutputStream to ").append(this.url).toString();
                        return;
                    }
                    return;
                }
                if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
                    this.receive_ostream = this.receive_connection.openOutputStream();
                    if (this.receive_ostream == null) {
                        this.m_bError = true;
                        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                            this.m_bErrorString = new StringBuffer().append("StreamConnection.openOutputStream to ").append(this.url).toString();
                            return;
                        }
                        return;
                    }
                }
                this.istream = null;
                if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
                    this.receive_istream = null;
                }
                try {
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        System.out.println("TCP: Opening input stream");
                    }
                    this.istream = this.connection.openInputStream();
                    if (this.istream == null) {
                        this.m_bError = true;
                        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                            this.m_bErrorString = new StringBuffer().append("StreamConnection.openInputStream to ").append(this.url).toString();
                            return;
                        }
                        return;
                    }
                    if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
                        this.receive_istream = this.receive_connection.openInputStream();
                        if (this.receive_istream == null) {
                            this.m_bError = true;
                            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                                this.m_bErrorString = new StringBuffer().append("StreamConnection.openInputStream to ").append(this.url).toString();
                                return;
                            }
                            return;
                        }
                    }
                    this.m_connected = true;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        System.out.println("TCP: Connection established, starting recv thread");
                    }
                    if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
                        this.m_receiveThread = new TCPRecv(this, this.receive_istream, this.incomingQueue);
                    } else {
                        this.m_receiveThread = new TCPRecv(this, this.istream, this.incomingQueue);
                    }
                    this.m_receiveThread.start();
                    byte[] psize = new byte[1];
                    while (this.m_connected && this.m_receiveThread.m_running) {
                        synchronized (this.outgoingQueue) {
                            packet = null;
                            if (this.outgoingQueue.size() > 0) {
                                packet = (byte[]) this.outgoingQueue.firstElement();
                                this.outgoingQueue.removeElementAt(0);
                            }
                        }
                        if (packet == null) {
                            Thread.yield();
                        } else {
                            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                                System.out.println("TCP: new packet to send");
                            }
                            psize[0] = (byte) (packet.length & 255);
                            try {
                                this.ostream.write(psize);
                                this.ostream.write(packet);
                            } catch (Exception e) {
                                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                                    System.out.println(new StringBuffer().append("TCP: send exception: ").append(e.toString()).toString());
                                    e.printStackTrace();
                                }
                                this.m_bError = true;
                                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                                    this.m_bErrorString = new StringBuffer().append("Send th: ").append(e.getMessage() == null ? e.toString() : e.getMessage()).toString();
                                }
                                this.m_connected = false;
                            }
                            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                                System.out.println(new StringBuffer().append("TCP: Sent ").append((int) psize[0]).append(" bytes packet:").append(new String(packet)).toString());
                            }
                            if (GLLibConfig.xplayer_ENABLE_DUAL_TCP && this.outgoing_data_on_receive_connection != null) {
                                psize[0] = (byte) (this.outgoing_data_on_receive_connection.length & 255);
                                try {
                                    this.receive_ostream.write(psize);
                                    this.receive_ostream.write(this.outgoing_data_on_receive_connection);
                                } catch (Exception e2) {
                                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                                        System.out.println(new StringBuffer().append("TCP: send exception when sending establish connection on receive: ").append(e2.toString()).toString());
                                        e2.printStackTrace();
                                    }
                                    this.m_bError = true;
                                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                                        this.m_bErrorString = new StringBuffer().append("Send th: ").append(e2.getMessage() == null ? e2.toString() : e2.getMessage()).toString();
                                    }
                                    this.m_connected = false;
                                }
                                this.outgoing_data_on_receive_connection = null;
                            }
                            Thread.yield();
                        }
                    }
                    this.m_connected = false;
                    cleanup();
                    try {
                        join();
                    } catch (Exception e3) {
                        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                            System.out.println(new StringBuffer().append("TCP: join exception: ").append(e3.toString()).toString());
                            e3.printStackTrace();
                        }
                    }
                } catch (Exception e4) {
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        System.out.println(new StringBuffer().append("TCP: run exception: ").append(e4.toString()).toString());
                        e4.printStackTrace();
                    }
                    this.m_bError = true;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        this.m_bErrorString = new StringBuffer().append("StreamConnection.openInputStream to ").append(this.url).append(" exception: ").append(e4).toString();
                    }
                }
            } catch (Exception e5) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    System.out.println(new StringBuffer().append("TCP: run exception: ").append(e5.toString()).toString());
                    e5.printStackTrace();
                }
                this.m_bError = true;
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    this.m_bErrorString = new StringBuffer().append("StreamConnection.openOutputStream to ").append(this.url).append(" exception: ").append(e5).toString();
                }
            }
        } catch (Exception e6) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println(new StringBuffer().append("TCP: run exception: ").append(e6.toString()).toString());
                e6.printStackTrace();
            }
            this.m_bError = true;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                this.m_bErrorString = new StringBuffer().append("StreamConnection.open to ").append(this.url).append(" exception: ").append(e6).toString();
            }
        }
    }
}
