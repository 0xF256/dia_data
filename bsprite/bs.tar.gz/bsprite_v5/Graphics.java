package defpackage;

import javax.microedition.lcdui.Font;
import net.rim.device.api.system.Bitmap;

/* loaded from: GLLib.jar:Graphics.class */
public class Graphics {
    private net.rim.device.api.ui.Graphics m_gfx;
    private Font m_font;
    public static final int HCENTER = 1;
    public static final int VCENTER = 2;
    public static final int LEFT = 4;
    public static final int RIGHT = 8;
    public static final int TOP = 16;
    public static final int BOTTOM = 32;
    public static final int BASELINE = 64;
    public static final int TRANS_NONE = 0;
    public static final int TRANS_MIRROR_ROT180 = 1;
    public static final int TRANS_MIRROR = 2;
    public static final int TRANS_ROT180 = 3;
    public static final int TRANS_MIRROR_ROT270 = 4;
    public static final int TRANS_ROT90 = 5;
    public static final int TRANS_ROT270 = 6;
    public static final int TRANS_MIRROR_ROT90 = 7;
    private static Bitmap m_bitmap = new Bitmap(GLLib.GetScreenWidth(), GLLib.GetScreenWidth());
    private int color;

    Graphics() {
    }

    Graphics(net.rim.device.api.ui.Graphics g) {
        this.m_gfx = g;
        this.m_gfx.pushContext(0, 0, GLLib.GetScreenWidth(), GLLib.GetScreenHeight(), 0, 0);
    }

    Graphics(int w, int h) {
        this.m_gfx = new net.rim.device.api.ui.Graphics(new Bitmap(w, h));
        this.m_gfx.pushContext(0, 0, w, h, 0, 0);
    }

    Graphics(Bitmap bmp) {
        this.m_gfx = new net.rim.device.api.ui.Graphics(bmp);
        this.m_gfx.pushContext(0, 0, bmp.getWidth(), bmp.getHeight(), 0, 0);
    }

    public void popContext() {
        this.m_gfx.popContext();
    }

    public void setClip(int x, int y, int width, int height) {
        this.color = getColor();
        this.m_gfx.popContext();
        this.m_gfx.pushContext(x, y, width, height, 0, 0);
        setColor(this.color);
    }

    public void drawString(String s, int x, int y, int flags) {
        this.m_gfx.drawText(s, x, y, flags);
    }

    public void drawImage(Image image, int x, int y, int anchor) {
        int width = image.getWidth();
        if ((anchor & 8) == 8) {
            x -= width;
        } else if ((anchor & 1) == 1) {
            x -= width >> 1;
        }
        int height = image.getHeight();
        if ((anchor & 32) == 32) {
            y -= height;
        } else if ((anchor & 2) == 2) {
            y -= height >> 1;
        }
        this.m_gfx.drawBitmap(x, y, image.m_iWidth, image.m_iHeight, image.m_bitmap, 0, 0);
    }

    public void translate(int x, int y) {
        this.m_gfx.translate(x, y);
    }

    public void drawRGB(int[] data, int offset, int scanlength, int x, int y, int w, int h, boolean processAlpha) {
        if (processAlpha) {
            m_bitmap.setARGB(data, 0, scanlength, 0, 0, w, h);
            this.m_gfx.drawBitmap(x, y, w, h, m_bitmap, 0, 0);
        } else {
            this.m_gfx.drawRGB(data, offset, scanlength, x, y, w, h);
        }
    }

    public void drawRegion(Image img, int x_src, int y_src, int width, int height, int transform, int x_dest, int y_dest, int anchor) {
        if ((anchor & 8) == 8) {
            x_dest -= width;
        } else if ((anchor & 1) == 1) {
            x_dest -= width >> 1;
        }
        if ((anchor & 32) == 32) {
            y_dest -= height;
        } else if ((anchor & 2) == 2) {
            y_dest -= height >> 1;
        }
        try {
            switch (transform) {
                case 0:
                    this.m_gfx.drawBitmap(x_dest, y_dest, width, height, img.m_bitmap, x_src, y_src);
                    break;
                case 1:
                    this.m_gfx.drawBitmap(x_dest, y_dest, width, height, img.getMirrorRot180(), x_src, (img.m_iHeight - height) - y_src);
                    break;
                case 2:
                    this.m_gfx.drawBitmap(x_dest, y_dest, width, height, img.getMirror(), (img.m_iWidth - width) - x_src, y_src);
                    break;
                case 3:
                    this.m_gfx.drawBitmap(x_dest, y_dest, width, height, img.getRot180(), (img.m_iWidth - width) - x_src, (img.m_iHeight - height) - y_src);
                    break;
                case 4:
                    this.m_gfx.drawBitmap(x_dest, y_dest, height, width, img.getMirrorRot270(), y_src, x_src);
                    break;
                case 5:
                    this.m_gfx.drawBitmap(x_dest, y_dest, height, width, img.getRot90(), (img.m_iHeight - y_src) - height, x_src);
                    break;
                case 6:
                    this.m_gfx.drawBitmap(x_dest, y_dest, height, width, img.getRot270(), y_src, (img.m_iWidth - width) - x_src);
                    break;
                case 7:
                    this.m_gfx.drawBitmap(x_dest, y_dest, height, width, img.getMirrorRot90(), (img.m_iHeight - y_src) - height, (img.m_iWidth - x_src) - width);
                    break;
            }
        } catch (Throwable th) {
        }
    }

    public void setColor(int RGB) {
        this.m_gfx.setColor(RGB);
    }

    public void setFont(Font font) {
        this.m_font = font;
    }

    public Font getFont() {
        return this.m_font;
    }

    public void fillRect(int i, int j, int k, int l) {
        this.m_gfx.fillRect(i, j, k, l);
    }

    public void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
        int[] x = {x1, x2, x3};
        int[] y = {y1, y2, y3};
        this.m_gfx.drawFilledPath(x, y, (byte[]) null, (int[]) null);
    }

    public void drawLine(int i, int j, int k, int l) {
        this.m_gfx.drawLine(i, j, k, l);
    }

    public void drawRect(int i, int j, int k, int l) {
        this.m_gfx.drawRect(i, j, k + 1, l + 1);
    }

    public int getColor() {
        return this.m_gfx.getColor();
    }

    public int getTranslateX() {
        return this.m_gfx.getTranslateX();
    }

    public int getTranslateY() {
        return this.m_gfx.getTranslateY();
    }

    public void setColor(int red, int green, int blue) {
        this.m_gfx.setColor((red << 16) | (green << 8) | blue);
    }

    public int getClipX() {
        return this.m_gfx.getClippingRect().x;
    }

    public int getClipY() {
        return this.m_gfx.getClippingRect().y;
    }

    public int getClipWidth() {
        return this.m_gfx.getClippingRect().width;
    }

    public int getClipHeight() {
        return this.m_gfx.getClippingRect().height;
    }

    public void drawRoundRect(int x, int y, int w, int h, int startAngle, int arcAngle) {
        this.m_gfx.drawRoundRect(x, y, w, h, startAngle, arcAngle);
    }

    public void fillRoundRect(int x, int y, int w, int h, int startAngle, int arcAngle) {
        this.m_gfx.fillRoundRect(x, y, w, h, startAngle, arcAngle);
    }

    public void fillArc(int x, int y, int w, int h, int startAngle, int arcAngle) {
        this.m_gfx.fillArc(x, y, w, h, startAngle, arcAngle);
    }

    public void drawArc(int x, int y, int w, int h, int startAngle, int arcAngle) {
        this.m_gfx.drawArc(x, y, w, h, startAngle, arcAngle);
    }

    public void copyArea(int x_src, int y_src, int width, int height, int x_dest, int y_dest, int anchor) {
        this.m_gfx.copyArea(x_src, y_src, width, height, x_dest, y_dest);
    }

    public void drawChar(char c, int x, int y, int anchor) {
        this.m_gfx.drawText(new StringBuffer().append("").append(c).toString(), x, y, 0);
    }

    public void clipRect(int x, int y, int width, int height) {
    }

    public int getBlueComponent() {
        return this.m_gfx.getColor() & 255;
    }

    public int getGreenComponent() {
        return (this.m_gfx.getColor() & 65280) >> 8;
    }

    public int getRedComponent() {
        return (this.m_gfx.getColor() & 16711680) >> 16;
    }

    public void drawSubstring(String str, int offset, int len, int x, int y, int anchor) {
        this.m_gfx.drawText(str, offset, len, x, y, anchor, str.length());
    }

    public void drawChars(char[] data, int offset, int length, int x, int y, int anchor) {
        int width_chars = this.m_font.charsWidth(data, offset, length);
        this.m_gfx.drawText(data, offset, length, x, y, anchor, width_chars);
    }

    public int getDisplayColor(int color) {
        net.rim.device.api.ui.Graphics graphics = this.m_gfx;
        return net.rim.device.api.ui.Graphics.getDisplayColor(color);
    }
}
