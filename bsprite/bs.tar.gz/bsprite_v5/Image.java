package defpackage;

import java.io.InputStream;
import net.rim.device.api.system.Bitmap;

/* loaded from: GLLib.jar:Image.class */
public class Image {
    public Bitmap m_bitmap;
    private Bitmap m_imgMirror;
    private Bitmap m_imgMirrorRot90;
    private Bitmap m_imgMirrorRot180;
    private Bitmap m_imgMirrorRot270;
    private Bitmap m_imgRot90;
    private Bitmap m_imgRot270;
    private Bitmap m_imgRot180;
    public int m_iWidth;
    public int m_iHeight;
    private Graphics m_gfx;

    private Image(String bmpFile) {
        try {
            InputStream is = "".getClass().getResourceAsStream(bmpFile);
            byte[] buf = new byte[is.available()];
            is.read(buf, 0, buf.length);
            is.close();
            this.m_bitmap = Bitmap.createBitmapFromPNG(buf, 0, buf.length);
            init();
        } catch (Exception e) {
        }
    }

    private Image(int w, int h) {
        this.m_bitmap = new Bitmap(w, h);
        init();
    }

    private Image(int[] data, int w, int h) {
        this.m_bitmap = new Bitmap(w, h);
        this.m_bitmap.setARGB(data, 0, w, 0, 0, w, h);
        init();
    }

    private Image(byte[] pngData, int offset, int length) {
        this.m_bitmap = Bitmap.createBitmapFromPNG(pngData, offset, length);
        init();
    }

    public void init() {
        this.m_iWidth = this.m_bitmap.getWidth();
        this.m_iHeight = this.m_bitmap.getHeight();
        this.m_gfx = new Graphics(this.m_bitmap);
    }

    public static Image createImage(String bmpFile) {
        return new Image(bmpFile);
    }

    public static Image createImage(int w, int h) {
        return new Image(w, h);
    }

    public static Image createRGBImage(int[] data, int w, int h, boolean processAlpha) {
        return new Image(data, w, h);
    }

    public static Image createImage(byte[] data, int offset, int length) {
        return new Image(data, offset, length);
    }

    public static Image createImage(Image image, int x, int y, int width, int height, int transform) {
        Image temp = new Image(width, height);
        int[] argbData = new int[width * height];
        image.m_bitmap.getARGB(argbData, 0, width, x, y, width, height);
        temp.m_bitmap.setARGB(argbData, 0, width, 0, 0, width, height);
        return temp;
    }

    public int getWidth() {
        return this.m_bitmap.getWidth();
    }

    public int getHeight() {
        return this.m_bitmap.getHeight();
    }

    public void getRGB(int[] data, int offset, int scanlength, int x, int y, int w, int h) {
        this.m_bitmap.getARGB(data, offset, scanlength, x, y, w, h);
    }

    public Graphics getGraphics() {
        return this.m_gfx;
    }

    public Bitmap getMirror() {
        if (this.m_imgMirror == null) {
            createMirror();
        }
        return this.m_imgMirror;
    }

    public Bitmap getMirrorRot90() {
        if (this.m_imgMirrorRot90 == null) {
            createMirrorRot90();
        }
        return this.m_imgMirrorRot90;
    }

    public Bitmap getMirrorRot180() {
        if (this.m_imgMirrorRot180 == null) {
            createMirrorRot180();
        }
        return this.m_imgMirrorRot180;
    }

    public Bitmap getMirrorRot270() {
        if (this.m_imgMirrorRot270 == null) {
            createMirrorRot270();
        }
        return this.m_imgMirrorRot270;
    }

    public Bitmap getRot90() {
        if (this.m_imgRot90 == null) {
            createRot90();
        }
        return this.m_imgRot90;
    }

    public Bitmap getRot180() {
        if (this.m_imgRot180 == null) {
            createRot180();
        }
        return this.m_imgRot180;
    }

    public Bitmap getRot270() {
        if (this.m_imgRot270 == null) {
            createRot270();
        }
        return this.m_imgRot270;
    }

    public void flipAll() {
        int size = this.m_iWidth * this.m_iHeight;
        int[] data = new int[size];
        int[] src = new int[size];
        this.m_bitmap.getARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        int pos2 = 0;
        int i = this.m_iWidth >> 1;
        while (true) {
            int mid = i;
            if (pos2 >= size) {
                break;
            }
            int pos0 = pos2;
            int pos1 = (pos0 + this.m_iWidth) - 1;
            while (pos0 < mid) {
                int tmp = data[pos0];
                int i2 = pos0;
                pos0++;
                data[i2] = data[pos1];
                int i3 = pos1;
                pos1 = i3 - 1;
                data[i3] = tmp;
            }
            pos2 += this.m_iWidth;
            i = mid + this.m_iWidth;
        }
        if (this.m_imgMirror == null) {
            this.m_imgMirror = new Bitmap(this.m_iWidth, this.m_iHeight);
        }
        this.m_imgMirror.setARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        int mid2 = this.m_iWidth * (this.m_iHeight >> 1);
        int pos02 = 0;
        int pos12 = size - this.m_iWidth;
        int pos22 = this.m_iWidth;
        int tmp2 = this.m_iWidth << 1;
        this.m_bitmap.getARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        while (pos22 < mid2) {
            while (pos02 < pos22) {
                int tmp3 = data[pos02];
                int i4 = pos02;
                pos02++;
                data[i4] = data[pos12];
                int i5 = pos12;
                pos12++;
                data[i5] = tmp3;
            }
            pos22 += this.m_iWidth;
            pos12 -= tmp2;
        }
        if (this.m_imgMirrorRot180 == null) {
            this.m_imgMirrorRot180 = new Bitmap(this.m_iWidth, this.m_iHeight);
        }
        this.m_imgMirrorRot180.setARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        this.m_bitmap.getARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        for (int row = 0; row < this.m_iWidth; row++) {
            for (int col = 0; col < this.m_iHeight; col++) {
                data[(row * this.m_iHeight) + col] = src[(col * this.m_iWidth) + row];
            }
        }
        if (this.m_imgMirrorRot270 == null) {
            this.m_imgMirrorRot270 = new Bitmap(this.m_iHeight, this.m_iWidth);
        }
        this.m_imgMirrorRot270.setARGB(data, 0, this.m_iHeight, 0, 0, this.m_iHeight, this.m_iWidth);
        this.m_bitmap.getARGB(src, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        for (int row2 = 0; row2 < this.m_iWidth; row2++) {
            for (int col2 = 0; col2 < this.m_iHeight; col2++) {
                data[(row2 * this.m_iHeight) + col2] = src[(((this.m_iHeight - 1) - col2) * this.m_iWidth) + ((this.m_iWidth - 1) - row2)];
            }
        }
        if (this.m_imgMirrorRot90 == null) {
            this.m_imgMirrorRot90 = new Bitmap(this.m_iHeight, this.m_iWidth);
        }
        this.m_imgMirrorRot90.setARGB(data, 0, this.m_iHeight, 0, 0, this.m_iHeight, this.m_iWidth);
        this.m_bitmap.getARGB(src, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        for (int row3 = 0; row3 < this.m_iWidth; row3++) {
            for (int col3 = 0; col3 < this.m_iHeight; col3++) {
                data[(row3 * this.m_iHeight) + col3] = src[(col3 * this.m_iWidth) + ((this.m_iWidth - 1) - row3)];
            }
        }
        if (this.m_imgRot270 == null) {
            this.m_imgRot270 = new Bitmap(this.m_iHeight, this.m_iWidth);
        }
        this.m_imgRot270.setARGB(data, 0, this.m_iHeight, 0, 0, this.m_iHeight, this.m_iWidth);
        this.m_bitmap.getARGB(src, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        for (int row4 = 0; row4 < this.m_iWidth; row4++) {
            for (int col4 = 0; col4 < this.m_iHeight; col4++) {
                data[(row4 * this.m_iHeight) + col4] = src[(((this.m_iHeight - 1) - col4) * this.m_iWidth) + row4];
            }
        }
        if (this.m_imgRot90 == null) {
            this.m_imgRot90 = new Bitmap(this.m_iHeight, this.m_iWidth);
        }
        this.m_imgRot90.setARGB(data, 0, this.m_iHeight, 0, 0, this.m_iHeight, this.m_iWidth);
        int mid3 = size >> 1;
        int pos03 = 0;
        int pos13 = size - 1;
        this.m_bitmap.getARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        while (pos03 < mid3) {
            int tmp4 = data[pos03];
            int i6 = pos03;
            pos03++;
            data[i6] = data[pos13];
            int i7 = pos13;
            pos13 = i7 - 1;
            data[i7] = tmp4;
        }
        if (this.m_imgRot180 == null) {
            this.m_imgRot180 = new Bitmap(this.m_iWidth, this.m_iHeight);
        }
        this.m_imgRot180.setARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
    }

    public void createMirror() {
        int size = this.m_iWidth * this.m_iHeight;
        int[] data = new int[size];
        this.m_bitmap.getARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        int pos2 = 0;
        int i = this.m_iWidth >> 1;
        while (true) {
            int mid = i;
            if (pos2 >= size) {
                break;
            }
            int pos0 = pos2;
            int pos1 = (pos0 + this.m_iWidth) - 1;
            while (pos0 < mid) {
                int tmp = data[pos0];
                int i2 = pos0;
                pos0++;
                data[i2] = data[pos1];
                int i3 = pos1;
                pos1 = i3 - 1;
                data[i3] = tmp;
            }
            pos2 += this.m_iWidth;
            i = mid + this.m_iWidth;
        }
        if (this.m_imgMirror == null) {
            this.m_imgMirror = new Bitmap(this.m_iWidth, this.m_iHeight);
        }
        this.m_imgMirror.setARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
    }

    public void createMirrorRot180() {
        int size = this.m_iWidth * this.m_iHeight;
        int mid = this.m_iWidth * (this.m_iHeight >> 1);
        int pos0 = 0;
        int pos1 = size - this.m_iWidth;
        int pos2 = this.m_iWidth;
        int tmp2 = this.m_iWidth << 1;
        int[] data = new int[size];
        this.m_bitmap.getARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        while (pos2 < mid) {
            while (pos0 < pos2) {
                int tmp = data[pos0];
                int i = pos0;
                pos0++;
                data[i] = data[pos1];
                int i2 = pos1;
                pos1++;
                data[i2] = tmp;
            }
            pos2 += this.m_iWidth;
            pos1 -= tmp2;
        }
        if (this.m_imgMirrorRot180 == null) {
            this.m_imgMirrorRot180 = new Bitmap(this.m_iWidth, this.m_iHeight);
        }
        this.m_imgMirrorRot180.setARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
    }

    public void createMirrorRot270() {
        int size = this.m_iWidth * this.m_iHeight;
        int[] data = new int[size];
        int[] src = new int[size];
        this.m_bitmap.getARGB(src, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        for (int row = 0; row < this.m_iWidth; row++) {
            for (int col = 0; col < this.m_iHeight; col++) {
                data[(row * this.m_iHeight) + col] = src[(col * this.m_iWidth) + row];
            }
        }
        if (this.m_imgMirrorRot270 == null) {
            this.m_imgMirrorRot270 = new Bitmap(this.m_iHeight, this.m_iWidth);
        }
        this.m_imgMirrorRot270.setARGB(data, 0, this.m_iHeight, 0, 0, this.m_iHeight, this.m_iWidth);
    }

    public void createMirrorRot90() {
        int size = this.m_iWidth * this.m_iHeight;
        int[] data = new int[size];
        int[] src = new int[size];
        this.m_bitmap.getARGB(src, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        for (int row = 0; row < this.m_iWidth; row++) {
            for (int col = 0; col < this.m_iHeight; col++) {
                data[(row * this.m_iHeight) + col] = src[(((this.m_iHeight - 1) - col) * this.m_iWidth) + ((this.m_iWidth - 1) - row)];
            }
        }
        if (this.m_imgMirrorRot90 == null) {
            this.m_imgMirrorRot90 = new Bitmap(this.m_iHeight, this.m_iWidth);
        }
        this.m_imgMirrorRot90.setARGB(data, 0, this.m_iHeight, 0, 0, this.m_iHeight, this.m_iWidth);
    }

    public void createRot270() {
        int size = this.m_iWidth * this.m_iHeight;
        int[] data = new int[size];
        int[] src = new int[size];
        this.m_bitmap.getARGB(src, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        for (int row = 0; row < this.m_iWidth; row++) {
            for (int col = 0; col < this.m_iHeight; col++) {
                data[(row * this.m_iHeight) + col] = src[(col * this.m_iWidth) + ((this.m_iWidth - 1) - row)];
            }
        }
        if (this.m_imgRot270 == null) {
            this.m_imgRot270 = new Bitmap(this.m_iHeight, this.m_iWidth);
        }
        this.m_imgRot270.setARGB(data, 0, this.m_iHeight, 0, 0, this.m_iHeight, this.m_iWidth);
    }

    public void createRot90() {
        int size = this.m_iWidth * this.m_iHeight;
        int[] data = new int[size];
        int[] src = new int[size];
        this.m_bitmap.getARGB(src, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        for (int row = 0; row < this.m_iWidth; row++) {
            for (int col = 0; col < this.m_iHeight; col++) {
                data[(row * this.m_iHeight) + col] = src[(((this.m_iHeight - 1) - col) * this.m_iWidth) + row];
            }
        }
        if (this.m_imgRot90 == null) {
            this.m_imgRot90 = new Bitmap(this.m_iHeight, this.m_iWidth);
        }
        this.m_imgRot90.setARGB(data, 0, this.m_iHeight, 0, 0, this.m_iHeight, this.m_iWidth);
    }

    public void createRot180() {
        int size = this.m_iWidth * this.m_iHeight;
        int mid = size >> 1;
        int pos0 = 0;
        int pos1 = size - 1;
        int[] data = new int[size];
        this.m_bitmap.getARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
        while (pos0 < mid) {
            int tmp = data[pos0];
            int i = pos0;
            pos0++;
            data[i] = data[pos1];
            int i2 = pos1;
            pos1 = i2 - 1;
            data[i2] = tmp;
        }
        if (this.m_imgRot180 == null) {
            this.m_imgRot180 = new Bitmap(this.m_iWidth, this.m_iHeight);
        }
        this.m_imgRot180.setARGB(data, 0, this.m_iWidth, 0, 0, this.m_iWidth, this.m_iHeight);
    }
}
