package defpackage;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;

/* loaded from: GLLib.jar:HTTP.class */
public final class HTTP implements Runnable {
    private String m_sUrl;
    private String m_sQuery;
    public String m_response;
    public byte[] m_responseByteArray;
    public static String userAgent = null;
    public static String clientId = null;
    public static String x_up_subno = null;
    public static String CarrierDeviceId = null;
    public static String upsubid = null;
    public static String x_up_calling_line_id = null;
    private final int RECEIVEBUFFERSIZE = 16;
    private Thread m_thread = null;
    private HttpConnection m_c = null;
    private InputStream m_i = null;
    private OutputStream m_o = null;
    private boolean m_bInProgress = false;
    private boolean m_bCanceled = false;
    public boolean m_bError = false;

    public boolean isInProgress() {
        return this.m_bInProgress;
    }

    public boolean isErrorOccurred() {
        return this.m_bError;
    }

    public void cancel() {
        this.m_bCanceled = true;
        if (GLLibConfig.xplayer_HTTP_NO_CANCEL) {
            return;
        }
        if (this.m_c != null) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            }
            try {
                synchronized (this.m_c) {
                    this.m_i.close();
                }
            } catch (Throwable th) {
            }
            try {
                synchronized (this.m_c) {
                    this.m_c.close();
                }
            } catch (Throwable th2) {
            }
            if (GLLibConfig.xplayer_USE_HTTP_POST) {
                try {
                    synchronized (this.m_o) {
                        this.m_o.close();
                    }
                } catch (Throwable th3) {
                }
                this.m_o = null;
            }
        }
        this.m_i = null;
        this.m_c = null;
        this.m_bInProgress = false;
        this.m_thread = null;
        GLLib.Gc();
    }

    public void cleanup() {
        cancel();
        this.m_response = null;
        this.m_responseByteArray = null;
    }

    public void sendByGet(String sUrl, String sQuery) {
        GLLib.Gc();
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
        }
        while (this.m_bInProgress) {
            try {
                if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - XPlayer.callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                    cancel();
                }
                synchronized (this) {
                    wait(50L);
                }
            } catch (Throwable th) {
            }
        }
        this.m_bInProgress = true;
        this.m_bCanceled = false;
        if (GLLibConfig.xplayer_USE_HTTP_POST) {
            this.m_sUrl = sUrl;
            this.m_sQuery = sQuery;
            this.m_sQuery = new StringBuffer().append(this.m_sQuery).append("&v=").append(GLLibConfig.xplayer_XPLAYER_VERSION).toString();
        } else {
            this.m_sUrl = new StringBuffer().append(sUrl).append("?b=").append(sQuery).toString();
            this.m_sUrl = new StringBuffer().append(this.m_sUrl).append("&v=").append(GLLibConfig.xplayer_XPLAYER_VERSION).toString();
        }
        if (this.m_thread != null) {
            try {
                this.m_thread.join();
            } catch (Throwable th2) {
            }
        }
        this.m_bError = false;
        this.m_thread = new Thread(this);
        this.m_thread.start();
    }

    @Override // java.lang.Runnable
    public void run() {
        if (this.m_sUrl == null) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            }
            cancel();
            this.m_bError = true;
            this.m_bInProgress = false;
            this.m_bCanceled = false;
            return;
        }
        if (GLLibConfig.xplayer_USE_HTTP_POST) {
            if (this.m_sQuery == null) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                }
                cancel();
                this.m_bError = true;
                this.m_bInProgress = false;
                this.m_bCanceled = false;
                return;
            }
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            }
        }
        try {
            try {
                this.m_bError = false;
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                }
                if (this.m_bCanceled) {
                    this.m_bInProgress = false;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                    cancel();
                    this.m_thread = null;
                    GLLib.Gc();
                    this.m_bInProgress = false;
                    return;
                }
                this.m_c = Connector.open(this.m_sUrl, 3);
                if (this.m_bCanceled) {
                    this.m_bInProgress = false;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                    cancel();
                    this.m_thread = null;
                    GLLib.Gc();
                    this.m_bInProgress = false;
                    return;
                }
                if (GLLibConfig.xplayer_USE_HTTP_POST) {
                    this.m_c.setRequestMethod("POST");
                } else {
                    this.m_c.setRequestMethod("GET");
                }
                this.m_c.setRequestProperty("Connection", "close");
                if (userAgent != null) {
                    this.m_c.setRequestProperty("User-Agent", userAgent);
                }
                if ((GLLibConfig.xplayer_CARRIER_USSPRINT || GLLibConfig.xplayer_CARRIER_MXTELCEL) && clientId != null) {
                    this.m_c.setRequestProperty("ClientID", clientId);
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                }
                if (GLLibConfig.xplayer_CARRIER_USVIRGIN && x_up_calling_line_id != null) {
                    this.m_c.setRequestProperty("x-up-calling-line-id", x_up_calling_line_id);
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                }
                if ((GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE || GLLibConfig.xplayer_CARRIER_USVIRGIN) && x_up_subno != null) {
                    this.m_c.setRequestProperty("x-up-subno", x_up_subno);
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                }
                if (GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE && CarrierDeviceId != null) {
                    this.m_c.setRequestProperty("CarrierDeviceId", CarrierDeviceId);
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                }
                if (GLLibConfig.xplayer_CARRIER_USNEXTEL && upsubid != null) {
                    this.m_c.setRequestProperty("UPSUBID", upsubid);
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                }
                if (GLLibConfig.xplayer_USE_HTTP_POST) {
                    this.m_c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    String sQuery = new StringBuffer().append("b=").append(this.m_sQuery).toString();
                    this.m_c.setRequestProperty("Content-Length", String.valueOf(sQuery.length()));
                    this.m_o = this.m_c.openOutputStream();
                    this.m_o.write(sQuery.getBytes(), 0, sQuery.length());
                    this.m_o.flush();
                }
                if (this.m_bCanceled) {
                    this.m_bInProgress = false;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                    cancel();
                    this.m_thread = null;
                    GLLib.Gc();
                    this.m_bInProgress = false;
                    return;
                }
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                }
                int responseCode = this.m_c.getResponseCode();
                HttpConnection httpConnection = this.m_c;
                if (responseCode != 200) {
                    cancel();
                    this.m_bError = true;
                    this.m_bInProgress = false;
                    this.m_bCanceled = false;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                    cancel();
                    this.m_thread = null;
                    GLLib.Gc();
                    this.m_bInProgress = false;
                    return;
                }
                if (this.m_bCanceled) {
                    this.m_bInProgress = false;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                    cancel();
                    this.m_thread = null;
                    GLLib.Gc();
                    this.m_bInProgress = false;
                    return;
                }
                synchronized (this.m_c) {
                    this.m_i = this.m_c.openInputStream();
                }
                Thread thread = this.m_thread;
                Thread.yield();
                if (this.m_bCanceled) {
                    this.m_bInProgress = false;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                    cancel();
                    this.m_thread = null;
                    GLLib.Gc();
                    this.m_bInProgress = false;
                    return;
                }
                ByteArrayOutputStream bao = new ByteArrayOutputStream();
                byte[] abInBuffer = new byte[16];
                int nBytesRead = 0;
                while (nBytesRead != -1) {
                    if (this.m_bCanceled) {
                        this.m_bInProgress = false;
                        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        }
                        cancel();
                        this.m_thread = null;
                        GLLib.Gc();
                        this.m_bInProgress = false;
                        return;
                    }
                    if (GLLibConfig.xplayer_USE_BUG_FIX_MESSAGE_SIZE) {
                        for (int i = 0; i < 16; i++) {
                            abInBuffer[i] = 0;
                        }
                    }
                    nBytesRead = this.m_i.read(abInBuffer, 0, 16);
                    if (this.m_bCanceled) {
                        this.m_bInProgress = false;
                        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        }
                        cancel();
                        this.m_thread = null;
                        GLLib.Gc();
                        this.m_bInProgress = false;
                        return;
                    }
                    if (nBytesRead == -1) {
                        break;
                    }
                    if (GLLibConfig.xplayer_USE_BUG_FIX_MESSAGE_SIZE) {
                        int i2 = 15;
                        while (i2 >= 0 && abInBuffer[i2] == 0) {
                            i2--;
                        }
                        nBytesRead = i2 + 1;
                    }
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                    bao.write(abInBuffer, 0, nBytesRead);
                }
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                }
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                }
                if (this.m_bCanceled) {
                    this.m_bInProgress = false;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    }
                    cancel();
                    this.m_thread = null;
                    GLLib.Gc();
                    this.m_bInProgress = false;
                    return;
                }
                this.m_response = bao.toString();
                this.m_responseByteArray = bao.toByteArray();
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                }
                cancel();
                this.m_thread = null;
                GLLib.Gc();
                this.m_bInProgress = false;
            } catch (Throwable th) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                }
                this.m_bError = true;
                this.m_bInProgress = false;
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                }
                cancel();
                this.m_thread = null;
                GLLib.Gc();
                this.m_bInProgress = false;
            }
        } catch (Throwable th2) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            }
            cancel();
            this.m_thread = null;
            GLLib.Gc();
            this.m_bInProgress = false;
            throw th2;
        }
    }
}
