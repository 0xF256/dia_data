package defpackage;

/* loaded from: GLLib.jar:GLLibPlayer.class */
class GLLibPlayer implements Runnable {
    int posX;
    int posY;
    int curFlags;
    ASprite sprite;
    private int curAnim;
    private int curFrame;
    public int curTime;
    private int nbLoop;
    private boolean animIsOver;
    private int curBlend;
    private int curScale;
    private static final int k_snd_command_dummy = 0;
    private static final int k_snd_command_prepare = 1;
    private static final int k_snd_command_free = 2;
    private static final int k_snd_command_play = 3;
    private static final int k_snd_command_stop = 4;
    private static final int k_snd_command_pause = 5;
    private static final int k_snd_command_resume = 6;
    private static final int k_snd_command_amount = 7;
    private static final int k_snd_state_unprepared = 0;
    private static final int k_snd_state_ready = 1;
    private static final int k_snd_state_playing = 2;
    private static final int k_snd_state_paused = 3;
    private static final int k_snd_queue_command = 0;
    private static final int k_snd_queue_index = 1;
    private static final int k_snd_queue_priority = 2;
    private static final int k_snd_queue_volume = 3;
    private static final int k_snd_queue_loop = 4;
    private static final int k_snd_queue_size = 5;
    private static final int k_snd_max_queue_length = 7;
    static final int k_snd_priority_highest = 0;
    static final int k_snd_priority_normal = 7;
    static final int k_snd_priority_lowest = 15;
    static int s_snd_masterVolume;
    static int s_snd_maxNbSoundSlot;
    private static boolean s_snd_isSoundEngineInitialized;
    public static final int WRAP_CLAMP = 0;
    public static final int WRAP_REPEAT = 1;
    public static final int TILESET_EFFECT_NONE = 0;
    public static final int TILESET_EFFECT_NORMAL = 1;
    public static final int TILESET_EFFECT_ADDITIVE = 2;
    public static final int TILESET_EFFECT_MULTIPLICATIVE = 3;
    private static final int k_TilesetInfoDestWidth = 0;
    private static final int k_TilesetInfoDestHeight = 1;
    private static final int k_TilesetInfoTileWidth = 2;
    private static final int k_TilesetInfoTileWidthShift = 3;
    private static final int k_TilesetInfoTileWidthMask = 4;
    private static final int k_TilesetInfoTileHeight = 5;
    private static final int k_TilesetInfoTileHeightShift = 6;
    private static final int k_TilesetInfoTileHeightMask = 7;
    private static final int k_TilesetInfoCOUNT = 8;
    private static final int k_TilesetLayerInitialized = 0;
    private static final int k_TilesetLayerEnabled = 1;
    private static final int k_TilesetLayerTileCountWidth = 2;
    private static final int k_TilesetLayerTileCountHeight = 3;
    private static final int k_TilesetLayerWidth = 4;
    private static final int k_TilesetLayerHeight = 5;
    private static final int k_TilesetLayerCBWidth = 6;
    private static final int k_TilesetLayerCBHeight = 7;
    private static final int k_TilesetLayerFirstTileX = 8;
    private static final int k_TilesetLayerFirstTileY = 9;
    private static final int k_TilesetLayerLastTileX = 10;
    private static final int k_TilesetLayerLastTileY = 11;
    private static final int k_TilesetLayerCamX = 12;
    private static final int k_TilesetLayerCamY = 13;
    private static final int k_TilesetLayerFlag = 14;
    private static final int k_TilesetLayerCOUNT = 15;
    private static final int k_TilesetLayerImageCB = 0;
    private static final int k_TilesetLayerImageCOUNT = 1;
    private static final int k_TilesetLayerGraphicsCB = 0;
    private static final int k_TilesetLayerGraphicsCOUNT = 1;
    private static final int k_TilesetLayerDataMap = 0;
    private static final int k_TilesetLayerDataFlip = 1;
    private static final int k_TilesetLayerDataCOUNT = 2;
    private static int[] s_TilesetInfo;
    private static int[][] s_TilesetLayerInfo;
    private static byte[][][] s_TilesetLayerData;
    private static Image[][] s_TilesetLayerImage;
    private static Graphics[][] s_TilesetLayerGraphics;
    private static ASprite[] s_TilesetSprite;
    private static final int flag_wrappingX = 1;
    private static final int flag_wrappingY = 2;
    private static final int flag_useCB = 4;
    private static final int flag_origin = 8;
    private static int k_animBaseFrameTime = 1000 / GLLibConfig.sprite_animFPS;
    private static boolean s_bTilesetPlayerInitialized = false;
    private static int s_TilesetMaxLayerCount = GLLibConfig.tileset_maxLayerCount;
    private static int s_TilesetEffectLayer = -1;
    private static int s_TilesetAlphaLayer = -1;
    private static int s_TilesetEffectType = 0;

    GLLibPlayer() {
        Reset();
    }

    GLLibPlayer(ASprite sprite, int x, int y) {
        Reset();
        this.posX = x;
        this.posY = y;
        SetSprite(sprite);
    }

    void Reset() {
        this.posX = 0;
        this.posY = 0;
        this.curAnim = -1;
        this.curFrame = 0;
        this.sprite = null;
        this.curFlags = 0;
        this.curTime = 0;
        this.nbLoop = 1;
        this.animIsOver = true;
        if (GLLibConfig.pfx_useSpriteEffects && GLLibConfig.pfx_useSpriteEffectScale) {
            this.curScale = -1;
        }
        if (GLLibConfig.pfx_useSpriteEffects && GLLibConfig.pfx_useSpriteEffectBlend) {
            this.curBlend = -1;
        }
    }

    final void SetPos(int x, int y) {
        this.posX = x;
        this.posY = y;
    }

    final ASprite GetSprite() {
        return this.sprite;
    }

    void SetSprite(ASprite sprite) {
        this.sprite = sprite;
        SetAnim(-1, -1);
    }

    final void SetAnim(int anim) {
        SetAnim(anim, -1);
    }

    final void SetAnim(int anim, int nbLoop, boolean restart) {
        if (restart) {
            SetAnim(-1, 1);
        }
        SetAnim(anim, nbLoop);
    }

    void SetAnim(int anim, int nbLoop) {
        if (this.animIsOver || anim != this.curAnim) {
            this.curAnim = anim;
            SetFrame(0);
            this.nbLoop = nbLoop - 1;
            this.animIsOver = false;
        }
    }

    final int GetAnim() {
        return this.curAnim;
    }

    int SetFrame(int frame) {
        if (this.curAnim < 0) {
            return -1;
        }
        int nbFrame = GetNbFrame();
        while (frame > nbFrame) {
            frame -= nbFrame;
        }
        this.curFrame = frame;
        this.curTime = 0;
        return frame;
    }

    void RandomizeAnim() {
        this.curFrame = GLLib.Math_Rand(0, GetNbFrame());
        this.curTime = 0;
    }

    final int GetFrame() {
        return this.curFrame;
    }

    final void SetTransform(int transform) {
        switch (transform) {
            case 0:
                this.curFlags = 0;
                break;
            case 1:
                this.curFlags = 2;
                break;
            case 2:
                this.curFlags = 1;
                break;
            case 3:
                this.curFlags = 3;
                break;
            case 4:
                this.curFlags = 5;
                break;
            case 5:
                this.curFlags = 4;
                break;
            case 6:
                this.curFlags = 7;
                break;
            case 7:
                this.curFlags = 6;
                break;
        }
    }

    final int GetTransform() {
        switch (this.curFlags) {
            case 0:
                return 0;
            case 1:
                return 2;
            case 2:
                return 1;
            case 3:
                return 3;
            case 4:
                return 5;
            case 5:
                return 4;
            case 6:
                return 7;
            case 7:
                return 6;
            default:
                return -1;
        }
    }

    int GetNbanim() {
        return this.sprite._anims_naf.length;
    }

    int GetNbFrame() {
        if (this.curAnim >= 0) {
            return this.sprite.GetAFrames(this.curAnim);
        }
        return -1;
    }

    final int GetDuration() {
        if (this.curAnim >= 0) {
            return this.sprite.GetAFrameTime(this.curAnim, this.curFrame) * k_animBaseFrameTime;
        }
        return 0;
    }

    boolean IsAnimOver() {
        if (this.curAnim < 0) {
            return true;
        }
        if (this.nbLoop < 0) {
            return false;
        }
        return this.animIsOver;
    }

    void Render() {
        if (this.curAnim < 0) {
            return;
        }
        if (GLLibConfig.pfx_useSpriteEffects && (GLLibConfig.pfx_useSpriteEffectScale || GLLibConfig.pfx_useSpriteEffectBlend)) {
            if (GLLibConfig.pfx_useSpriteEffectScale && this.curScale != -1) {
                GLLib.PFX_EnableEffect(9);
                GLLib.PFX_SetParam(9, 1, this.curScale);
                if (GLLibConfig.pfx_useSpriteEffectBlend && this.curBlend != -1) {
                    GLLib.PFX_SetParam(9, 2, this.curBlend);
                }
            } else if (GLLibConfig.pfx_useSpriteEffectBlend && this.curBlend != -1) {
                GLLib.PFX_EnableEffect(8);
                GLLib.PFX_SetParam(8, 1, this.curBlend);
            }
        }
        this.sprite.PaintAFrame(GLLib.g, this.curAnim, this.curFrame, this.posX, this.posY, this.curFlags, 0, 0);
        if (GLLibConfig.pfx_useSpriteEffects) {
            if (GLLibConfig.pfx_useSpriteEffectScale || GLLibConfig.pfx_useSpriteEffectBlend) {
                GLLib.PFX_DisableAllSpriteEffects();
            }
        }
    }

    final void Update() {
        if (GLLibConfig.sprite_animFPS == 1000) {
            Update(1);
        } else {
            Update(GLLib.s_game_frameDT);
        }
    }

    void Update(int DT) {
        if (this.animIsOver || this.curAnim < 0) {
            return;
        }
        this.curTime += DT;
        int duration = GetDuration();
        if (GLLibConfig.sprite_noFrameSkip) {
            if (this.curTime >= duration) {
                this.curTime -= duration;
                if (this.curFrame < this.sprite.GetAFrames(this.curAnim) - 1) {
                    this.curFrame++;
                } else if (this.nbLoop == 0) {
                    this.animIsOver = true;
                } else {
                    if (this.nbLoop > 0) {
                        this.nbLoop--;
                    }
                    this.curFrame = 0;
                }
                GetDuration();
                return;
            }
            return;
        }
        while (this.curTime >= duration) {
            this.curTime -= duration;
            if (this.curFrame < this.sprite.GetAFrames(this.curAnim) - 1) {
                this.curFrame++;
            } else if (this.nbLoop == 0) {
                this.animIsOver = true;
                return;
            } else {
                if (this.nbLoop > 0) {
                    this.nbLoop--;
                }
                this.curFrame = 0;
            }
            duration = GetDuration();
        }
    }

    final int GetScale() {
        if (GLLibConfig.pfx_useSpriteEffects && GLLibConfig.pfx_useSpriteEffectScale) {
            return this.curScale;
        }
        return 0;
    }

    final void SetScale(int scale) {
        if (GLLibConfig.pfx_useSpriteEffects && GLLibConfig.pfx_useSpriteEffectScale) {
            this.curScale = scale;
        }
    }

    final int GetBlend() {
        if (GLLibConfig.pfx_useSpriteEffects && GLLibConfig.pfx_useSpriteEffectBlend) {
            return this.curBlend;
        }
        return 0;
    }

    final void SetBlend(int alpha) {
        if (GLLibConfig.pfx_useSpriteEffects && GLLibConfig.pfx_useSpriteEffectBlend) {
            this.curBlend = alpha;
        }
    }

    static int SndQueue_NormalizeIndex(int index) {
        return -1;
    }

    static int SndQueue_GetData(int channel, int index) {
        return 0;
    }

    static void SndQueue_Push(int channel, int command, int index, int priority, int volume, int loop) {
    }

    static void SndQueue_Push(int channel, int command) {
    }

    static void SndQueue_Pop(int channel) {
    }

    static void Snd_Init(int nbSoundSlot) {
    }

    static void Snd_Quit() {
    }

    static void Snd_LoadSound(String dataFileName, int index) {
    }

    static void Snd_UnLoadSound(int index) {
    }

    static void Snd_PrepareSound(int channel, int index, int priority) {
    }

    static void Snd_FreeChannel(int channel) {
    }

    static void Snd_Play(int channel, int index, int loop, int volume, int priority) {
    }

    static void Snd_Stop(int channel) {
    }

    static void Snd_StopAllSounds() {
    }

    static void Snd_Pause(int channel) {
    }

    static void Snd_Resume(int channel) {
    }

    static void Snd_SetMasterVolume(int volume) {
    }

    static void Snd_Update() {
    }

    static boolean Snd_IsPlaying(int channel) {
        return false;
    }

    static int Snd_GetCurrentSoundIndex(int nChannel) {
        return 0;
    }

    @Override // java.lang.Runnable
    public void run() {
    }

    static long Snd_MediaTimeGet(int channel) {
        return -1L;
    }

    static long Snd_MediaTimeSet(int channel, long time) {
        return -1L;
    }

    static boolean Snd_MidiSetChannelVolume(int channel, int MIDIChannel, int volume) {
        return false;
    }

    static void Snd_MidiPlayNote(int channel, int MIDIChannel, int note, int volume) {
    }

    static int Snd_TempoGet(int channel) {
        return -1;
    }

    static boolean Snd_TempoSet(int channel, int tempo) {
        return false;
    }

    static int Snd_RateGet(int channel) {
        return 100000;
    }

    static boolean Snd_RateSet(int channel, int rate) {
        return false;
    }

    static int Snd_RateGetMax(int channel) {
        return 100000;
    }

    static int Snd_RateGetMin(int channel) {
        return 100000;
    }

    static int Snd_DurationGet(int channel) {
        return 0;
    }

    static Object Snd_GetChannelPlayer(int channel) {
        return null;
    }

    static void Snd_ForceExecOnThreadOnGamePause() {
    }

    static void Tileset_Init(int nDestWidth, int nDestHeight, int nTileWidth, int nTileHeight) {
        s_TilesetInfo = new int[8];
        s_TilesetLayerInfo = new int[s_TilesetMaxLayerCount][15];
        s_TilesetLayerData = new byte[s_TilesetMaxLayerCount][2][];
        s_TilesetLayerImage = new Image[s_TilesetMaxLayerCount][1];
        s_TilesetLayerGraphics = new Graphics[s_TilesetMaxLayerCount][1];
        s_TilesetSprite = new ASprite[s_TilesetMaxLayerCount];
        s_TilesetInfo[0] = nDestWidth;
        s_TilesetInfo[1] = nDestHeight;
        if (GLLibConfig.tileset_useTileShift) {
            int nTileWidth2 = GLLib.Math_Log2(nTileWidth);
            int nTileHeight2 = GLLib.Math_Log2(nTileHeight);
            s_TilesetInfo[3] = nTileWidth2;
            s_TilesetInfo[2] = 1 << nTileWidth2;
            s_TilesetInfo[4] = s_TilesetInfo[2] - 1;
            s_TilesetInfo[6] = nTileHeight2;
            s_TilesetInfo[5] = 1 << nTileHeight2;
            s_TilesetInfo[7] = s_TilesetInfo[5] - 1;
        } else {
            s_TilesetInfo[2] = nTileWidth;
            s_TilesetInfo[4] = 0;
            s_TilesetInfo[5] = nTileHeight;
            s_TilesetInfo[7] = 0;
        }
        s_bTilesetPlayerInitialized = true;
    }

    private static final boolean isFlag(int nLayer, int flag) {
        return (s_TilesetLayerInfo[nLayer][14] & flag) != 0;
    }

    private static final void setFlag(int nLayer, int flag, boolean value) {
        if (value) {
            int[] iArr = s_TilesetLayerInfo[nLayer];
            iArr[14] = iArr[14] | flag;
        } else {
            int[] iArr2 = s_TilesetLayerInfo[nLayer];
            iArr2[14] = iArr2[14] & (flag ^ (-1));
        }
    }

    static void Tileset_LoadLayer(int nLayer, byte[] MapSizes, byte[] MapData, byte[] MapFlip, ASprite MapSprite, boolean bUseCB, int origin, int wrappingX, int wrappingY) {
        if (bUseCB) {
            Tileset_LoadLayer(nLayer, MapSizes, MapData, MapFlip, MapSprite, nLayer, origin, wrappingX, wrappingY);
        } else {
            Tileset_LoadLayer(nLayer, MapSizes, MapData, MapFlip, MapSprite, -1, origin, wrappingX, wrappingY);
        }
    }

    static void Tileset_LoadLayer(int nLayer, byte[] MapSizes, byte[] MapData, byte[] MapFlip, ASprite MapSprite, int iUseCB, int origin, int wrappingX, int wrappingY) {
        if (!s_bTilesetPlayerInitialized) {
            return;
        }
        Tileset_Destroy(nLayer, false);
        s_TilesetLayerData[nLayer][0] = MapData;
        s_TilesetLayerData[nLayer][1] = MapFlip;
        s_TilesetLayerInfo[nLayer][2] = GLLib.Mem_GetShort(MapSizes, 0);
        s_TilesetLayerInfo[nLayer][3] = GLLib.Mem_GetShort(MapSizes, 2);
        s_TilesetLayerInfo[nLayer][4] = s_TilesetLayerInfo[nLayer][2] * s_TilesetInfo[2];
        s_TilesetLayerInfo[nLayer][5] = s_TilesetLayerInfo[nLayer][3] * s_TilesetInfo[5];
        s_TilesetSprite[nLayer] = MapSprite;
        if (iUseCB > -1) {
            try {
                if (GLLibConfig.tileset_useTileShift) {
                    s_TilesetLayerInfo[nLayer][6] = (s_TilesetInfo[0] & (s_TilesetInfo[4] ^ (-1))) + (1 * s_TilesetInfo[2]);
                    s_TilesetLayerInfo[nLayer][7] = (s_TilesetInfo[1] & (s_TilesetInfo[7] ^ (-1))) + (1 * s_TilesetInfo[5]);
                    if (s_TilesetLayerInfo[nLayer][6] - s_TilesetInfo[0] < s_TilesetInfo[2]) {
                        int[] iArr = s_TilesetLayerInfo[nLayer];
                        iArr[6] = iArr[6] + s_TilesetInfo[2];
                    }
                    if (s_TilesetLayerInfo[nLayer][7] - s_TilesetInfo[1] < s_TilesetInfo[5]) {
                        int[] iArr2 = s_TilesetLayerInfo[nLayer];
                        iArr2[7] = iArr2[7] + s_TilesetInfo[5];
                    }
                } else {
                    int nRestX = s_TilesetInfo[0] % s_TilesetInfo[2];
                    int nAddX = 1 + (nRestX != 0 ? 1 : 0);
                    s_TilesetLayerInfo[nLayer][6] = (s_TilesetInfo[0] - nRestX) + (nAddX * s_TilesetInfo[2]);
                    int nRestY = s_TilesetInfo[1] % s_TilesetInfo[5];
                    int nAddY = 1 + (nRestY != 0 ? 1 : 0);
                    s_TilesetLayerInfo[nLayer][7] = (s_TilesetInfo[1] - nRestY) + (nAddY * s_TilesetInfo[5]);
                }
                if (iUseCB == nLayer) {
                    if (s_TilesetLayerImage[nLayer][0] == null || s_TilesetLayerImage[nLayer][0].getWidth() != s_TilesetLayerInfo[nLayer][6] || s_TilesetLayerImage[nLayer][0].getHeight() != s_TilesetLayerInfo[nLayer][7]) {
                        s_TilesetLayerImage[nLayer][0] = Image.createImage(s_TilesetLayerInfo[nLayer][6], s_TilesetLayerInfo[nLayer][7]);
                        s_TilesetLayerGraphics[nLayer][0] = s_TilesetLayerImage[nLayer][0].getGraphics();
                    }
                } else {
                    s_TilesetLayerImage[nLayer][0] = s_TilesetLayerImage[iUseCB][0];
                    s_TilesetLayerGraphics[nLayer][0] = s_TilesetLayerGraphics[iUseCB][0];
                }
                setFlag(nLayer, 4, true);
            } catch (Throwable th) {
            }
        }
        s_TilesetLayerInfo[nLayer][8] = -1;
        s_TilesetLayerInfo[nLayer][9] = -1;
        s_TilesetLayerInfo[nLayer][10] = -1;
        s_TilesetLayerInfo[nLayer][11] = -1;
        s_TilesetLayerInfo[nLayer][0] = 1;
        s_TilesetLayerInfo[nLayer][1] = 1;
        s_TilesetLayerInfo[nLayer][12] = 0;
        s_TilesetLayerInfo[nLayer][13] = 0;
        setFlag(nLayer, 1, wrappingX == 1);
        setFlag(nLayer, 2, wrappingY == 1);
        setFlag(nLayer, 8, origin == 32);
    }

    static void Tileset_Destroy(int nLayer) {
        Tileset_Destroy(nLayer, true);
    }

    /* JADX WARN: Multi-variable type inference failed */
    static void Tileset_Destroy(int nLayer, boolean bFreeBufferImage) {
        if (!s_bTilesetPlayerInitialized) {
            return;
        }
        s_TilesetLayerInfo[nLayer] = new int[15];
        if (bFreeBufferImage) {
            s_TilesetLayerImage[nLayer] = new Image[1];
            s_TilesetLayerGraphics[nLayer] = new Graphics[1];
        }
        s_TilesetLayerData[nLayer] = new byte[2];
        s_TilesetSprite[nLayer] = null;
    }

    static void Tileset_Draw(Graphics g, int nLayer) {
        Tileset_Draw(g, 0, 0, nLayer);
    }

    static void Tileset_Draw(Graphics g, int dx, int dy, int nLayer) {
        int tileX0;
        int tileY0;
        int nbTileX;
        int nbTileY;
        int offsetX;
        int offsetY;
        int firstTileX;
        int firstTileY;
        int lastTileX;
        int lastTileY;
        int start;
        int end;
        int start2;
        int end2;
        if (!s_bTilesetPlayerInitialized) {
            return;
        }
        int cx = 0;
        int cy = 0;
        int cw = 0;
        int ch = 0;
        if (g != null) {
            cx = g.getClipX();
            cy = g.getClipY();
            cw = g.getClipWidth();
            ch = g.getClipHeight();
        }
        int destWidth = s_TilesetInfo[0];
        int destHeight = s_TilesetInfo[1];
        if (nLayer == -1) {
            for (int i = 0; i < s_TilesetMaxLayerCount; i++) {
                if (GLLibConfig.tileset_usePixelEffects) {
                    if (i != s_TilesetAlphaLayer) {
                        Tileset_Draw(g, i);
                    }
                } else {
                    Tileset_Draw(g, i);
                }
            }
            return;
        }
        if (s_TilesetLayerInfo[nLayer][0] != 1 || s_TilesetLayerInfo[nLayer][1] != 1) {
            return;
        }
        int originX = s_TilesetLayerInfo[nLayer][12];
        int originY = s_TilesetLayerInfo[nLayer][13];
        if (isFlag(nLayer, 4)) {
            if (GLLibConfig.tileset_useTileShift) {
                firstTileX = originX >> s_TilesetInfo[3];
                firstTileY = originY >> s_TilesetInfo[6];
                lastTileX = (originX + s_TilesetInfo[0]) >> s_TilesetInfo[3];
                lastTileY = (originY + s_TilesetInfo[1]) >> s_TilesetInfo[6];
            } else {
                int nTmpStartX = originX;
                int nTmpStartY = originY;
                if (nTmpStartX < 0) {
                    nTmpStartX -= s_TilesetInfo[2];
                }
                if (nTmpStartY < 0) {
                    nTmpStartY -= s_TilesetInfo[5];
                }
                firstTileX = nTmpStartX / s_TilesetInfo[2];
                firstTileY = nTmpStartY / s_TilesetInfo[5];
                lastTileX = (firstTileX + (s_TilesetLayerInfo[nLayer][6] / s_TilesetInfo[2])) - 1;
                lastTileY = (firstTileY + (s_TilesetLayerInfo[nLayer][7] / s_TilesetInfo[5])) - 1;
            }
            if (s_TilesetLayerInfo[nLayer][8] != firstTileX || s_TilesetLayerInfo[nLayer][10] != lastTileX) {
                if (s_TilesetLayerInfo[nLayer][8] < firstTileX || s_TilesetLayerInfo[nLayer][10] < lastTileX) {
                    if (s_TilesetLayerInfo[nLayer][10] < firstTileX) {
                        start = firstTileX;
                        end = lastTileX;
                    } else {
                        start = s_TilesetLayerInfo[nLayer][10] + 1;
                        end = lastTileX;
                    }
                } else if (s_TilesetLayerInfo[nLayer][8] > lastTileX) {
                    start = firstTileX;
                    end = lastTileX;
                } else {
                    start = firstTileX;
                    end = s_TilesetLayerInfo[nLayer][8] - 1;
                }
                Tileset_UpdateBuffer(s_TilesetLayerGraphics[nLayer][0], nLayer, start, firstTileY, end - start, lastTileY - firstTileY, 0, 0);
                s_TilesetLayerInfo[nLayer][8] = firstTileX;
                s_TilesetLayerInfo[nLayer][10] = lastTileX;
            }
            if (s_TilesetLayerInfo[nLayer][9] != firstTileY || s_TilesetLayerInfo[nLayer][11] != lastTileY) {
                if (s_TilesetLayerInfo[nLayer][9] < firstTileY || s_TilesetLayerInfo[nLayer][11] < lastTileY) {
                    if (s_TilesetLayerInfo[nLayer][11] < firstTileY) {
                        start2 = firstTileY;
                        end2 = lastTileY;
                    } else {
                        start2 = s_TilesetLayerInfo[nLayer][11] + 1;
                        end2 = lastTileY;
                    }
                } else if (s_TilesetLayerInfo[nLayer][9] > lastTileY) {
                    start2 = firstTileY;
                    end2 = lastTileY;
                } else {
                    start2 = firstTileY;
                    end2 = s_TilesetLayerInfo[nLayer][9] - 1;
                }
                Tileset_UpdateBuffer(s_TilesetLayerGraphics[nLayer][0], nLayer, firstTileX, start2, lastTileX - firstTileX, end2 - start2, 0, 0);
                s_TilesetLayerInfo[nLayer][9] = firstTileY;
                s_TilesetLayerInfo[nLayer][11] = lastTileY;
            }
            if (g != null) {
                while (originX < 0) {
                    originX += s_TilesetLayerInfo[nLayer][6];
                }
                while (originY < 0) {
                    originY += s_TilesetLayerInfo[nLayer][7];
                }
                int modX0 = originX % s_TilesetLayerInfo[nLayer][6];
                int modY0 = originY % s_TilesetLayerInfo[nLayer][7];
                int modX1 = (originX + destWidth) % s_TilesetLayerInfo[nLayer][6];
                int modY1 = (originY + destHeight) % s_TilesetLayerInfo[nLayer][7];
                if (modX1 > modX0) {
                    if (modY1 > modY0) {
                        Tileset_Draw2Screen(g, nLayer, modX0, modY0, destWidth, destHeight, 0 + dx, 0 + dy);
                    } else {
                        Tileset_Draw2Screen(g, nLayer, modX0, modY0, destWidth, destHeight - modY1, 0 + dx, 0 + dy);
                        Tileset_Draw2Screen(g, nLayer, modX0, 0, destWidth, modY1, 0 + dx, (destHeight - modY1) + dy);
                    }
                } else if (modY1 > modY0) {
                    Tileset_Draw2Screen(g, nLayer, modX0, modY0, destWidth - modX1, destHeight, 0 + dx, 0 + dy);
                    Tileset_Draw2Screen(g, nLayer, 0, modY0, modX1, destHeight, (destWidth - modX1) + dx, 0 + dy);
                } else {
                    Tileset_Draw2Screen(g, nLayer, modX0, modY0, destWidth - modX1, destHeight - modY1, 0 + dx, 0 + dy);
                    Tileset_Draw2Screen(g, nLayer, modX0, 0, destWidth - modX1, modY1, 0 + dx, (destHeight - modY1) + dy);
                    Tileset_Draw2Screen(g, nLayer, 0, modY0, modX1, destHeight - modY1, (destWidth - modX1) + dx, 0 + dy);
                    Tileset_Draw2Screen(g, nLayer, 0, 0, modX1, modY1, (destWidth - modX1) + dx, (destHeight - modY1) + dy);
                }
            }
        } else {
            if (GLLibConfig.tileset_useTileShift) {
                tileX0 = originX >> s_TilesetInfo[3];
                tileY0 = originY >> s_TilesetInfo[6];
                nbTileX = destWidth >> s_TilesetInfo[3];
                if ((nbTileX << s_TilesetInfo[3]) < destWidth) {
                    nbTileX++;
                }
                nbTileY = destHeight >> s_TilesetInfo[6];
                if ((nbTileY << s_TilesetInfo[6]) < destHeight) {
                    nbTileY++;
                }
                offsetX = (tileX0 << s_TilesetInfo[3]) - originX;
                offsetY = (tileY0 << s_TilesetInfo[6]) - originY;
            } else {
                int nTmpStartX2 = originX;
                int nTmpStartY2 = originY;
                if (nTmpStartX2 < 0) {
                    nTmpStartX2 -= s_TilesetInfo[2];
                }
                if (nTmpStartY2 < 0) {
                    nTmpStartY2 -= s_TilesetInfo[5];
                }
                tileX0 = nTmpStartX2 / s_TilesetInfo[2];
                tileY0 = nTmpStartY2 / s_TilesetInfo[5];
                nbTileX = destWidth / s_TilesetInfo[2];
                if (nbTileX * s_TilesetInfo[2] < destWidth) {
                    nbTileX++;
                }
                nbTileY = destHeight / s_TilesetInfo[5];
                if (nbTileY * s_TilesetInfo[5] < destHeight) {
                    nbTileY++;
                }
                offsetX = (tileX0 * s_TilesetInfo[2]) - originX;
                offsetY = (tileY0 * s_TilesetInfo[5]) - originY;
            }
            Tileset_UpdateBuffer(g, nLayer, tileX0, tileY0, nbTileX, nbTileY, offsetX + dx, offsetY + dy);
        }
        if (g != null) {
            g.setClip(cx, cy, cw, ch);
        }
    }

    private static void Tileset_Draw2Screen(Graphics g, int nLayer, int srcX, int srcY, int width, int height, int destX, int destY) {
        g.setClip(destX, destY, width, height);
        g.drawImage(s_TilesetLayerImage[nLayer][0], destX - srcX, destY - srcY, 0);
    }

    static void Tileset_Update(int nLayer) {
    }

    private static void Tileset_UpdateBuffer(Graphics gDest, int nLayer, int tileX0, int tileY0, int nbTileX, int nbTileY, int offsetX, int offsetY) {
        int originDestX;
        int destY;
        int data;
        boolean emptyIndex;
        int flag;
        int alphaData;
        boolean alphaEmpty;
        boolean useCB = isFlag(nLayer, 4);
        boolean repeatX = isFlag(nLayer, 1);
        boolean repeatY = isFlag(nLayer, 2);
        int tileMapWidth = s_TilesetLayerInfo[nLayer][2];
        int tileMapHeight = s_TilesetLayerInfo[nLayer][3];
        byte[] dataArray = s_TilesetLayerData[nLayer][0];
        byte[] flagArray = s_TilesetLayerData[nLayer][1];
        int tileWidth = s_TilesetInfo[2];
        int tileHeight = s_TilesetInfo[5];
        if (useCB) {
            if (GLLibConfig.tileset_useTileShift) {
                originDestX = ((tileX0 << s_TilesetInfo[3]) % s_TilesetLayerInfo[nLayer][6]) + offsetX;
                destY = ((tileY0 << s_TilesetInfo[6]) % s_TilesetLayerInfo[nLayer][7]) + offsetY;
            } else {
                originDestX = ((tileX0 * s_TilesetInfo[2]) % s_TilesetLayerInfo[nLayer][6]) + offsetX;
                destY = ((tileY0 * s_TilesetInfo[5]) % s_TilesetLayerInfo[nLayer][7]) + offsetY;
            }
            if (originDestX < 0) {
                originDestX += s_TilesetLayerInfo[nLayer][6];
            }
            if (destY < 0) {
                destY += s_TilesetLayerInfo[nLayer][7];
            }
        } else {
            originDestX = offsetX;
            destY = offsetY;
        }
        if (repeatX) {
            while (tileX0 < 0) {
                tileX0 += tileMapWidth;
            }
            while (tileX0 >= tileMapWidth) {
                tileX0 -= tileMapWidth;
            }
        } else {
            if (tileX0 < 0) {
                nbTileX += tileX0;
                tileX0 = 0;
            }
            if (tileX0 + nbTileX >= tileMapWidth) {
                nbTileX = tileMapWidth - tileX0;
            }
        }
        if (repeatY) {
            while (tileY0 < 0) {
                tileY0 += tileMapHeight;
            }
            while (tileY0 >= tileMapHeight) {
                tileY0 -= tileMapHeight;
            }
        } else {
            if (tileY0 < 0) {
                nbTileY += tileY0;
                tileY0 = 0;
            }
            if (tileY0 + nbTileY >= tileMapHeight) {
                nbTileY = tileMapHeight - tileY0;
                if (nbTileY == 0) {
                    return;
                }
            }
        }
        byte[] alphaDataArray = null;
        byte[] alphaFlagArray = null;
        if (GLLibConfig.tileset_usePixelEffects && nLayer == s_TilesetEffectLayer && s_TilesetAlphaLayer > 0) {
            alphaDataArray = s_TilesetLayerData[s_TilesetAlphaLayer][0];
            alphaFlagArray = s_TilesetLayerData[s_TilesetAlphaLayer][1];
        }
        while (true) {
            int i = nbTileY;
            nbTileY = i - 1;
            if (i >= 0) {
                int destX = originDestX;
                int nbX = nbTileX;
                int tileX = tileX0;
                while (true) {
                    int i2 = nbX;
                    nbX = i2 - 1;
                    if (i2 < 0) {
                        break;
                    }
                    int offsetCur = tileX + (tileY0 * tileMapWidth);
                    if ((!GLLibConfig.tileset_useIndexAsShort && offsetCur < dataArray.length) || (GLLibConfig.tileset_useIndexAsShort && (offsetCur << 1) < dataArray.length)) {
                        if (GLLibConfig.tileset_useIndexAsShort) {
                            data = GLLib.Mem_GetShort(dataArray, offsetCur << 1) & 65535;
                            emptyIndex = data == 65535;
                        } else {
                            data = dataArray[offsetCur] & 255;
                            emptyIndex = data == 255;
                        }
                        if (!emptyIndex) {
                            if (flagArray == null) {
                                flag = 0;
                            } else {
                                flag = flagArray[offsetCur] & 255;
                            }
                            if (s_TilesetSprite[nLayer].GetFrameCount() == 0) {
                                s_TilesetSprite[nLayer].PaintModule(gDest, data, destX, destY, flag);
                            } else {
                                int tx = destX;
                                int ty = destY;
                                if (GLLibConfig.sprite_useTransfFlip) {
                                    if ((flag & 1) != 0) {
                                        tx += s_TilesetInfo[2];
                                    }
                                    if ((flag & 2) != 0) {
                                        ty += s_TilesetInfo[5];
                                    }
                                }
                                s_TilesetSprite[nLayer].PaintFrame(gDest, data, tx, ty, flag);
                            }
                            if (GLLibConfig.tileset_usePixelEffects && nLayer == s_TilesetEffectLayer && s_TilesetAlphaLayer > 0) {
                                if (GLLibConfig.tileset_useIndexAsShort) {
                                    alphaData = GLLib.Mem_GetShort(alphaDataArray, offsetCur << 1) & 65535;
                                    alphaEmpty = alphaData == 65535;
                                } else {
                                    alphaData = alphaDataArray[offsetCur] & 255;
                                    alphaEmpty = alphaData == 255;
                                }
                                if (!alphaEmpty) {
                                    int alphaFlag = 0;
                                    if (alphaFlagArray != null) {
                                        alphaFlag = alphaFlagArray[offsetCur] & 255;
                                    }
                                    if (s_TilesetSprite[s_TilesetAlphaLayer].GetFrameCount() != 0) {
                                        alphaData = s_TilesetSprite[s_TilesetAlphaLayer].GetFrameModule(alphaData, 0);
                                    }
                                    if (s_TilesetEffectType == 2 || s_TilesetEffectType == 3) {
                                        s_TilesetSprite[s_TilesetAlphaLayer].RenderTilesetEffect(gDest, alphaData, s_TilesetLayerImage[nLayer][0], s_TilesetEffectType, destX, destY, tileWidth, tileHeight, alphaFlag);
                                    } else if (s_TilesetEffectType == 1) {
                                        s_TilesetSprite[s_TilesetAlphaLayer].PaintModule(gDest, alphaData, destX, destY, alphaFlag);
                                    }
                                }
                            }
                        }
                    }
                    tileX++;
                    if (tileX >= tileMapWidth) {
                        if (!repeatX) {
                            break;
                        } else {
                            tileX = 0;
                        }
                    }
                    destX += tileWidth;
                    if (useCB && destX >= s_TilesetLayerInfo[nLayer][6]) {
                        destX = 0;
                    }
                }
                tileY0++;
                if (tileY0 >= tileMapHeight) {
                    if (repeatY) {
                        tileY0 = 0;
                    } else {
                        return;
                    }
                }
                destY += tileHeight;
                if (useCB && destY >= s_TilesetLayerInfo[nLayer][7]) {
                    destY = 0;
                }
            } else {
                return;
            }
        }
    }

    private static final int Tileset_GetTranslatedOriginY(int nLayer, int y) {
        if (isFlag(nLayer, 8)) {
            return (s_TilesetLayerInfo[nLayer][5] - s_TilesetInfo[1]) - y;
        }
        return y;
    }

    static final void Tileset_SetCamera(int nLayer, int x, int y) {
        s_TilesetLayerInfo[nLayer][12] = x;
        s_TilesetLayerInfo[nLayer][13] = Tileset_GetTranslatedOriginY(nLayer, y);
        if (!isFlag(nLayer, 1)) {
            if (s_TilesetLayerInfo[nLayer][12] < 0) {
                s_TilesetLayerInfo[nLayer][12] = 0;
            } else if (s_TilesetLayerInfo[nLayer][12] + s_TilesetInfo[0] > s_TilesetLayerInfo[nLayer][4]) {
                s_TilesetLayerInfo[nLayer][12] = s_TilesetLayerInfo[nLayer][4] - s_TilesetInfo[0];
            }
        }
        if (!isFlag(nLayer, 2)) {
            if (s_TilesetLayerInfo[nLayer][13] < 0) {
                s_TilesetLayerInfo[nLayer][13] = 0;
            } else if (s_TilesetLayerInfo[nLayer][13] + s_TilesetInfo[1] > s_TilesetLayerInfo[nLayer][5]) {
                s_TilesetLayerInfo[nLayer][13] = s_TilesetLayerInfo[nLayer][5] - s_TilesetInfo[1];
            }
        }
    }

    static final int[] Tileset_GetCamera(int nLayer) {
        int[] res = {Tileset_GetCameraX(nLayer), Tileset_GetCameraY(nLayer)};
        return res;
    }

    static final int Tileset_GetCameraX(int nLayer) {
        return s_TilesetLayerInfo[nLayer][12];
    }

    static final int Tileset_GetCameraY(int nLayer) {
        if (isFlag(nLayer, 8)) {
            return (s_TilesetLayerInfo[nLayer][5] - s_TilesetInfo[1]) - s_TilesetLayerInfo[nLayer][13];
        }
        return s_TilesetLayerInfo[nLayer][13];
    }

    static final int Tileset_GetLayerWidth(int nLayer) {
        return s_TilesetLayerInfo[nLayer][4];
    }

    static final int Tileset_GetLayerHeight(int nLayer) {
        return s_TilesetLayerInfo[nLayer][5];
    }

    static final int Tileset_GetLayerTileCountWidth(int nLayer) {
        return s_TilesetLayerInfo[nLayer][2];
    }

    static final int Tileset_GetLayerTileCountHeight(int nLayer) {
        return s_TilesetLayerInfo[nLayer][3];
    }

    static final int Tileset_GetTile(int nLayer, int x, int y) {
        int y2 = Tileset_GetTranslatedOriginY(nLayer, y);
        if (GLLibConfig.tileset_useIndexAsShort) {
            return GLLib.Mem_GetShort(s_TilesetLayerData[nLayer][0], ((y2 * s_TilesetLayerInfo[nLayer][2]) + x) << 1) & 65535;
        }
        return s_TilesetLayerData[nLayer][0][(y2 * s_TilesetLayerInfo[nLayer][2]) + x] & 255;
    }

    static final int Tileset_GetTileFlags(int nLayer, int x, int y) {
        int y2 = Tileset_GetTranslatedOriginY(nLayer, y);
        if (s_TilesetLayerData[nLayer][1] == null) {
            return 0;
        }
        return s_TilesetLayerData[nLayer][1][(y2 * s_TilesetLayerInfo[nLayer][2]) + x] & 255;
    }

    static final Image Tileset_GetBufferImage(int p_iLayer) {
        return Tileset_GetBufferImage(p_iLayer, 0);
    }

    static final Image Tileset_GetBufferImage(int p_iLayer, int p_iImage) {
        return s_TilesetLayerImage[p_iLayer][p_iImage];
    }

    static final Graphics Tileset_GetBufferGraphics(int p_iLayer) {
        return Tileset_GetBufferGraphics(p_iLayer, 0);
    }

    static final Graphics Tileset_GetBufferGraphics(int p_iLayer, int p_iImage) {
        return s_TilesetLayerGraphics[p_iLayer][p_iImage];
    }

    static void Tileset_Refresh(int nLayer) {
        if (!s_bTilesetPlayerInitialized) {
            return;
        }
        s_TilesetLayerInfo[nLayer][8] = -1;
        s_TilesetLayerInfo[nLayer][9] = -1;
        s_TilesetLayerInfo[nLayer][10] = -1;
        s_TilesetLayerInfo[nLayer][11] = -1;
    }

    static void Tileset_SetAlphaEffects(int effectLayer, int alphaLayer, int alphaEffect) {
        if (GLLibConfig.tileset_usePixelEffects) {
            s_TilesetEffectLayer = effectLayer;
            s_TilesetAlphaLayer = alphaLayer;
            s_TilesetEffectType = alphaEffect;
        }
    }
}
