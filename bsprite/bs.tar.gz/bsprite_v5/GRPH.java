package defpackage;

/* loaded from: GLLib.jar:GRPH.class */
interface GRPH {
    public static final int LEFT = 4;
    public static final int HCENTER = 1;
    public static final int RIGHT = 8;
    public static final int TOP = 16;
    public static final int VCENTER = 2;
    public static final int BOTTOM = 32;
    public static final int LEFT_TOP = 20;
    public static final int LEFT_VCENTER = 6;
    public static final int LEFT_BOTTOM = 36;
    public static final int HCENTER_TOP = 17;
    public static final int HCENTER_VCENTER = 3;
    public static final int HCENTER_BOTTOM = 33;
    public static final int RIGHT_TOP = 24;
    public static final int RIGHT_VCENTER = 10;
    public static final int RIGHT_BOTTOM = 40;
}
