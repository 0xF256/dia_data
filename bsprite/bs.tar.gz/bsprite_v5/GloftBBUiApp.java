package defpackage;

import java.util.Hashtable;
import net.rim.blackberry.api.browser.Browser;
import net.rim.blackberry.api.browser.BrowserSession;
import net.rim.device.api.system.ApplicationDescriptor;
import net.rim.device.api.system.GlobalEventListener;
import net.rim.device.api.ui.UiApplication;

/* loaded from: GLLib.jar:GloftBBUiApp.class */
public abstract class GloftBBUiApp extends UiApplication implements GlobalEventListener {
    static GloftBBUiApp m_instance;
    static Hashtable s_AppPropertyTable = new Hashtable();

    public abstract void eventOccurred(long j, int i, int i2, Object obj, Object obj2);

    public abstract void destroyApp(boolean z);

    public static String getAppProperty(String key) {
        if (key.equals("MIDlet-Version")) {
            return ApplicationDescriptor.currentApplicationDescriptor().getVersion();
        }
        return (String) s_AppPropertyTable.get(key);
    }

    public static void setAppProperty(String key, String value) {
        s_AppPropertyTable.put(key, value);
    }

    public static boolean platformRequest(String url) {
        BrowserSession browser = Browser.getDefaultSession();
        browser.displayPage(url);
        return true;
    }
}
