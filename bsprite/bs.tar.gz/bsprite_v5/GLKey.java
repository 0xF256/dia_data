package defpackage;

/* compiled from: GLLibInterface.java */
/* loaded from: GLLib.jar:GLKey.class */
interface GLKey {
    public static final byte k_invalid = -1;
    public static final byte k_dummy = 0;
    public static final byte k_up = 1;
    public static final byte k_down = 2;
    public static final byte k_left = 3;
    public static final byte k_right = 4;
    public static final byte k_fire = 5;
    public static final byte k_num0 = 6;
    public static final byte k_num1 = 7;
    public static final byte k_num2 = 8;
    public static final byte k_num3 = 9;
    public static final byte k_num4 = 10;
    public static final byte k_num5 = 11;
    public static final byte k_num6 = 12;
    public static final byte k_num7 = 13;
    public static final byte k_num8 = 14;
    public static final byte k_num9 = 15;
    public static final byte k_star = 16;
    public static final byte k_pound = 17;
    public static final byte k_menuOK = 18;
    public static final byte k_menuBack = 19;
    public static final byte k_nbKey = 20;
    public static final byte k_consoleLogEnable = 17;
    public static final byte k_rmsLogEnable = 16;
}
