package defpackage;

import java.io.PrintStream;
import java.util.Date;
import java.util.Random;
import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;

/* loaded from: GLLib.jar:License.class */
public final class License {
    private static final byte FUNCTION_VALIDATE_LICENSE = 40;
    private static String GGI;
    private String url;
    public static final int NOT_A_NUMBER = -666666;
    private HTTP whttp;
    public static long callstarttime;
    private int lastErrorCode;

    /* loaded from: GLLib.jar:License$Error.class */
    public interface Error {
        public static final int ERROR_INIT = -100;
        public static final byte ERROR_CONNECTION = -2;
        public static final byte ERROR_PENDING = -1;
        public static final byte ERROR_NONE = 0;
        public static final byte ERROR_NO_UUID = 1;
        public static final byte ERROR_NO_PHONE_NUMBER = 25;
        public static final byte ERROR_NO_CLIENT_ID = 26;
        public static final byte ERROR_INVALID_GGI = 27;
        public static final byte ERROR_BAD_RESPONSE = 40;
    }

    public License(MIDlet midlet) {
        this.url = midlet.getAppProperty("XPlayerURL");
        GGI = midlet.getAppProperty("GGI");
        if (this.url == null || GGI == null) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("Please check that you have fields XPlayerURL, GGI in .jad file");
                return;
            }
            return;
        }
        this.url = this.url.trim();
        GGI = GGI.trim();
        this.whttp = new HTTP();
        HTTP http = this.whttp;
        HTTP.CarrierDeviceId = midlet.getAppProperty("CarrierDeviceId");
        HTTP http2 = this.whttp;
        if (HTTP.CarrierDeviceId != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
            PrintStream printStream = System.out;
            StringBuffer append = new StringBuffer().append("WARNING CarrierDeviceId=");
            HTTP http3 = this.whttp;
            printStream.println(append.append(HTTP.CarrierDeviceId).append(", REMOVE the value IN PRODUCTION jad but leave CarrierDeviceId:").toString());
        }
    }

    public int getLastError() {
        if (this.whttp.isInProgress()) {
            return -1;
        }
        if (this.whttp.m_bError) {
            return -2;
        }
        return this.lastErrorCode;
    }

    public void cancel() {
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = 0L;
        }
        this.whttp.cancel();
    }

    public void cleanup() {
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = 0L;
        }
        this.whttp.cleanup();
    }

    private String String2Blob(String str) {
        int nBlobLength;
        byte[] bs = str.getBytes();
        int nBlobPos = 0;
        int nSPos = 0;
        int nBitsNotUsed = 8;
        int nBlobLength2 = (str.length() * 8) / 6;
        if ((str.length() * 8) % 6 != 0) {
            nBlobLength = nBlobLength2 + 2;
        } else {
            nBlobLength = nBlobLength2 + 1;
        }
        byte[] sBlob = new byte[nBlobLength];
        for (int k = 0; k < nBlobLength; k++) {
            sBlob[k] = 0;
        }
        while (nSPos < str.length()) {
            byte nKeyIndex = (byte) (((byte) (bs[nSPos] & Byte.MAX_VALUE)) >> (8 - nBitsNotUsed));
            if (nBitsNotUsed < 6) {
                nSPos++;
                if (nSPos < str.length()) {
                    nKeyIndex = (byte) (nKeyIndex | (bs[nSPos] << nBitsNotUsed));
                    nBitsNotUsed += 2;
                }
            } else {
                nBitsNotUsed -= 6;
            }
            sBlob[nBlobPos] = SSEncDec_GetCharFromKeyByIndex((byte) (nKeyIndex & 63));
            nBlobPos++;
        }
        String retval = new String(sBlob, 0, nBlobPos);
        return retval;
    }

    private byte SSEncDec_GetCharFromKeyByIndex(byte nKeyIndex) {
        if (nKeyIndex < 26) {
            return (byte) (nKeyIndex + 97);
        }
        if (nKeyIndex < 52) {
            return (byte) (nKeyIndex + 39);
        }
        if (nKeyIndex < 62) {
            return (byte) (nKeyIndex - 4);
        }
        if (nKeyIndex == 62) {
            return (byte) 95;
        }
        return (byte) 45;
    }

    private String Blob2String(String blob) {
        byte[] b = blob.getBytes();
        int nSPos = 0;
        int nBitsNotSet = 8;
        int nStrLength = ((blob.length() * 6) / 8) + 1;
        byte[] s = new byte[nStrLength];
        for (int k = 0; k < nStrLength; k++) {
            s[k] = 0;
        }
        for (int nBlobPos = 0; nBlobPos < blob.length(); nBlobPos++) {
            byte nKeyIndex = SSEncDec_GetKeyFromChar(b[nBlobPos]);
            int i = nSPos;
            s[i] = (byte) (s[i] | (nKeyIndex << (8 - nBitsNotSet)));
            if (nBitsNotSet > 6) {
                nBitsNotSet -= 6;
            } else if (nSPos < nStrLength - 2) {
                nSPos++;
                s[nSPos] = (byte) (s[nSPos] | (nKeyIndex >> nBitsNotSet));
                nBitsNotSet += 2;
            }
        }
        String retval = new String(s, 0, nStrLength);
        return retval.trim();
    }

    private byte SSEncDec_GetKeyFromChar(byte nChar) {
        if (nChar == 45) {
            return (byte) 63;
        }
        if (nChar == 95) {
            return (byte) 62;
        }
        if (nChar < 58) {
            return (byte) (nChar + 4);
        }
        if (nChar < 91) {
            return (byte) (nChar - 39);
        }
        return (byte) (nChar - 97);
    }

    private String getValue(String src, int pos) {
        int start = 0;
        int end = src.indexOf(124, 0 + 1);
        while (pos > 0) {
            if (start == -1) {
                return null;
            }
            start = end;
            end = src.indexOf(124, start + 1);
            pos--;
        }
        if (start == -1) {
            return null;
        }
        if (end == -1) {
            end = src.length();
        }
        if (pos > 0) {
            start++;
        }
        if (start == end) {
            return "";
        }
        if (start > end) {
            return null;
        }
        try {
            char[] buf = new char[end - start];
            src.getChars(start, end, buf, 0);
            String value = new String(buf);
            return value;
        } catch (IndexOutOfBoundsException e) {
            return null;
        }
    }

    private void rmsStoreExpiration(String lengthTimeValid_str, String currentTime_str) {
        RecordStore rs = null;
        if (lengthTimeValid_str == null) {
            try {
                RecordStore.deleteRecordStore("MRC");
                return;
            } catch (Throwable th) {
                return;
            }
        }
        try {
            RecordStore rs2 = RecordStore.openRecordStore("MRC", true);
            Random key = new Random(Long.parseLong(currentTime_str));
            String blob_expInfo = String2Blob(new StringBuffer().append(Integer.toHexString(key.nextInt())).append("|SubExp|").append(lengthTimeValid_str).append("|").append(currentTime_str).append("|GL7x|").toString());
            byte[] tmp_expInfo = blob_expInfo.getBytes();
            if (rs2.getNumRecords() >= 1) {
                rs2.setRecord(1, tmp_expInfo, 0, tmp_expInfo.length);
            } else {
                rs2.addRecord(tmp_expInfo, 0, tmp_expInfo.length);
            }
            try {
                rs2.closeRecordStore();
            } catch (Throwable th2) {
            }
        } catch (Throwable th3) {
            try {
                rs.closeRecordStore();
            } catch (Throwable th4) {
            }
            throw th3;
        }
    }

    private String rmsGetExpiration() {
        RecordStore rs = null;
        String expInfo_str = null;
        try {
            rs = RecordStore.openRecordStore("MRC", true);
            if (rs.getNumRecords() >= 1) {
                byte[] tmp_expInfo = rs.getRecord(1);
                expInfo_str = Blob2String(new String(tmp_expInfo));
            }
            try {
                rs.closeRecordStore();
            } catch (Throwable th) {
            }
        } catch (Throwable th2) {
            try {
                rs.closeRecordStore();
            } catch (Throwable th3) {
            }
            throw th2;
        }
        return expInfo_str;
    }

    public boolean isLicenseValid() {
        if (this.url == null || GGI == null) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("XPlayerURL or GGI fields missing. SKIPPING Cingular MRC.");
                return true;
            }
            return true;
        }
        String expInfo_str = rmsGetExpiration();
        if (expInfo_str != null) {
            String header = getValue(expInfo_str, 1);
            String validForTime_str = getValue(expInfo_str, 2);
            String timeLastMsg_str = getValue(expInfo_str, 3);
            String footer = getValue(expInfo_str, 4);
            if (header.compareTo("SubExp") == 0 && validForTime_str != "" && timeLastMsg_str != "" && footer.compareTo("GL7x") == 0) {
                long lengthTimeValid = Long.parseLong(validForTime_str);
                long timeLastMsg = Long.parseLong(timeLastMsg_str);
                Date current_date = new Date();
                long currentTime = current_date.getTime() / 1000;
                if (currentTime > timeLastMsg + lengthTimeValid || currentTime < timeLastMsg) {
                    return false;
                }
                return true;
            }
            return false;
        }
        return false;
    }

    public void sendValidateLicense() {
        this.whttp.cancel();
        StringBuffer append = new StringBuffer().append("f|40|i|").append(GGI).append("|u|");
        HTTP http = this.whttp;
        String tmp = append.append(HTTP.CarrierDeviceId).append("|").toString();
        String tmpBlob = String2Blob(tmp);
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmpBlob);
    }

    public boolean handleValidateLicense() {
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                cancel();
                this.lastErrorCode = -2;
                return true;
            }
            return false;
        }
        if (this.whttp.m_bError) {
            return true;
        }
        if (this.whttp.m_response != null && this.whttp.m_response != "") {
            if (this.whttp.m_response.indexOf("|") == -1) {
                this.whttp.m_response = Blob2String(this.whttp.m_response);
            }
            if (Integer.parseInt(getValue(this.whttp.m_response, 1)) != 40) {
                this.lastErrorCode = 40;
                return true;
            }
            String tmpHR = getValue(this.whttp.m_response, 3);
            if (tmpHR.compareTo("e") == 0) {
                this.lastErrorCode = Integer.parseInt(getValue(this.whttp.m_response, 4));
                return true;
            }
            if (tmpHR.compareTo("s") == 0) {
                this.lastErrorCode = 0;
                String lengthTimeValid_str = getValue(this.whttp.m_response, 4).trim();
                if (lengthTimeValid_str.compareTo("0") == 0) {
                    rmsStoreExpiration(null, null);
                    return true;
                }
                Date current_date = new Date();
                long currentTime = current_date.getTime() / 1000;
                String currentTime_str = Long.toString(currentTime);
                rmsStoreExpiration(lengthTimeValid_str, currentTime_str);
                return true;
            }
        }
        this.lastErrorCode = 40;
        return true;
    }
}
