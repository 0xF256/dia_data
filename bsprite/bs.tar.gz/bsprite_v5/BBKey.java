package defpackage;

/* loaded from: GLLib.jar:BBKey.class */
class BBKey {
    public static int NUM0;
    public static int NUM1;
    public static int NUM2;
    public static int NUM3;
    public static int NUM4;
    public static int NUM5;
    public static int NUM6;
    public static int NUM7;
    public static int NUM8;
    public static int NUM9;
    public static int UP;
    public static int DOWN;
    public static int LEFT;
    public static int RIGHT;
    public static int FIRE;
    public static int POUND;
    public static int STAR;

    BBKey() {
    }
}
