package defpackage;

/* loaded from: GLLib.jar:GLLibMidiSpectrumAnalyzer.class */
public class GLLibMidiSpectrumAnalyzer {
    private static final byte[] HEADER_CHUNK = "MThd".getBytes();
    private static final byte[] TRACK_CHUNK = "MTrk".getBytes();
    public static final int NO_ERRORS = 0;
    public static final int ERROR_INVALID_HEADER_CHUNK = 1;
    public static final int ERROR_INVALID_TRACK_CHUNK = 2;
    public static final int ERROR_INVALID_FILE_LENGTH = 3;
    public static final int ERROR_INVALID_META_EVENT = 4;
    private static final int EVENT_NOTE_OFF = 128;
    private static final int EVENT_NOTE_ON = 144;
    private static final int EVENT_POLYPHONIC_KEY_PRESSURE = 160;
    private static final int EVENT_CONTROL_CHANGE = 176;
    private static final int EVENT_PROGRAM_CHANGE = 192;
    private static final int EVENT_CHANNEL_KEY_PRESSURE = 208;
    private static final int EVENT_PITCH_BEND = 224;
    private static final int EVENT_META = 240;
    private static final int META_EVENT_SET_SEQUENCE_NUMBRE = 0;
    private static final int META_EVENT_TEXT = 1;
    private static final int META_EVENT_COPYRIGHT = 2;
    private static final int META_EVENT_TRACK_NAME = 3;
    private static final int META_EVENT_INSTRUMENT_NAME = 4;
    private static final int META_EVENT_LYRIC = 5;
    private static final int META_EVENT_MARKER = 6;
    private static final int META_EVENT_CUE_POINT = 7;
    private static final int META_EVENT_TRACK_END = 47;
    private static final int META_EVENT_SET_TEMPO = 81;
    private static final int META_EVENT_SET_TIME_SIGNATURE = 88;
    private static final int META_EVENT_KEY_SIGNATURE = 89;
    private byte[][] m_tracks;
    private byte[] m_data;
    private int m_offset;
    public int m_bars;
    public int[] m_barLevels;
    private int m_maxValue;
    private int m_velocityShift;
    private int m_millisShift;
    private int m_releaseDamping;
    private int m_fileFormat;
    private int m_numberOfTracks;
    private int m_deltaTimeTickPerQuarterNote;
    public int m_channelFilter = 15;
    private int m_tempo = 500000;
    public long m_currentTime = 0;
    private long m_lastNoteTime = 0;
    private int m_event = 0;
    private int m_metaEvent = 0;

    public GLLibMidiSpectrumAnalyzer(int bars, int maxValue, int velocityShift, int millisShift, int releaseDamping) {
        this.m_barLevels = new int[bars];
        this.m_bars = bars;
        this.m_maxValue = maxValue;
        this.m_velocityShift = velocityShift;
        this.m_millisShift = millisShift;
        this.m_releaseDamping = releaseDamping;
    }

    private int MidiSpectrumAnalyzer_PeakByte() {
        return this.m_data[this.m_offset] & 255;
    }

    private int MidiSpectrumAnalyzer_ReadByte() {
        byte[] bArr = this.m_data;
        int i = this.m_offset;
        this.m_offset = i + 1;
        return bArr[i] & 255;
    }

    private int MidiSpectrumAnalyzer_ReadShort() {
        int value = ((this.m_data[this.m_offset + 0] & 255) << 8) | ((this.m_data[this.m_offset + 1] & 255) << 0);
        this.m_offset += 2;
        return value;
    }

    private int MidiSpectrumAnalyzer_ReadInt() {
        int value = ((this.m_data[this.m_offset + 0] & 255) << 24) | ((this.m_data[this.m_offset + 1] & 255) << 16) | ((this.m_data[this.m_offset + 2] & 255) << 8) | ((this.m_data[this.m_offset + 3] & 255) << 0);
        this.m_offset += 4;
        return value;
    }

    private int MidiSpectrumAnalyzer_ReadThreeBytes() {
        int value = ((this.m_data[this.m_offset + 0] & 255) << 16) | ((this.m_data[this.m_offset + 1] & 255) << 8) | ((this.m_data[this.m_offset + 2] & 255) << 0);
        this.m_offset += 3;
        return value;
    }

    private int MidiSpectrumAnalyzer_ReadVariableLength() {
        byte b;
        int value = 0;
        do {
            byte[] bArr = this.m_data;
            int i = this.m_offset;
            this.m_offset = i + 1;
            b = bArr[i];
            value = (value << 7) + (b & Byte.MAX_VALUE);
        } while ((b & EVENT_NOTE_OFF) == EVENT_NOTE_OFF);
        return value;
    }

    /* JADX WARN: Type inference failed for: r1v16, types: [byte[], byte[][]] */
    public int MidiSpectrumAnalyzer_Parse(byte[] data) {
        this.m_offset = 0;
        this.m_data = data;
        if (this.m_offset + 16 > data.length) {
            return 1;
        }
        for (int i = 0; i < HEADER_CHUNK.length; i++) {
            if (HEADER_CHUNK[i] != MidiSpectrumAnalyzer_ReadByte()) {
                return 1;
            }
        }
        int headerLength = MidiSpectrumAnalyzer_ReadInt();
        if (headerLength != 6) {
            return 1;
        }
        this.m_fileFormat = MidiSpectrumAnalyzer_ReadShort();
        this.m_numberOfTracks = MidiSpectrumAnalyzer_ReadShort();
        this.m_deltaTimeTickPerQuarterNote = MidiSpectrumAnalyzer_ReadShort();
        this.m_tracks = new byte[this.m_numberOfTracks];
        for (int t = 0; t < this.m_numberOfTracks; t++) {
            if (this.m_offset + 8 > data.length) {
                return 2;
            }
            for (int i2 = 0; i2 < TRACK_CHUNK.length; i2++) {
                if (TRACK_CHUNK[i2] != MidiSpectrumAnalyzer_ReadByte()) {
                    return 2;
                }
            }
            int trackLength = MidiSpectrumAnalyzer_ReadInt();
            if (this.m_offset + trackLength > data.length) {
                return 2;
            }
            this.m_tracks[t] = new byte[trackLength];
            System.arraycopy(data, this.m_offset, this.m_tracks[t], 0, trackLength);
            this.m_offset += trackLength;
        }
        if (this.m_offset < data.length) {
            return 3;
        }
        this.m_data = null;
        MidiSpectrumAnalyzer_Reset();
        return 0;
    }

    public void MidiSpectrumAnalyzer_Reset() {
        this.m_offset = 0;
        this.m_data = this.m_tracks[0];
        this.m_currentTime = 0L;
        this.m_lastNoteTime = 0L;
    }

    public int MidiSpectrumAnalyzer_Update(long timeMillis) {
        long deltaTimeMillis = timeMillis - this.m_currentTime;
        this.m_currentTime = timeMillis;
        for (int i = 0; i < this.m_barLevels.length; i++) {
            this.m_barLevels[i] = (int) (r0[r1] - (deltaTimeMillis << this.m_millisShift));
            if (this.m_barLevels[i] < 0) {
                this.m_barLevels[i] = 0;
            }
        }
        if (this.m_offset >= this.m_data.length) {
            return 0;
        }
        do {
            int offset = this.m_offset;
            int dtToNextEvent = MidiSpectrumAnalyzer_ReadVariableLength();
            long time = MidiSpectrumAnalyzer_GetTicksInMillis(dtToNextEvent);
            if (this.m_currentTime < this.m_lastNoteTime + time) {
                this.m_offset = offset;
                return 0;
            }
            this.m_lastNoteTime += time;
            if ((MidiSpectrumAnalyzer_PeakByte() & EVENT_NOTE_OFF) == EVENT_NOTE_OFF) {
                this.m_event = MidiSpectrumAnalyzer_ReadByte() & 255;
            }
            int channel = this.m_event & 15;
            switch (this.m_event & EVENT_META) {
                case EVENT_NOTE_OFF /* 128 */:
                    int noteNumber = MidiSpectrumAnalyzer_ReadByte();
                    MidiSpectrumAnalyzer_ReadByte();
                    if ((channel & this.m_channelFilter) != 0) {
                        int bar = (this.m_bars * noteNumber) / EVENT_NOTE_OFF;
                        int[] iArr = this.m_barLevels;
                        iArr[bar] = iArr[bar] - this.m_releaseDamping;
                        if (this.m_barLevels[bar] < 0) {
                            this.m_barLevels[bar] = 0;
                            break;
                        }
                    }
                    break;
                case EVENT_NOTE_ON /* 144 */:
                    int noteNumber2 = MidiSpectrumAnalyzer_ReadByte();
                    int velocity = MidiSpectrumAnalyzer_ReadByte();
                    if (velocity == 0 && (channel & this.m_channelFilter) != 0) {
                        int bar2 = (this.m_bars * noteNumber2) / EVENT_NOTE_OFF;
                        int[] iArr2 = this.m_barLevels;
                        iArr2[bar2] = iArr2[bar2] - this.m_releaseDamping;
                        if (this.m_barLevels[bar2] < 0) {
                            this.m_barLevels[bar2] = 0;
                        }
                    }
                    if ((channel & this.m_channelFilter) != 0) {
                        int bar3 = (this.m_bars * noteNumber2) / EVENT_NOTE_OFF;
                        int[] iArr3 = this.m_barLevels;
                        iArr3[bar3] = iArr3[bar3] + (velocity << this.m_velocityShift);
                        if (this.m_barLevels[bar3] > this.m_maxValue) {
                            this.m_barLevels[bar3] = this.m_maxValue;
                            break;
                        }
                    }
                    break;
                case EVENT_POLYPHONIC_KEY_PRESSURE /* 160 */:
                    MidiSpectrumAnalyzer_ReadByte();
                    MidiSpectrumAnalyzer_ReadByte();
                    break;
                case EVENT_CONTROL_CHANGE /* 176 */:
                    MidiSpectrumAnalyzer_ReadByte();
                    MidiSpectrumAnalyzer_ReadByte();
                    break;
                case EVENT_PROGRAM_CHANGE /* 192 */:
                    MidiSpectrumAnalyzer_ReadByte();
                    break;
                case EVENT_CHANNEL_KEY_PRESSURE /* 208 */:
                    MidiSpectrumAnalyzer_ReadByte();
                    break;
                case EVENT_PITCH_BEND /* 224 */:
                    MidiSpectrumAnalyzer_ReadByte();
                    MidiSpectrumAnalyzer_ReadByte();
                    break;
                case EVENT_META /* 240 */:
                    switch (this.m_event) {
                        case 255:
                            this.m_metaEvent = MidiSpectrumAnalyzer_ReadByte();
                            int m_metaEventLength = MidiSpectrumAnalyzer_ReadByte();
                            switch (this.m_metaEvent) {
                                case META_EVENT_SET_TEMPO /* 81 */:
                                    this.m_tempo = MidiSpectrumAnalyzer_ReadThreeBytes();
                                    break;
                                default:
                                    this.m_offset += m_metaEventLength;
                                    break;
                            }
                    }
                default:
                    System.out.println("\t!!! ERROR - Unsupported m_event");
                    break;
            }
        } while (this.m_offset < this.m_data.length);
        return 0;
    }

    private long MidiSpectrumAnalyzer_GetTicksInMillis(long ticks) {
        return ((ticks * 1000) * 60) / ((60000000 / this.m_tempo) * this.m_deltaTimeTickPerQuarterNote);
    }
}
