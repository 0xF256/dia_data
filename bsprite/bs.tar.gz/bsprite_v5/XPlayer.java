package defpackage;

import java.util.Random;
import java.util.Vector;
import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;

/* loaded from: GLLib.jar:XPlayer.class */
public final class XPlayer {
    public static final byte SCORE_TYPE_POINTS = 1;
    public static final byte SCORE_TYPE_TIME = 2;
    private static final byte FUNCTION_LOGIN_REGISTER = 11;
    private static final byte FUNCTION_UPLOAD_SCORE = 0;
    private static final byte FUNCTION_GET_RANKINGS = 12;
    private static final byte FUNCTION_GET_RANKINGS_AROUND_PLAYER = 13;
    private static final byte FUNCTION_CHANGE_USERNAME = 14;
    private static final byte FUNCTION_RATE_GAME = 8;
    private static final byte FUNCTION_RECOMMEND_GAME_TO_BUDDIES = 9;
    private static final byte FUNCTION_GET_STATS = 10;
    private static String GGI;
    public static final int NOT_A_NUMBER = -666666;
    private HTTP whttp;
    private String url;
    private String username;
    private String uid;
    private boolean is_logged_in;
    private int newRankAfterScoreSending;
    public static long callstarttime;
    private int lastErrorCode;
    private String phoneNumber;
    private int crtPosWrite;
    private int crtPosRead;
    private byte[] msgData;
    private TCP wtcp;
    private String url_tcp;
    private String[] m_lNameList;
    private String[] m_lBinaryDataList;
    private byte[] m_lByteDataList;
    private String found_player_name;
    private byte found_player_status;
    private String found_player_session_name;
    private byte found_player_session_number_of_players;
    private String requested_player_data;
    private String requested_player_nickname;
    private byte m_type;
    private byte m_subtype;
    private byte[] m_data;
    private Vector incomingGameData;
    private int leaderboardSize = -666666;
    private String[] leaderboardPlayerNames = null;
    private int[] leaderboardPlayerPositions = null;
    private int[] leaderboardPlayerScores = null;
    private int[][] leaderboardPlayerScoreDatas = (int[][]) null;
    private int leaderboardSupplementalDataFieldsNumber = 0;
    private int currentPlayerLeaderboardPosition = -666666;
    private int currentPlayerLeaderboardScore = -666666;
    private int[] currentPlayerLeaderboardScoreData = null;
    private String multipleScoresRequestBuffer = null;
    private int bestRank = -666666;
    private int highScore = -666666;
    private int[] highScoreData = null;
    private int lowScore = -666666;
    private int[] lowScoreData = null;
    private int avgScore = -666666;
    private int numberOfGamesPlayed = -666666;
    private String lastTimePlayed = null;
    private byte m_MPConnectLevel = 0;
    private boolean m_MPHasOpponentFinished = false;
    private byte noitems = 0;
    private int nosessionsbase = 0;
    private String currentsessionname = null;
    private String currentsessiondata = null;
    public boolean isGameMessageInQueue = false;

    /* loaded from: GLLib.jar:XPlayer$ConnectLevel.class */
    interface ConnectLevel {
        public static final byte NOT_CONNECTED = 0;
        public static final byte NOT_LOGGED_IN = 1;
        public static final byte IN_CONNECTED = 2;
        public static final byte IN_SESSION = 3;
        public static final byte IN_SESSION_MASTER = 4;
        public static final byte IN_GAME = 5;
        public static final byte IN_GAME_MASTER = 6;
    }

    /* loaded from: GLLib.jar:XPlayer$Error.class */
    public interface Error {
        public static final int ERROR_INIT = -100;
        public static final byte ERROR_NOT_M7_ENABLED = -3;
        public static final byte ERROR_CONNECTION = -2;
        public static final byte ERROR_PENDING = -1;
        public static final byte ERROR_NONE = 0;
        public static final byte ERROR_NO_UUID = 1;
        public static final byte ERROR_NO_NICKNAME = 2;
        public static final byte ERROR_REGISTER_FAILED = 3;
        public static final byte ERROR_NOT_REGISTERED = 4;
        public static final byte ERROR_NICK_TAKEN = 5;
        public static final byte ERROR_SCORE_UPLOAD_FAILED = 21;
        public static final byte ERROR_GET_RANKINGS_FAILED = 22;
        public static final byte ERROR_RATE_GAME_FAILED = 23;
        public static final byte ERROR_RECOMMEND_GAME_FAILED = 24;
        public static final byte ERROR_NO_PHONE_NUMBER = 25;
        public static final byte ERROR_NO_CLIENT_ID = 26;
        public static final byte ERROR_INVALID_GGI = 27;
        public static final byte ERROR_GET_STATS_FAILED = 29;
        public static final byte ERROR_SUPPLEMENTAL_DATA_NEEDED = 31;
        public static final byte ERROR_VALIDATE_LICENSE_FAILED = 32;
        public static final byte ERROR_CHANGE_USERNAME_FAILED = 33;
        public static final byte ERROR_BAD_RESPONSE = 40;
        public static final byte ERROR_WRONGFULL_QSTATE = 50;
        public static final byte ERROR_WRONGFULL_RSTATE = 51;
        public static final byte ERROR_START_GAME = 52;
        public static final byte ERROR_JOIN_GAME = 53;
        public static final byte ERROR_REQUEST_FAILED = 54;
    }

    /* loaded from: GLLib.jar:XPlayer$MessageType.class */
    public interface MessageType {
        public static final byte BASIC_MESSAGE_TYPE_UNKNOWN = 0;
        public static final byte BASIC_MESSAGE_TYPE_GAME = 103;
        public static final byte BASIC_MESSAGE_TYPE_CONNECT = 115;
        public static final byte CONNECT_MESSAGE_INIT_WRITE = 119;
        public static final byte CONNECT_MESSAGE_INIT_READ = 114;
        public static final byte CONNECT_MESSAGE_SUCCESS = 115;
        public static final byte CONNECT_MESSAGE_ERROR = 101;
        public static final byte CONNECT_MESSAGE_DISCONNECT = 120;
        public static final byte GAME_MESSAGE_REQUEST = 114;
        public static final byte GAME_MESSAGE_PUSH = 112;
        public static final byte GAME_MESSAGE_IN_GAME = 103;
        public static final byte GAME_MESSAGE_IN_GAME_TOALL = 104;
        public static final byte GAME_MESSAGE_ERROR = 101;
        public static final byte GAME_MESSAGE_KEEP_ALIVE = 97;
        public static final byte REQUEST_MESSAGE_LOGIN = 105;
        public static final byte REQUEST_MESSAGE_CREATE_SESSION = 99;
        public static final byte REQUEST_MESSAGE_LIST_SESSIONS = 108;
        public static final byte REQUEST_MESSAGE_GET_QUICK_SESSION = 117;
        public static final byte REQUEST_MESSAGE_JOIN_SESSION = 106;
        public static final byte REQUEST_MESSAGE_LEAVE_SESSION = 113;
        public static final byte REQUEST_MESSAGE_KICK_OUT_PLAYER = 107;
        public static final byte REQUEST_MESSAGE_START_GAME = 115;
        public static final byte REQUEST_MESSAGE_FINISH_GAME = 102;
        public static final byte REQUEST_MESSAGE_GET_PLAYER_INFO = 119;
        public static final byte REQUEST_MESSAGE_GET_PLAYER_DATA = 121;
        public static final byte RESPONSE_MESSAGE_SUCCESS = 115;
        public static final byte RESPONSE_MESSAGE_ERROR = 101;
        public static final byte ERROR_INVALID_INPUT = 105;
        public static final byte ERROR_NO_SESSION = 115;
        public static final byte ERROR_SESSION_CLOSED = 99;
        public static final byte ERROR_NOT_MASTER = 109;
        public static final byte ERROR_LOGIN_NICKNAME_USED = 110;
        public static final byte ERROR_LOGIN_INVALID_NICKNAME = 113;
        public static final byte ERROR_LOGIN_AUTHENTICATION_FAILED = 97;
        public static final byte ERROR_CREATE_SESSION_INVALID_NAME = 118;
        public static final byte ERROR_CREATE_SESSION_NAME_USED = 117;
        public static final byte ERROR_BLOCKED_SESSION = 98;
        public static final byte ERROR_LIST_SESSION_INVALID_INDEX = 108;
        public static final byte ERROR_JOIN_SESSION_TOO_MANY_PLAYERS = 106;
        public static final byte ERROR_NO_PLAYER = 107;
        public static final byte ERROR_KICK_OUT_PLAYER_IS_MASTER = 100;
        public static final byte ERROR_START_GAME_NOT_ENOUGH_PLAYERS = 103;
        public static final byte PUSH_MESSAGE_JOIN_SESSION = 106;
        public static final byte PUSH_MESSAGE_LEAVE_SESSION = 108;
        public static final byte PUSH_MESSAGE_KICK_OUT = 107;
        public static final byte PUSH_MESSAGE_START_GAME = 115;
        public static final byte PUSH_MESSAGE_FINISH_GAME = 102;
        public static final byte PLAYER_STATUS_NOT_REGISTERED = 110;
        public static final byte PLAYER_STATUS_OFFLINE = 102;
        public static final byte PLAYER_STATUS_ONLINE = 111;
        public static final byte PLAYER_STATUS_ONLINE_IN_SESSION = 115;
        public static final byte PLAYER_STATUS_ONLINE_PLAYING = 112;
        public static final byte PLAYER_STATUS_HAS_PSD = 104;
        public static final byte PLAYER_STATUS_HAS_NO_PSD = 100;
    }

    public XPlayer(MIDlet midlet) {
        this.is_logged_in = false;
        this.url = midlet.getAppProperty("XPlayerURL");
        GGI = midlet.getAppProperty("GGI");
        if (this.url == null || GGI == null) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Please check that you have fields XPlayerURL, XPlayMPURL, GGI in .jad file");
                return;
            }
            return;
        }
        this.whttp = new HTTP();
        if (GLLibConfig.xplayer_CARRIER_USSPRINT || GLLibConfig.xplayer_CARRIER_MXTELCEL) {
            HTTP http = this.whttp;
            HTTP.clientId = midlet.getAppProperty("ClientId");
            HTTP http2 = this.whttp;
            if (HTTP.clientId != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
                StringBuffer append = new StringBuffer().append("WARNING ClientId=");
                HTTP http3 = this.whttp;
                GLLib.Dbg(append.append(HTTP.clientId).append(", ERASE IN PRODUCTION jad").toString());
            }
        }
        if (GLLibConfig.xplayer_CARRIER_USNEXTEL) {
            HTTP http4 = this.whttp;
            HTTP.upsubid = midlet.getAppProperty("UPSUBID");
            HTTP http5 = this.whttp;
            if (HTTP.upsubid != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
                StringBuffer append2 = new StringBuffer().append("WARNING UPSUBID=");
                HTTP http6 = this.whttp;
                GLLib.Dbg(append2.append(HTTP.upsubid).append(", ERASE IN PRODUCTION jad").toString());
            }
        }
        if (GLLibConfig.xplayer_CARRIER_USVIRGIN) {
            HTTP http7 = this.whttp;
            HTTP.x_up_calling_line_id = midlet.getAppProperty("x-up-calling-line-id");
            HTTP http8 = this.whttp;
            if (HTTP.x_up_calling_line_id != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
                StringBuffer append3 = new StringBuffer().append("WARNING x-up-calling-line-id=");
                HTTP http9 = this.whttp;
                GLLib.Dbg(append3.append(HTTP.x_up_calling_line_id).append(", ERASE IN PRODUCTION jad").toString());
            }
        }
        if (GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE || GLLibConfig.xplayer_CARRIER_USVIRGIN) {
            HTTP http10 = this.whttp;
            HTTP.x_up_subno = midlet.getAppProperty("x-up-subno");
            HTTP http11 = this.whttp;
            if (HTTP.x_up_subno != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
                StringBuffer append4 = new StringBuffer().append("WARNING x-up-subno=");
                HTTP http12 = this.whttp;
                GLLib.Dbg(append4.append(HTTP.x_up_subno).append(", ERASE IN PRODUCTION jad").toString());
            }
        }
        if (GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE) {
            HTTP http13 = this.whttp;
            HTTP.CarrierDeviceId = midlet.getAppProperty("CarrierDeviceId");
            HTTP http14 = this.whttp;
            if (HTTP.CarrierDeviceId != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
                StringBuffer append5 = new StringBuffer().append("WARNING CarrierDeviceId=");
                HTTP http15 = this.whttp;
                GLLib.Dbg(append5.append(HTTP.CarrierDeviceId).append(", ERASE IN PRODUCTION jad").toString());
            }
        }
        if (GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN) {
            this.phoneNumber = new String("");
        }
        if (GLLibConfig.xplayer_ENABLE_MULTIPLAYER) {
            this.url_tcp = midlet.getAppProperty("XPlayMPURL");
            if (this.url_tcp != null) {
                this.wtcp = new TCP(this.url_tcp);
                this.crtPosWrite = 0;
                this.crtPosRead = 0;
                this.msgData = new byte[255];
            } else {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Please check that you have fields XPlayerURL, XPlayMPURL, GGI in .jad file");
                    return;
                }
                return;
            }
        }
        this.username = new String("");
        this.newRankAfterScoreSending = -666666;
        this.is_logged_in = false;
        init();
    }

    private void init() {
        clearLeaderboard();
        RecordStore rs = null;
        try {
            RecordStore rs2 = RecordStore.openRecordStore("UUID", true);
            if (rs2.getNumRecords() >= 1) {
                this.uid = new String(rs2.getRecord(1));
            } else {
                this.uid = GenerateUID();
                byte[] the_uid = this.uid.getBytes();
                if (rs2.getNumRecords() >= 1) {
                    rs2.setRecord(1, the_uid, 0, the_uid.length);
                } else {
                    rs2.addRecord(the_uid, 0, the_uid.length);
                }
            }
            try {
                rs2.closeRecordStore();
            } catch (Exception e) {
            }
        } catch (Exception e2) {
            try {
                rs.closeRecordStore();
            } catch (Exception e3) {
            }
        } catch (Throwable th) {
            try {
                rs.closeRecordStore();
            } catch (Exception e4) {
            }
            throw th;
        }
    }

    private String GenerateUID() {
        byte[] b = new byte[20];
        Random random = new Random();
        random.setSeed(System.currentTimeMillis());
        for (int i = 0; i < 20; i++) {
            int random_number = random.nextInt() % 35;
            if (random_number < 0) {
                random_number = -random_number;
            }
            b[i] = (byte) random_number;
            if (b[i] < 10) {
                int i2 = i;
                b[i2] = (byte) (b[i2] + 48);
            } else {
                int i3 = i;
                b[i3] = (byte) (b[i3] + 87);
            }
        }
        String retval = new String(b);
        GLLib.Gc();
        return new StringBuffer().append(retval).append(Integer.toString(((int) System.currentTimeMillis()) / 1000)).toString();
    }

    public boolean isLoggedIn() {
        return this.is_logged_in;
    }

    public void setUsername(String name) {
        this.username = new String(name);
    }

    public String getUsername() {
        return this.username;
    }

    public int getNewRankAfterScoreSending() {
        return this.newRankAfterScoreSending;
    }

    public int getLastError() {
        if (this.whttp.isInProgress()) {
            return -1;
        }
        if (this.whttp.m_bError) {
            return -2;
        }
        return this.lastErrorCode;
    }

    public void cancel() {
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = 0L;
        }
        this.whttp.cancel();
    }

    public void cleanup() {
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = 0L;
        }
        this.whttp.cleanup();
    }

    private String String2Blob(String str) {
        int nBlobLength;
        byte[] bs = str.getBytes();
        int nBlobPos = 0;
        int nSPos = 0;
        int nBitsNotUsed = 8;
        int nBlobLength2 = (str.length() * 8) / 6;
        if ((str.length() * 8) % 6 != 0) {
            nBlobLength = nBlobLength2 + 2;
        } else {
            nBlobLength = nBlobLength2 + 1;
        }
        byte[] sBlob = new byte[nBlobLength];
        for (int k = 0; k < nBlobLength; k++) {
            sBlob[k] = 0;
        }
        while (nSPos < str.length()) {
            byte nKeyIndex = (byte) (((byte) (bs[nSPos] & Byte.MAX_VALUE)) >> (8 - nBitsNotUsed));
            if (nBitsNotUsed < 6) {
                nSPos++;
                if (nSPos < str.length()) {
                    nKeyIndex = (byte) (nKeyIndex | (bs[nSPos] << nBitsNotUsed));
                    nBitsNotUsed += 2;
                }
            } else {
                nBitsNotUsed -= 6;
                if (nBitsNotUsed == 0) {
                    nBitsNotUsed = 8;
                    nSPos++;
                }
            }
            sBlob[nBlobPos] = SSEncDec_GetCharFromKeyByIndex((byte) (nKeyIndex & 63));
            nBlobPos++;
        }
        String retval = new String(sBlob, 0, nBlobPos);
        return retval;
    }

    private byte SSEncDec_GetCharFromKeyByIndex(byte nKeyIndex) {
        if (nKeyIndex < 26) {
            return (byte) (nKeyIndex + 97);
        }
        if (nKeyIndex < 52) {
            return (byte) (nKeyIndex + 39);
        }
        if (nKeyIndex < 62) {
            return (byte) (nKeyIndex - 4);
        }
        if (nKeyIndex == 62) {
            return (byte) 95;
        }
        return (byte) 45;
    }

    private String getValue(String src, int pos) {
        int start = 0;
        int end = src.indexOf(124, 0 + 1);
        while (pos > 0) {
            if (start == -1) {
                return null;
            }
            start = end;
            end = src.indexOf(124, start + 1);
            pos--;
        }
        if (start == -1) {
            return null;
        }
        if (end == -1) {
            end = src.length();
        }
        if (pos > 0) {
            start++;
        }
        if (start == end) {
            return "";
        }
        if (start > end) {
            return null;
        }
        try {
            char[] buf = new char[end - start];
            src.getChars(start, end, buf, 0);
            String value = new String(buf);
            return value;
        } catch (IndexOutOfBoundsException e) {
            return null;
        }
    }

    public void sendChangeUsername() {
        String tmp_request;
        if (GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN) {
            tmp_request = new StringBuffer().append("f|14|i|").append(GGI).append("|n|").append(this.username).append("|p|").append(this.phoneNumber).append("|u|").append(this.uid).append("|").toString();
        } else {
            tmp_request = new StringBuffer().append("f|14|i|").append(GGI).append("|n|").append(this.username).append("|u|").append(this.uid).append("|").toString();
        }
        String request = String2Blob(tmp_request);
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, request);
    }

    public void sendLogin(String playerData) {
        String tmp_request;
        if (GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN) {
            tmp_request = new StringBuffer().append("f|11|i|").append(GGI).append("|n|").append(this.username).append("|p|").append(this.phoneNumber).append("|u|").append(this.uid).append("|").toString();
        } else {
            tmp_request = new StringBuffer().append("f|11|i|").append(GGI).append("|n|").append(this.username).append("|u|").append(this.uid).append("|").toString();
        }
        if (playerData != null) {
            tmp_request = new StringBuffer().append(tmp_request).append("b|").append(playerData).append("|").toString();
        }
        String request = String2Blob(tmp_request);
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, request);
    }

    public void handleLogin() {
        handleLoginChangeUsername(11);
    }

    public void handleChangeUsername() {
        handleLoginChangeUsername(14);
    }

    private void handleLoginChangeUsername(int _function) {
        String tmpHR;
        String tmpHR2;
        if (_function != 11 && _function != 14) {
            return;
        }
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                cancel();
                this.lastErrorCode = -2;
                return;
            }
            return;
        }
        if (this.whttp.m_bError || this.whttp.m_response == null || getValue(this.whttp.m_response, 0).compareTo("f") != 0 || (tmpHR = getValue(this.whttp.m_response, 1)) == null || Integer.parseInt(tmpHR) != _function || (tmpHR2 = getValue(this.whttp.m_response, 3)) == null) {
            return;
        }
        if (tmpHR2.compareTo("e") == 0) {
            this.lastErrorCode = Integer.parseInt(getValue(this.whttp.m_response, 4));
            if (this.lastErrorCode == 3) {
                String tmpHR3 = getValue(this.whttp.m_response, 5);
                if (tmpHR3 != null && tmpHR3.compareTo("d") == 0 && getValue(this.whttp.m_response, 6).compareTo("5 M7 error, contact Online Team") == 0) {
                    this.lastErrorCode = -2;
                    return;
                }
                return;
            }
            if (this.lastErrorCode == 5) {
                this.username = getValue(this.whttp.m_response, 6);
                return;
            }
            return;
        }
        if (tmpHR2.compareTo("s") == 0) {
            this.lastErrorCode = 0;
            this.username = getValue(this.whttp.m_response, 5);
            this.is_logged_in = true;
        }
    }

    public void sendHighscore(int score, int level, int scoreType) {
        this.whttp.cancel();
        String tmp = new StringBuffer().append("f|0|i|").append(GGI).append("|u|").append(this.uid).toString();
        if (level >= 0) {
            tmp = new StringBuffer().append(tmp).append("|l|").append(level).toString();
        }
        String tmpBlob = String2Blob(new StringBuffer().append(tmp).append("|t|").append(scoreType).append("|s|").append(score).append('|').toString());
        this.lastErrorCode = -100;
        this.newRankAfterScoreSending = -666666;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmpBlob);
    }

    public void sendHighscoreWithSupplementalData(int score, int level, int scoreType, int[] supplemental_data) {
        this.whttp.cancel();
        String tmp = new StringBuffer().append("f|0|i|").append(GGI).append("|u|").append(this.uid).toString();
        if (level < 0) {
            level = 0;
        }
        String tmp2 = new StringBuffer().append(tmp).append("|l|").append(level).append("|t|").append(scoreType).append("|sl|0|s|").append(score).toString();
        for (int i = 0; i < supplemental_data.length; i++) {
            tmp2 = new StringBuffer().append(tmp2).append("|l|").append(level).append("|t|").append(scoreType).append("|sl|").append(i + 1).append("|s|").append(supplemental_data[i]).toString();
        }
        String tmpBlob = String2Blob(new StringBuffer().append(tmp2).append("|").toString());
        this.lastErrorCode = -100;
        this.newRankAfterScoreSending = -666666;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmpBlob);
    }

    public void handleHighscore() {
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                cancel();
                this.lastErrorCode = -2;
                return;
            }
            return;
        }
        if (!this.whttp.m_bError && this.whttp.m_response != null) {
            String tmpHR = getValue(this.whttp.m_response, 0);
            if (tmpHR.compareTo("f") != 0) {
                return;
            }
            String tmpHR2 = getValue(this.whttp.m_response, 1);
            if (Integer.parseInt(tmpHR2) != 0) {
                return;
            }
            String tmpHR3 = getValue(this.whttp.m_response, 3);
            if (tmpHR3.compareTo("e") == 0) {
                String tmpHR4 = getValue(this.whttp.m_response, 4);
                this.lastErrorCode = Integer.parseInt(tmpHR4);
                return;
            }
            if (tmpHR3.compareTo("s") == 0) {
                this.lastErrorCode = 0;
                int entry = 4 + 1;
                String tmpHR5 = getValue(this.whttp.m_response, 4);
                if (tmpHR5.compareTo("l") == 0) {
                    int entry2 = entry + 1;
                    entry = entry2 + 1;
                    tmpHR5 = getValue(this.whttp.m_response, entry2);
                }
                if (tmpHR5.compareTo("r") == 0) {
                    String tmpHR6 = getValue(this.whttp.m_response, entry);
                    this.newRankAfterScoreSending = Integer.parseInt(tmpHR6);
                }
            }
        }
    }

    public void initMultipleScores() {
        this.multipleScoresRequestBuffer = new StringBuffer().append("f|0|i|").append(GGI).append("|u|").append(this.uid).toString();
    }

    public void addMultipleScoreEntry(int score, int level, int scoreType) {
        if (this.multipleScoresRequestBuffer == null) {
            return;
        }
        this.multipleScoresRequestBuffer = new StringBuffer().append(this.multipleScoresRequestBuffer).append("|l|").append(level).append("|t|").append(scoreType).append("|s|").append(score).toString();
    }

    public void addMultipleScoreEntryWithSupplementalData(int score, int level, int scoreType, int[] supplemental_data) {
        if (this.multipleScoresRequestBuffer == null) {
            return;
        }
        this.multipleScoresRequestBuffer = new StringBuffer().append(this.multipleScoresRequestBuffer).append("|l|").append(level).append("|t|").append(scoreType).append("|sl|0|s|").append(score).toString();
        for (int i = 0; i < supplemental_data.length; i++) {
            this.multipleScoresRequestBuffer = new StringBuffer().append(this.multipleScoresRequestBuffer).append("|l|").append(level).append("|t|").append(scoreType).append("|sl|").append(i + 1).append("|s|").append(supplemental_data[i]).toString();
        }
    }

    public void sendMultipleHighscores() {
        if (this.multipleScoresRequestBuffer == null) {
            return;
        }
        this.whttp.cancel();
        this.multipleScoresRequestBuffer = new StringBuffer().append(this.multipleScoresRequestBuffer).append("|").toString();
        String tmpBlob = String2Blob(this.multipleScoresRequestBuffer);
        this.lastErrorCode = -100;
        this.newRankAfterScoreSending = -666666;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmpBlob);
    }

    public void sendRankGet(int level, int number_of_players, int scoreType, int numberOfSupplementalDataFields) {
        this.whttp.cancel();
        String tmp = new StringBuffer().append("f|12|i|").append(GGI).append("|u|").append(this.uid).append("|p|").append(number_of_players).append("|").append("t|").append(scoreType).append("|").toString();
        if (level >= 0) {
            tmp = new StringBuffer().append(tmp).append("l|").append(level).append("|").toString();
        }
        String tmpBlob = String2Blob(tmp);
        clearLeaderboard();
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = System.currentTimeMillis();
        }
        this.leaderboardSupplementalDataFieldsNumber = numberOfSupplementalDataFields;
        this.whttp.sendByGet(this.url, tmpBlob);
    }

    public void handleRankGet() {
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                cancel();
                this.lastErrorCode = -2;
                return;
            }
            return;
        }
        if (!this.whttp.m_bError && this.whttp.m_response != null) {
            String tmpHR = getValue(this.whttp.m_response, 0);
            if (tmpHR.compareTo("f") != 0) {
                return;
            }
            String tmpHR2 = getValue(this.whttp.m_response, 1);
            if (Integer.parseInt(tmpHR2) != 12) {
                return;
            }
            String tmpHR3 = getValue(this.whttp.m_response, 3);
            if (tmpHR3.compareTo("e") == 0) {
                String tmpHR4 = getValue(this.whttp.m_response, 4);
                this.lastErrorCode = Integer.parseInt(tmpHR4);
                return;
            }
            if (tmpHR3.compareTo("s") == 0) {
                this.lastErrorCode = 0;
                clearLeaderboard();
                try {
                    processLeaderboardData(this.whttp.m_response);
                } catch (Exception e) {
                    this.lastErrorCode = 40;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        GLLib.Dbg(new StringBuffer().append("Error processing leaderboard data: ").append(e.getMessage()).toString());
                    }
                }
            }
        }
    }

    public void sendRankGetAroundPlayer(int level, int number_of_players_around, int scoreType, int numberOfSupplementalDataFields) {
        this.whttp.cancel();
        String tmp = new StringBuffer().append("f|13|i|").append(GGI).append("|u|").append(this.uid).append("|p|").append(number_of_players_around).append("|").append("t|").append(scoreType).append("|").toString();
        if (level >= 0) {
            tmp = new StringBuffer().append(tmp).append("l|").append(level).append("|").toString();
        }
        String tmpBlob = String2Blob(tmp);
        clearLeaderboard();
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = System.currentTimeMillis();
        }
        this.leaderboardSupplementalDataFieldsNumber = numberOfSupplementalDataFields;
        this.whttp.sendByGet(this.url, tmpBlob);
    }

    public void handleRankGetAroundPlayer() {
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                cancel();
                this.lastErrorCode = -2;
                return;
            }
            return;
        }
        if (!this.whttp.m_bError && this.whttp.m_response != null) {
            String tmpHR = getValue(this.whttp.m_response, 0);
            if (tmpHR.compareTo("f") != 0) {
                return;
            }
            String tmpHR2 = getValue(this.whttp.m_response, 1);
            if (Integer.parseInt(tmpHR2) != 13) {
                return;
            }
            String tmpHR3 = getValue(this.whttp.m_response, 3);
            if (tmpHR3.compareTo("e") == 0) {
                String tmpHR4 = getValue(this.whttp.m_response, 4);
                this.lastErrorCode = Integer.parseInt(tmpHR4);
                return;
            }
            if (tmpHR3.compareTo("s") == 0) {
                this.lastErrorCode = 0;
                clearLeaderboard();
                try {
                    processRankingAroundPlayerData(this.whttp.m_response);
                } catch (Exception e) {
                    this.lastErrorCode = 40;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        GLLib.Dbg(new StringBuffer().append("Error processing rank around player data: ").append(e.getMessage()).toString());
                    }
                }
            }
        }
    }

    public int getCurrentPlayerLeaderboardPosition() {
        return this.currentPlayerLeaderboardPosition;
    }

    public int getCurrentPlayerLeaderboardScore() {
        return this.currentPlayerLeaderboardScore;
    }

    public int[] getCurrentPlayerLeaderboardScoreData() {
        return this.currentPlayerLeaderboardScoreData;
    }

    public boolean getLeaderboardData(String[] names, int[] positions, int[] scores, int[][] scoreDatas) {
        if (this.leaderboardSize <= 0 || this.leaderboardPlayerNames == null || names == null || names.length < this.leaderboardSize || positions == null || positions.length < this.leaderboardSize || scores == null || scores.length < this.leaderboardSize) {
            return false;
        }
        System.arraycopy(this.leaderboardPlayerNames, 0, names, 0, this.leaderboardSize);
        System.arraycopy(this.leaderboardPlayerPositions, 0, positions, 0, this.leaderboardSize);
        System.arraycopy(this.leaderboardPlayerScores, 0, scores, 0, this.leaderboardSize);
        if (this.leaderboardPlayerScoreDatas != null && this.leaderboardSupplementalDataFieldsNumber > 0) {
            if (scoreDatas == null || scoreDatas.length < this.leaderboardSize || scoreDatas[0].length < this.leaderboardSupplementalDataFieldsNumber) {
                return false;
            }
            System.arraycopy(this.leaderboardPlayerScoreDatas, 0, scoreDatas, 0, this.leaderboardSize);
            return true;
        }
        return true;
    }

    public int getLeaderboardSize() {
        if (this.leaderboardPlayerNames == null) {
            return -1;
        }
        return this.leaderboardSize;
    }

    public String getLeaderboardEntryPlayerName(int index) {
        if (index >= this.leaderboardSize || this.leaderboardPlayerNames == null) {
            return null;
        }
        return this.leaderboardPlayerNames[index];
    }

    public int getLeaderboardEntryPlayerPosition(int index) {
        if (index >= this.leaderboardSize || this.leaderboardPlayerPositions == null) {
            return -1;
        }
        return this.leaderboardPlayerPositions[index];
    }

    public int getLeaderboardEntryPlayerScore(int index) {
        if (index >= this.leaderboardSize || this.leaderboardPlayerScores == null) {
            return -666666;
        }
        return this.leaderboardPlayerScores[index];
    }

    public int[] getLeaderboardEntryPlayerScoreData(int index) {
        if (index >= this.leaderboardSize || this.leaderboardPlayerScoreDatas == null) {
            return null;
        }
        return this.leaderboardPlayerScoreDatas[index];
    }

    private void processLeaderboardData(String leaderboardData) {
        int index = 4 + 1;
        String tmpHR = getValue(leaderboardData, 4);
        int count = 0;
        if (tmpHR.compareTo("y") == 0) {
            int index2 = index + 1;
            this.currentPlayerLeaderboardPosition = Integer.parseInt(getValue(leaderboardData, index));
            if (this.currentPlayerLeaderboardPosition < 0) {
                this.currentPlayerLeaderboardPosition = -666666;
                this.currentPlayerLeaderboardPosition = -666666;
                this.currentPlayerLeaderboardScore = -666666;
                this.currentPlayerLeaderboardScoreData = null;
                index = index2 + 2 + this.leaderboardSupplementalDataFieldsNumber;
                count = 0 - (3 + this.leaderboardSupplementalDataFieldsNumber);
            } else {
                int index3 = index2 + 1;
                index = index3 + 1;
                this.currentPlayerLeaderboardScore = Integer.parseInt(getValue(leaderboardData, index3));
                if (this.leaderboardSupplementalDataFieldsNumber > 0) {
                    this.currentPlayerLeaderboardScoreData = new int[this.leaderboardSupplementalDataFieldsNumber];
                }
                for (int i = 0; i < this.leaderboardSupplementalDataFieldsNumber; i++) {
                    int i2 = index;
                    index++;
                    this.currentPlayerLeaderboardScoreData[i] = Integer.parseInt(getValue(leaderboardData, i2));
                }
            }
        } else if (tmpHR.compareTo("n") != 0) {
            return;
        }
        int indexOf = leaderboardData.indexOf(124, 0 + 1);
        while (true) {
            int start = indexOf;
            if (start == -1) {
                break;
            }
            count++;
            indexOf = leaderboardData.indexOf(124, start + 1);
        }
        int count2 = count - 4;
        if (this.currentPlayerLeaderboardPosition >= 0) {
            count2 -= 3 + this.leaderboardSupplementalDataFieldsNumber;
        }
        this.leaderboardSize = count2 / (3 + this.leaderboardSupplementalDataFieldsNumber);
        if (this.leaderboardSize <= 0) {
            return;
        }
        this.leaderboardPlayerNames = new String[this.leaderboardSize];
        this.leaderboardPlayerPositions = new int[this.leaderboardSize];
        this.leaderboardPlayerScores = new int[this.leaderboardSize];
        if (this.leaderboardSupplementalDataFieldsNumber > 0) {
            this.leaderboardPlayerScoreDatas = new int[this.leaderboardSize][this.leaderboardSupplementalDataFieldsNumber];
        }
        for (int i3 = 0; i3 < this.leaderboardSize; i3++) {
            int i4 = index;
            int index4 = index + 1;
            this.leaderboardPlayerPositions[i3] = Integer.parseInt(getValue(leaderboardData, i4));
            int index5 = index4 + 1;
            this.leaderboardPlayerNames[i3] = new String(getValue(leaderboardData, index4));
            index = index5 + 1;
            this.leaderboardPlayerScores[i3] = Integer.parseInt(getValue(leaderboardData, index5));
            for (int j = 0; j < this.leaderboardSupplementalDataFieldsNumber; j++) {
                int i5 = index;
                index++;
                this.leaderboardPlayerScoreDatas[i3][j] = Integer.parseInt(getValue(leaderboardData, i5));
            }
        }
    }

    private void processRankingAroundPlayerData(String rankingData) {
        int count = 0;
        int indexOf = rankingData.indexOf(124, 0 + 1);
        while (true) {
            int start = indexOf;
            if (start == -1) {
                break;
            }
            count++;
            indexOf = rankingData.indexOf(124, start + 1);
        }
        this.leaderboardSize = (count - 3) / (3 + this.leaderboardSupplementalDataFieldsNumber);
        if (this.leaderboardSize <= 0) {
            return;
        }
        this.leaderboardPlayerNames = new String[this.leaderboardSize];
        this.leaderboardPlayerPositions = new int[this.leaderboardSize];
        this.leaderboardPlayerScores = new int[this.leaderboardSize];
        if (this.leaderboardSupplementalDataFieldsNumber > 0) {
            this.leaderboardPlayerScoreDatas = new int[this.leaderboardSize][this.leaderboardSupplementalDataFieldsNumber];
        }
        int index = 4;
        for (int i = 0; i < this.leaderboardSize; i++) {
            int i2 = index;
            int index2 = index + 1;
            String tmpHR = getValue(rankingData, i2);
            this.leaderboardPlayerPositions[i] = Integer.parseInt(tmpHR);
            int index3 = index2 + 1;
            String tmpHR2 = getValue(rankingData, index2);
            this.leaderboardPlayerNames[i] = new String(tmpHR2);
            index = index3 + 1;
            String tmpHR3 = getValue(rankingData, index3);
            this.leaderboardPlayerScores[i] = Integer.parseInt(tmpHR3);
            for (int j = 0; j < this.leaderboardSupplementalDataFieldsNumber; j++) {
                int i3 = index;
                index++;
                String tmpHR4 = getValue(rankingData, i3);
                this.leaderboardPlayerScoreDatas[i][j] = Integer.parseInt(tmpHR4);
            }
        }
    }

    private void clearLeaderboard() {
        this.leaderboardPlayerNames = null;
        this.leaderboardPlayerPositions = null;
        this.leaderboardPlayerScores = null;
        this.leaderboardPlayerScoreDatas = (int[][]) null;
        this.currentPlayerLeaderboardPosition = -666666;
        this.currentPlayerLeaderboardScore = -666666;
        this.currentPlayerLeaderboardScoreData = null;
        this.leaderboardSize = -666666;
        GLLib.Gc();
    }

    public void setPhoneNumber(String phoneNr) {
        this.phoneNumber = new String(phoneNr);
    }

    public void sendStatsGet(int level, int numberOfSupplementalDataFields) {
        this.whttp.cancel();
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        String tmp = new StringBuffer().append("f|10|i|").append(GGI).append("|u|").append(this.uid).append("|l|").append(level).append("|").toString();
        String tmpBlob = String2Blob(tmp);
        this.lastErrorCode = 0;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = System.currentTimeMillis();
        }
        this.leaderboardSupplementalDataFieldsNumber = numberOfSupplementalDataFields;
        this.whttp.sendByGet(this.url, tmpBlob);
    }

    public void handleStatsGet() {
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                cancel();
                this.lastErrorCode = -2;
                return;
            }
            return;
        }
        if (!this.whttp.m_bError && this.whttp.m_response != null) {
            int j = 0 + 1;
            String tmpHR = getValue(this.whttp.m_response, 0);
            if (tmpHR.compareTo("f") != 0) {
                return;
            }
            int j2 = j + 1;
            String tmpHR2 = getValue(this.whttp.m_response, j);
            try {
                if (Integer.parseInt(tmpHR2) != 10) {
                    return;
                }
                int j3 = j2 + 1;
                int j4 = j3 + 1;
                String tmpHR3 = getValue(this.whttp.m_response, j3);
                if (tmpHR3.compareTo("e") == 0) {
                    int i = j4 + 1;
                    String tmpHR4 = getValue(this.whttp.m_response, j4);
                    this.lastErrorCode = Integer.parseInt(tmpHR4);
                    return;
                }
                if (tmpHR3.compareTo("s") == 0) {
                    this.lastErrorCode = 0;
                    int j5 = j4 + 1;
                    String tmpHR5 = getValue(this.whttp.m_response, j4);
                    this.bestRank = Integer.parseInt(tmpHR5);
                    int j6 = j5 + 1;
                    String tmpHR6 = getValue(this.whttp.m_response, j5);
                    this.highScore = Integer.parseInt(tmpHR6);
                    if (this.leaderboardSupplementalDataFieldsNumber > 0) {
                        this.highScoreData = new int[this.leaderboardSupplementalDataFieldsNumber];
                    }
                    for (int i2 = 0; i2 < this.leaderboardSupplementalDataFieldsNumber; i2++) {
                        int i3 = j6;
                        j6++;
                        String tmpHR7 = getValue(this.whttp.m_response, i3);
                        this.highScoreData[i2] = Integer.parseInt(tmpHR7);
                    }
                    int i4 = j6;
                    int j7 = j6 + 1;
                    String tmpHR8 = getValue(this.whttp.m_response, i4);
                    this.lowScore = Integer.parseInt(tmpHR8);
                    if (this.leaderboardSupplementalDataFieldsNumber > 0) {
                        this.lowScoreData = new int[this.leaderboardSupplementalDataFieldsNumber];
                    }
                    for (int i5 = 0; i5 < this.leaderboardSupplementalDataFieldsNumber; i5++) {
                        int i6 = j7;
                        j7++;
                        String tmpHR9 = getValue(this.whttp.m_response, i6);
                        this.lowScoreData[i5] = Integer.parseInt(tmpHR9);
                    }
                    int i7 = j7;
                    int j8 = j7 + 1;
                    String tmpHR10 = getValue(this.whttp.m_response, i7);
                    this.avgScore = Integer.parseInt(tmpHR10);
                    int j9 = j8 + 1;
                    String tmpHR11 = getValue(this.whttp.m_response, j8);
                    this.numberOfGamesPlayed = Integer.parseInt(tmpHR11);
                    int i8 = j9 + 1;
                    this.lastTimePlayed = getValue(this.whttp.m_response, j9);
                }
            } catch (Exception e) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("EERRRR");
                }
            }
        }
    }

    public void getPlayerStats(int[] bestRankArr, int[] highScoreArr, int[] lowScoreArr, int[] avgScoreArr, int[] numberOfGamesPlayerdArr, String[] lastTimePlayedArr, int[] lowScoreDataArr, int[] highScoreDataArr) {
        bestRankArr[0] = this.bestRank;
        highScoreArr[0] = this.highScore;
        for (int i = 0; i < this.leaderboardSupplementalDataFieldsNumber; i++) {
            highScoreDataArr[i] = this.highScoreData[i];
        }
        lowScoreArr[0] = this.lowScore;
        for (int i2 = 0; i2 < this.leaderboardSupplementalDataFieldsNumber; i2++) {
            lowScoreDataArr[i2] = this.lowScoreData[i2];
        }
        avgScoreArr[0] = this.avgScore;
        numberOfGamesPlayerdArr[0] = this.numberOfGamesPlayed;
        lastTimePlayedArr[0] = this.lastTimePlayed;
    }

    public int getMyBestRank() {
        return this.bestRank;
    }

    public int getMyHighScore() {
        return this.highScore;
    }

    public int getMyLowScore() {
        return this.lowScore;
    }

    public int[] getMyLowScoreData() {
        return this.lowScoreData;
    }

    public int[] getMyHighScoreData() {
        return this.highScoreData;
    }

    public int getMyAvgScore() {
        return this.avgScore;
    }

    public int getMyNumberOfGamesPlayed() {
        return this.numberOfGamesPlayed;
    }

    public String getMyLastTimePlayed() {
        return this.lastTimePlayed;
    }

    public void sendRateGame(int rating) {
        this.whttp.cancel();
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        String tmp = new StringBuffer().append("f|8|i|").append(GGI).append("|u|").append(this.uid).append("|s|").append(rating).append("|").toString();
        String tmpBlob = String2Blob(tmp);
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmpBlob);
    }

    public void handleRateGame() {
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                cancel();
                this.lastErrorCode = -2;
                return;
            }
            return;
        }
        if (!this.whttp.m_bError && this.whttp.m_response != null) {
            String tmpHR = getValue(this.whttp.m_response, 0);
            if (tmpHR.compareTo("f") != 0) {
                return;
            }
            String tmpHR2 = getValue(this.whttp.m_response, 1);
            if (Integer.parseInt(tmpHR2) != 8) {
                return;
            }
            String tmpHR3 = getValue(this.whttp.m_response, 3);
            if (tmpHR3.compareTo("e") == 0) {
                String tmpHR4 = getValue(this.whttp.m_response, 4);
                this.lastErrorCode = Integer.parseInt(tmpHR4);
            } else if (tmpHR3.compareTo("s") == 0) {
                this.lastErrorCode = 0;
            }
        }
    }

    public void sendRecommendGame() {
        this.whttp.cancel();
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        String tmp = new StringBuffer().append("f|9|i|").append(GGI).append("|u|").append(this.uid).append("|").toString();
        String tmpBlob = String2Blob(tmp);
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmpBlob);
    }

    public void handleRecommendGame() {
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                cancel();
                this.lastErrorCode = -2;
                return;
            }
            return;
        }
        if (this.whttp.m_bError || this.whttp.m_response == null || Integer.parseInt(getValue(this.whttp.m_response, 1)) != 9) {
            return;
        }
        String tmpHR = getValue(this.whttp.m_response, 3);
        if (tmpHR.compareTo("e") == 0) {
            this.lastErrorCode = Integer.parseInt(getValue(this.whttp.m_response, 4));
        } else if (tmpHR.compareTo("s") == 0) {
            this.lastErrorCode = 0;
        }
    }

    public void setData(byte[] data) {
        System.arraycopy(data, 0, this.msgData, 0, data.length);
        this.crtPosWrite = data.length;
        this.crtPosRead = 0;
    }

    public byte[] getData() {
        byte[] retval = new byte[this.crtPosWrite];
        System.arraycopy(this.msgData, 0, retval, 0, this.crtPosWrite);
        this.crtPosWrite = 0;
        this.crtPosRead = 0;
        return retval;
    }

    public void clearData() {
        this.m_type = (byte) 0;
        this.m_subtype = (byte) 0;
        this.crtPosWrite = 0;
        this.crtPosRead = 0;
    }

    public int getLength() {
        return this.crtPosWrite;
    }

    public void addByte(byte data) throws Exception {
        if (this.msgData != null && this.crtPosWrite < this.msgData.length) {
            byte[] bArr = this.msgData;
            int i = this.crtPosWrite;
            this.crtPosWrite = i + 1;
            bArr[i] = data;
            return;
        }
        throw new Exception("Xplayer.addByte.Error adding byte to current data");
    }

    public byte getByte() throws Exception {
        if (this.msgData != null && this.crtPosRead < this.crtPosWrite) {
            byte[] bArr = this.msgData;
            int i = this.crtPosRead;
            this.crtPosRead = i + 1;
            return bArr[i];
        }
        throw new Exception("Xplayer.getByte.Error retrieving byte from current data");
    }

    public void addShort(short data) throws Exception {
        if (this.msgData != null && this.crtPosWrite < this.msgData.length - 1) {
            byte[] bArr = this.msgData;
            int i = this.crtPosWrite;
            this.crtPosWrite = i + 1;
            bArr[i] = (byte) ((data & 65280) >> 8);
            byte[] bArr2 = this.msgData;
            int i2 = this.crtPosWrite;
            this.crtPosWrite = i2 + 1;
            bArr2[i2] = (byte) (data & 255);
            return;
        }
        throw new Exception("Xplayer.addShort.Error add short to current data");
    }

    public short getShort() throws Exception {
        if (this.msgData != null && this.crtPosRead < this.crtPosWrite - 1) {
            short ret = (short) (((this.msgData[this.crtPosRead] << 8) & 65280) | (this.msgData[this.crtPosRead + 1] & 255));
            this.crtPosRead += 2;
            return ret;
        }
        throw new Exception("Xplayer.getShort.Error retrieve short from current data");
    }

    public void addInt(int data) throws Exception {
        if (this.msgData != null && this.crtPosWrite < this.msgData.length - 3) {
            byte[] bArr = this.msgData;
            int i = this.crtPosWrite;
            this.crtPosWrite = i + 1;
            bArr[i] = (byte) (data >>> 24);
            byte[] bArr2 = this.msgData;
            int i2 = this.crtPosWrite;
            this.crtPosWrite = i2 + 1;
            bArr2[i2] = (byte) (data >>> 16);
            byte[] bArr3 = this.msgData;
            int i3 = this.crtPosWrite;
            this.crtPosWrite = i3 + 1;
            bArr3[i3] = (byte) (data >>> 8);
            byte[] bArr4 = this.msgData;
            int i4 = this.crtPosWrite;
            this.crtPosWrite = i4 + 1;
            bArr4[i4] = (byte) (data >>> 0);
            return;
        }
        throw new Exception("Xplayer.addInt.Error add int to current data");
    }

    public int getInt() throws Exception {
        if (this.msgData != null && this.crtPosRead < this.crtPosWrite - 3) {
            int ret = 0 | ((this.msgData[this.crtPosRead] << 24) & (-16777216));
            int ret2 = ret | ((this.msgData[this.crtPosRead + 1] << 16) & 16711680) | ((this.msgData[this.crtPosRead + 2] << 8) & 65280) | ((this.msgData[this.crtPosRead + 3] << 0) & 255);
            this.crtPosRead += 4;
            return ret2;
        }
        throw new Exception("Xplayer.getInt.Error retrieve int from current data");
    }

    public void addByteArray(byte size, int dataOffset, byte[] data) throws Exception {
        if (this.msgData != null && this.crtPosWrite < this.msgData.length - size) {
            byte[] bArr = this.msgData;
            int i = this.crtPosWrite;
            this.crtPosWrite = i + 1;
            bArr[i] = size;
            System.arraycopy(data, dataOffset, this.msgData, this.crtPosWrite, size);
            this.crtPosWrite += size;
            return;
        }
        throw new Exception("Xplayer.addByteArray.Error adding byte array to current data");
    }

    public byte[] getByteArray() throws Exception {
        if (this.msgData != null && this.crtPosRead < this.crtPosWrite) {
            byte[] bArr = this.msgData;
            int i = this.crtPosRead;
            this.crtPosRead = i + 1;
            int i2 = bArr[i];
            if (this.crtPosRead < (this.crtPosWrite - i2) + 1) {
                byte[] data = new byte[i2];
                System.arraycopy(this.msgData, this.crtPosRead, data, 0, i2);
                this.crtPosRead += i2;
                return data;
            }
            throw new Exception("Xplayer.getByteArray.Error adding byte array to current data");
        }
        throw new Exception("Xplayer.getByteArray.Error getting byte array size from current data");
    }

    public byte[] getByteArray(int dataOffset, byte[] datadest) throws Exception {
        if (this.msgData != null && this.crtPosRead < this.crtPosWrite) {
            byte[] bArr = this.msgData;
            int i = this.crtPosRead;
            this.crtPosRead = i + 1;
            byte size = bArr[i];
            if (this.crtPosRead < (this.crtPosWrite - size) + 1) {
                System.arraycopy(this.msgData, this.crtPosRead, datadest, dataOffset, size);
                this.crtPosRead += size;
                return datadest;
            }
            throw new Exception("Error adding byte array to current data");
        }
        throw new Exception("Error getting byte array size from current data");
    }

    public void addString(String data) throws Exception {
        byte[] db = data.getBytes();
        if (db.length > 255) {
            throw new Exception("Error adding string to current data");
        }
        addByteArray((byte) db.length, 0, db);
    }

    public String getString() throws Exception {
        return new String(getByteArray());
    }

    public final boolean mpIsConnected() {
        return this.m_MPConnectLevel >= 1;
    }

    public final boolean mpIsLoggedIn() {
        return this.m_MPConnectLevel >= 2;
    }

    public final boolean mpIsInSession() {
        return this.m_MPConnectLevel >= 3;
    }

    public final boolean mpIsInGame() {
        return this.m_MPConnectLevel >= 5;
    }

    public final boolean mpIsMaster() {
        return this.m_MPConnectLevel == 4 || this.m_MPConnectLevel == 6;
    }

    public final boolean mpHasOpponnentFinished() {
        return this.m_MPHasOpponentFinished;
    }

    private boolean mpProcessIncomingMessages() {
        if (System.currentTimeMillis() - callstarttime > GLLibConfig.xplayer_KEEP_ALIVE_TIME) {
            mpSendKeepAlive();
        }
        if (!this.wtcp.m_connected) {
            this.m_MPConnectLevel = (byte) 0;
            if (this.wtcp.m_bError) {
                this.lastErrorCode = -2;
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("XPLAYER: TCP says ").append(this.wtcp.m_bErrorString).toString());
                    return true;
                }
                return true;
            }
            return true;
        }
        this.m_data = this.wtcp.recvPacket();
        if (this.m_data == null) {
            if (!this.wtcp.m_connected) {
                this.m_MPConnectLevel = (byte) 0;
                if (this.wtcp.m_bError) {
                    this.lastErrorCode = -2;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        GLLib.Dbg(new StringBuffer().append("XPLAYER: TCP says ").append(this.wtcp.m_bErrorString).toString());
                        return false;
                    }
                    return false;
                }
                return false;
            }
            return false;
        }
        setData(this.m_data);
        try {
            this.m_type = getByte();
            this.m_subtype = (byte) 0;
            switch (this.m_type) {
                case 103:
                    this.m_subtype = getByte();
                    switch (this.m_subtype) {
                        case 97:
                            return false;
                        case 103:
                        case 104:
                            this.incomingGameData.addElement(this.m_data);
                            return false;
                        case 112:
                            mpProcessPushMessages();
                            return false;
                        case 114:
                            return true;
                        default:
                            throw new Exception("Unknown message type");
                    }
                case 115:
                    this.m_subtype = getByte();
                    switch (this.m_subtype) {
                        case 101:
                        case 115:
                        case 120:
                            return true;
                        default:
                            throw new Exception("Unknown message type");
                    }
                default:
                    throw new Exception("Unknown message type");
            }
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
                return false;
            }
            return false;
        }
    }

    private void mpProcessPushMessages() throws Exception {
        int newlen;
        if (!mpIsInSession()) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Push message outside session !");
            }
            return;
        }
        byte result = getByte();
        switch (result) {
            case 102:
                this.m_MPHasOpponentFinished = true;
                break;
            case 106:
                byte index = getByte();
                String name = getString();
                if (this.m_lNameList != null) {
                    newlen = this.m_lNameList.length + 1;
                } else {
                    newlen = 1;
                }
                String[] newnamelist = new String[newlen];
                byte[] newbytedatalist = new byte[newlen];
                int cnt = 0;
                while (cnt < newlen - 1) {
                    newnamelist[cnt] = this.m_lNameList[cnt];
                    newbytedatalist[cnt] = this.m_lByteDataList[cnt];
                    cnt++;
                }
                newnamelist[cnt] = name;
                newbytedatalist[cnt] = index;
                this.m_lNameList = newnamelist;
                this.m_lByteDataList = newbytedatalist;
                this.noitems = (byte) this.m_lNameList.length;
                break;
            case 107:
                this.m_MPConnectLevel = (byte) 2;
                break;
            case 108:
                String name2 = getString();
                int pos = 0;
                while (pos < this.m_lNameList.length && !name2.toLowerCase().equals(this.m_lNameList[pos].toLowerCase())) {
                    pos++;
                }
                if (pos != this.m_lNameList.length) {
                    String[] newnamelist2 = new String[this.m_lNameList.length - 1];
                    byte[] newbytedatalist2 = new byte[this.m_lNameList.length - 1];
                    int cnt2 = 0;
                    int cnt22 = 0;
                    while (cnt2 < this.m_lNameList.length) {
                        if (cnt2 == pos) {
                            cnt2++;
                        } else {
                            newnamelist2[cnt22] = this.m_lNameList[cnt2];
                            newbytedatalist2[cnt22] = this.m_lByteDataList[cnt2];
                            cnt2++;
                            cnt22++;
                        }
                    }
                    this.m_lNameList = newnamelist2;
                    this.m_lByteDataList = newbytedatalist2;
                    this.noitems = (byte) this.m_lNameList.length;
                    break;
                }
                break;
            case 115:
                if (this.m_MPConnectLevel != 4) {
                    int i = getByte();
                    this.m_lNameList = new String[i];
                    this.m_lByteDataList = new byte[i];
                    for (int cnt3 = 0; cnt3 < i; cnt3++) {
                        this.m_lNameList[cnt3] = getString();
                        this.m_lByteDataList[cnt3] = (byte) (cnt3 + 1);
                    }
                    this.noitems = (byte) this.m_lNameList.length;
                    if (this.m_MPConnectLevel == 3) {
                        this.m_MPConnectLevel = (byte) 5;
                        this.m_MPHasOpponentFinished = false;
                    } else {
                        this.lastErrorCode = 51;
                    }
                    this.incomingGameData = new Vector();
                    break;
                }
                break;
        }
    }

    private void mpPrepareGameRequest(byte type) throws Exception {
        clearData();
        addByte((byte) 103);
        addByte((byte) 114);
        addByte(type);
    }

    public void mpPrepareGameData() throws Exception {
        if (!mpIsInGame()) {
            this.lastErrorCode = 50;
            return;
        }
        this.lastErrorCode = -1;
        clearData();
        addByte((byte) 103);
        addByte((byte) 103);
    }

    public void mpSendGameData() {
        if (!mpIsInGame() || this.lastErrorCode != -1) {
            this.lastErrorCode = 50;
            return;
        }
        this.lastErrorCode = 0;
        this.wtcp.sendPacket(getData());
        callstarttime = System.currentTimeMillis();
    }

    public void mpHandleGameData() throws Exception {
        this.isGameMessageInQueue = false;
        if (!mpIsInGame()) {
            this.lastErrorCode = 50;
            return;
        }
        if (mpProcessIncomingMessages()) {
            return;
        }
        if (this.incomingGameData.size() > 0) {
            this.m_data = (byte[]) this.incomingGameData.firstElement();
            this.incomingGameData.removeElementAt(0);
            this.isGameMessageInQueue = true;
            return;
        }
        this.m_data = null;
    }

    public void mpSendDisconnect() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: send disconnect");
        }
        clearData();
        try {
            addByte((byte) 115);
            addByte((byte) 120);
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            GLLib.Dbg(e.getMessage());
        }
    }

    public void mpHandleDisconnect() {
        if (!mpProcessIncomingMessages()) {
            return;
        }
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: receive disconnect");
        }
        if (this.m_type == 115 && this.m_subtype == 120) {
            mpDisconnect();
        }
        this.lastErrorCode = 0;
    }

    public void mpDisconnect() {
        this.wtcp.disconnect();
        this.m_MPConnectLevel = (byte) 0;
    }

    public void mpHandleUpdates() {
        mpProcessIncomingMessages();
    }

    public void mpSendEstablishConnection() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: Establish connection");
        }
        if (mpIsConnected()) {
            this.lastErrorCode = 50;
            return;
        }
        int sig = new Random().nextInt();
        this.wtcp.connect();
        clearData();
        try {
            addByte((byte) 115);
            addByte((byte) 114);
            addInt(sig);
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            clearData();
            try {
                addByte((byte) 115);
                addByte((byte) 119);
                addInt(sig);
                this.wtcp.sendEstablishConnectionPackageOnReceive(getData());
            } catch (Exception e) {
                GLLib.Dbg(e.getMessage());
            }
        } catch (Exception e2) {
            GLLib.Dbg(e2.getMessage());
        }
    }

    public void mpHandleEstablishConnection() {
        if (mpIsConnected()) {
            this.lastErrorCode = 50;
        }
        if (mpProcessIncomingMessages() && this.m_type == 115) {
            switch (this.m_subtype) {
                case 101:
                    this.m_MPConnectLevel = (byte) 0;
                    this.lastErrorCode = -2;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        GLLib.Dbg(new StringBuffer().append("XPLAYER: TCP says ").append(this.wtcp.m_bErrorString).toString());
                        break;
                    }
                    break;
                case 115:
                    this.m_MPConnectLevel = (byte) 1;
                    this.lastErrorCode = 0;
                    break;
            }
        }
    }

    public void mpSendLogin() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: Logging in");
        }
        if (!mpIsConnected() || mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            mpPrepareGameRequest((byte) 105);
            addString(new StringBuffer().append("").append(GGI).append("-").append(this.uid).toString());
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpSendLogin(String player_data) {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: Logging in");
        }
        if (!mpIsConnected() || mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            mpPrepareGameRequest((byte) 105);
            addString(new StringBuffer().append("").append(GGI).append("-").append(this.uid).toString());
            addString(player_data);
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpHandleLogin() {
        if (!mpIsConnected() || mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        if (!mpProcessIncomingMessages() || this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = getByte();
            if (result != 105) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("Bad response LOGIN").append(new String(this.m_data)).toString());
                }
                this.lastErrorCode = 51;
            } else {
                byte result2 = getByte();
                if (result2 == 115) {
                    this.m_MPConnectLevel = (byte) 2;
                    this.lastErrorCode = 0;
                } else {
                    this.lastErrorCode = 3;
                }
            }
        } catch (Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpSendQuickGame() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: Quick game");
        }
        if (!mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            mpPrepareGameRequest((byte) 117);
            this.m_lBinaryDataList = null;
            this.m_lNameList = null;
            this.noitems = (byte) 0;
            this.nosessionsbase = 0;
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpSendListSession(byte numberOfSessions, byte firstSessionIndex) {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: List session");
        }
        if (!mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.noitems = numberOfSessions;
            this.nosessionsbase = firstSessionIndex;
            if (this.noitems <= 0) {
                this.noitems = (byte) 1;
            }
            if (this.nosessionsbase < 0) {
                this.nosessionsbase = 0;
            }
            mpPrepareGameRequest((byte) 108);
            addByte(this.noitems);
            addInt(this.nosessionsbase);
            this.m_lBinaryDataList = null;
            this.m_lNameList = null;
            this.noitems = (byte) 0;
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpHandleListSession() {
        if (!mpProcessIncomingMessages()) {
            return;
        }
        if (!mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = getByte();
            if (result != 117 && result != 108) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("Bad response LIST").append(new String(this.m_data)).toString());
                }
                this.lastErrorCode = 51;
                return;
            }
            if (getByte() == 115) {
                this.noitems = getByte();
                this.nosessionsbase = getInt();
                if (this.noitems > 0) {
                    this.m_lNameList = new String[this.noitems];
                    this.m_lByteDataList = new byte[this.noitems];
                    this.m_lBinaryDataList = new String[this.noitems];
                    for (int cnt = 0; cnt < this.noitems; cnt++) {
                        this.m_lNameList[cnt] = getString();
                        this.m_lByteDataList[cnt] = getByte();
                    }
                    for (int cnt2 = 0; cnt2 < this.noitems; cnt2++) {
                        this.m_lBinaryDataList[cnt2] = getString();
                    }
                }
                this.lastErrorCode = 0;
            } else {
                this.lastErrorCode = 3;
            }
        } catch (Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpSendCreateSession(String sessionname, String sessiondata) {
        if (!mpIsLoggedIn() || mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            mpPrepareGameRequest((byte) 99);
            addString(sessionname);
            if (sessiondata != null) {
                addString(sessiondata);
            }
            this.currentsessionname = sessionname;
            this.currentsessiondata = sessiondata;
            this.m_lBinaryDataList = null;
            this.m_lNameList = null;
            this.noitems = (byte) 0;
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpHandleCreateSession() {
        if (!mpProcessIncomingMessages()) {
            return;
        }
        if (!mpIsLoggedIn() || mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = getByte();
            if (result != 99) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("Bad response CREATE").append(new String(this.m_data)).toString());
                }
                this.lastErrorCode = 51;
                return;
            }
            byte result2 = getByte();
            if (result2 == 115) {
                this.m_MPConnectLevel = (byte) 4;
                this.noitems = (byte) 1;
                this.m_lNameList = new String[this.noitems];
                this.m_lByteDataList = new byte[this.noitems];
                for (int cnt = 0; cnt < this.noitems; cnt++) {
                    this.m_lNameList[cnt] = this.username;
                    this.m_lByteDataList[cnt] = 1;
                }
                this.lastErrorCode = 0;
            } else {
                this.lastErrorCode = 54;
            }
        } catch (Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpSendJoinSession(String sessionname) {
        if (!mpIsLoggedIn() || mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            mpPrepareGameRequest((byte) 106);
            addString(sessionname);
            this.currentsessionname = sessionname;
            this.m_lBinaryDataList = null;
            this.m_lNameList = null;
            this.noitems = (byte) 0;
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpHandleJoinSession() {
        if (!mpIsLoggedIn() || mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        if (!mpProcessIncomingMessages() || this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = getByte();
            if (result != 106) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("Bad response JOIN").append(new String(this.m_data)).toString());
                }
                this.lastErrorCode = 51;
                return;
            }
            byte result2 = getByte();
            if (result2 == 115) {
                this.m_MPConnectLevel = (byte) 3;
                this.lastErrorCode = 0;
                this.noitems = getByte();
                this.m_lNameList = new String[this.noitems];
                this.m_lByteDataList = new byte[this.noitems];
                for (int cnt = 0; cnt < this.noitems; cnt++) {
                    this.m_lNameList[cnt] = getString();
                    this.m_lByteDataList[cnt] = (byte) (cnt + 1);
                }
                this.currentsessiondata = getString();
                if (this.currentsessiondata.length() == 0) {
                    this.currentsessiondata = null;
                }
            } else {
                this.lastErrorCode = 54;
            }
        } catch (Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpSendLeaveSession() {
        if (!mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            mpPrepareGameRequest((byte) 113);
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpHandleLeaveSession() {
        if (!mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        if (!mpProcessIncomingMessages() || this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = getByte();
            if (result != 113) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("Bad response LEAVE").append(new String(this.m_data)).toString());
                }
                this.lastErrorCode = 51;
            } else {
                byte result2 = getByte();
                if (result2 == 115) {
                    this.m_MPConnectLevel = (byte) 2;
                    this.lastErrorCode = 0;
                } else {
                    this.lastErrorCode = 3;
                }
            }
        } catch (Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpSendKickOutPlayer(String playerName) {
        if (!mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            mpPrepareGameRequest((byte) 107);
            addString(playerName);
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpHandleKickOutPlayer(String name) {
        if (!mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        if (!mpProcessIncomingMessages() || this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = getByte();
            if (result != 107) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("Bad response KICK OUT").append(new String(this.m_data)).toString());
                }
                this.lastErrorCode = 51;
                return;
            }
            byte result2 = getByte();
            if (result2 == 115) {
                int pos = 0;
                while (pos < this.m_lNameList.length && !name.toLowerCase().equals(this.m_lNameList[pos].toLowerCase())) {
                    pos++;
                }
                if (pos == this.m_lNameList.length) {
                    this.lastErrorCode = 0;
                    return;
                }
                String[] newlist = new String[this.m_lNameList.length - 1];
                byte[] newdata = new byte[this.m_lNameList.length - 1];
                int cnt = 0;
                int cnt2 = 0;
                while (cnt < this.m_lNameList.length) {
                    if (cnt == pos) {
                        cnt++;
                    } else {
                        newlist[cnt2] = this.m_lNameList[cnt];
                        newdata[cnt2] = this.m_lByteDataList[cnt];
                        cnt++;
                        cnt2++;
                    }
                }
                this.m_lNameList = newlist;
                this.m_lByteDataList = newdata;
                this.noitems = (byte) this.m_lNameList.length;
                this.lastErrorCode = 0;
            } else {
                this.lastErrorCode = 3;
            }
        } catch (Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpSendStartGame() {
        if (!mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            mpPrepareGameRequest((byte) 115);
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpHandleStartGame() {
        if (mpIsInGame()) {
            if (!mpProcessIncomingMessages() || this.m_type != 103 || this.m_subtype != 114) {
                return;
            }
            try {
                byte result = getByte();
                if (result != 115) {
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        GLLib.Dbg(new StringBuffer().append("Bad response START while in game").append(new String(this.m_data)).toString());
                    }
                    this.lastErrorCode = 51;
                    return;
                }
                this.lastErrorCode = 0;
                this.incomingGameData = new Vector();
            } catch (Exception e) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
                    return;
                }
                return;
            }
        }
        if (!mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        if (!mpProcessIncomingMessages() || this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result2 = getByte();
            if (result2 != 115) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("Bad response START").append(new String(this.m_data)).toString());
                }
                this.lastErrorCode = 51;
                return;
            }
            byte result3 = getByte();
            if (result3 == 115) {
                if (this.m_MPConnectLevel == 3) {
                    this.m_MPConnectLevel = (byte) 5;
                } else if (this.m_MPConnectLevel == 4) {
                    this.m_MPConnectLevel = (byte) 6;
                }
                this.m_MPHasOpponentFinished = false;
                this.noitems = getByte();
                this.m_lNameList = new String[this.noitems];
                this.m_lByteDataList = new byte[this.noitems];
                for (int cnt = 0; cnt < this.noitems; cnt++) {
                    this.m_lNameList[cnt] = getString();
                    this.m_lByteDataList[cnt] = (byte) (cnt + 1);
                }
                this.incomingGameData = new Vector();
                this.lastErrorCode = 0;
            } else {
                this.lastErrorCode = 54;
            }
        } catch (Exception e2) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e2.getMessage()).toString());
            }
        }
    }

    public void mpSendFinishGame() {
        if (!mpIsInGame()) {
            return;
        }
        try {
            mpPrepareGameRequest((byte) 102);
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpHandleFinishGame() {
        if (!mpProcessIncomingMessages() || this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = getByte();
            if (result != 102) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("Bad response FINISH").append(new String(this.m_data)).toString());
                }
                this.lastErrorCode = 51;
            }
            byte result2 = getByte();
            if (result2 == 115) {
                this.m_MPConnectLevel = (byte) 2;
                this.lastErrorCode = 0;
            } else {
                this.lastErrorCode = 54;
            }
        } catch (Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpSendFindPlayer(String playerName) {
        if (!mpIsConnected()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            mpPrepareGameRequest((byte) 119);
            addString(playerName);
            this.found_player_session_name = null;
            this.found_player_session_number_of_players = (byte) -1;
            this.found_player_status = (byte) -1;
            this.found_player_name = playerName;
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpHandleFindPlayer() {
        if (!mpProcessIncomingMessages() || this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = getByte();
            if (result != 119) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("Bad response find player").append(new String(this.m_data)).toString());
                }
                this.lastErrorCode = 40;
                return;
            }
            byte result2 = getByte();
            if (result2 == 115) {
                this.found_player_status = getByte();
                if (this.found_player_status == 115 || this.found_player_status == 112) {
                    this.found_player_session_name = getString();
                    this.found_player_session_number_of_players = getByte();
                }
                this.lastErrorCode = 0;
            } else {
                this.lastErrorCode = 54;
            }
        } catch (Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpSendGetPlayerData(String playerName) {
        if (!mpIsConnected()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            mpPrepareGameRequest((byte) 121);
            addString(playerName);
            this.requested_player_data = null;
            this.requested_player_nickname = playerName;
            this.lastErrorCode = -1;
            this.whttp.m_bError = false;
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
        } catch (Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    public void mpHandleGetPlayerData() {
        if (!mpProcessIncomingMessages() || this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = getByte();
            if (result != 121) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg(new StringBuffer().append("Bad response find player").append(new String(this.m_data)).toString());
                }
                this.lastErrorCode = 40;
                return;
            }
            byte result2 = getByte();
            if (result2 == 115) {
                byte result3 = getByte();
                if (result3 == 104) {
                    this.requested_player_data = getString();
                    this.lastErrorCode = 0;
                } else if (result3 == 100) {
                    this.lastErrorCode = 0;
                } else {
                    this.lastErrorCode = 40;
                }
            } else {
                this.lastErrorCode = 54;
            }
        } catch (Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg(new StringBuffer().append("Error: ").append(e.getMessage()).toString());
            }
        }
    }

    private boolean mpSendKeepAlive() {
        try {
            clearData();
            addByte((byte) 103);
            addByte((byte) 97);
            this.wtcp.sendPacket(getData());
            callstarttime = System.currentTimeMillis();
            return true;
        } catch (Exception e) {
            return true;
        }
    }

    public String[] getNameList() {
        return this.m_lNameList;
    }

    public String[] getDataList() {
        return this.m_lBinaryDataList;
    }

    public byte[] getByteDataList() {
        return this.m_lByteDataList;
    }

    public String getSessionName() {
        return this.currentsessionname;
    }

    public String getSessionData() {
        return this.currentsessiondata;
    }

    public int getNumberOfItems() {
        return this.noitems;
    }

    public int getFirstSessionIndex() {
        return this.nosessionsbase;
    }

    public String getFoundPlayerName() {
        return this.found_player_name;
    }

    public byte getFoundPlayerStatus() {
        return this.found_player_status;
    }

    public String getFoundPlayerSessionName() {
        return this.found_player_session_name;
    }

    public byte getFoundPlayerSessionNumberOfPlayers() {
        return this.found_player_session_number_of_players;
    }

    public String getRequestedPlayerData() {
        return this.requested_player_data;
    }

    public String getRequestedPlayerNickname() {
        return this.requested_player_nickname;
    }
}
