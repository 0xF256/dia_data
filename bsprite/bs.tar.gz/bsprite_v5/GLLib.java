package defpackage;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.Random;
import javax.microedition.lcdui.Font;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import net.rim.device.api.compress.GZIPInputStream;
import net.rim.device.api.system.Alert;
import net.rim.device.api.ui.Graphics;
import net.rim.device.api.ui.container.FullScreen;

/* loaded from: GLLib.jar:GLLib.class */
public abstract class GLLib extends FullScreen implements Runnable {
    static boolean s_game_isPaused;
    static int s_game_state;
    static long s_game_timeWhenFrameStart;
    static long s_game_lastFrameTime;
    static boolean s_game_interruptNotify;
    private static boolean s_game_isInPaint;
    static GloftBBUiApp s_application;
    private long m_frameCoheranceTimer;
    private Image m_imgBackBuffer = null;
    private Graphics m_gBackBuffer = null;
    static int s_game_frameDT;
    private static long s_game_frameDTTimer;
    static int s_game_totalExecutionTime;
    static int s_game_FPSAverage;
    static int s_game_currentFrameNB;
    static GLLib s_gllib_instance;
    static byte[] s_keyState;
    static byte[] s_keyStateRT;
    static int s_keyLastKeyStates;
    static int s_game_keyEventIndex;
    static int s_game_keyJustPressed;
    static long s_game_keyPressedTime;
    static int m_keys_pressed;
    static int m_keys_released;
    static int m_keys_state;
    static int m_current_keys_state;
    static int m_current_keys_pressed;
    static int m_current_keys_released;
    private static Hashtable standardKeyTable;
    private static Hashtable gameActionKeyTable;
    static Random s_math_random;
    static int s_Math_distPointLineX;
    static int s_Math_distPointLineY;
    static int s_Math_intersectX;
    static int s_Math_intersectY;
    static final int MATH_SEGMENTINTERSECT_DONT_INTERSECT = 0;
    static final int MATH_SEGMENTINTERSECT_COLLINEAR = -1;
    static final int MATH_SEGMENTINTERSECT_DO_INTERSECT = 1;
    private static int Math_quickSortIndices_nbItemPerValue;
    private static int Math_quickSortIndices_itemNb;
    private static int[] Math_quickSortIndices_result;
    private static int[] Math_quickSortIndices_data;
    static int s_math_bezierX;
    static int s_math_bezierY;
    static int s_math_bezierZ;
    private static int[] s_math_cosTable;
    private static int[] s_math_sqrtTable;
    private static int[] s_math_aTanTable;
    static final int MATH_INTERSECT_NO_INTERSECT = 0;
    static final int MATH_INTERSECT_ONE_POINT = 2;
    static final int MATH_INTERSECT_TWO_POINTS = 4;
    private static final int ARRAY_BYTE = 0;
    private static final int ARRAY_SHORT = 1;
    private static final int ARRAY_INT = 2;
    private static String s_pack_filename;
    private static InputStream s_pack_is;
    private static int s_pack_curOffset;
    private static short s_pack_nbData;
    private static int[] s_pack_offset;
    private static short s_pack_subPack_nbOf;
    private static short[] s_pack_subPack_fat;
    private static String s_pack_subPack_filename;
    private static int s_pack_subPack_curSubPack;
    static int s_pack_lastDataReadMimeType;
    private static boolean s_pack_lastDataIsCompress;
    private static byte[] s_Pack_SkipBuffer;
    static byte[][] MIME_type;
    private static byte[][] s_pack_BinaryCache;
    private static Hashtable s_pack_HashIndex;
    private static Hashtable s_pack_HashSize;
    static byte[] m_Buffer;
    static int m_inSize;
    static long m_Range;
    static long m_Code;
    static int m_ExtraBytes;
    static byte[] m_outStream;
    static int inputIndex;
    private static short[] m_lzmaInternalData;
    static final int kNumBitModelTotalBits = 11;
    static final int kBitModelTotal = 2048;
    static final int tkNumMoveBits = 5;
    static final int LZMA_BASE_SIZE = 1846;
    static final int LZMA_LIT_SIZE = 768;
    static final int LZMA_RESULT_OK = 0;
    static final int LZMA_RESULT_DATA_ERROR = 1;
    static final int LZMA_RESULT_NOT_ENOUGH_MEM = 2;
    static final int kNumStates = 12;
    static final int kNumPosBitsMax = 4;
    static final int kNumLenToPosStates = 4;
    static final int kNumPosSlotBits = 6;
    static final int kStartPosModelIndex = 4;
    static final int kEndPosModelIndex = 14;
    static final int kNumFullDistances = 128;
    static final int kNumAlignBits = 4;
    static final int kAlignTableSize = 16;
    static final int IsMatch = 0;
    static final int IsRep = 192;
    static final int IsRepG0 = 204;
    static final int IsRepG1 = 216;
    static final int IsRepG2 = 228;
    static final int IsRep0Long = 240;
    static final int PosSlot = 432;
    static final int SpecPos = 688;
    static final int Align = 802;
    static final int LenCoder = 818;
    static final int kNumPosStatesMax = 16;
    static final int kLenNumLowBits = 3;
    static final int kLenNumLowSymbols = 8;
    static final int kLenNumMidBits = 3;
    static final int kLenNumMidSymbols = 8;
    static final int kLenNumHighBits = 8;
    static final int kLenNumHighSymbols = 256;
    static final int kMatchMinLen = 2;
    static final int LenChoice = 0;
    static final int LenChoice2 = 1;
    static final int LenLow = 2;
    static final int LenMid = 130;
    static final int LenHigh = 258;
    static final int kNumLenProbs = 514;
    static final int RepLenCoder = 1332;
    static final int Literal = 1846;
    static final int kNumMoveBits = 5;
    static final int kNumTopBits = 24;
    static final int kTopValue = 16777216;
    static final int HCENTER = 1;
    static final int VCENTER = 2;
    static final int LEFT = 4;
    static final int RIGHT = 8;
    static final int TOP = 16;
    static final int BOTTOM = 32;
    static final int SOLID = 0;
    static final int DOTTED = 1;
    static final int TRANS_NONE = 0;
    static final int TRANS_ROT90 = 5;
    static final int TRANS_ROT180 = 3;
    static final int TRANS_ROT270 = 6;
    static final int TRANS_MIRROR = 2;
    static final int TRANS_MIRROR_ROT90 = 7;
    static final int TRANS_MIRROR_ROT180 = 1;
    static final int TRANS_MIRROR_ROT270 = 4;
    private static long m_nextTimeVibrationAllowed;
    static int text_nbString;
    private static byte[] text_array;
    private static int[] text_arrayOffset;
    private static String[] text_stringCacheArray;
    private static RecordStore s_rs;
    private static byte[] s_rms_buffer;
    private static String s_rms_vendor;
    private static String s_rms_midletName;
    static final int PROFILER_MAX_EVENTS = 200;
    private static String[] s_profiler_eventNames;
    private static long[] s_profiler_eventBegins;
    private static long[] s_profiler_eventEnds;
    private static short[] s_profiler_eventDepths;
    private static short[] s_profiler_eventStack;
    private static int s_profiler_eventCount;
    private static int s_profiler_eventStackIndex;
    private static boolean s_profiler_recording;
    private static boolean s_profiler_emulator;
    private static int s_alphaRectCurrentARGB;
    private static int[] s_alphaRectARGBData;
    private static Image s_alphaRectImage;
    static boolean m_PFX_hasAlpha;
    static int m_PFX_sizeX;
    static int m_PFX_sizeY;
    static int m_PFX_windowX;
    static int m_PFX_windowY;
    static int m_PFX_windowWidth;
    static int m_PFX_windowHeight;
    static int m_PFX_timer;
    public static Graphics g = null;
    private static Graphics s_lastPaintGraphics = null;
    public static Graphics s_screenGraphics = null;
    private static int s_screenWidth = GLLibConfig.screenWidth;
    private static int s_screenHeight = GLLibConfig.screenHeight;
    private static int m_FPSLimiter = 1000 / GLLibConfig.FPSLimiter;
    static int s_keyLastKeyPressUntranslatedCode = -9999;
    static int m_last_key_pressed = -9999;
    static final int s_math_F_1 = 1 << GLLibConfig.math_fixedPointBase;
    static final int s_math_F_05 = s_math_F_1 >> 1;
    static final int Math_AngleMUL = 1 << GLLibConfig.math_angleFixedPointBase;
    static final int Math_Angle90 = Math_DegreeToFixedPointAngle(90);
    static final int Math_Angle180 = Math_DegreeToFixedPointAngle(180);
    static final int Math_Angle270 = Math_DegreeToFixedPointAngle(270);
    static final int Math_Angle360 = Math_DegreeToFixedPointAngle(360);
    static final int Math_FixedPoint_PI = 1686629713 >> (29 - GLLibConfig.math_fixedPointBase);
    static final int Math_FixedPoint_E = 1459366444 >> (29 - GLLibConfig.math_fixedPointBase);
    private static final int ratioRadiansToDegrees = Math_FixedPoint_Divide(180 << GLLibConfig.math_fixedPointBase, Math_FixedPoint_PI);
    private static final int ratioDegreesToAngleFixedPoint = Math_FixedPoint_Divide(1 << GLLibConfig.math_angleFixedPointBase, 360);
    static int[][] s_Math_intersectPoints = new int[2][2];
    private static int Stream_readOffset = 0;
    static String text_encoding = "UTF-8";
    private static String StrEN = "EN";
    private static String StrDE = "DE";
    private static String StrFR = "FR";
    private static String StrIT = "IT";
    private static String StrES = "ES";
    private static String StrBR = "BR";
    private static String StrPT = "PT";
    private static String StrJP = "JP";
    private static String StrCN = "CN";
    private static String StrKR = "KR";
    private static String StrRU = "RU";
    private static String StrTR = "TR";
    private static String StrPL = "PL";
    private static String StrCZ = "CZ";
    private static String StrNL = "NL";
    static boolean m_PFX_initializd = false;
    static int m_PFX_type = 0;
    static int[][] m_PFX_params = (int[][]) null;
    static Image m_PFX_screenBuffer = null;
    static Graphics m_PFX_screenBufferG = null;
    static int m_PFX_enableScreenBuffer = 0;
    static int m_PFX_enableScreenBufferThisFrame = 0;
    static boolean m_PFX_screenIsBuffered = false;

    abstract void Game_update() throws Throwable;

    abstract void BlackBerry_Init();

    public void Game_Run() throws Throwable {
    }

    public GLLib(Object application, Object display) {
        BlackBerry_Init();
        s_gllib_instance = this;
        s_game_state = -1;
        s_game_isInPaint = true;
        s_application = (GloftBBUiApp) application;
        SetupDisplay();
        SetupDefaultKey();
        s_game_frameDTTimer = System.currentTimeMillis();
        this.m_frameCoheranceTimer = s_game_frameDTTimer;
    }

    protected void Init() {
        if (s_game_state >= 0) {
            return;
        }
        s_screenWidth = GLLibConfig.screenWidth;
        s_screenHeight = GLLibConfig.screenHeight;
        if (GLLibConfig.useKeyAccumulation) {
            s_keyState = new byte[20];
            s_keyStateRT = new byte[20];
        }
        if (GLLibConfig.useSoftwareDoubleBuffer) {
            this.m_imgBackBuffer = Image.createImage(getWidth(), getHeight());
            this.m_gBackBuffer = this.m_imgBackBuffer.getGraphics();
        }
        Math_RandSetSeed(System.currentTimeMillis());
        s_game_state = 0;
        s_application.invokeLater(this);
    }

    protected Image GetSoftwareDoubleBuffer() {
        if (GLLibConfig.useSoftwareDoubleBuffer) {
            return this.m_imgBackBuffer;
        }
        return null;
    }

    protected Graphics GetSoftwareDoubleBufferGraphics() {
        if (GLLibConfig.useSoftwareDoubleBuffer) {
            return this.m_gBackBuffer;
        }
        return null;
    }

    protected void UnInit() {
        if (GLLibConfig.useKeyAccumulation) {
            s_keyState = null;
            s_keyStateRT = null;
        }
        if (GLLibConfig.useSoftwareDoubleBuffer) {
            this.m_imgBackBuffer = null;
            this.m_gBackBuffer = null;
        }
        MIME_type = (byte[][]) null;
        Gc();
    }

    protected void Pause() {
        s_game_isPaused = true;
        if (GLLibConfig.sound_useStopSoundsOnInterrupt) {
            try {
                GLLibPlayer.Snd_StopAllSounds();
                GLLibPlayer.Snd_ForceExecOnThreadOnGamePause();
            } catch (Throwable th) {
            }
        }
    }

    protected void Resume() {
        if (s_game_isPaused) {
            long time = System.currentTimeMillis();
            s_game_timeWhenFrameStart = time;
            s_game_frameDTTimer = time;
            this.m_frameCoheranceTimer = time;
            s_game_isPaused = false;
            SetupDisplay();
            s_game_interruptNotify = true;
            repaint();
            ResetKey();
        }
    }

    public void hideNotify() {
        Pause();
    }

    public void showNotify() {
        Resume();
    }

    public void sizeChanged(int w, int h) {
        s_screenWidth = w;
        s_screenHeight = h;
    }

    protected void SetupDisplay() {
    }

    protected static void SetupDefaultKey() {
        Game_KeyClearKeyCode();
        standardKeyTable.put(new Integer(BBKey.NUM0), new Integer(6));
        standardKeyTable.put(new Integer(BBKey.NUM1), new Integer(7));
        standardKeyTable.put(new Integer(BBKey.NUM2), new Integer(8));
        standardKeyTable.put(new Integer(BBKey.NUM3), new Integer(9));
        standardKeyTable.put(new Integer(BBKey.NUM4), new Integer(10));
        standardKeyTable.put(new Integer(BBKey.NUM5), new Integer(11));
        standardKeyTable.put(new Integer(BBKey.NUM6), new Integer(12));
        standardKeyTable.put(new Integer(BBKey.NUM7), new Integer(13));
        standardKeyTable.put(new Integer(BBKey.NUM8), new Integer(14));
        standardKeyTable.put(new Integer(BBKey.NUM9), new Integer(15));
        standardKeyTable.put(new Integer(BBKey.POUND), new Integer(17));
        standardKeyTable.put(new Integer(BBKey.STAR), new Integer(16));
        if (GLLibConfig.softkeyOKOnLeft) {
            standardKeyTable.put(new Integer(GLLibConfig.keycodeLeftSoftkey), new Integer(18));
            standardKeyTable.put(new Integer(GLLibConfig.keycodeRightSoftkey), new Integer(19));
        } else {
            standardKeyTable.put(new Integer(GLLibConfig.keycodeLeftSoftkey), new Integer(19));
            standardKeyTable.put(new Integer(GLLibConfig.keycodeRightSoftkey), new Integer(18));
        }
        gameActionKeyTable.put(new Integer(BBKey.FIRE), new Integer(5));
        gameActionKeyTable.put(new Integer(BBKey.UP), new Integer(1));
        gameActionKeyTable.put(new Integer(BBKey.DOWN), new Integer(2));
        gameActionKeyTable.put(new Integer(BBKey.LEFT), new Integer(3));
        gameActionKeyTable.put(new Integer(BBKey.RIGHT), new Integer(4));
    }

    protected void Quit() {
        s_game_state = -1;
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            if (!GLLibConfig.useCallSerially) {
                SetupDisplay();
            }
            s_game_isInPaint = false;
            if (s_game_state >= 0) {
                if (!s_game_isPaused) {
                    repaint();
                    Game_Run();
                    long curTime = System.currentTimeMillis();
                    this.m_frameCoheranceTimer = Math.min(this.m_frameCoheranceTimer, curTime);
                    if (GLLibConfig.useSleepInsteadOfYield) {
                        try {
                            Thread.sleep(Math.max(1L, m_FPSLimiter - (curTime - this.m_frameCoheranceTimer)));
                        } catch (Throwable th) {
                        }
                    } else {
                        while (curTime - this.m_frameCoheranceTimer < m_FPSLimiter) {
                            Thread.yield();
                            curTime = System.currentTimeMillis();
                            this.m_frameCoheranceTimer = Math.min(this.m_frameCoheranceTimer, curTime);
                        }
                    }
                    this.m_frameCoheranceTimer = System.currentTimeMillis();
                } else {
                    this.m_frameCoheranceTimer = Math.min(this.m_frameCoheranceTimer, System.currentTimeMillis());
                    if (GLLibConfig.useSleepInsteadOfYield) {
                        try {
                            Thread.sleep(1L);
                        } catch (Throwable th2) {
                        }
                    } else {
                        Thread.yield();
                    }
                }
                s_application.invokeLater(this);
                return;
            }
        } catch (Throwable th3) {
            s_game_state = -1;
        }
        UnInit();
        s_application.destroyApp(true);
    }

    public void paint(Graphics rimGraphics) {
        Game_Paint(rimGraphics);
    }

    protected void repaint() {
        paint(getGraphics());
        updateDisplay();
    }

    private void Game_Paint(Graphics rimGraphics) {
        Graphics _g = new Graphics(rimGraphics);
        s_screenGraphics = _g;
        if (GLLibConfig.useFakeInterruptHandling) {
            long elapsedTime = System.currentTimeMillis() - s_game_lastFrameTime;
            s_game_lastFrameTime = System.currentTimeMillis();
            if (elapsedTime > GLLibConfig.FakeInterruptThreshold && s_game_lastFrameTime != 0) {
                Pause();
                Resume();
            }
        }
        if (s_game_isPaused || s_game_isInPaint) {
            _g.popContext();
            return;
        }
        s_game_isInPaint = true;
        UpdateKeypad();
        s_game_timeWhenFrameStart = System.currentTimeMillis();
        if (GLLibConfig.useFrameDT) {
            s_game_frameDT = (int) (s_game_timeWhenFrameStart - s_game_frameDTTimer);
            if (s_game_frameDT < 0) {
                s_game_frameDT = 0;
            }
            if (s_game_frameDT > 1000) {
                s_game_frameDT = 1000;
            }
            s_game_frameDTTimer = s_game_timeWhenFrameStart;
            s_game_totalExecutionTime += s_game_frameDT;
            s_game_FPSAverage = (100000 * s_game_currentFrameNB) / (s_game_totalExecutionTime + 1);
        }
        s_game_currentFrameNB++;
        try {
            if (GLLibConfig.useSoftwareDoubleBuffer) {
                Graphics graphics = this.m_gBackBuffer;
                s_lastPaintGraphics = graphics;
                g = graphics;
                Game_update();
                _g.drawImage(this.m_imgBackBuffer, 0, 0, 20);
            } else {
                if (GLLibConfig.pfx_useScreenBuffer && PFX_NeedScreenBufferThisFrame()) {
                    Graphics graphics2 = m_PFX_screenBufferG;
                    s_lastPaintGraphics = graphics2;
                    g = graphics2;
                } else {
                    s_lastPaintGraphics = _g;
                    g = _g;
                }
                Game_update();
                if (GLLibConfig.pfx_useScreenBuffer && m_PFX_initializd) {
                    boolean skipPaint = false;
                    if (GLLibConfig.pfx_useEffectFullScreenBlend) {
                        if (m_PFX_params[1][4] != 0) {
                            skipPaint = true;
                        }
                        m_PFX_params[1][4] = 0;
                    }
                    if (PFX_NeedScreenBufferThisFrame()) {
                        if (!skipPaint) {
                            _g.drawImage(m_PFX_screenBuffer, 0, 0, 20);
                        }
                        m_PFX_enableScreenBufferThisFrame = 0;
                    }
                }
            }
            _g.popContext();
        } catch (Throwable th) {
            s_game_state = -1;
        }
        s_game_interruptNotify = false;
        s_game_isInPaint = false;
        s_screenGraphics = null;
    }

    public static final Graphics GetScreenGraphics() {
        return s_screenGraphics;
    }

    public boolean keyDown(int keyCode, int time) {
        keyPressed(keyCode);
        return true;
    }

    public boolean keyUp(int keyCode, int time) {
        keyReleased(keyCode);
        return true;
    }

    public boolean trackwheelClick(int status, int time) {
        keyPressed(BBKey.NUM5);
        return true;
    }

    public boolean trackwheelUnclick(int status, int time) {
        keyReleased(BBKey.NUM5);
        return true;
    }

    public boolean navigationMovement(int dx, int dy, int status, int time) {
        if (dx < 0) {
            if (dy < 0) {
                keyPressed(BBKey.NUM1);
                keyReleased(BBKey.NUM1);
                return true;
            }
            if (dy > 0) {
                keyPressed(BBKey.NUM7);
                keyReleased(BBKey.NUM7);
                return true;
            }
            keyPressed(BBKey.LEFT);
            keyReleased(BBKey.LEFT);
            return true;
        }
        if (dx > 0) {
            if (dy < 0) {
                keyPressed(BBKey.NUM3);
                keyReleased(BBKey.NUM3);
                return true;
            }
            if (dy > 0) {
                keyPressed(BBKey.NUM9);
                keyReleased(BBKey.NUM9);
                return true;
            }
            keyPressed(BBKey.RIGHT);
            keyReleased(BBKey.RIGHT);
            return true;
        }
        if (dy < 0) {
            keyPressed(BBKey.UP);
            keyReleased(BBKey.UP);
            return true;
        }
        if (dy > 0) {
            keyPressed(BBKey.DOWN);
            keyReleased(BBKey.DOWN);
            return true;
        }
        return true;
    }

    protected void keyPressed(int keyCode) {
        if (GLLibConfig.useKeyAccumulation) {
            s_keyLastKeyPressUntranslatedCode = keyCode;
            byte i = Game_TranslateKeyCode(keyCode);
            if (s_keyStateRT[i] > 0) {
                return;
            }
            if (s_keyStateRT[i] < 0) {
                s_keyStateRT[i] = 0;
            }
            if (s_keyStateRT[i] < 126) {
                byte[] bArr = s_keyStateRT;
                bArr[i] = (byte) (bArr[i] + 1);
                return;
            }
            return;
        }
        if (GLLibConfig.useBugFixMultipleKeyPressed) {
            if (m_last_key_pressed != keyCode && m_last_key_pressed != -9999) {
                keyReleased(m_last_key_pressed);
            }
            m_last_key_pressed = keyCode;
        }
        int keyFlag = 1 << Game_TranslateKeyCode(keyCode);
        m_current_keys_pressed |= keyFlag;
        m_current_keys_state |= keyFlag;
    }

    protected void keyReleased(int keyCode) {
        if (GLLibConfig.useKeyAccumulation) {
            byte i = Game_TranslateKeyCode(keyCode);
            if (s_keyStateRT[i] > 0) {
                byte[] bArr = s_keyStateRT;
                bArr[i] = (byte) (bArr[i] * (-1));
                return;
            }
            return;
        }
        if (GLLibConfig.useBugFixMultipleKeyPressed && keyCode == m_last_key_pressed) {
            m_last_key_pressed = -9999;
        }
        int keyFlag = 1 << Game_TranslateKeyCode(keyCode);
        m_current_keys_released |= keyFlag;
        m_current_keys_state &= keyFlag ^ (-1);
    }

    private void UpdateKeypad() {
        if (GLLibConfig.useKeyAccumulation) {
            s_game_keyEventIndex = -1;
            s_game_keyJustPressed = -1;
            for (int i = 0; i < 20; i++) {
                s_keyState[i] = s_keyStateRT[i];
                if (s_keyStateRT[i] != 0) {
                    s_game_keyEventIndex = i;
                    if (s_keyStateRT[i] < 0) {
                        s_keyStateRT[i] = 0;
                    } else if (s_keyStateRT[i] < 126) {
                        if (s_keyStateRT[i] == 1) {
                            s_game_keyJustPressed = i;
                            s_game_keyPressedTime = s_game_timeWhenFrameStart;
                        }
                        byte[] bArr = s_keyStateRT;
                        int i2 = i;
                        bArr[i2] = (byte) (bArr[i2] + 1);
                        if (i >= 18) {
                            byte[] bArr2 = s_keyStateRT;
                            int i3 = i;
                            bArr2[i3] = (byte) (bArr2[i3] * (-1));
                        }
                    }
                }
            }
            return;
        }
        m_keys_pressed = m_current_keys_pressed;
        m_keys_released = m_current_keys_released;
        m_keys_state = m_current_keys_state;
        m_current_keys_pressed = 0;
        m_current_keys_released = 0;
        s_game_keyPressedTime = s_game_timeWhenFrameStart;
    }

    public static void Game_KeyClearKeyCode() {
        gameActionKeyTable = new Hashtable();
        standardKeyTable = new Hashtable();
    }

    public static void Game_KeySetKeyCode(boolean gameAction, int keyCode, int key) {
        Hashtable hashtable;
        Integer ikey = new Integer(keyCode);
        if (gameAction) {
            hashtable = gameActionKeyTable;
        } else {
            hashtable = standardKeyTable;
        }
        Integer oldAssignation = (Integer) hashtable.get(ikey);
        if (oldAssignation != null) {
            hashtable.remove(ikey);
        }
        hashtable.put(ikey, new Integer(key));
    }

    private byte Game_TranslateKeyCode(int keyCode) {
        if (GLLibConfig.useAbsoluteValueOfKeyCode && keyCode < 0) {
            keyCode *= -1;
        }
        Integer key = new Integer(keyCode);
        Integer code = (Integer) standardKeyTable.get(key);
        if (code != null) {
            return code.byteValue();
        }
        Integer code2 = (Integer) gameActionKeyTable.get(key);
        if (code2 != null) {
            return code2.byteValue();
        }
        return (byte) 0;
    }

    public static void ResetKey() {
        if (GLLibConfig.useKeyAccumulation) {
            if (s_keyState != null && s_keyStateRT != null) {
                for (int i = 0; i < 20; i++) {
                    s_keyState[i] = 0;
                    s_keyStateRT[i] = 0;
                }
                return;
            }
            return;
        }
        m_keys_pressed = 0;
        m_keys_released = 0;
        m_keys_state = 0;
        m_current_keys_state = 0;
        m_current_keys_pressed = 0;
        m_current_keys_released = 0;
    }

    public static void ResetAKey(int keyFlag) {
        if (GLLibConfig.useKeyAccumulation) {
            s_keyState[keyFlag] = 0;
            s_keyStateRT[keyFlag] = 0;
        } else if ((m_keys_state & (1 << keyFlag)) != 0) {
            m_keys_pressed = 0;
            m_keys_released = 0;
            m_keys_state = 0;
            m_current_keys_state = 0;
            m_current_keys_pressed = 0;
            m_current_keys_released = 0;
        }
    }

    public static int IsAnyKeyDown() {
        if (GLLibConfig.useKeyAccumulation) {
            for (int i = 0; i < 20; i++) {
                if (s_keyState[i] > 0) {
                    return i;
                }
            }
            return -1;
        }
        for (int i2 = 0; i2 < 20; i2++) {
            if ((m_keys_state & (1 << i2)) != 0) {
                return i2;
            }
        }
        return -1;
    }

    public static boolean IsKeyDown(int keyFlag) {
        return GLLibConfig.useKeyAccumulation ? s_keyState[keyFlag] > 0 : (m_keys_state & (1 << keyFlag)) != 0;
    }

    public static boolean IsKeyUp(int keyFlag) {
        return GLLibConfig.useKeyAccumulation ? s_keyState[keyFlag] <= 0 : (m_keys_state & (1 << keyFlag)) == 0;
    }

    public static int WasAnyKeyPressed() {
        if (GLLibConfig.useKeyAccumulation) {
            for (int i = 0; i < 20; i++) {
                if (s_keyState[i] == 1) {
                    return i;
                }
            }
            return -1;
        }
        if (m_keys_pressed == 0) {
            return -1;
        }
        for (int i2 = 0; i2 < 20; i2++) {
            if ((m_keys_pressed & (1 << i2)) != 0) {
                return i2;
            }
        }
        return -1;
    }

    public static int WasAnyKeyReleased() {
        if (GLLibConfig.useKeyAccumulation) {
            for (int i = 0; i < 20; i++) {
                if (s_keyState[i] < 0) {
                    return i;
                }
            }
            return -1;
        }
        if (m_keys_released == 0) {
            return -1;
        }
        for (int i2 = 0; i2 < 20; i2++) {
            if ((m_keys_released & (1 << i2)) != 0) {
                return i2;
            }
        }
        return -1;
    }

    public static boolean WasKeyPressed(int keyFlag) {
        return GLLibConfig.useKeyAccumulation ? s_keyState[keyFlag] == 1 : (m_keys_pressed & (1 << keyFlag)) != 0;
    }

    public static boolean WasKeyReleased(int keyFlag) {
        return GLLibConfig.useKeyAccumulation ? s_keyState[keyFlag] < 0 : (m_keys_released & (1 << keyFlag)) != 0;
    }

    static void Dbg(String log) {
    }

    static void Assert(boolean test, String errMessage) {
    }

    static void Warning(String message) {
    }

    static void Print(String log) {
    }

    static void Math_Init(String packName, int cos, int sqrt) throws Throwable {
        Pack_Open(packName);
        if (cos >= 0) {
            s_math_cosTable = (int[]) Pack_ReadArray(cos);
        } else {
            s_math_cosTable = null;
        }
        if (sqrt >= 0) {
            s_math_sqrtTable = (int[]) Pack_ReadArray(sqrt);
        } else {
            s_math_sqrtTable = null;
        }
        Pack_Close();
    }

    static void Math_Quit() {
        s_math_cosTable = null;
        s_math_sqrtTable = null;
        s_math_random = null;
        s_math_aTanTable = null;
    }

    static int Math_FixedPointAdjust(int a) {
        if (GLLibConfig.math_fixedPointBase > GLLibConfig.math_angleFixedPointBase) {
            return a << (GLLibConfig.math_fixedPointBase - GLLibConfig.math_angleFixedPointBase);
        }
        if (GLLibConfig.math_fixedPointBase < GLLibConfig.math_angleFixedPointBase) {
            return a >> (GLLibConfig.math_angleFixedPointBase - GLLibConfig.math_fixedPointBase);
        }
        return a;
    }

    static int Math_IntToFixedPoint(int a) {
        return a << GLLibConfig.math_fixedPointBase;
    }

    static int Math_FixedPointToInt(int a) {
        return (a + (s_math_F_1 >> 1)) >> GLLibConfig.math_fixedPointBase;
    }

    static int Math_Div10(int a) {
        return (a * 6554) >> (16 - GLLibConfig.math_fixedPointBase);
    }

    static int Math_Log2(int a) {
        int r = 0;
        while ((a >> r) > 1) {
            r++;
        }
        return r;
    }

    static boolean Math_SameSign(int a, int b) {
        return (a ^ b) >= 0;
    }

    static int Math_Det(int x1, int y1, int x2, int y2) {
        return (x1 * y2) - (y1 * x2);
    }

    static int Math_DotProduct(int x1, int y1, int x2, int y2) {
        return (x1 * x2) + (y1 * y2);
    }

    static int Math_NormPow(int x1, int y1) {
        return (x1 * x1) + (y1 * y1);
    }

    static int Math_Norm(int x, int y, int iter) {
        int R = (x * x) + (y * y);
        int x_0 = 1;
        for (int i = 0; i < iter; i++) {
            x_0 = (x_0 + (R / x_0)) >> 1;
        }
        return x_0;
    }

    static final void Math_RandSetSeed(long seed) {
        if (s_math_random == null) {
            s_math_random = new Random(seed);
        } else {
            s_math_random.setSeed(seed);
        }
    }

    static int Math_Rand(int a, int b) {
        if (b != a) {
            int rnd = s_math_random.nextInt();
            if (rnd < 0) {
                rnd *= -1;
            }
            return a + (rnd % (b - a));
        }
        return b;
    }

    static final int Math_Rand() {
        return s_math_random.nextInt();
    }

    static int Math_DegreeToFixedPointAngle(int a) {
        return (a * Math_AngleMUL) / 360;
    }

    static int Math_FixedPointAngleToDegree(int a) {
        return (a * 360) >> GLLibConfig.math_angleFixedPointBase;
    }

    static int Math_Sin(int a) {
        return Math_Cos(Math_Angle90 - a);
    }

    static int Math_Cos(int angle) {
        if (angle < 0) {
            angle *= -1;
        }
        int angle2 = angle & (Math_Angle360 - 1);
        if (angle2 <= Math_Angle90) {
            return s_math_cosTable[angle2];
        }
        if (angle2 < Math_Angle180) {
            return -s_math_cosTable[Math_Angle180 - angle2];
        }
        if (angle2 <= Math_Angle270) {
            return -s_math_cosTable[angle2 - Math_Angle180];
        }
        return s_math_cosTable[Math_Angle360 - angle2];
    }

    static int Math_Tan(int angle) {
        int tan = Math_Cos(angle);
        if (tan == 0) {
            return Integer.MAX_VALUE;
        }
        return Math_IntToFixedPoint(Math_Sin(angle)) / tan;
    }

    private static int Math_AtanSlow(int st, int end, int tang) {
        for (int i = st; i < end; i++) {
            if (Math_Tan(i) <= tang && tang < Math_Tan(i + 1)) {
                return i;
            }
        }
        if (st == Math_Angle90 || end == Math_Angle90) {
            return Math_Angle90;
        }
        if (st == Math_Angle270 || end == Math_Angle270) {
            return Math_Angle270;
        }
        return 0;
    }

    static int Math_AtanSlow(int dx, int dy) {
        if (dx > 0) {
            if (dy > 0) {
                return Math_AtanSlow(0, Math_Angle90, (dy * s_math_F_1) / dx);
            }
            if (dy == 0) {
                return 0;
            }
            return Math_AtanSlow(Math_Angle270, Math_Angle360, (dy * s_math_F_1) / dx);
        }
        if (dx == 0) {
            if (dy > 0) {
                return Math_Angle90;
            }
            if (dy == 0) {
                return 0;
            }
            return Math_Angle270;
        }
        if (dy > 0) {
            return Math_AtanSlow(Math_Angle90, Math_Angle180, (dy * s_math_F_1) / dx);
        }
        if (dy == 0) {
            return Math_Angle180;
        }
        return Math_AtanSlow(Math_Angle180, Math_Angle270, (dy * s_math_F_1) / dx);
    }

    static int Math_Atan(int dx, int dy) {
        if (GLLibConfig.math_AtanUseCacheTable) {
            if (s_math_aTanTable == null) {
                s_math_aTanTable = new int[s_math_F_1 + 1];
                for (int i = 0; i < s_math_F_1 + 1; i++) {
                    s_math_aTanTable[i] = Math_AtanSlow(s_math_F_1, i);
                }
            }
            if (dx == 0) {
                if (dy > 0) {
                    return Math_Angle90;
                }
                if (dy == 0) {
                    return 0;
                }
                return Math_Angle270;
            }
            if (dx > 0) {
                if (dy >= 0) {
                    if (dx >= dy) {
                        int idx = (dy * s_math_F_1) / dx;
                        return s_math_aTanTable[idx];
                    }
                    int idx2 = (dx * s_math_F_1) / dy;
                    return Math_Angle90 - s_math_aTanTable[idx2];
                }
                int dy2 = dy * (-1);
                if (dx >= dy2) {
                    int idx3 = (dy2 * s_math_F_1) / dx;
                    return Math_Angle360 - s_math_aTanTable[idx3];
                }
                int idx4 = (dx * s_math_F_1) / dy2;
                return Math_Angle270 + s_math_aTanTable[idx4];
            }
            int dx2 = dx * (-1);
            if (dy >= 0) {
                if (dx2 >= dy) {
                    int idx5 = (dy * s_math_F_1) / dx2;
                    return Math_Angle180 - s_math_aTanTable[idx5];
                }
                int idx6 = (dx2 * s_math_F_1) / dy;
                return Math_Angle90 + s_math_aTanTable[idx6];
            }
            int dy3 = dy * (-1);
            if (dx2 >= dy3) {
                int idx7 = (dy3 * s_math_F_1) / dx2;
                return Math_Angle180 + s_math_aTanTable[idx7];
            }
            int idx8 = (dx2 * s_math_F_1) / dy3;
            return Math_Angle270 - s_math_aTanTable[idx8];
        }
        return Math_AtanSlow(dx, dy);
    }

    static int Math_Sqrt(int x) {
        if (x >= 65536) {
            if (x >= kTopValue) {
                if (x >= 268435456) {
                    if (x >= 1073741824) {
                        return s_math_sqrtTable[x >> 24] << 8;
                    }
                    return s_math_sqrtTable[x >> 22] << 7;
                }
                if (x >= 67108864) {
                    return s_math_sqrtTable[x >> 20] << 6;
                }
                return s_math_sqrtTable[x >> 18] << 5;
            }
            if (x >= 1048576) {
                if (x >= 4194304) {
                    return s_math_sqrtTable[x >> 16] << 4;
                }
                return s_math_sqrtTable[x >> 14] << 3;
            }
            if (x >= 262144) {
                return s_math_sqrtTable[x >> 12] << 2;
            }
            return s_math_sqrtTable[x >> 10] << 1;
        }
        if (x >= kLenNumHighSymbols) {
            if (x >= 4096) {
                if (x >= 16384) {
                    return s_math_sqrtTable[x >> 8];
                }
                return s_math_sqrtTable[x >> 6] >> 1;
            }
            if (x >= 1024) {
                return s_math_sqrtTable[x >> 4] >> 2;
            }
            return s_math_sqrtTable[x >> 2] >> 3;
        }
        if (x >= 0) {
            return s_math_sqrtTable[x] >> 4;
        }
        return 0;
    }

    static int Math_Sqrt(long val) {
        long j;
        long g2 = 0;
        long b = 32768;
        long bshft = 15;
        do {
            long j2 = (g2 << 1) + b;
            bshft--;
            long temp = j2 << ((int) j2);
            if (val >= temp) {
                g2 += b;
                val -= temp;
            }
            j = b >> 1;
            b = j;
        } while (j > 0);
        return (int) g2;
    }

    static int Math_Sqrt_FixedPoint(int val, int precisionLoop) {
        int r = val;
        int q = 0;
        for (int b = 1073741824 >> (16 - GLLibConfig.math_fixedPointBase); b >= kLenNumHighSymbols; b >>= 1) {
            int i = precisionLoop;
            precisionLoop = i - 1;
            if (i <= 0) {
                break;
            }
            int t = q + b;
            if (r >= t) {
                r -= t;
                q = t + b;
            }
            r <<= 1;
        }
        return q >> 8;
    }

    static boolean Math_RectIntersect(int Ax0, int Ay0, int Ax1, int Ay1, int Bx0, int By0, int Bx1, int By1) {
        return Ax1 >= Bx0 && Ax0 <= Bx1 && Ay1 >= By0 && Ay0 <= By1;
    }

    static int Math_SegmentIntersect(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4) {
        int x1hi;
        int x1lo;
        int y1hi;
        int y1lo;
        int Ax = x2 - x1;
        int Bx = x3 - x4;
        if (Ax < 0) {
            x1lo = x2;
            x1hi = x1;
        } else {
            x1hi = x2;
            x1lo = x1;
        }
        if (Bx > 0) {
            if (x1hi < x4 || x3 < x1lo) {
                return 0;
            }
        } else if (x1hi < x3 || x4 < x1lo) {
            return 0;
        }
        int Ay = y2 - y1;
        int By = y3 - y4;
        if (Ay < 0) {
            y1lo = y2;
            y1hi = y1;
        } else {
            y1hi = y2;
            y1lo = y1;
        }
        if (By > 0) {
            if (y1hi < y4 || y3 < y1lo) {
                return 0;
            }
        } else if (y1hi < y3 || y4 < y1lo) {
            return 0;
        }
        int Cx = x1 - x3;
        int Cy = y1 - y3;
        int d = (By * Cx) - (Bx * Cy);
        int f = (Ay * Bx) - (Ax * By);
        if (f > 0) {
            if (d < 0 || d > f) {
                return 0;
            }
        } else if (d > 0 || d < f) {
            return 0;
        }
        int e = (Ax * Cy) - (Ay * Cx);
        if (f > 0) {
            if (e < 0 || e > f) {
                return 0;
            }
        } else if (e > 0 || e < f) {
            return 0;
        }
        if (f == 0) {
            return -1;
        }
        int num = d * Ax;
        int offset = Math_SameSign(num, f) ? f >> 1 : (-f) >> 1;
        s_Math_intersectX = x1 + ((num + offset) / f);
        int num2 = d * Ay;
        int offset2 = Math_SameSign(num2, f) ? f >> 1 : (-f) >> 1;
        s_Math_intersectY = y1 + ((num2 + offset2) / f);
        return 1;
    }

    static int Math_DistPointLine(int x0, int y0, int x1, int y1, int x2, int y2) {
        int v0x = x1 - x0;
        int v0y = y1 - y0;
        int angle0 = Math_Atan(v0x, v0y);
        int v1x = x2 - x0;
        int v1y = y2 - y0;
        int l1 = Math_Sqrt(Math_NormPow(v1x, v1y));
        int angle1 = Math_Atan(v1x, v1y);
        int angle01 = Math.abs(angle0 - angle1);
        int dopp = l1 * Math_Sin(angle01);
        int dadj = l1 * Math_Cos(angle01);
        s_Math_distPointLineX = Math_FixedPoint_Add(Math_IntToFixedPoint(x0), Math_FixedPoint_Multiply(dadj, Math_Cos(angle0)));
        s_Math_distPointLineY = Math_FixedPoint_Add(Math_IntToFixedPoint(y0), Math_FixedPoint_Multiply(dadj, Math_Sin(angle0)));
        return dopp;
    }

    static void Math_QuickSort(int[] array) {
        Math_Q_Sort(array, 0, array.length - 1);
    }

    private static void Math_Q_Sort(int[] array, int left, int right) {
        int pivot = array[left];
        while (left < right) {
            while (array[right] >= pivot && left < right) {
                right--;
            }
            if (left != right) {
                array[left] = array[right];
                left++;
            }
            while (array[left] <= pivot && left < right) {
                left++;
            }
            if (left != right) {
                array[right] = array[left];
                right--;
            }
        }
        array[left] = pivot;
        int pivot2 = left;
        if (left < pivot2) {
            Math_Q_Sort(array, left, pivot2 - 1);
        }
        if (right > pivot2) {
            Math_Q_Sort(array, pivot2 + 1, right);
        }
    }

    static int[] Math_QuickSortIndices(int[] data) {
        return Math_QuickSortIndices(data, 1, 0);
    }

    static int[] Math_QuickSortIndices(int[] data, int nbItemPerValue, int itemNb) {
        Math_quickSortIndices_nbItemPerValue = nbItemPerValue;
        Math_quickSortIndices_itemNb = itemNb;
        Math_quickSortIndices_data = data;
        int size = Math_quickSortIndices_data.length / Math_quickSortIndices_nbItemPerValue;
        if (Math_quickSortIndices_result != null && Math_quickSortIndices_result.length != size) {
            Math_quickSortIndices_result = null;
            Gc();
        }
        if (Math_quickSortIndices_result == null) {
            Math_quickSortIndices_result = new int[size];
        }
        for (int i = 0; i < size; i++) {
            Math_quickSortIndices_result[i] = i;
        }
        Math_QuickSortIndices(0, size - 1);
        return Math_quickSortIndices_result;
    }

    private static void Math_QuickSortIndices(int left, int right) {
        int pivot_i = Math_quickSortIndices_result[left];
        int pivot = Math_quickSortIndices_data[(pivot_i * Math_quickSortIndices_nbItemPerValue) + Math_quickSortIndices_itemNb];
        while (left < right) {
            while (Math_quickSortIndices_data[(Math_quickSortIndices_result[right] * Math_quickSortIndices_nbItemPerValue) + Math_quickSortIndices_itemNb] >= pivot && left < right) {
                right--;
            }
            if (left != right) {
                Math_quickSortIndices_result[left] = Math_quickSortIndices_result[right];
                left++;
            }
            while (Math_quickSortIndices_data[(Math_quickSortIndices_result[left] * Math_quickSortIndices_nbItemPerValue) + Math_quickSortIndices_itemNb] <= pivot && left < right) {
                left++;
            }
            if (left != right) {
                Math_quickSortIndices_result[right] = Math_quickSortIndices_result[left];
                right--;
            }
        }
        Math_quickSortIndices_result[left] = pivot_i;
        int pivot2 = left;
        if (left < pivot2) {
            Math_QuickSortIndices(left, pivot2 - 1);
        }
        if (right > pivot2) {
            Math_QuickSortIndices(pivot2 + 1, right);
        }
    }

    private static int Math_BezierUtility(int v1, int v2, int v3, int mum1, int mum12, int mu2) {
        return (((v1 * mum12) + ((2 * v2) * mum1)) + (v3 * mu2)) / (1 << (GLLibConfig.math_fixedPointBase * 2));
    }

    static void Math_Bezier2D(int x1, int y1, int x2, int y2, int x3, int y3, int interp) {
        int mu2 = interp * interp;
        int mum1 = s_math_F_1 - interp;
        int mum12 = mum1 * mum1;
        int mum13 = mum1 * interp;
        s_math_bezierX = Math_BezierUtility(x1, x2, x3, mum13, mum12, mu2);
        s_math_bezierY = Math_BezierUtility(y1, y2, y3, mum13, mum12, mu2);
    }

    static void Math_Bezier3D(int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int interp) {
        int mu2 = interp * interp;
        int mum1 = s_math_F_1 - interp;
        int mum12 = mum1 * mum1;
        int mum13 = mum1 * interp;
        s_math_bezierX = Math_BezierUtility(x1, x2, x3, mum13, mum12, mu2);
        s_math_bezierY = Math_BezierUtility(y1, y2, y3, mum13, mum12, mu2);
        s_math_bezierZ = Math_BezierUtility(z1, z2, z3, mum13, mum12, mu2);
    }

    static int Math_FixedPoint_Add(int summand1, int summand2) {
        long result = summand1 + summand2;
        return (int) result;
    }

    static int Math_FixedPoint_Subtract(int minuend, int subtrahend) {
        long result = minuend - subtrahend;
        return (int) result;
    }

    static int Math_FixedPoint_Multiply(int multiplicand, int multiplier) {
        long result = ((multiplicand * multiplier) + (s_math_F_1 >> 1)) >> GLLibConfig.math_fixedPointBase;
        return (int) result;
    }

    static int Math_FixedPoint_Divide(int dividend, int divisor) {
        return ((int) ((((dividend << GLLibConfig.math_fixedPointBase) << 1) / divisor) + 1)) >> 1;
    }

    static int Math_FixedPoint_Square(int value) {
        return Math_FixedPoint_Multiply(value, value);
    }

    static int Math_FixedPoint_Round(int value) {
        return ((value + (s_math_F_1 >> 1)) >> GLLibConfig.math_fixedPointBase) << GLLibConfig.math_fixedPointBase;
    }

    static int Math_FixedPoint_Sqrt(int value) {
        if (value == 0 || value == s_math_F_1) {
            return value;
        }
        int adj = (GLLibConfig.math_fixedPointBase & 1) == 0 ? 0 : 1;
        long r = value;
        long q = 0;
        for (long b = 1 << (30 - adj); b >= 256; b >>= 1) {
            long t = q + b;
            if (r >= t) {
                r -= t;
                q = t + b;
            }
            r <<= 1;
        }
        return (int) (q >> ((16 - (GLLibConfig.math_fixedPointBase >> 1)) - adj));
    }

    static int Math_FixedPoint_Sqrt(long value) {
        int i;
        if (value == 0 || value == s_math_F_1) {
            return (int) value;
        }
        if (value < 2147483647L) {
            return Math_FixedPoint_Sqrt((int) value);
        }
        int bshft = 30 - GLLibConfig.math_fixedPointBase;
        int b = 1073741824;
        int g2 = 0;
        long val = value;
        do {
            long temp = ((g2 + g2) + b) << bshft;
            if (val >= temp) {
                g2 += b;
                val -= temp;
            }
            b >>= 1;
            i = bshft;
            bshft = i - 1;
        } while (i >= 0);
        return g2;
    }

    static int Math_FixedPoint_NormPow(int x, int y) {
        long result = (((x * x) + (y * y)) + s_math_F_05) >> GLLibConfig.math_fixedPointBase;
        return (int) result;
    }

    static int Math_FixedPoint_Norm(int x, int y) {
        return Math_FixedPoint_Sqrt((((x * x) + (y * y)) + s_math_F_05) >> GLLibConfig.math_fixedPointBase);
    }

    static int Math_FixedPoint_Det(int x1, int y1, int x2, int y2) {
        return Math_FixedPoint_Multiply(x1, y2) - Math_FixedPoint_Multiply(x2, y1);
    }

    static int Math_FixedPoint_DotProduct(int x1, int y1, int x2, int y2) {
        return Math_FixedPoint_Multiply(x1, x2) + Math_FixedPoint_Multiply(y1, y2);
    }

    static int Math_FixedPoint_RadiansToDegrees(int angle) {
        return Math_FixedPoint_Multiply(angle, ratioRadiansToDegrees);
    }

    static int Math_FixedPoint_DegreesToRadians(int angle) {
        return Math_FixedPoint_Divide(angle, ratioRadiansToDegrees);
    }

    static int Math_FixedPoint_RadiansToAngleFixedPoint(int angle) {
        return Math_FixedPoint_Multiply(Math_FixedPoint_Multiply(angle, ratioRadiansToDegrees), ratioDegreesToAngleFixedPoint);
    }

    static int Math_FixedPoint_DegreesToAngleFixedPoint(int angle) {
        return Math_FixedPoint_Multiply(angle, ratioDegreesToAngleFixedPoint);
    }

    static int Math_FixedPoint_PointLineDistance(int in_lineX1, int in_lineY1, int in_lineX2, int in_lineY2, int in_pointX, int in_pointY) {
        int x;
        int y;
        int dx = in_lineX1 - in_lineX2;
        int dy = in_lineY1 - in_lineY2;
        if (dx == 0) {
            x = in_lineX1;
            y = in_pointY;
        } else if (dy == 0) {
            x = in_pointX;
            y = in_lineY1;
        } else {
            int m1 = Math_FixedPoint_Divide(dy, dx);
            int b1 = (-Math_FixedPoint_Multiply(m1, in_lineX1)) + in_lineY1;
            int m2 = -Math_FixedPoint_Divide(dx, dy);
            int b2 = (-Math_FixedPoint_Multiply(m2, in_pointX)) + in_pointY;
            x = Math_FixedPoint_Divide(b1 - b2, m2 - m1);
            y = Math_FixedPoint_Multiply(m1, x) + b1;
        }
        s_Math_distPointLineX = x;
        s_Math_distPointLineY = y;
        return Math_FixedPoint_Norm(x - in_pointX, y - in_pointY);
    }

    static int Math_FixedPoint_LineCircleIntersect(int in_x1, int in_y1, int in_x2, int in_y2, int in_circleX, int in_circleY, int in_radius) {
        int x1;
        int x2;
        int y1;
        int y2;
        int sX = in_x1 - in_circleX;
        int sY = in_y1 - in_circleY;
        int eX = in_x2 - in_circleX;
        int eY = in_y2 - in_circleY;
        long dX = eX - sX;
        long dY = eY - sY;
        if (dY == 0) {
            if (eY < (-in_radius) || eY > in_radius) {
                return 0;
            }
            x1 = Math_FixedPoint_Sqrt(Math_FixedPoint_Square(in_radius) - Math_FixedPoint_Square(eY));
            x2 = -x1;
            y1 = eY;
            y2 = eY;
        } else if (dX == 0) {
            if (eY < (-in_radius) || eY > in_radius) {
                return 0;
            }
            x1 = eX;
            x2 = eX;
            y1 = Math_FixedPoint_Sqrt(Math_FixedPoint_Square(in_radius) - Math_FixedPoint_Square(eX));
            y2 = -y1;
        } else {
            long D = ((sX * eY) - (eX * sY)) >> GLLibConfig.math_fixedPointBase;
            long dR_SQR = ((dX * dX) + (dY * dY)) >> GLLibConfig.math_fixedPointBase;
            long discriminant = ((Math_FixedPoint_Square(in_radius) * dR_SQR) - (D * D)) >> GLLibConfig.math_fixedPointBase;
            if (discriminant < 0 || dR_SQR == 0) {
                return 0;
            }
            if (discriminant == 0) {
                int i = (int) ((D * dY) / dR_SQR);
                x1 = i;
                x2 = i;
                int i2 = (int) ((D * dX) / dR_SQR);
                y1 = i2;
                y2 = i2;
            } else {
                long sqrtDisc = Math_FixedPoint_Sqrt(discriminant);
                long tmp1 = D * dY;
                long tmp2 = (dY < 0 ? -1 : 1) * dX * sqrtDisc;
                x1 = (int) ((tmp1 + tmp2) / dR_SQR);
                x2 = (int) ((tmp1 - tmp2) / dR_SQR);
                long tmp12 = (-D) * dX;
                long tmp22 = Math.abs(dY) * sqrtDisc;
                y1 = (int) ((tmp12 + tmp22) / dR_SQR);
                y2 = (int) ((tmp12 - tmp22) / dR_SQR);
            }
        }
        s_Math_intersectPoints[0][0] = x1 + in_circleX;
        s_Math_intersectPoints[0][1] = y1 + in_circleY;
        s_Math_intersectPoints[1][0] = x2 + in_circleX;
        s_Math_intersectPoints[1][1] = y2 + in_circleY;
        return (x1 == x2 && y1 == y2) ? 2 : 4;
    }

    static int Math_FixedPoint_LineRectangleIntersect(int in_x1, int in_y1, int in_x2, int in_y2, int in_rectX, int in_rectY, int in_rectW, int in_rectH) {
        int x1;
        int y1;
        int x2;
        int y2;
        int rightX = in_rectX + in_rectW;
        int bottomY = in_rectY + in_rectH;
        if (in_x1 - in_x2 == 0) {
            if (in_x2 < in_rectX || in_x2 > rightX) {
                return 0;
            }
            x1 = in_x2;
            y1 = in_rectY;
            x2 = in_x2;
            y2 = bottomY;
        } else {
            int m = Math_FixedPoint_Divide(in_y1 - in_y2, in_x1 - in_x2);
            if (m == 0) {
                if (in_y2 < in_rectY || in_y2 > bottomY) {
                    return 0;
                }
                x1 = in_rectX;
                y1 = in_y2;
                x2 = rightX;
                y2 = in_y2;
            } else {
                int b = (-Math_FixedPoint_Multiply(m, in_x2)) + in_y2;
                x1 = in_rectX;
                y1 = Math_FixedPoint_Multiply(m, x1) + b;
                if (y1 < in_rectY || y1 > bottomY) {
                    y1 = y1 < in_rectY ? in_rectY : bottomY;
                    x1 = Math_FixedPoint_Divide(b - y1, -m);
                    if (x1 < in_rectX || x1 > rightX) {
                        return 0;
                    }
                }
                x2 = rightX;
                y2 = Math_FixedPoint_Multiply(m, x2) + b;
                if (y2 < in_rectY || y2 > bottomY) {
                    y2 = y2 < in_rectY ? in_rectY : bottomY;
                    x2 = Math_FixedPoint_Divide(b - y2, -m);
                    if (x2 < in_rectX || x2 > rightX) {
                        return 0;
                    }
                }
            }
        }
        s_Math_intersectPoints[0][0] = x1;
        s_Math_intersectPoints[0][1] = y1;
        s_Math_intersectPoints[1][0] = x2;
        s_Math_intersectPoints[1][1] = y2;
        return (x1 == x2 && y1 == y2) ? 2 : 4;
    }

    static String ConvertFixedPointToString(int value, int precision) {
        if (precision == 0) {
            return new StringBuffer().append("").append(value >> GLLibConfig.math_fixedPointBase).toString();
        }
        String str = value < 0 ? "-" : "";
        int value2 = value < 0 ? -value : value;
        for (int i = -1; i < precision; i++) {
            int tmp = value2 >> GLLibConfig.math_fixedPointBase;
            str = new StringBuffer().append(str).append(tmp).toString();
            if (i == -1) {
                str = new StringBuffer().append(str).append(".").toString();
            }
            value2 = (value2 - (tmp * s_math_F_1)) * 10;
        }
        return str;
    }

    static final int Math_Abs(int a) {
        return Math.abs(a);
    }

    static final long Math_Abs(long a) {
        return Math.abs(a);
    }

    static final int Math_Max(int a, int b) {
        return Math.max(a, b);
    }

    static final long Math_Max(long a, long b) {
        return Math.max(a, b);
    }

    static final int Math_Min(int a, int b) {
        return Math.min(a, b);
    }

    static final long Math_Min(long a, long b) {
        return Math.min(a, b);
    }

    public InputStream GetResourceAsStream(String s) {
        InputStream is = "".getClass().getResourceAsStream(s);
        return is;
    }

    static void Pack_Open(String filename) {
        if (s_pack_filename != null && filename.compareTo(s_pack_filename) == 0) {
            return;
        }
        Pack_Close();
        s_pack_filename = filename;
        s_pack_is = Pack_GetInputStreamFromName(s_pack_filename);
        s_pack_nbData = (short) Pack_Read16();
        s_pack_subPack_nbOf = (short) Pack_Read16();
        s_pack_subPack_fat = new short[s_pack_subPack_nbOf];
        for (int i = 0; i < s_pack_subPack_nbOf; i++) {
            s_pack_subPack_fat[i] = (short) Pack_Read16();
        }
        s_pack_subPack_curSubPack = 0;
        Pack_GetDataOffset();
    }

    /* JADX WARN: Type inference failed for: r0v37, types: [byte[], byte[][]] */
    private static InputStream Pack_GetInputStreamFromName(String strName) {
        InputStream pStream;
        if (GLLibConfig.rms_usePackRead && !strName.startsWith("/")) {
            pStream = GetRmsInputStream(strName);
        } else if (GLLibConfig.pack_keepLoaded) {
            if (s_pack_HashIndex == null) {
                s_pack_HashIndex = new Hashtable();
                s_pack_HashSize = new Hashtable();
                try {
                    s_pack_is = s_gllib_instance.GetResourceAsStream("/999");
                    int nCount = Pack_Read32();
                    s_pack_BinaryCache = new byte[nCount];
                    for (int i = 0; i < nCount; i++) {
                        int nStrLength = Pack_Read32();
                        byte[] pStr = new byte[nStrLength];
                        s_pack_is.read(pStr);
                        String strFileName = new String(pStr);
                        int nSize = Pack_Read32();
                        s_pack_HashIndex.put(new StringBuffer().append("/").append(strFileName).toString(), new Integer(i));
                        s_pack_HashSize.put(new StringBuffer().append("/").append(strFileName).toString(), new Integer(nSize));
                    }
                    Pack_Close();
                } catch (Throwable th) {
                    Dbg("   Exception while reading file INDEX");
                }
            }
            int nDataIndex = ((Integer) s_pack_HashIndex.get(strName)).intValue();
            if (s_pack_BinaryCache[nDataIndex] == null) {
                int nSize2 = ((Integer) s_pack_HashSize.get(strName)).intValue();
                s_pack_BinaryCache[nDataIndex] = new byte[nSize2];
                try {
                    s_pack_is = s_gllib_instance.GetResourceAsStream(strName);
                    s_pack_is.read(s_pack_BinaryCache[nDataIndex]);
                    s_pack_is.close();
                    s_pack_is = null;
                } catch (Throwable th2) {
                    Dbg(new StringBuffer().append("   Exception while reading file to cache : ").append(strName).toString());
                }
            }
            pStream = new ByteArrayInputStream(s_pack_BinaryCache[nDataIndex]);
        } else if (GLLibConfig.pack_useBlackBerryGZipDecompression) {
            pStream = Lib_getGZipStream(strName);
        } else {
            pStream = s_gllib_instance.GetResourceAsStream(strName);
        }
        return pStream;
    }

    static void Pack_ReleaseBinaryCache(String filename) {
        if (GLLibConfig.pack_keepLoaded) {
            int nDataIndex = ((Integer) s_pack_HashIndex.get(filename)).intValue();
            if (s_pack_BinaryCache[nDataIndex] != null) {
                int nbSubPack = Mem_GetShort(s_pack_BinaryCache[nDataIndex], 2);
                s_pack_BinaryCache[nDataIndex] = null;
                for (int i = 1; i < nbSubPack; i++) {
                    String strSubPack = new StringBuffer().append(filename).append(".").append(i).toString();
                    s_pack_BinaryCache[((Integer) s_pack_HashIndex.get(strSubPack)).intValue()] = null;
                }
            }
        }
    }

    private static void Pack_GetDataOffset() {
        int nbData;
        if (s_pack_subPack_curSubPack == s_pack_subPack_nbOf - 1) {
            nbData = s_pack_nbData - s_pack_subPack_fat[s_pack_subPack_curSubPack];
        } else {
            nbData = s_pack_subPack_fat[s_pack_subPack_curSubPack + 1] - s_pack_subPack_fat[s_pack_subPack_curSubPack];
        }
        s_pack_offset = new int[nbData + 1];
        for (int i = 0; i < nbData + 1; i++) {
            s_pack_offset[i] = Pack_Read32();
        }
    }

    static void Pack_Close() {
        if (s_pack_is != null) {
            try {
                s_pack_is.close();
            } catch (Throwable th) {
            }
            s_pack_is = null;
        }
        s_pack_curOffset = 0;
        if (GLLibConfig.rms_usePackRead) {
            s_rms_buffer = null;
        }
        Gc();
    }

    static int Pack_PositionAtData(int idx) {
        int subpack = s_pack_subPack_nbOf - 1;
        while (subpack >= 0 && s_pack_subPack_fat[subpack] > idx) {
            subpack--;
        }
        if (s_pack_subPack_curSubPack != subpack) {
            s_pack_subPack_curSubPack = subpack;
            Pack_Close();
            if (s_pack_subPack_curSubPack == 0) {
                String name = s_pack_filename;
                s_pack_filename = null;
                Pack_Open(name);
            } else {
                s_pack_is = Pack_GetInputStreamFromName(new StringBuffer().append(s_pack_filename).append(".").append(s_pack_subPack_curSubPack).toString());
                Pack_GetDataOffset();
            }
        } else if (s_pack_is == null) {
            if (s_pack_subPack_curSubPack == 0) {
                String name2 = s_pack_filename;
                s_pack_filename = null;
                Pack_Open(name2);
            } else {
                s_pack_is = Pack_GetInputStreamFromName(new StringBuffer().append(s_pack_filename).append(".").append(s_pack_subPack_curSubPack).toString());
            }
        }
        int idx2 = idx - s_pack_subPack_fat[s_pack_subPack_curSubPack];
        int offset = s_pack_offset[idx2];
        int size = s_pack_offset[idx2 + 1] - s_pack_offset[idx2];
        Pack_Seek(offset);
        s_pack_lastDataIsCompress = false;
        if (size > 0) {
            s_pack_lastDataReadMimeType = Pack_Read() & 255;
            if (GLLibConfig.pack_supportLZMADecompression && s_pack_lastDataReadMimeType >= 127) {
                s_pack_lastDataReadMimeType -= 127;
                s_pack_lastDataIsCompress = true;
            }
            size--;
        }
        return size;
    }

    static byte[] Pack_ReadData(int idx) {
        int size = Pack_PositionAtData(idx);
        byte[] data = null;
        if (GLLibConfig.pack_supportLZMADecompression && s_pack_lastDataIsCompress) {
            try {
                LZMA_Inflate(s_pack_is, size);
                s_pack_curOffset += size;
                data = m_outStream;
                m_outStream = null;
            } catch (Throwable th) {
            }
        } else {
            data = new byte[size];
            Pack_ReadFully(data, 0, data.length);
        }
        return data;
    }

    static void Pack_Seek(int addr) {
        if (s_pack_curOffset == addr) {
            return;
        }
        if (s_pack_curOffset > addr) {
            Pack_Close();
            if (s_pack_subPack_curSubPack == 0) {
                s_pack_is = Pack_GetInputStreamFromName(s_pack_filename);
            } else {
                s_pack_is = Pack_GetInputStreamFromName(new StringBuffer().append(s_pack_filename).append(".").append(s_pack_subPack_curSubPack).toString());
            }
        } else {
            addr -= s_pack_curOffset;
        }
        Pack_Skip(addr);
    }

    static void Pack_Skip(int nb) {
        if (nb == 0) {
            return;
        }
        if (GLLibConfig.pack_skipbufferSize == 0) {
            s_pack_curOffset += nb;
            while (nb > 0) {
                try {
                    nb = (int) (nb - s_pack_is.skip(nb));
                } catch (Throwable th) {
                    return;
                }
            }
            return;
        }
        if (s_Pack_SkipBuffer == null) {
            s_Pack_SkipBuffer = new byte[GLLibConfig.pack_skipbufferSize];
        }
        while (nb > GLLibConfig.pack_skipbufferSize) {
            Pack_ReadFully(s_Pack_SkipBuffer, 0, GLLibConfig.pack_skipbufferSize);
            nb -= GLLibConfig.pack_skipbufferSize;
        }
        if (nb > 0) {
            Pack_ReadFully(s_Pack_SkipBuffer, 0, nb);
        }
    }

    static int Pack_Read() {
        int read = 0;
        try {
            read = s_pack_is.read();
        } catch (Throwable th) {
        }
        s_pack_curOffset++;
        return read;
    }

    static int Pack_Read16() {
        return (Pack_Read() & 255) | ((Pack_Read() & 255) << 8);
    }

    static int Pack_Read32() {
        return (Pack_Read() & 255) | ((Pack_Read() & 255) << 8) | ((Pack_Read() & 255) << 16) | ((Pack_Read() & 255) << 24);
    }

    static int Pack_ReadFully(byte[] array, int offset, int length) {
        int off = offset;
        int len = length;
        while (len > 0) {
            try {
                int read = s_pack_is.read(array, off, len);
                len -= read;
                off += read;
            } catch (Throwable th) {
            }
        }
        s_pack_curOffset += length;
        return length;
    }

    static Object Pack_ReadArray(int idx) {
        Object array;
        Pack_PositionAtData(idx);
        Stream_readOffset = 0;
        if (GLLibConfig.pack_supportLZMADecompression && s_pack_lastDataIsCompress) {
            byte[] data = Pack_ReadData(idx);
            ByteArrayInputStream bis = new ByteArrayInputStream(data);
            array = Mem_ReadArray(bis);
        } else {
            array = Mem_ReadArray(s_pack_is);
            s_pack_curOffset += Stream_readOffset;
        }
        return array;
    }

    /* JADX WARN: Type inference failed for: r0v6, types: [byte[], byte[][]] */
    static void Pack_LoadMIME(String filename) {
        if (MIME_type == null) {
            InputStream is = s_pack_is;
            s_pack_is = Pack_GetInputStreamFromName(filename);
            int nbOfMime = Pack_Read();
            MIME_type = new byte[nbOfMime];
            for (int i = 0; i < nbOfMime; i++) {
                int len = Pack_Read();
                MIME_type[i] = new byte[len];
                Pack_ReadFully(MIME_type[i], 0, len);
            }
            try {
                s_pack_is.close();
            } catch (Throwable th) {
            }
            s_pack_is = is;
        }
    }

    static String GetMIME(int idx) {
        if (idx >= MIME_type.length) {
            return "";
        }
        try {
            return new String(MIME_type[idx], "UTF-8");
        } catch (Throwable th) {
            return "";
        }
    }

    static int GetNBData() {
        return s_pack_nbData;
    }

    public static InputStream Lib_getGZipStream(String filename) {
        try {
            DataInputStream dis = new DataInputStream(new GZIPInputStream("".getClass().getResourceAsStream(filename)));
            int count = ((dis.readByte() << 24) & (-16777216)) | ((dis.readByte() << 16) & 16711680) | ((dis.readByte() << 8) & 65280) | (dis.readByte() & 255);
            byte[] dis_buffer = new byte[count];
            dis.readFully(dis_buffer);
            return new ByteArrayInputStream(dis_buffer);
        } catch (Throwable th) {
            return null;
        }
    }

    private static int LZMA_RangeDecoderReadByte() {
        if (inputIndex == m_inSize) {
            m_ExtraBytes = 1;
            return 255;
        }
        byte[] bArr = m_Buffer;
        int i = inputIndex;
        inputIndex = i + 1;
        return bArr[i] & 255;
    }

    private static void LZMA_RangeDecoderInit(byte[] stream, int bufferSize) {
        m_Buffer = stream;
        m_inSize = bufferSize;
        inputIndex = 0;
        m_ExtraBytes = 0;
        m_Code = 0L;
        m_Range = 4294967295L;
        for (int i = 0; i < 5; i++) {
            m_Code = (m_Code << 8) | LZMA_RangeDecoderReadByte();
        }
    }

    private static int LZMA_RangeDecoderBitDecode(int prob) {
        long bound = (m_Range >> 11) * m_lzmaInternalData[prob];
        if (m_Code < bound) {
            m_Range = bound;
            short[] sArr = m_lzmaInternalData;
            sArr[prob] = (short) (sArr[prob] + ((kBitModelTotal - m_lzmaInternalData[prob]) >> 5));
            if (m_Range < 16777216) {
                m_Code = (m_Code << 8) | LZMA_RangeDecoderReadByte();
                m_Range <<= 8;
                return 0;
            }
            return 0;
        }
        m_Range -= bound;
        m_Code -= bound;
        short[] sArr2 = m_lzmaInternalData;
        sArr2[prob] = (short) (sArr2[prob] - (m_lzmaInternalData[prob] >> 5));
        if (m_Range < 16777216) {
            m_Code = (m_Code << 8) | LZMA_RangeDecoderReadByte();
            m_Range <<= 8;
            return 1;
        }
        return 1;
    }

    private static int LZMA_LiteralDecodeMatch(int prob, byte matchByte) {
        int symbol = 1;
        while (true) {
            int matchBit = (matchByte >> 7) & 1;
            matchByte = (byte) (matchByte << 1);
            int bit = LZMA_RangeDecoderBitDecode(prob + ((1 + matchBit) << 8) + symbol);
            symbol = (symbol << 1) | bit;
            if (matchBit != bit) {
                while (symbol < kLenNumHighSymbols) {
                    symbol = (symbol << 1) | LZMA_RangeDecoderBitDecode(prob + symbol);
                }
            } else if (symbol >= kLenNumHighSymbols) {
                break;
            }
        }
        return symbol;
    }

    private static int LZMA_LiteralDecode(int probs) {
        int symbol = 1;
        do {
            symbol = (symbol << 1) | LZMA_RangeDecoderBitDecode(probs + symbol);
        } while (symbol < kLenNumHighSymbols);
        return symbol;
    }

    private static int LZMA_RangeDecoderBitTreeDecode(int probs, int numLevels) {
        int mi = 1;
        for (int i = numLevels; i > 0; i--) {
            mi = (mi << 1) + LZMA_RangeDecoderBitDecode(probs + mi);
        }
        return mi - (1 << numLevels);
    }

    private static int LZMA_LenDecode(int p, int posState) {
        if (LZMA_RangeDecoderBitDecode(p + 0) == 0) {
            return LZMA_RangeDecoderBitTreeDecode(p + 2 + (posState << 3), 3);
        }
        if (LZMA_RangeDecoderBitDecode(p + 1) == 0) {
            return 8 + LZMA_RangeDecoderBitTreeDecode(p + LenMid + (posState << 3), 3);
        }
        return 16 + LZMA_RangeDecoderBitTreeDecode(p + LenHigh, 8);
    }

    private static int LZMA_RangeDecoderReverseBitTreeDecode(int probs, int numLevels) {
        int mi = 1;
        int symbol = 0;
        for (int i = 0; i < numLevels; i++) {
            int bit = LZMA_RangeDecoderBitDecode(probs + mi);
            mi = (mi << 1) + bit;
            symbol |= bit << i;
        }
        return symbol;
    }

    private static int LZMA_RangeDecoderDecodeDirectBits(int numTotalBits) {
        long range = m_Range;
        long code = m_Code;
        int result = 0;
        for (int i = numTotalBits; i > 0; i--) {
            range >>= 1;
            result <<= 1;
            if (code >= range) {
                code -= range;
                result |= 1;
            }
            if (range < 16777216) {
                range <<= 8;
                code = (code << 8) | LZMA_RangeDecoderReadByte();
            }
        }
        m_Range = range;
        m_Code = code;
        return result;
    }

    private static void LZMA_Decode(int bufferSize, int lc, int lp, int pb, byte[] inStream, int outSize) {
        int len;
        int rep0;
        int distance;
        int inSize = inStream.length;
        int numProbs = 1846 + (LZMA_LIT_SIZE << (lc + lp));
        short[] buffer = m_lzmaInternalData;
        int state = 0;
        boolean previousIsMatch = false;
        int previousByte = 0;
        int rep02 = 1;
        int rep1 = 1;
        int rep2 = 1;
        int rep3 = 1;
        int nowPos = 0;
        int posStateMask = (1 << pb) - 1;
        int literalPosMask = (1 << lp) - 1;
        if (bufferSize < (numProbs << 1)) {
            return;
        }
        for (int i = 0; i < numProbs; i++) {
            buffer[i] = 1024;
        }
        LZMA_RangeDecoderInit(inStream, inSize);
        while (nowPos < outSize) {
            int posState = nowPos & posStateMask;
            if (LZMA_RangeDecoderBitDecode(0 + (state << 4) + posState) == 0) {
                int probs = 1846 + (LZMA_LIT_SIZE * (((nowPos & literalPosMask) << lc) + ((previousByte & 255) >> (8 - lc))));
                if (state < 4) {
                    state = 0;
                } else if (state < 10) {
                    state -= 3;
                } else {
                    state -= 6;
                }
                if (previousIsMatch) {
                    byte matchByte = m_outStream[nowPos - rep02];
                    previousByte = LZMA_LiteralDecodeMatch(probs, matchByte) & 255;
                    previousIsMatch = false;
                } else {
                    previousByte = LZMA_LiteralDecode(probs) & 255;
                }
                int i2 = nowPos;
                nowPos++;
                m_outStream[i2] = (byte) previousByte;
            } else {
                previousIsMatch = true;
                if (LZMA_RangeDecoderBitDecode(IsRep + state) == 1) {
                    if (LZMA_RangeDecoderBitDecode(IsRepG0 + state) == 0) {
                        if (LZMA_RangeDecoderBitDecode(IsRep0Long + (state << 4) + posState) == 0) {
                            state = state < 7 ? 9 : 11;
                            previousByte = m_outStream[nowPos - rep02] & 255;
                            int i3 = nowPos;
                            nowPos++;
                            m_outStream[i3] = (byte) previousByte;
                        }
                    } else {
                        if (LZMA_RangeDecoderBitDecode(IsRepG1 + state) == 0) {
                            distance = rep1;
                        } else {
                            if (LZMA_RangeDecoderBitDecode(IsRepG2 + state) == 0) {
                                distance = rep2;
                            } else {
                                distance = rep3;
                                rep3 = rep2;
                            }
                            rep2 = rep1;
                        }
                        rep1 = rep02;
                        rep02 = distance;
                    }
                    len = LZMA_LenDecode(RepLenCoder, posState);
                    state = state < 7 ? 8 : 11;
                } else {
                    rep3 = rep2;
                    rep2 = rep1;
                    rep1 = rep02;
                    state = state < 7 ? 7 : 10;
                    len = LZMA_LenDecode(LenCoder, posState);
                    int posSlot = LZMA_RangeDecoderBitTreeDecode(PosSlot + ((len < 4 ? len : 3) << 6), 6);
                    if (posSlot >= 4) {
                        int numDirectBits = (posSlot >> 1) - 1;
                        int rep03 = (2 | (posSlot & 1)) << numDirectBits;
                        if (posSlot < 14) {
                            rep0 = rep03 + LZMA_RangeDecoderReverseBitTreeDecode(((SpecPos + rep03) - posSlot) - 1, numDirectBits);
                        } else {
                            rep0 = rep03 + (LZMA_RangeDecoderDecodeDirectBits(numDirectBits - 4) << 4) + LZMA_RangeDecoderReverseBitTreeDecode(Align, 4);
                        }
                    } else {
                        rep0 = posSlot;
                    }
                    rep02 = rep0 + 1;
                }
                int len2 = len + 2;
                do {
                    previousByte = m_outStream[nowPos - rep02] & 255;
                    int i4 = nowPos;
                    nowPos++;
                    m_outStream[i4] = (byte) previousByte;
                    len2--;
                    if (len2 > 0) {
                    }
                } while (nowPos < outSize);
            }
        }
    }

    private static void LZMA_Inflate(InputStream is, int size) throws Throwable {
        if (GLLibConfig.pack_supportLZMADecompression) {
            byte[] header = new byte[13];
            byte[] data = new byte[size - 13];
            Stream_ReadFully(is, header, 0, 13);
            Stream_ReadFully(is, data, 0, size - 13);
            int[] properties = new int[5];
            for (int i = 0; i < 5; i++) {
                properties[i] = header[i] & 255;
            }
            int outSize = 0;
            for (int i2 = 0; i2 < 4; i2++) {
                outSize += (header[i2 + 5] & 255) << (i2 << 3);
            }
            int prop0 = properties[0];
            int pb = prop0 / 45;
            int prop02 = prop0 % 45;
            int lp = prop02 / 9;
            int lc = prop02 % 9;
            int lzmaInternalSize = 1846 + (LZMA_LIT_SIZE << (lc + lp));
            m_outStream = new byte[outSize];
            m_lzmaInternalData = new short[lzmaInternalSize];
            LZMA_Decode(lzmaInternalSize * 2, lc, lp, pb, data, outSize);
            m_lzmaInternalData = null;
            m_Buffer = null;
            Gc();
        }
    }

    public static void LZMA_Inflate(byte[] compressDat) throws Throwable {
        if (GLLibConfig.pack_supportLZMADecompression) {
            byte[] header = new byte[13];
            byte[] data = new byte[compressDat.length - 13];
            System.arraycopy(compressDat, 0, header, 0, 13);
            System.arraycopy(compressDat, 13, data, 0, data.length);
            int[] properties = new int[5];
            for (int i = 0; i < 5; i++) {
                properties[i] = header[i] & 255;
            }
            int outSize = 0;
            for (int i2 = 0; i2 < 4; i2++) {
                outSize += (header[i2 + 5] & 255) << (i2 << 3);
            }
            int prop0 = properties[0];
            int pb = prop0 / 45;
            int prop02 = prop0 % 45;
            int lp = prop02 / 9;
            int lc = prop02 % 9;
            int lzmaInternalSize = 1846 + (LZMA_LIT_SIZE << (lc + lp));
            m_outStream = new byte[outSize];
            m_lzmaInternalData = new short[lzmaInternalSize];
            LZMA_Decode(lzmaInternalSize * 2, lc, lp, pb, data, outSize);
            m_lzmaInternalData = null;
            m_Buffer = null;
            Gc();
        }
    }

    static final void SetCurrentGraphics(Graphics graphics) {
        if (graphics == null) {
            g = s_lastPaintGraphics;
        } else {
            g = graphics;
        }
    }

    static final void SetCurrentGraphics(Image img) {
        if (img == null) {
            g = s_lastPaintGraphics;
        } else {
            g = img.getGraphics();
        }
    }

    static final long GetRealTime() {
        return System.currentTimeMillis();
    }

    static final long GetFrameTime() {
        return s_game_timeWhenFrameStart;
    }

    static final int GetScreenWidth() {
        return s_screenWidth;
    }

    static final int GetScreenHeight() {
        return s_screenHeight;
    }

    static final void Gc() {
        if (GLLibConfig.useSystemGc) {
            System.gc();
        }
    }

    static final void Translate(int x, int y) {
        g.translate(x, y);
    }

    static final int GetTranslateX() {
        return g.getTranslateX();
    }

    static final int GetTranslateY() {
        return g.getTranslateY();
    }

    static final int GetColor() {
        return g.getColor();
    }

    static final int GetRedComponent() {
        return g.getRedComponent();
    }

    static final int GetGreenComponent() {
        return g.getGreenComponent();
    }

    static final int GetBlueComponent() {
        return g.getBlueComponent();
    }

    static final int GetGrayScale() {
        return 0;
    }

    static final void SetColor(int RGB) {
        g.setColor(RGB);
    }

    static final void setColor(int red, int green, int blue) {
        g.setColor((red << 16) | (green << 8) | blue);
    }

    static final void SetGrayScale(int value) {
    }

    static final Font GetFont() {
        return g.getFont();
    }

    static final void SetStrokeStyle(int style) {
    }

    static final int GetStrokeStyle() {
        return 0;
    }

    static final void SetFont(Font font) {
        g.setFont(font);
    }

    static final int GetClipX() {
        return g.getClipX();
    }

    static final int GetClipY() {
        return g.getClipY();
    }

    static final int GetClipWidth() {
        return g.getClipWidth();
    }

    static final int GetClipHeight() {
        return g.getClipHeight();
    }

    static final void ClipRect(int x, int y, int width, int height) {
        g.clipRect(x, y, width, height);
    }

    static final void SetClip(int x, int y, int width, int height) {
        g.setClip(x, y, width, height);
        if (GLLibConfig.useNokiaS60SetClipBugfix) {
            g.clipRect(x, y, width, height);
        }
    }

    static final void DrawLine(int x1, int y1, int x2, int y2) {
        if (GLLibConfig.useDrawLineClippingBug && y1 > y2) {
            x1 = x2;
            x2 = x1;
            y1 = y2;
            y2 = y1;
        }
        g.drawLine(x1, y1, x2, y2);
    }

    static final void FillRect(int x, int y, int width, int height) {
        if (GLLibConfig.useSafeFillRect) {
            Image fillRectImage = Image.createImage(width, height);
            Graphics fillRectGraphics = fillRectImage.getGraphics();
            fillRectGraphics.setColor(g.getColor());
            fillRectGraphics.fillRect(0, 0, width, height);
            g.drawImage(fillRectImage, x, y, 0);
            return;
        }
        g.fillRect(x, y, width, height);
    }

    static final void DrawRect(int x, int y, int width, int height) {
        g.drawRect(x, y, width, height);
    }

    static final void DrawRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
        g.drawRoundRect(x, y, width, height, arcWidth, arcHeight);
    }

    static final void FillRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
        g.fillRoundRect(x, y, width, height, arcWidth, arcHeight);
    }

    static final void FillArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
        g.fillArc(x, y, width, height, startAngle, arcAngle);
    }

    static final void DrawArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
        g.drawArc(x, y, width, height, startAngle, arcAngle);
    }

    private static final int transformAnchorForText(int anchor) {
        if ((anchor & 2) != 0) {
            Graphics graphics = g;
            anchor = (anchor & (-3)) | 64;
        }
        return anchor;
    }

    static final void DrawString(String str, int x, int y, int anchor) {
        try {
            g.drawString(str, x, y, transformAnchorForText(anchor));
        } catch (Throwable th) {
        }
    }

    static final void DrawSubstring(String str, int offset, int len, int x, int y, int anchor) {
        try {
            g.drawSubstring(str, offset, len, x, y, transformAnchorForText(anchor));
        } catch (Throwable th) {
        }
    }

    static final void DrawChar(char character, int x, int y, int anchor) {
        try {
            g.drawChar(character, x, y, transformAnchorForText(anchor));
        } catch (Throwable th) {
        }
    }

    static final void DrawChars(char[] data, int offset, int length, int x, int y, int anchor) {
        try {
            g.drawChars(data, offset, length, x, y, transformAnchorForText(anchor));
        } catch (Throwable th) {
        }
    }

    static final void DrawImage(Image img, int x, int y, int anchor) {
        try {
            g.drawImage(img, x, y, anchor);
        } catch (Throwable th) {
        }
    }

    static final void DrawRegion(Image src, int x_src, int y_src, int width, int height, int transform, int x_dest, int y_dest, int anchor) {
        if (GLLibConfig.useSafeDrawRegion) {
            if (x_src < 0) {
                width += x_src;
                x_src = 0;
            }
            if (x_src + width >= src.getWidth()) {
                width += src.getWidth() - (x_src + width);
            }
            if (y_src < 0) {
                height += y_src;
                y_src = 0;
            }
            if (y_src + height >= src.getHeight()) {
                height += src.getHeight() - (y_src + height);
            }
            if (height <= 0 || width <= 0) {
                return;
            }
        }
        try {
            if (!GLLibConfig.sprite_drawRegionFlippedBug) {
                g.drawRegion(src, x_src, y_src, width, height, transform, x_dest, y_dest, anchor);
            }
        } catch (Throwable th) {
        }
    }

    static final void CopyArea(int x_src, int y_src, int width, int height, int x_dest, int y_dest, int anchor) {
        try {
            g.copyArea(x_src, y_src, width, height, x_dest, y_dest, anchor);
        } catch (Throwable th) {
        }
    }

    static final void FillTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
        g.fillTriangle(x1, y1, x2, y2, x3, y3);
    }

    static final Image CreateRGBImage(int[] data, int w, int h, boolean alpha) {
        Image img;
        if (GLLibConfig.sprite_useCreateRGBTransparencyBug) {
            img = Image.createRGBImage(data, w, h, true);
        } else {
            img = Image.createRGBImage(data, w, h, alpha);
        }
        return img;
    }

    static final void DrawRGB(Graphics g2, int[] rgbData, int offset, int scanlength, int x, int y, int width, int height, boolean processAlpha) {
        if (GLLibConfig.sprite_drawRGBTransparencyBug) {
            Image tmp_img = CreateRGBImage(rgbData, width, height, processAlpha);
            g2.drawImage(tmp_img, x, y, 0);
        } else if (GLLibConfig.useDrawPartialRGB || GLLibConfig.sprite_useTruncatedRGBBuffer) {
            drawPartialRGB(g2, rgbData, scanlength, offset % scanlength, offset / scanlength, x, y, width, height, processAlpha);
        } else {
            g2.drawRGB(rgbData, offset, scanlength, x, y, width, height, processAlpha);
        }
    }

    public static final void drawPartialRGB(Graphics g2, int[] rgbData, int scanlength, int srcX, int srcY, int x, int y, int width, int height, boolean processAlpha) {
        drawPartialRGB(g2, GetScreenWidth(), GetScreenHeight(), rgbData, scanlength, srcX, srcY, x, y, width, height, processAlpha);
    }

    public static final void drawPartialRGB(Graphics g2, int screenWidth, int screenHeight, int[] rgbData, int scanlength, int srcX, int srcY, int x, int y, int width, int height, boolean processAlpha) {
        int offset = srcX + (srcY * scanlength);
        if (g2 == s_lastPaintGraphics) {
            if (x >= screenWidth || x + width <= 0 || y >= screenHeight || y + height <= 0) {
                return;
            }
            if (x <= 0) {
                offset -= x;
                width += x;
                x = 0;
            }
            if (x + width >= screenWidth) {
                width = screenWidth - x;
            }
            if (y + height >= screenHeight) {
                height = screenHeight - y;
            }
            if (y <= 0) {
                offset -= y * scanlength;
                height += y;
                y = 0;
            }
        }
        try {
            g2.drawRGB(rgbData, offset, scanlength, x, y, width, height, processAlpha);
        } catch (Throwable th) {
        }
    }

    static final int GetDisplayColor(int color) {
        return g.getDisplayColor(color);
    }

    static final boolean PlatformRequest(String url) {
        try {
            GloftBBUiApp gloftBBUiApp = s_application;
            return GloftBBUiApp.platformRequest(url);
        } catch (Throwable e) {
            Dbg(new StringBuffer().append("PlatformRequest.Failed with url ").append(url).append(" with exception ").append(e.getMessage()).toString());
            return false;
        }
    }

    public static void Vibrate(int duration) {
        try {
            if (m_nextTimeVibrationAllowed < s_game_timeWhenFrameStart) {
                Alert.startVibrate(duration);
                m_nextTimeVibrationAllowed = s_game_timeWhenFrameStart + 200;
            }
        } catch (Throwable th) {
        }
    }

    public static final Image CreateImage(byte[] data, int offset, int length) {
        if (!GLLibConfig.sprite_useA870CreateRGBTransparencyFix) {
            return Image.createImage(data, offset, length);
        }
        return FixImageLackingTransparencyBug(Image.createImage(data, offset, length));
    }

    public static final Image FixImageLackingTransparencyBug(Image img) {
        int w = img.getWidth();
        int h = img.getHeight();
        int size = w * h;
        Image imgTemp = Image.createImage(w, h);
        Graphics graTemp = imgTemp.getGraphics();
        graTemp.setColor(16711935);
        graTemp.fillRect(0, 0, w, h);
        graTemp.drawImage(img, 0, 0, 0);
        int[] rgbData = ASprite.temp_int;
        if (rgbData == null || rgbData.length < size) {
            rgbData = new int[w * h];
        }
        imgTemp.getRGB(rgbData, 0, w, 0, 0, w, h);
        for (int i = size - 1; i >= 0; i--) {
            if ((rgbData[i] & 16777215) == 16711935) {
                rgbData[i] = 16711935;
            }
        }
        return Image.createRGBImage(rgbData, w, h, true);
    }

    static int Mem_SetByte(byte[] dst, int dst_off, byte src) {
        int dst_off2 = dst_off + 1;
        dst[dst_off] = src;
        return dst_off2;
    }

    static int Mem_SetShort(byte[] dst, int dst_off, short src) {
        int dst_off2 = dst_off + 1;
        dst[dst_off] = (byte) (src & 255);
        int dst_off3 = dst_off2 + 1;
        dst[dst_off2] = (byte) ((src >>> 8) & 255);
        return dst_off3;
    }

    static int Mem_SetInt(byte[] dst, int dst_off, int src) {
        int dst_off2 = dst_off + 1;
        dst[dst_off] = (byte) (src & 255);
        int dst_off3 = dst_off2 + 1;
        dst[dst_off2] = (byte) ((src >>> 8) & 255);
        int dst_off4 = dst_off3 + 1;
        dst[dst_off3] = (byte) ((src >>> 16) & 255);
        int dst_off5 = dst_off4 + 1;
        dst[dst_off4] = (byte) ((src >>> 24) & 255);
        return dst_off5;
    }

    static int Mem_SetLong(byte[] dst, int dst_off, long src) {
        int dst_off2 = dst_off + 1;
        dst[dst_off] = (byte) (src & 255);
        int dst_off3 = dst_off2 + 1;
        dst[dst_off2] = (byte) ((src >>> 8) & 255);
        int dst_off4 = dst_off3 + 1;
        dst[dst_off3] = (byte) ((src >>> 16) & 255);
        int dst_off5 = dst_off4 + 1;
        dst[dst_off4] = (byte) ((src >>> 24) & 255);
        int dst_off6 = dst_off5 + 1;
        dst[dst_off5] = (byte) ((src >>> 32) & 255);
        int dst_off7 = dst_off6 + 1;
        dst[dst_off6] = (byte) ((src >>> 40) & 255);
        int dst_off8 = dst_off7 + 1;
        dst[dst_off7] = (byte) ((src >>> 48) & 255);
        int dst_off9 = dst_off8 + 1;
        dst[dst_off8] = (byte) ((src >>> 56) & 255);
        return dst_off9;
    }

    static byte Mem_GetByte(byte[] src, int src_off) {
        return src[src_off];
    }

    static short Mem_GetShort(byte[] src, int src_off) {
        int src_off2 = src_off + 1;
        int i = src[src_off] & 255;
        int i2 = src_off2 + 1;
        return (short) (i | ((src[src_off2] & 255) << 8));
    }

    static int Mem_GetInt(byte[] src, int src_off) {
        int src_off2 = src_off + 1;
        int i = src[src_off] & 255;
        int src_off3 = src_off2 + 1;
        int i2 = i | ((src[src_off2] & 255) << 8);
        int src_off4 = src_off3 + 1;
        int i3 = i2 | ((src[src_off3] & 255) << 16);
        int i4 = src_off4 + 1;
        return i3 | ((src[src_off4] & 255) << 24);
    }

    static long Mem_GetLong(byte[] src, int src_off) {
        long j = src[src_off] & 255;
        long j2 = j | ((src[r7] & 255) << 8);
        long j3 = j2 | ((src[r7] & 255) << 16);
        long j4 = j3 | ((src[r7] & 255) << 24);
        long j5 = j4 | ((src[r7] & 255) << 32);
        long j6 = j5 | ((src[r7] & 255) << 40);
        long j7 = j6 | ((src[r7] & 255) << 48);
        int i = src_off + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1;
        return j7 | ((src[r7] & 255) << 56);
    }

    static void Mem_ArrayCopy(Object src, int src_position, Object dst, int dst_position, int length) throws Throwable {
        System.arraycopy(src, src_position, dst, dst_position, length);
    }

    static int Mem_SetArray(byte[] dst, int dst_off, byte[] src) throws Throwable {
        Mem_ArrayCopy(src, 0, dst, dst_off, src.length);
        return dst_off + src.length;
    }

    static int Mem_GetArray(byte[] src, int src_off, byte[] dst) throws Throwable {
        Mem_ArrayCopy(src, src_off, dst, 0, dst.length);
        return src_off + dst.length;
    }

    static Object Mem_ReadArray(InputStream is) {
        int nbComponent;
        Object[] genArray;
        Object array = null;
        try {
            int ID = Stream_Read(is);
            int dataPadding = ID >> 4;
            int type = ID & 7;
            if ((ID & 8) != 0) {
                nbComponent = Stream_Read16(is);
            } else {
                nbComponent = Stream_Read(is);
            }
            switch (type) {
                case 0:
                    byte[] array2 = new byte[nbComponent];
                    for (int i = 0; i < nbComponent; i++) {
                        array2[i] = (byte) Stream_Read(is);
                    }
                    array = array2;
                    break;
                case 1:
                    short[] array22 = new short[nbComponent];
                    if (dataPadding == 0) {
                        for (int i2 = 0; i2 < nbComponent; i2++) {
                            array22[i2] = (byte) Stream_Read(is);
                        }
                    } else {
                        for (int i3 = 0; i3 < nbComponent; i3++) {
                            array22[i3] = (short) Stream_Read16(is);
                        }
                    }
                    array = array22;
                    break;
                case 2:
                    int[] array23 = new int[nbComponent];
                    if (dataPadding == 0) {
                        for (int i4 = 0; i4 < nbComponent; i4++) {
                            array23[i4] = (byte) Stream_Read(is);
                        }
                    } else if (dataPadding == 1) {
                        for (int i5 = 0; i5 < nbComponent; i5++) {
                            array23[i5] = (short) Stream_Read16(is);
                        }
                    } else {
                        for (int i6 = 0; i6 < nbComponent; i6++) {
                            array23[i6] = Stream_Read32(is);
                        }
                    }
                    array = array23;
                    break;
                default:
                    switch (type & 3) {
                        case 0:
                            if (dataPadding == 2) {
                                genArray = (Object[]) new byte[nbComponent];
                                break;
                            } else {
                                genArray = new byte[nbComponent][];
                                break;
                            }
                        case 1:
                            if (dataPadding == 2) {
                                genArray = (Object[]) new short[nbComponent];
                                break;
                            } else {
                                genArray = new short[nbComponent][];
                                break;
                            }
                        default:
                            if (dataPadding == 2) {
                                genArray = (Object[]) new int[nbComponent];
                                break;
                            } else {
                                genArray = new int[nbComponent][];
                                break;
                            }
                    }
                    for (int i7 = 0; i7 < nbComponent; i7++) {
                        genArray[i7] = Mem_ReadArray(is);
                    }
                    array = genArray;
                    break;
            }
        } catch (Throwable th) {
        }
        return array;
    }

    static int Stream_Read(InputStream is) throws Throwable {
        int read = is.read();
        if (read >= 0) {
            Stream_readOffset++;
        }
        return read;
    }

    static int Stream_Read16(InputStream is) throws Throwable {
        return (Stream_Read(is) & 255) | ((Stream_Read(is) & 255) << 8);
    }

    static int Stream_Read32(InputStream is) throws Throwable {
        return (Stream_Read(is) & 255) | ((Stream_Read(is) & 255) << 8) | ((Stream_Read(is) & 255) << 16) | ((Stream_Read(is) & 255) << 24);
    }

    static int Stream_ReadFully(InputStream is, byte[] array, int offset, int length) {
        int off = offset;
        int len = length;
        while (len > 0) {
            try {
                int read = is.read(array, off, len);
                len -= read;
                off += read;
            } catch (Throwable th) {
            }
        }
        Stream_readOffset += length;
        return length;
    }

    int Text_GetPhoneDefaultLangage() {
        try {
            String lang = System.getProperty("microedition.locale");
            if (lang == null) {
                return 0;
            }
            String lang2 = lang.toUpperCase();
            if (lang2.indexOf(StrEN) >= 0) {
                return 0;
            }
            if (lang2.indexOf(StrDE) >= 0) {
                return 1;
            }
            if (lang2.indexOf(StrFR) >= 0) {
                return 2;
            }
            if (lang2.indexOf(StrIT) >= 0) {
                return 3;
            }
            if (lang2.indexOf(StrES) >= 0) {
                return 4;
            }
            if (lang2.indexOf(StrBR) >= 0) {
                return 5;
            }
            if (lang2.indexOf(StrPT) >= 0) {
                return 6;
            }
            if (lang2.indexOf("JA") >= 0 || lang2.indexOf(StrJP) >= 0) {
                return 7;
            }
            if (lang2.indexOf("ZH") >= 0 || lang2.indexOf(StrCN) >= 0) {
                return 8;
            }
            if (lang2.indexOf("KO") >= 0 || lang2.indexOf("KP") >= 0 || lang2.indexOf(StrKR) >= 0) {
                return 9;
            }
            if (lang2.indexOf(StrRU) >= 0) {
                return 10;
            }
            if (lang2.indexOf(StrPL) >= 0) {
                return 12;
            }
            if (lang2.indexOf(StrTR) >= 0) {
                return 11;
            }
            if (lang2.indexOf(StrCZ) >= 0) {
                return 13;
            }
            return lang2.indexOf(StrNL) >= 0 ? 14 : 0;
        } catch (Throwable th) {
            return 0;
        }
    }

    String Text_GetLanguageAsString(int languageCode) {
        switch (languageCode) {
            case 0:
                return StrEN;
            case 1:
                return StrDE;
            case 2:
                return StrFR;
            case 3:
                return StrIT;
            case 4:
                return StrES;
            case 5:
                return StrBR;
            case 6:
                return StrPT;
            case 7:
                return StrJP;
            case 8:
                return StrCN;
            case 9:
                return StrKR;
            case 10:
                return StrRU;
            case 11:
                return StrTR;
            case 12:
                return StrPL;
            case 13:
                return StrCZ;
            case 14:
                return StrNL;
            default:
                return null;
        }
    }

    private static int Text_LoadTextFromStream(InputStream is) {
        try {
            text_nbString = Stream_Read32(is);
            text_arrayOffset = new int[text_nbString + 1];
            for (int i = 1; i < text_nbString + 1; i++) {
                text_arrayOffset[i] = Stream_Read32(is);
            }
            text_array = new byte[text_arrayOffset[text_nbString]];
            Stream_ReadFully(is, text_array, 0, text_array.length);
        } catch (Throwable th) {
        }
        return text_array.length + ((text_nbString + 1) << 2);
    }

    static void Text_LoadTextFromPack(String filename, int index) {
        Text_FreeAll();
        Pack_Open(filename);
        Pack_PositionAtData(index);
        if (GLLibConfig.pack_supportLZMADecompression && s_pack_lastDataIsCompress) {
            byte[] data = Pack_ReadData(index);
            ByteArrayInputStream bis = new ByteArrayInputStream(data);
            Text_LoadTextFromStream(bis);
        } else {
            Text_LoadTextFromStream(s_pack_is);
        }
        Pack_Close();
        if (GLLibConfig.text_useStringCache) {
            Text_BuildStringCache();
        }
    }

    static void Text_LoadTextFromPack(String filename, int index1, int index2) {
        Text_FreeAll();
        Pack_Open(filename);
        Pack_PositionAtData(index1);
        if (GLLibConfig.pack_supportLZMADecompression && s_pack_lastDataIsCompress) {
            ByteArrayInputStream bis = new ByteArrayInputStream(Pack_ReadData(index1));
            Text_LoadTextFromStream(bis);
        } else {
            s_pack_curOffset += Text_LoadTextFromStream(s_pack_is);
        }
        int nbString1 = text_nbString;
        int[] arrayOffset1 = text_arrayOffset;
        byte[] arrayText1 = text_array;
        Text_FreeAll();
        Pack_PositionAtData(index2);
        if (GLLibConfig.pack_supportLZMADecompression && s_pack_lastDataIsCompress) {
            ByteArrayInputStream bis2 = new ByteArrayInputStream(Pack_ReadData(index2));
            Text_LoadTextFromStream(bis2);
        } else {
            s_pack_curOffset += Text_LoadTextFromStream(s_pack_is);
        }
        int nbString2 = text_nbString;
        int[] arrayOffset2 = text_arrayOffset;
        byte[] arrayText2 = text_array;
        for (int i = 1; i < nbString2 + 1; i++) {
            int i2 = i;
            arrayOffset2[i2] = arrayOffset2[i2] + arrayOffset1[nbString1];
        }
        Text_FreeAll();
        Pack_Close();
        text_nbString = nbString1 + nbString2;
        text_arrayOffset = new int[text_nbString + 1];
        System.arraycopy(arrayOffset1, 0, text_arrayOffset, 0, arrayOffset1.length);
        System.arraycopy(arrayOffset2, 1, text_arrayOffset, arrayOffset1.length, arrayOffset2.length - 1);
        text_array = new byte[text_arrayOffset[text_nbString]];
        System.arraycopy(arrayText1, 0, text_array, 0, arrayText1.length);
        System.arraycopy(arrayText2, 0, text_array, arrayText1.length, arrayText2.length);
        if (GLLibConfig.text_useStringCache) {
            Text_BuildStringCache();
        }
    }

    static final void Text_SetEncoding(String encoding) {
        text_encoding = encoding;
    }

    static String Text_FromUTF8(byte[] src, int offset, int len) {
        char[] buf = new char[len];
        int d = 0;
        int s = offset;
        int max = offset + len;
        while (s < max) {
            if ((src[s] & kNumFullDistances) == 0) {
                int i = d;
                d++;
                int i2 = s;
                s++;
                buf[i] = (char) src[i2];
            } else if ((src[s] & 224) == 224 && s + 2 < max && (src[s + 1] & IsRep) == kNumFullDistances && (src[s + 2] & IsRep) == kNumFullDistances) {
                int i3 = d;
                d++;
                buf[i3] = (char) (((src[s] & 15) << 12) | ((src[s + 1] & 63) << 6) | (src[s + 2] & 63));
                s += 3;
            } else if ((src[s] & IsRep) == IsRep && s + 1 < max && (src[s + 1] & IsRep) == kNumFullDistances) {
                int i4 = d;
                d++;
                buf[i4] = (char) (((src[s] & 31) << 6) | (src[s + 1] & 63));
                s += 2;
            } else {
                return "";
            }
        }
        return new String(buf, 0, d);
    }

    static String Text_GetString(int index) {
        if (GLLibConfig.text_useStringCache && text_stringCacheArray != null) {
            return text_stringCacheArray[index];
        }
        try {
            int l = text_arrayOffset[index + 1] - text_arrayOffset[index];
            if (l == 0) {
                return null;
            }
            if (GLLibConfig.text_useInternalUTF8Converter) {
                if (!text_encoding.equals("UTF-8")) {
                    return new String(text_array, text_arrayOffset[index], l, text_encoding);
                }
                System.out.println("Using manual UTF8!");
                return Text_FromUTF8(text_array, text_arrayOffset[index], l);
            }
            return new String(text_array, text_arrayOffset[index], l, text_encoding);
        } catch (Throwable th) {
            return null;
        }
    }

    static final int Text_GetNbString() {
        return text_nbString;
    }

    static void Text_BuildStringCache() {
        String[] text = new String[text_nbString];
        for (int i = 0; i < text_nbString; i++) {
            text[i] = Text_GetString(i);
        }
        text_stringCacheArray = text;
        text_arrayOffset = null;
        text_array = null;
        Gc();
    }

    static void Text_FreeAll() {
        if (text_stringCacheArray != null) {
            for (int i = 0; i < text_nbString; i++) {
                text_stringCacheArray[i] = null;
            }
            text_stringCacheArray = null;
        }
        text_arrayOffset = null;
        text_array = null;
        text_nbString = 0;
    }

    static String Text_FormatNumber(int p_iValue, int p_iLang) {
        if (p_iValue < 1000) {
            return new StringBuffer().append("").append(p_iValue).toString();
        }
        String sSeperator = "";
        switch (p_iLang) {
            case 0:
            case 7:
            case 8:
            case 9:
                sSeperator = ",";
                break;
            case 1:
            case 3:
            case 5:
            case 11:
                sSeperator = ".";
                break;
            case 2:
            case 4:
            case 10:
            case 13:
                if (p_iValue >= 10000) {
                    sSeperator = " ";
                    break;
                }
                break;
            case 6:
            case 12:
                sSeperator = " ";
                break;
            case 14:
                if (p_iValue >= 10000) {
                    sSeperator = ".";
                    break;
                }
                break;
            default:
                return new StringBuffer().append("").append(p_iValue).toString();
        }
        String sResult = "";
        int end = p_iValue % 1000 < 0 ? -(p_iValue % 1000) : p_iValue % 1000;
        int p_iValue2 = p_iValue / 1000;
        while (true) {
            if (end != 0 || p_iValue2 != 0) {
                if (end < 10) {
                    sResult = new StringBuffer().append("00").append(end < 0 ? -end : end).append(sResult).toString();
                } else if (end < 100) {
                    sResult = new StringBuffer().append("0").append(end < 0 ? -end : end).append(sResult).toString();
                } else {
                    sResult = new StringBuffer().append(end < 0 ? -end : end).append(sResult).toString();
                }
                end = p_iValue2 % 1000;
                p_iValue2 /= 1000;
                if (p_iValue2 != 0) {
                    sResult = new StringBuffer().append(sSeperator).append(sResult).toString();
                } else if (end != 0) {
                    sResult = new StringBuffer().append(end).append(sSeperator).append(sResult).toString();
                    end = 0;
                }
            } else {
                return sResult;
            }
        }
    }

    private static void Rms_Close() {
        if (s_rs == null) {
            return;
        }
        try {
            s_rs.closeRecordStore();
        } catch (RecordStoreException e) {
        }
        s_rs = null;
    }

    private static void Rms_Open(String strName) throws RecordStoreException {
        if (GLLibConfig.rms_useSharing && s_rms_vendor != null && s_rms_midletName != null) {
            s_rs = RecordStore.openRecordStore(strName, s_rms_vendor, s_rms_midletName);
        } else {
            s_rs = RecordStore.openRecordStore(strName, true);
        }
    }

    static byte[] Rms_Read(String strName) {
        byte[] data = null;
        try {
            Rms_Open(strName);
            if (s_rs.getNumRecords() > 0) {
                data = s_rs.getRecord(1);
            }
        } catch (RecordStoreException e) {
            data = null;
        }
        Rms_Close();
        return data;
    }

    static void Rms_Write(String strName, byte[] data) {
        try {
            Rms_Open(strName);
            if (s_rs.getNumRecords() > 0) {
                s_rs.setRecord(1, data, 0, data.length);
            } else {
                s_rs.addRecord(data, 0, data.length);
            }
        } catch (RecordStoreException e) {
        }
        Rms_Close();
    }

    private static InputStream GetRmsInputStream(String strName) {
        s_rms_buffer = null;
        try {
            s_rms_buffer = Rms_Read(strName);
        } catch (Throwable th) {
        }
        if (s_rms_buffer != null) {
            return new ByteArrayInputStream(s_rms_buffer);
        }
        return null;
    }

    static void InitSharedRms(String strVendor, String strMidletName) {
        s_rms_vendor = strVendor;
        s_rms_midletName = strMidletName;
    }

    static void Rms_WriteShared(String strName, String strVendor, String strMidletName, byte[] data) {
        InitSharedRms(strVendor, strMidletName);
        Rms_Write(strName, data);
        InitSharedRms(null, null);
    }

    static byte[] Rms_ReadShared(String strName, String strVendor, String strMidletName) {
        InitSharedRms(strVendor, strMidletName);
        byte[] data = Rms_Read(strName);
        InitSharedRms(null, null);
        return data;
    }

    static void Pack_OpenShared(String strName, String strVendor, String strMidletName) throws Throwable {
        InitSharedRms(strVendor, strMidletName);
        Pack_Open(strName);
    }

    static void Pack_CloseShared() throws Throwable {
        InitSharedRms(null, null);
        Pack_Close();
    }

    static void SavePack(String packName, String rmsName) {
        byte[] buffer = new byte[1024];
        try {
            InputStream is = s_gllib_instance.GetResourceAsStream(packName);
            int size = 0;
            for (int len = is.read(buffer, 0, 1024); len > 0; len = is.read(buffer, 0, 1024)) {
                size += len;
            }
            is.close();
            byte[] buffer2 = new byte[size];
            InputStream is2 = s_gllib_instance.GetResourceAsStream(packName);
            int off = 0;
            while (size > 0) {
                int len2 = is2.read(buffer2, off, size);
                off += len2;
                size -= len2;
            }
            is2.close();
            Rms_Write(rmsName, buffer2);
        } catch (Throwable th) {
        }
    }

    static void Profiler_Start() {
        if (s_profiler_eventNames == null) {
            s_profiler_eventNames = new String[PROFILER_MAX_EVENTS];
            s_profiler_eventBegins = new long[PROFILER_MAX_EVENTS];
            s_profiler_eventEnds = new long[PROFILER_MAX_EVENTS];
            s_profiler_eventDepths = new short[PROFILER_MAX_EVENTS];
            s_profiler_eventStack = new short[PROFILER_MAX_EVENTS];
        }
        s_profiler_eventCount = 0;
        s_profiler_eventStackIndex = 0;
        s_profiler_recording = true;
    }

    static void Profiler_End() {
        s_profiler_recording = false;
    }

    static void Profiler_Draw() {
        SetColor(0);
        FillRect(0, 0, GetScreenWidth(), s_profiler_eventCount * g.getFont().getHeight());
        SetColor(16777215);
        int y = 0;
        for (int i = 0; i < s_profiler_eventCount; i++) {
            g.drawString(s_profiler_eventNames[i], s_profiler_eventDepths[i] * 10, y, 0);
            g.drawString(Long.toString(s_profiler_eventEnds[i] - s_profiler_eventBegins[i]), GetScreenWidth() - 2, y, 24);
            y += g.getFont().getHeight();
        }
    }

    static void Profiler_BeginNamedEvent(String name) {
        if (s_profiler_recording) {
            s_profiler_eventNames[s_profiler_eventCount] = name;
            s_profiler_eventBegins[s_profiler_eventCount] = GetRealTime();
            s_profiler_eventDepths[s_profiler_eventCount] = (short) s_profiler_eventStackIndex;
            s_profiler_eventStack[s_profiler_eventStackIndex] = (short) s_profiler_eventCount;
            s_profiler_eventCount++;
            s_profiler_eventStackIndex++;
        }
    }

    static void Profiler_EndNamedEvent() {
        if (s_profiler_recording) {
            s_profiler_eventStackIndex--;
            s_profiler_eventEnds[s_profiler_eventStack[s_profiler_eventStackIndex]] = GetRealTime();
        }
    }

    public static void AlphaRect_SetColor(int p_iColor) {
        if (p_iColor != s_alphaRectCurrentARGB || ((GLLibConfig.alphaRectUseImage && s_alphaRectImage == null) || (!GLLibConfig.alphaRectUseImage && s_alphaRectARGBData == null))) {
            s_alphaRectCurrentARGB = p_iColor;
            if (GLLibConfig.alphaRectUseImage && GLLibConfig.alphaRectBufferSize * GLLibConfig.alphaRectBufferSize < GLLibConfig.TMP_BUFFER_SIZE) {
                s_alphaRectARGBData = ASprite.temp_int;
            }
            if (s_alphaRectARGBData == null) {
                s_alphaRectARGBData = new int[GLLibConfig.alphaRectBufferSize * GLLibConfig.alphaRectBufferSize];
            }
            int i = GLLibConfig.alphaRectBufferSize * GLLibConfig.alphaRectBufferSize;
            while (i > 0) {
                i--;
                s_alphaRectARGBData[i] = p_iColor;
            }
            if (GLLibConfig.alphaRectUseImage) {
                s_alphaRectImage = CreateRGBImage(s_alphaRectARGBData, GLLibConfig.alphaRectBufferSize, GLLibConfig.alphaRectBufferSize, true);
            }
        }
    }

    public static void AlphaRect_Draw(Graphics g2, int x, int y, int w, int h) {
        int cx = GetClipX();
        int cy = GetClipY();
        int cw = GetClipWidth();
        int ch = GetClipHeight();
        SetClip(x > cx ? x : cx, y > cy ? y : cy, (x + w < cx + cw ? x + w : cx + cw) - (x > cx ? x : cx), (y + h < cy + ch ? y + h : cy + ch) - (y > cy ? y : cy));
        int i = x;
        while (true) {
            int i2 = i;
            if (i2 < w + x) {
                int i3 = y;
                while (true) {
                    int j = i3;
                    if (j < h + y) {
                        if (GLLibConfig.alphaRectUseImage) {
                            g2.drawImage(s_alphaRectImage, i2, j, 0);
                        } else {
                            DrawRGB(g2, s_alphaRectARGBData, 0, GLLibConfig.alphaRectBufferSize, i2, j, GLLibConfig.alphaRectBufferSize, GLLibConfig.alphaRectBufferSize, true);
                        }
                        i3 = j + GLLibConfig.alphaRectBufferSize;
                    }
                }
                i = i2 + GLLibConfig.alphaRectBufferSize;
            } else {
                SetClip(cx, cy, cw, ch);
                return;
            }
        }
    }

    static final short PFX_BlurRBlock(int size, short[] buf, int amount, int initPixel) {
        return (short) 0;
    }

    static final short PFX_BlurLBlock(int size, short[] buf, int amount, int initPixel) {
        return (short) 0;
    }

    static final int PFX_ProcessAdditiveColumn(short[] src, int srcOff, short[] dst, int dstOff, int height, int width, int pixelToRed) {
        return 0;
    }

    static final int PFX_ProcessAdditiveColumnInverse(short[] src, int srcOff, short[] dst, int dstOff, int height, int width, int pixelToRed) {
        return 0;
    }

    static final int PFX_ProcessAdditiveLine(short[] src, int srcOff, short[] dst, int dstOff, int width, int pixelToRed) {
        return 0;
    }

    static final int PFX_ProcessAdditiveLineInverse(short[] src, int srcOff, short[] dst, int dstOff, int width, int pixelToRed) {
        return 0;
    }

    static final int PFX_ProcessMultiplicativeLine(short[] src, int srcOff, short[] dst, int dstOff, int width) {
        return 0;
    }

    static final int PFX_ProcessMultiplicativeLineInverse(short[] src, int srcOff, short[] dst, int dstOff, int width) {
        return 0;
    }

    static final void PFX_MultiplicativeBlock(int size, short[] buf, int color) {
    }

    static final short[] PFX_ProcessGrayscaleEffect(short[] src, short[] dst, int size, int alpha, boolean hasAlpha, boolean isAlphaSprite) {
        return src;
    }

    static final void PFX_ProcessGlowBlock(short[] src, short[] dst, int off2, int hspread, int vspread, int intensity, int w, int h, int offset) {
    }

    static final short[] PFX_ProcessBlend(short[] src, short[] dst, int size, int alpha, boolean hasAlpha, boolean isAlphaSprite) {
        return dst;
    }

    static final void PFX_ProcessBlendSimple(short[] buffer, int alpha, int size) {
    }

    static final short[] PFX_ProcessScaling(short[] src, short[] dst, int sWidth, int sHeight, int percent, int alpha, boolean hasAlpha, boolean isAlphaSprite) {
        return dst;
    }

    static final short[] PFX_ProcessShineEffect(short[] src, short[] dst, int posX, int posY, int sWidth, int sHeight, int flags, boolean isAlphaSprite) {
        return src;
    }

    static final short PFX_ComputeBlinkingColor(int period, short c1, short c2) {
        return (short) 0;
    }

    static final int PFX_BlurRBlock(int size, int[] buf, int amount, int initPixel) {
        int r1b1 = initPixel & 16711935;
        int g1 = initPixel & 65280;
        for (int k = size - 1; k >= 0; k--) {
            int c2 = buf[k];
            int r2b2 = c2 & 16711935;
            int g2 = c2 & 65280;
            r1b1 = (r2b2 + (((r1b1 - r2b2) * amount) >> 7)) & 16711935;
            g1 = (g2 + (((g1 - g2) * amount) >> 7)) & 65280;
            int color = r1b1 | g1;
            buf[k] = color;
        }
        return r1b1 | g1;
    }

    static final int PFX_BlurLBlock(int size, int[] buf, int amount, int initPixel) {
        int r1b1 = initPixel & 16711935;
        int g1 = initPixel & 65280;
        for (int k = 0; k < size; k++) {
            int c2 = buf[k];
            int r2b2 = c2 & 16711935;
            int g2 = c2 & 65280;
            r1b1 = (r2b2 + (((r1b1 - r2b2) * amount) >> 7)) & 16711935;
            g1 = (g2 + (((g1 - g2) * amount) >> 7)) & 65280;
            int color = r1b1 | g1;
            buf[k] = color;
        }
        return r1b1 | g1;
    }

    static final int PFX_ProcessAdditiveColumn(int[] src, int srcOff, int[] dst, int dstOff, int height, int width, int pixelToRed) {
        for (int x = height - 1; x >= 0; x--) {
            int c1 = src[srcOff];
            int c2 = dst[dstOff];
            int r1 = c1 & 16711680;
            int g1 = c1 & 65280;
            int b1 = c1 & 255;
            if (pixelToRed != 0 && ((r1 != 0 || g1 != 0) && b1 != 0)) {
                r1 += pixelToRed << 16;
                if (r1 > 16711680) {
                    r1 = 16711680;
                }
                b1 -= pixelToRed;
                if (b1 < 0) {
                    b1 = 0;
                }
            }
            int r2 = c2 & 16711680;
            int g2 = c2 & 65280;
            int b2 = c2 & 255;
            int rr = r1 + r2;
            if (rr > 16711680) {
                rr = 16711680;
            }
            int gg = g1 + g2;
            if (gg > 65280) {
                gg = 65280;
            }
            int bb = b1 + b2;
            if (bb > 255) {
                bb = 255;
            }
            dst[dstOff] = rr | gg | bb;
            srcOff -= width;
            dstOff++;
        }
        return dstOff;
    }

    static final int PFX_ProcessAdditiveColumnInverse(int[] src, int srcOff, int[] dst, int dstOff, int height, int width, int pixelToRed) {
        for (int x = height - 1; x >= 0; x--) {
            int c1 = src[srcOff];
            int c2 = dst[dstOff];
            int r1 = c1 & 16711680;
            int g1 = c1 & 65280;
            int b1 = c1 & 255;
            if (pixelToRed != 0 && ((r1 != 0 || g1 != 0) && b1 != 0)) {
                r1 += pixelToRed << 16;
                if (r1 > 16711680) {
                    r1 = 16711680;
                }
                b1 -= pixelToRed;
                if (b1 < 0) {
                    b1 = 0;
                }
            }
            int r2 = c2 & 16711680;
            int g2 = c2 & 65280;
            int b2 = c2 & 255;
            int rr = r1 + r2;
            if (rr > 16711680) {
                rr = 16711680;
            }
            int gg = g1 + g2;
            if (gg > 65280) {
                gg = 65280;
            }
            int bb = b1 + b2;
            if (bb > 255) {
                bb = 255;
            }
            dst[dstOff] = rr | gg | bb;
            srcOff += width;
            dstOff++;
        }
        return dstOff;
    }

    static final int PFX_ProcessAdditiveLine(int[] src, int srcOff, int[] dst, int dstOff, int width, int pixelToRed) {
        for (int x = width - 1; x >= 0; x--) {
            int c1 = src[srcOff];
            int c2 = dst[dstOff];
            int r1 = c1 & 16711680;
            int g1 = c1 & 65280;
            int b1 = c1 & 255;
            if (pixelToRed != 0 && ((r1 != 0 || g1 != 0) && b1 != 0)) {
                r1 += pixelToRed << 16;
                if (r1 > 16711680) {
                    r1 = 16711680;
                }
                b1 -= pixelToRed;
                if (b1 < 0) {
                    b1 = 0;
                }
            }
            int r2 = c2 & 16711680;
            int g2 = c2 & 65280;
            int b2 = c2 & 255;
            int rr = r1 + r2;
            if (rr > 16711680) {
                rr = 16711680;
            }
            int gg = g1 + g2;
            if (gg > 65280) {
                gg = 65280;
            }
            int bb = b1 + b2;
            if (bb > 255) {
                bb = 255;
            }
            dst[dstOff] = rr | gg | bb;
            srcOff++;
            dstOff++;
        }
        return dstOff;
    }

    static final int PFX_ProcessAdditiveLineInverse(int[] src, int srcOff, int[] dst, int dstOff, int width, int pixelToRed) {
        int srcOff2 = srcOff + (width - 1);
        for (int x = width - 1; x >= 0; x--) {
            int c1 = src[srcOff2];
            int c2 = dst[dstOff];
            int r1 = c1 & 16711680;
            int g1 = c1 & 65280;
            int b1 = c1 & 255;
            if (pixelToRed != 0 && ((r1 != 0 || g1 != 0) && b1 != 0)) {
                r1 += pixelToRed << 16;
                if (r1 > 16711680) {
                    r1 = 16711680;
                }
                b1 -= pixelToRed;
                if (b1 < 0) {
                    b1 = 0;
                }
            }
            int r2 = c2 & 16711680;
            int g2 = c2 & 65280;
            int b2 = c2 & 255;
            int rr = r1 + r2;
            if (rr > 16711680) {
                rr = 16711680;
            }
            int gg = g1 + g2;
            if (gg > 65280) {
                gg = 65280;
            }
            int bb = b1 + b2;
            if (bb > 255) {
                bb = 255;
            }
            dst[dstOff] = rr | gg | bb;
            srcOff2--;
            dstOff++;
        }
        return dstOff;
    }

    static final int PFX_ProcessMultiplicativeLine(int[] src, int srcOff, int[] dst, int dstOff, int width) {
        for (int x = width - 1; x >= 0; x--) {
            int c1 = src[srcOff];
            int c2 = dst[dstOff];
            int r1 = (c1 & 16711680) >> 16;
            int g1 = (c1 & 65280) >> 8;
            int b1 = c1 & 255;
            int r2 = (c2 & 16711680) >> 16;
            int g2 = (c2 & 65280) >> 8;
            int b2 = c2 & 255;
            int rr = ((r1 * r2) >> 6) + r2;
            if (rr > 255) {
                rr = 255;
            }
            int rr2 = rr << 16;
            int gg = ((g1 * g2) >> 6) + g2;
            if (gg > 255) {
                gg = 255;
            }
            int gg2 = gg << 8;
            int bb = ((b1 * b2) >> 6) + b2;
            if (bb > 255) {
                bb = 255;
            }
            dst[dstOff] = rr2 | gg2 | bb;
            srcOff++;
            dstOff++;
        }
        return dstOff;
    }

    static final int PFX_ProcessMultiplicativeLineInverse(int[] src, int srcOff, int[] dst, int dstOff, int width) {
        int srcOff2 = srcOff + (width - 1);
        for (int x = width - 1; x >= 0; x--) {
            int c1 = src[srcOff2];
            int c2 = dst[dstOff];
            int r1 = (c1 & 16711680) >> 16;
            int g1 = (c1 & 65280) >> 8;
            int b1 = c1 & 255;
            int r2 = (c2 & 16711680) >> 16;
            int g2 = (c2 & 65280) >> 8;
            int b2 = c2 & 255;
            int rr = ((r1 * r2) >> 6) + r2;
            if (rr > 255) {
                rr = 255;
            }
            int rr2 = rr << 16;
            int gg = ((g1 * g2) >> 6) + g2;
            if (gg > 255) {
                gg = 255;
            }
            int gg2 = gg << 8;
            int bb = ((b1 * b2) >> 6) + b2;
            if (bb > 255) {
                bb = 255;
            }
            dst[dstOff] = rr2 | gg2 | bb;
            srcOff2--;
            dstOff++;
        }
        return dstOff;
    }

    static final void PFX_MultiplicativeBlock(int size, int[] buf, int color) {
        int r1 = (color & 16711680) >> 16;
        int g1 = (color & 65280) >> 8;
        int b1 = color & 255;
        for (int k = 0; k < size; k++) {
            int c2 = buf[k];
            int r2 = (c2 & 16711680) >> 16;
            int g2 = (c2 & 65280) >> 8;
            int b2 = c2 & 255;
            int rr = ((r1 * r2) >> 6) + r2;
            if (rr > 255) {
                rr = 255;
            }
            int rr2 = rr << 16;
            int gg = ((g1 * g2) >> 6) + g2;
            if (gg > 255) {
                gg = 255;
            }
            int gg2 = gg << 8;
            int bb = ((b1 * b2) >> 6) + b2;
            if (bb > 255) {
                bb = 255;
            }
            buf[k] = rr2 | gg2 | bb;
        }
    }

    static final int[] PFX_ProcessGrayscaleEffect(int[] src, int[] dst, int size, int alpha, boolean hasAlpha, boolean isAlphaSprite) {
        int offset = size;
        if (alpha < 0) {
            if (isAlphaSprite || !hasAlpha) {
                while (offset != 0) {
                    offset--;
                    int c = src[offset];
                    int r = ((c & 16711680) >> 16) & 255;
                    dst[offset] = (c & (-65536)) | (r << 8) | r;
                }
            } else if (hasAlpha) {
                while (offset != 0) {
                    offset--;
                    int c2 = src[offset];
                    if ((c2 & 16711935) != 16711935) {
                        int r2 = ((c2 & 16711680) >> 16) & 255;
                        dst[offset] = (c2 & (-65536)) | (r2 << 8) | r2;
                    } else {
                        dst[offset] = 0;
                    }
                }
            }
        } else {
            m_PFX_hasAlpha = true;
            if (isAlphaSprite) {
                while (offset != 0) {
                    offset--;
                    int r3 = ((src[offset] & 16711680) >> 16) & 255;
                    int a = (src[offset] >> 24) & 255;
                    dst[offset] = ((((a * alpha) >> 8) & 255) << 24) | (r3 << 16) | (r3 << 8) | r3;
                }
            } else if (hasAlpha) {
                int alpha2 = alpha << 24;
                while (offset != 0) {
                    offset--;
                    int c3 = src[offset];
                    if ((c3 & 16711935) != 16711935) {
                        int r4 = ((c3 & 16711680) >> 16) & 255;
                        dst[offset] = alpha2 | (r4 << 16) | (r4 << 8) | r4;
                    } else {
                        dst[offset] = 0;
                    }
                }
            } else {
                int alpha3 = alpha << 24;
                while (offset != 0) {
                    offset--;
                    int r5 = ((src[offset] & 16711680) >> 16) & 255;
                    dst[offset] = alpha3 | (r5 << 16) | (r5 << 8) | r5;
                }
            }
        }
        return dst;
    }

    static final void PFX_ProcessGlowBlock(int[] src, int[] dst, int off2, int hspread, int vspread, int intensity, int w, int h, int offset) {
        int thresholdR = m_PFX_params[7][0];
        int thresholdG = m_PFX_params[7][1];
        int thresholdB = m_PFX_params[7][2];
        int r1b1 = 0;
        int g1 = 0;
        for (int j = 0; j < h; j++) {
            int pos = j * w;
            int pos2 = pos + offset;
            for (int i = w - 1; i >= 0; i--) {
                int c2 = src[pos2 + i];
                int r2b2 = c2 & 16711935;
                int g2 = c2 & 65280;
                int b2 = c2 & 255;
                if (r2b2 > thresholdR && g2 > thresholdG && b2 > thresholdB) {
                    r2b2 = 0;
                    g2 = 0;
                }
                r1b1 = (r2b2 + (((r1b1 - r2b2) * hspread) >> 7)) & 16711935;
                g1 = (g2 + (((g1 - g2) * hspread) >> 7)) & 65280;
                dst[pos + i] = r1b1 | g1;
            }
            for (int i2 = 0; i2 < w; i2++) {
                int c22 = dst[pos + i2];
                int r2b22 = c22 & 16711935;
                int g22 = c22 & 65280;
                r1b1 = (r2b22 + (((r1b1 - r2b22) * hspread) >> 7)) & 16711935;
                g1 = (g22 + (((g1 - g22) * hspread) >> 7)) & 65280;
                dst[pos + i2] = r1b1 | g1;
            }
        }
        for (int i3 = 0; i3 < w; i3++) {
            int pos3 = i3;
            for (int j2 = h - 1; j2 >= 0; j2--) {
                int c23 = dst[pos3];
                int r2b23 = c23 & 16711935;
                int g23 = c23 & 65280;
                r1b1 = (r2b23 + (((r1b1 - r2b23) * vspread) >> 7)) & 16711935;
                g1 = (g23 + (((g1 - g23) * vspread) >> 7)) & 65280;
                dst[pos3] = r1b1 | g1;
                pos3 += w;
            }
            for (int j3 = 0; j3 < h; j3++) {
                int c24 = dst[pos3];
                int r2b24 = c24 & 16711935;
                int g24 = c24 & 65280;
                r1b1 = (r2b24 + (((r1b1 - r2b24) * vspread) >> 7)) & 16711935;
                g1 = (g24 + (((g1 - g24) * vspread) >> 7)) & 65280;
                dst[pos3] = r1b1 | g1;
                pos3 -= w;
            }
        }
        int intensity2 = (intensity * intensity) >> m_PFX_params[7][13];
        for (int j4 = 0; j4 < h; j4++) {
            int pos4 = j4 * w;
            int pos22 = pos4 + offset;
            int pos32 = pos4 + off2;
            for (int i4 = w - 1; i4 >= 0; i4--) {
                int c1 = dst[pos4 + i4];
                int c25 = src[pos22 + i4];
                int r1 = (c1 >> 16) & 255;
                int g12 = (c1 >> 8) & 255;
                int b1 = c1 & 255;
                int r12 = ((r1 * intensity2) >> 8) << 16;
                int g13 = ((g12 * intensity2) >> 8) << 8;
                int b12 = (b1 * intensity2) >> 8;
                int r2 = c25 & 16711680;
                int g25 = c25 & 65280;
                int b22 = c25 & 255;
                int rr = r12 + r2;
                if (rr > 16711680) {
                    rr = 16711680;
                }
                int gg = g13 + g25;
                if (gg > 65280) {
                    gg = 65280;
                }
                int bb = b12 + b22;
                if (bb > 255) {
                    bb = 255;
                }
                src[pos32 + i4] = rr | gg | bb;
            }
        }
    }

    static final int[] PFX_ProcessBlend(int[] src, int[] dst, int size, int alpha, boolean hasAlpha, boolean isAlphaSprite) {
        int alpha2 = (alpha < 0 ? 0 : alpha > 255 ? 255 : alpha) & 255;
        if (isAlphaSprite) {
            while (size > 0) {
                size--;
                int a = (src[size] >> 24) & 255;
                dst[size] = (src[size] & 16777215) | ((((a * alpha2) >> 8) & 255) << 24);
            }
        } else if (hasAlpha) {
            int alpha3 = alpha2 << 24;
            while (size > 0) {
                size--;
                if ((src[size] & 16777215) != 16711935) {
                    dst[size] = (src[size] & 16777215) | alpha3;
                } else {
                    dst[size] = 0;
                }
            }
        } else {
            int alpha4 = alpha2 << 24;
            while (size > 0) {
                size--;
                dst[size] = (src[size] & 16777215) | alpha4;
            }
        }
        m_PFX_hasAlpha = true;
        return dst;
    }

    static final void PFX_ProcessBlendSimple(int[] buffer, int alpha, int size) {
        int alpha2 = (alpha << 24) & (-16777216);
        for (int iPixel = size - 1; iPixel >= 0; iPixel--) {
            buffer[iPixel] = alpha2 | (buffer[iPixel] & 16777215);
        }
    }

    static final int[] PFX_ProcessScaling(int[] src, int[] dst, int sWidth, int sHeight, int percent, int alpha, boolean hasAlpha, boolean isAlphaSprite) {
        int size = src.length;
        int offset = 0;
        int dWidth = ((sWidth * percent) / 100) + 1;
        int dHeight = ((sHeight * percent) / 100) + 1;
        if (alpha < 0) {
            for (int j = 0; j < dHeight; j++) {
                int valH = PFX_Scale_GetNum(j, sHeight, dHeight) * sWidth;
                for (int i = 0; i < dWidth; i++) {
                    int valPos = valH + PFX_Scale_GetNum(i, sWidth, dWidth);
                    if (valPos < size) {
                        int i2 = offset;
                        offset++;
                        dst[i2] = src[valPos];
                    } else {
                        int i3 = offset;
                        offset++;
                        dst[i3] = 0;
                    }
                }
            }
        } else if (!isAlphaSprite && !hasAlpha) {
            int alpha2 = alpha << 24;
            for (int j2 = 0; j2 < dHeight; j2++) {
                int valH2 = PFX_Scale_GetNum(j2, sHeight, dHeight) * sWidth;
                for (int i4 = 0; i4 < dWidth; i4++) {
                    int valPos2 = valH2 + PFX_Scale_GetNum(i4, sWidth, dWidth);
                    if (valPos2 < size) {
                        int i5 = offset;
                        offset++;
                        dst[i5] = alpha2 | (src[valPos2] & 16777215);
                    } else {
                        int i6 = offset;
                        offset++;
                        dst[i6] = 0;
                    }
                }
            }
            m_PFX_hasAlpha = true;
        } else if (!isAlphaSprite && hasAlpha) {
            int alpha3 = alpha << 24;
            for (int j3 = 0; j3 < dHeight; j3++) {
                int valH3 = PFX_Scale_GetNum(j3, sHeight, dHeight) * sWidth;
                for (int i7 = 0; i7 < dWidth; i7++) {
                    int valPos3 = valH3 + PFX_Scale_GetNum(i7, sWidth, dWidth);
                    if (valPos3 < size) {
                        int color = src[valPos3] & 16777215;
                        if (color != 16711935) {
                            int i8 = offset;
                            offset++;
                            dst[i8] = alpha3 | color;
                        } else {
                            int i9 = offset;
                            offset++;
                            dst[i9] = 0;
                        }
                    } else {
                        int i10 = offset;
                        offset++;
                        dst[i10] = 0;
                    }
                }
            }
            m_PFX_hasAlpha = true;
        } else {
            for (int j4 = 0; j4 < dHeight; j4++) {
                int valH4 = PFX_Scale_GetNum(j4, sHeight, dHeight) * sWidth;
                for (int i11 = 0; i11 < dWidth; i11++) {
                    int valPos4 = valH4 + PFX_Scale_GetNum(i11, sWidth, dWidth);
                    if (valPos4 < size) {
                        int a = (src[valPos4] >> 24) & 255;
                        int i12 = offset;
                        offset++;
                        dst[i12] = ((((a * alpha) >> 8) & 255) << 24) | (src[valPos4] & 16777215);
                    } else {
                        int i13 = offset;
                        offset++;
                        dst[i13] = 0;
                    }
                }
            }
            m_PFX_hasAlpha = true;
        }
        m_PFX_sizeX = dWidth;
        m_PFX_sizeY = dHeight;
        return dst;
    }

    static final int[] PFX_ProcessShineEffect(int[] src, int[] dst, int posX, int posY, int sWidth, int sHeight, int flags, boolean isAlphaSprite) {
        if (GLLibConfig.pfx_useSpriteEffectShine) {
            int shinePos = m_PFX_params[6][1];
            int shineWidth = m_PFX_params[6][2];
            int i = m_PFX_params[6][3] & 16777215;
            int sPos = 0;
            PFX_WritePixelData(src, 0, sWidth, posX, posY, sWidth, sHeight, true);
            if (!isAlphaSprite) {
                for (int j = 0; j < sHeight; j++) {
                    for (int i2 = 0; i2 < sWidth; i2++) {
                        int alphaValue = 0;
                        if (i2 > shinePos && i2 < shinePos + shineWidth && (src[sPos] & (-16777216)) != 0 && (src[sPos] & 16777215) != 0) {
                            alphaValue = 255 - (((i2 - (shinePos + (shineWidth >> 1)) < 0 ? -(i2 - (shinePos + (shineWidth >> 1))) : i2 - (shinePos + (shineWidth >> 1))) << 8) / (shineWidth >> 1));
                        }
                        dst[sPos] = ((alphaValue & 255) << 24) | 16777215;
                        sPos++;
                    }
                }
            } else {
                for (int j2 = 0; j2 < sHeight; j2++) {
                    for (int i3 = 0; i3 < sWidth; i3++) {
                        int alphaValue2 = 0;
                        if (i3 > shinePos && i3 < shinePos + shineWidth && (src[sPos] & (-16777216)) != 0 && (src[sPos] & 16777215) != 0) {
                            alphaValue2 = 255 - (((i3 - (shinePos + (shineWidth >> 1)) < 0 ? -(i3 - (shinePos + (shineWidth >> 1))) : i3 - (shinePos + (shineWidth >> 1))) << 8) / (shineWidth >> 1));
                        }
                        int alphaFinal = (src[sPos] >> 24) & 255;
                        dst[sPos] = ((((alphaFinal * alphaValue2) >> 8) & 255) << 24) | 16777215;
                        sPos++;
                    }
                }
            }
            m_PFX_hasAlpha = true;
            return dst;
        }
        return null;
    }

    static final int PFX_ComputeBlinkingColor(int period, int c1, int c2) {
        int angle = Math_FixedPoint_Multiply(m_PFX_timer * 360, period) >> 10;
        int i = Math_Sin(angle);
        int i2 = i < 0 ? -i : i;
        int a1 = (c1 >> 24) & 255;
        int r1 = (c1 >> 16) & 255;
        int g1 = (c1 >> 8) & 255;
        int b1 = c1 & 255;
        int a2 = (c2 >> 24) & 255;
        int r2 = (c2 >> 16) & 255;
        int g2 = (c2 >> 8) & 255;
        int b2 = c2 & 255;
        int a = a1 + Math_FixedPointToInt((a2 - a1) * i2);
        int r = r1 + Math_FixedPointToInt((r2 - r1) * i2);
        int g3 = g1 + Math_FixedPointToInt((g2 - g1) * i2);
        int b = b1 + Math_FixedPointToInt((b2 - b1) * i2);
        return ((a & 255) << 24) | ((r & 255) << 16) | ((g3 & 255) << 8) | (b & 255);
    }

    private static final void PFX_ReadPixelData(int[] buffer, int offset, int scanlength, int x, int y, int w, int h) {
        if (GLLibConfig.pfx_useScreenBuffer) {
            m_PFX_screenBuffer.getRGB(buffer, offset, scanlength, x, y, w, h);
        }
    }

    private static final void PFX_ReadPixelData(short[] buffer, int offset, int scanlength, int x, int y, int w, int h) {
    }

    private static final void PFX_WritePixelData(int[] source, int offset, int scanlength, int x, int y, int w, int h, boolean alpha) {
        if (GLLibConfig.useDrawPartialRGB) {
            drawPartialRGB(g, source, scanlength, 0, 0, x, y, w, h, alpha);
        } else {
            g.drawRGB(source, offset, scanlength, x, y, w, h, alpha);
        }
    }

    private static final void PFX_WritePixelData(short[] source, int offset, int scanlength, int x, int y, int w, int h, boolean alpha) {
    }

    /* JADX WARN: Type inference failed for: r0v7, types: [int[], int[][]] */
    static final void PFX_Init() {
        m_PFX_type = 0;
        m_PFX_timer = 0;
        m_PFX_windowX = 0;
        m_PFX_windowY = 0;
        m_PFX_windowWidth = GetScreenWidth();
        m_PFX_windowHeight = GetScreenHeight();
        m_PFX_params = new int[10];
        if (GLLibConfig.pfx_useEffectFullScreenBlur) {
            m_PFX_params[0] = new int[5];
            m_PFX_params[0][4] = 250;
        }
        if (GLLibConfig.pfx_useEffectFullScreenBlend) {
            m_PFX_params[1] = new int[6];
            m_PFX_params[1][3] = 250;
        }
        if (GLLibConfig.pfx_useSpriteEffectGrayscale) {
            m_PFX_params[5] = new int[2];
            m_PFX_params[5][1] = -1;
            m_PFX_params[5][0] = -1;
        }
        if (GLLibConfig.pfx_useSpriteEffectShine) {
            m_PFX_params[6] = new int[4];
            m_PFX_params[6][1] = 0;
            m_PFX_params[6][2] = 40;
            m_PFX_params[6][3] = 16777215;
            m_PFX_params[6][0] = -1;
        }
        if (GLLibConfig.pfx_useSpriteEffectGlow) {
            m_PFX_params[7] = new int[19];
            m_PFX_params[7][0] = 11272192;
            m_PFX_params[7][1] = 26624;
            m_PFX_params[7][2] = 2;
            m_PFX_params[7][3] = 15;
            m_PFX_params[7][4] = 2;
            m_PFX_params[7][5] = Math_IntToFixedPoint(1);
            m_PFX_params[7][6] = Math_IntToFixedPoint(2);
            m_PFX_params[7][7] = 4;
            m_PFX_params[7][8] = 4;
            m_PFX_params[7][9] = 16;
            m_PFX_params[7][10] = 112;
            m_PFX_params[7][11] = 64;
            m_PFX_params[7][12] = 72;
            m_PFX_params[7][13] = 3;
        }
        if (GLLibConfig.pfx_useSpriteEffectBlend) {
            m_PFX_params[8] = new int[6];
            m_PFX_params[8][1] = 255;
            m_PFX_params[8][0] = -1;
        }
        if (GLLibConfig.pfx_useSpriteEffectScale) {
            m_PFX_params[9] = new int[3];
            m_PFX_params[9][1] = 100;
            m_PFX_params[9][2] = -1;
            m_PFX_params[9][0] = -1;
        }
        if (GLLibConfig.pfx_useScreenBuffer) {
            m_PFX_screenBuffer = Image.createImage(GetScreenWidth(), GetScreenHeight());
            m_PFX_screenBufferG = m_PFX_screenBuffer.getGraphics();
        }
        m_PFX_enableScreenBuffer = 0;
        m_PFX_initializd = true;
    }

    static final void PFX_Release() {
        m_PFX_screenBuffer = null;
        m_PFX_screenBufferG = null;
        for (int i = 0; i < 10; i++) {
            m_PFX_params[i] = null;
        }
        m_PFX_params = (int[][]) null;
    }

    static final boolean PFX_IsScreenBuffered() {
        return m_PFX_screenIsBuffered;
    }

    static final Graphics PFX_GetReadableGraphics() {
        return m_PFX_screenBufferG;
    }

    static final void PFX_EnableScreenBufferThisFrame() {
        m_PFX_enableScreenBufferThisFrame = 1;
    }

    static final void PFX_EnableScreenBuffer(int effect) {
        m_PFX_enableScreenBuffer |= 1 << effect;
    }

    static final void PFX_DisableScreenBuffer(int effect) {
        m_PFX_enableScreenBuffer &= (1 << effect) ^ (-1);
    }

    static final void PFX_DisableAllScreenBuffer() {
        m_PFX_enableScreenBuffer = 0;
    }

    static final boolean PFX_NeedScreenBufferThisFrame() {
        return (m_PFX_enableScreenBufferThisFrame == 0 && m_PFX_enableScreenBuffer == 0) ? false : true;
    }

    static final void PFX_EnableEffect(int effect) {
        m_PFX_type |= 1 << effect;
        if (!GLLibConfig.pfx_useScreenBuffer) {
            m_PFX_type &= -160;
        }
        if (((1 << effect) & 7) != 0) {
            PFX_EnableScreenBuffer(effect);
        }
        if (effect != 9 || GLLibConfig.pfx_useSpriteEffectScale) {
            if (effect != 8 || GLLibConfig.pfx_useSpriteEffectBlend) {
                if (effect != 5 || GLLibConfig.pfx_useSpriteEffectGrayscale) {
                    if (effect != 6 || GLLibConfig.pfx_useSpriteEffectShine) {
                        if ((effect != 3 || GLLibConfig.pfx_useSpriteEffectAdditive) && effect == 4 && !GLLibConfig.pfx_useSpriteEffectMultiplicative) {
                        }
                    }
                }
            }
        }
    }

    static final void PFX_DisableEffect(int effect) {
        if (GLLibConfig.pfx_useEffectFullScreenBlur && effect == 0 && m_PFX_params[0][3] != 3) {
            if (m_PFX_params[0][3] < 2) {
                m_PFX_params[0][3] = 2;
                return;
            }
            return;
        }
        m_PFX_type &= (1 << effect) ^ (-1);
        if (((1 << effect) & 7) != 0) {
            PFX_DisableScreenBuffer(effect);
        }
        if (GLLibConfig.pfx_useEffectFullScreenBlend && effect == 1) {
            m_PFX_screenIsBuffered = false;
        }
    }

    static final boolean PFX_IsEffectEnabled(int effect) {
        return (m_PFX_type & (1 << effect)) != 0;
    }

    static final void PFX_DisableAllEffects() {
        m_PFX_type = 0;
    }

    static final void PFX_DisableAllSpriteEffects() {
        m_PFX_type &= -889;
    }

    static final void PFX_SetParam(int effectId, int paramId, int value) {
        m_PFX_params[effectId][paramId] = value;
    }

    static final int PFX_GetParam(int effectId, int paramId) {
        return m_PFX_params[effectId][paramId];
    }

    static final void PFX_Update(int deltaT) {
        if (GLLibConfig.pfx_useEffectFullScreenBlur && PFX_IsEffectEnabled(0)) {
            int amount = m_PFX_params[0][2];
            if (m_PFX_params[0][3] == 0) {
                if (amount < m_PFX_params[0][1]) {
                    int amount2 = amount + (m_PFX_params[0][4] * deltaT);
                    if (amount2 >= m_PFX_params[0][1]) {
                        amount2 = m_PFX_params[0][1];
                        m_PFX_params[0][3] = 1;
                    }
                    m_PFX_params[0][2] = amount2;
                }
            } else if (m_PFX_params[0][3] == 2 && amount > 0) {
                int amount3 = amount - (m_PFX_params[0][4] * deltaT);
                if (amount3 <= 0) {
                    amount3 = 0;
                    m_PFX_params[0][3] = 3;
                    PFX_DisableEffect(0);
                }
                m_PFX_params[0][2] = amount3;
            }
        }
        if (GLLibConfig.pfx_useEffectFullScreenBlend && PFX_IsEffectEnabled(1)) {
            if (m_PFX_params[1][5] != 0) {
                if (m_PFX_params[1][5] > 0) {
                    int[] iArr = m_PFX_params[1];
                    iArr[5] = iArr[5] - 1;
                }
                m_PFX_screenIsBuffered = false;
                PFX_EnableScreenBufferThisFrame();
            } else {
                m_PFX_screenIsBuffered = true;
            }
            int amount4 = m_PFX_params[1][1];
            if (m_PFX_params[1][2] == 0) {
                if (amount4 < m_PFX_params[1][0]) {
                    int amount5 = amount4 + (m_PFX_params[1][3] * deltaT);
                    if (amount5 >= m_PFX_params[1][0]) {
                        amount5 = m_PFX_params[1][0];
                        m_PFX_params[1][2] = 1;
                        PFX_DisableEffect(1);
                    }
                    m_PFX_params[1][1] = amount5;
                }
            } else if (m_PFX_params[1][2] == 2 && amount4 > 0) {
                int amount6 = amount4 - (m_PFX_params[1][3] * deltaT);
                if (amount6 <= 0) {
                    amount6 = 0;
                    m_PFX_params[1][2] = 3;
                    PFX_DisableEffect(1);
                }
                m_PFX_params[1][1] = amount6;
            }
        }
        if (PFX_NeedScreenBufferThisFrame() && GLLibConfig.pfx_useScreenBuffer) {
            Graphics graphics = m_PFX_screenBufferG;
            s_lastPaintGraphics = graphics;
            g = graphics;
        }
        m_PFX_timer += deltaT;
    }

    static final void PFX_SetFullScreenEffectWindow(int x, int y, int w, int h) {
        if (GLLibConfig.pfx_useEffectFullScreenBlur || GLLibConfig.pfx_useEffectFullScreenBlend) {
            m_PFX_windowX = x;
            m_PFX_windowY = y;
            m_PFX_windowWidth = w;
            m_PFX_windowHeight = h;
        }
    }

    static final void PFX_SetBlurEffect(int initialAmount, int maxAmount, int direction) {
        if (GLLibConfig.pfx_useEffectFullScreenBlur) {
            if (m_PFX_params == null) {
            }
            m_PFX_params[0][0] = direction;
            m_PFX_params[0][1] = (maxAmount < 0 ? 0 : maxAmount > kNumFullDistances ? kNumFullDistances : maxAmount) << 10;
            m_PFX_params[0][2] = (initialAmount < 0 ? 0 : initialAmount > kNumFullDistances ? kNumFullDistances : initialAmount) << 10;
            m_PFX_params[0][3] = 0;
        }
    }

    static void PFX_ApplyFullScreenBlur(Graphics g2) {
        if (!GLLibConfig.pfx_useEffectFullScreenBlur || (m_PFX_type & 1) == 0) {
            return;
        }
        PFX_ApplyFullScreenBlur(g2, ASprite.GetPixelBuffer_int(null));
    }

    static final void PFX_SetBlendEffect(int initialAmount, int maxAmount, int repaintNum) {
        if (GLLibConfig.pfx_useEffectFullScreenBlend) {
            if (m_PFX_params == null) {
            }
            int initialAmount2 = (initialAmount < 0 ? 0 : initialAmount > 255 ? 255 : initialAmount) << 10;
            int maxAmount2 = (maxAmount < 0 ? 0 : maxAmount > 255 ? 255 : maxAmount) << 10;
            m_PFX_params[1][1] = initialAmount2;
            m_PFX_params[1][0] = maxAmount2;
            m_PFX_params[1][2] = maxAmount2 > initialAmount2 ? 0 : 2;
            m_PFX_params[1][5] = repaintNum;
        }
    }

    static final void PFX_PaintFullScreenBlend(Graphics g2) {
        if (GLLibConfig.pfx_useEffectFullScreenBlend) {
            PFX_PaintFullScreenBlend(g2, null);
        }
    }

    static final void PFX_PaintFullScreenBlend(Graphics g2, Image bottomBuffer) {
        if (!GLLibConfig.pfx_useEffectFullScreenBlend || (m_PFX_type & 2) == 0) {
            return;
        }
        PFX_PaintFullScreenBlend(g2, bottomBuffer, ASprite.GetPixelBuffer_int(null));
    }

    static final void PFX_ApplyFullScreenMultiplicative(Graphics g2, int color) {
        if (!GLLibConfig.pfx_useEffectFullScreenMultiplicative || (m_PFX_type & 4) == 0) {
            return;
        }
        PFX_ApplyFullScreenMultiplicative(g2, color, ASprite.GetPixelBuffer_int(null));
    }

    static final int PFX_ComputeBlinkingValue(int period, int v1, int v2) {
        int angle = Math_FixedPoint_Multiply(m_PFX_timer * 360, period) >> 10;
        int d = (v2 - v1) >> 1;
        return v1 + d + Math_FixedPointToInt(d * Math_Sin(angle));
    }

    static final void PFX_InitGlowArea(int x, int y, int w, int h) {
        if (GLLibConfig.pfx_useSpriteEffectGlow) {
            m_PFX_params[7][14] = x - m_PFX_params[7][3];
            m_PFX_params[7][15] = y - m_PFX_params[7][4];
            m_PFX_params[7][16] = w + (m_PFX_params[7][3] << 1);
            m_PFX_params[7][17] = h + (m_PFX_params[7][4] << 1);
            m_PFX_params[7][18] = m_PFX_params[7][16] * (m_PFX_params[7][17] + 4);
            int size = 3 * m_PFX_params[7][18];
            PFX_InitGlowArea(size, ASprite.GetPixelBuffer_int(null));
        }
    }

    static final int[] PFX_ProcessSpriteEffects(Image img, int x, int y, int w, int h, int flags, boolean hasAlpha, boolean multiAlpha) {
        int[] buffer = ASprite.GetPixelBuffer_int(null);
        img.getRGB(buffer, 0, w, 0, 0, w, h);
        return PFX_ProcessSpriteEffects(buffer, x, y, w, h, flags, hasAlpha, multiAlpha);
    }

    static final void PFX_ApplyGlow(Graphics g2) {
        if (GLLibConfig.pfx_useSpriteEffectGlow) {
            int hspread = PFX_ComputeBlinkingValue(m_PFX_params[7][6], m_PFX_params[7][7], m_PFX_params[7][10]);
            int vspread = PFX_ComputeBlinkingValue(m_PFX_params[7][5], m_PFX_params[7][8], m_PFX_params[7][11]);
            int intensity = PFX_ComputeBlinkingValue(m_PFX_params[7][5], m_PFX_params[7][9], m_PFX_params[7][12]);
            int offset = m_PFX_params[7][18] << 1;
            PFX_ApplyGlow(g2, offset, hspread, vspread, intensity, ASprite.GetPixelBuffer_int(null));
        }
    }

    static final int PFX_Scale_GetNum(int num, int des, int src) {
        return (num * des) / src;
    }

    private static final boolean PFX_UpdateMultiAlpha(boolean currentMultiAlpha, int param) {
        if (param == 1) {
            return false;
        }
        if (param == 2) {
            return true;
        }
        return currentMultiAlpha;
    }

    static final int[] PFX_ProcessSpriteEffects(int[] source, int x, int y, int w, int h, int flags, boolean hasAlpha, boolean multiAlpha) {
        m_PFX_hasAlpha = hasAlpha;
        m_PFX_sizeX = w;
        m_PFX_sizeY = h;
        if ((m_PFX_type & GLPixEffects.k_EFFECTS_SPRITE_NEED_TRANSFORM_MASK) != 0) {
            if ((flags & 4) != 0) {
                m_PFX_sizeX = h;
                m_PFX_sizeY = w;
                w = m_PFX_sizeX;
                h = m_PFX_sizeY;
            }
            source = ASprite.TransformRGB(source, w, h, flags);
        }
        int[] pixelBuffer = ASprite.GetPixelBuffer_int(source);
        if ((m_PFX_type & 512) != 0) {
            if (GLLibConfig.pfx_useSpriteEffectScale) {
                return PFX_ProcessScaling(source, pixelBuffer, w, h, m_PFX_params[9][1], m_PFX_params[9][2], hasAlpha, PFX_UpdateMultiAlpha(multiAlpha, m_PFX_params[9][0]));
            }
            return null;
        }
        if ((m_PFX_type & kLenNumHighSymbols) != 0) {
            if (GLLibConfig.pfx_useSpriteEffectBlend) {
                return PFX_ProcessBlend(source, pixelBuffer, w * h, m_PFX_params[8][1], hasAlpha, PFX_UpdateMultiAlpha(multiAlpha, m_PFX_params[8][0]));
            }
            return null;
        }
        if ((m_PFX_type & 32) != 0) {
            if (GLLibConfig.pfx_useSpriteEffectGrayscale) {
                return PFX_ProcessGrayscaleEffect(source, pixelBuffer, w * h, m_PFX_params[5][1], hasAlpha, PFX_UpdateMultiAlpha(multiAlpha, m_PFX_params[5][0]));
            }
            return null;
        }
        if ((m_PFX_type & 64) != 0) {
            if (GLLibConfig.pfx_useSpriteEffectShine) {
                return PFX_ProcessShineEffect(source, pixelBuffer, x, y, w, h, flags, PFX_UpdateMultiAlpha(multiAlpha, m_PFX_params[6][0]));
            }
            return null;
        }
        if ((m_PFX_type & 8) != 0) {
            if (GLLibConfig.pfx_useSpriteEffectAdditive) {
                return PFX_ProcessPixelEffect(source, pixelBuffer, x, y, w, h, flags, (m_PFX_type & 8) != 0, (m_PFX_type & 16) != 0, true);
            }
            return null;
        }
        if ((m_PFX_type & 16) == 0 || !GLLibConfig.pfx_useSpriteEffectMultiplicative) {
            return null;
        }
        return PFX_ProcessPixelEffect(source, pixelBuffer, x, y, w, h, flags, (m_PFX_type & 8) != 0, (m_PFX_type & 16) != 0, true);
    }

    public static final int[] PFX_ProcessPixelEffect(int[] source, int[] buffer, int posX, int posY, int sWidth, int sHeight, int flags, boolean bAdditive, boolean bMultiplicative, boolean bReadPixels) {
        int sourcePos;
        int srcX = 0;
        int srcY = 0;
        int width = sWidth;
        int height = sHeight;
        int cx = g.getClipX();
        int cy = g.getClipY();
        int cw = g.getClipWidth();
        int ch = g.getClipHeight();
        if ((flags & 4) != 0) {
            width = sHeight;
            height = sWidth;
        }
        int widthClipped = width;
        int heightClipped = height;
        if (posY + heightClipped > ch + cy) {
            heightClipped = (ch + cy) - posY;
        }
        if (posX + widthClipped > cw + cx) {
            widthClipped = (cw + cx) - posX;
        }
        if (posX < cx) {
            srcX = cx - posX;
            widthClipped = width - srcX;
            posX = 0;
        }
        if (posY < cy) {
            srcY = cy - posY;
            heightClipped = height - srcY;
            posY = 0;
        }
        if (width <= 0) {
            return source;
        }
        if (height <= 0) {
            return source;
        }
        int i = height * (width + 1);
        if (bReadPixels) {
            PFX_ReadPixelData(buffer, 0, widthClipped, posX, posY, widthClipped, heightClipped);
        }
        if (widthClipped != width || heightClipped != height) {
            for (int i2 = heightClipped - 1; i2 >= 0; i2--) {
                System.arraycopy(buffer, i2 * widthClipped, buffer, srcX + ((i2 + srcY) * width), widthClipped);
            }
        }
        int pos = 0;
        if ((flags & 4) != 0) {
            int xStart = 0;
            int xEnd = height;
            int xDiferential = 1;
            if ((flags & 1) != 0) {
                xStart = height - 1;
                xEnd = -1;
                xDiferential = -1;
            }
            int i3 = xStart;
            while (true) {
                int x = i3;
                if (x == xEnd) {
                    break;
                }
                if ((flags & 2) != 0) {
                    sourcePos = x;
                } else {
                    sourcePos = x + ((width - 1) * height);
                }
                int dstPos = 0;
                if (bAdditive) {
                    if ((flags & 2) != 0) {
                        dstPos = PFX_ProcessAdditiveColumnInverse(source, sourcePos, buffer, pos, width, height, 0);
                    } else {
                        dstPos = PFX_ProcessAdditiveColumn(source, sourcePos, buffer, pos, width, height, 0);
                    }
                }
                if (bMultiplicative) {
                    if ((flags & 2) != 0) {
                        dstPos = PFX_ProcessMultiplicativeLineInverse(source, sourcePos, buffer, pos, width);
                    } else {
                        dstPos = PFX_ProcessMultiplicativeLine(source, sourcePos, buffer, pos, width);
                    }
                }
                pos = dstPos;
                i3 = x + xDiferential;
            }
        } else {
            int yStart = 0;
            int yEnd = height;
            int yDiferential = 1;
            if ((flags & 2) != 0) {
                yStart = height - 1;
                yEnd = -1;
                yDiferential = -1;
            }
            int i4 = yStart;
            while (true) {
                int y = i4;
                if (y == yEnd) {
                    break;
                }
                int sourcePos2 = y * sWidth;
                int dstPos2 = 0;
                if (bAdditive) {
                    if ((flags & 1) != 0) {
                        dstPos2 = PFX_ProcessAdditiveLineInverse(source, sourcePos2, buffer, pos, width, 0);
                    } else {
                        dstPos2 = PFX_ProcessAdditiveLine(source, sourcePos2, buffer, pos, width, 0);
                    }
                }
                if (bMultiplicative) {
                    if ((flags & 1) != 0) {
                        dstPos2 = PFX_ProcessMultiplicativeLineInverse(source, sourcePos2, buffer, pos, width);
                    } else {
                        dstPos2 = PFX_ProcessMultiplicativeLine(source, sourcePos2, buffer, pos, width);
                    }
                }
                pos = dstPos2;
                i4 = y + yDiferential;
            }
        }
        m_PFX_sizeX = width;
        m_PFX_sizeY = height;
        m_PFX_hasAlpha = false;
        return buffer;
    }

    static void PFX_ApplyFullScreenBlur(Graphics g2, int[] buffer) {
        if (!GLLibConfig.pfx_useEffectFullScreenBlur || buffer == null) {
            return;
        }
        int x = m_PFX_windowX;
        int y = m_PFX_windowY;
        int width = m_PFX_windowWidth;
        int height = m_PFX_windowHeight;
        int type = m_PFX_params[0][0];
        int amount = m_PFX_params[0][2] >> 10;
        int maxBlock = buffer.length / width;
        int yy = 0;
        boolean done = false;
        int lastPixel = 0;
        if (type == 1) {
            int block = maxBlock - 1;
            while (!done) {
                if (height - yy < maxBlock) {
                    done = true;
                }
                PFX_ReadPixelData(buffer, 0, width, x, y + yy, width, block);
                if (yy == 0) {
                    lastPixel = buffer[0];
                }
                lastPixel = PFX_BlurLBlock(width * block, buffer, amount, lastPixel);
                PFX_WritePixelData(buffer, 0, width, x, y + yy, width, block, false);
                yy += block;
            }
            return;
        }
        if (type == 0) {
            int yy2 = height - (maxBlock - 1);
            int block2 = maxBlock - 1;
            while (!done) {
                if (yy2 < 0) {
                    block2 = (maxBlock - 1) + yy2;
                    yy2 = 0;
                    done = true;
                }
                PFX_ReadPixelData(buffer, 0, width, x, y + yy2, width, block2);
                if (yy2 == height - (maxBlock - 1)) {
                    lastPixel = buffer[(width * block2) - 1];
                }
                lastPixel = PFX_BlurRBlock(width * block2, buffer, amount, lastPixel);
                PFX_WritePixelData(buffer, 0, width, x, y + yy2, width, block2, false);
                yy2 -= block2;
            }
        }
    }

    static final void PFX_PaintFullScreenBlend(Graphics g2, Image bottomBuffer, int[] buffer) {
        if (GLLibConfig.pfx_useEffectFullScreenBlend) {
            int posX = m_PFX_windowX;
            int posY = m_PFX_windowY;
            int width = m_PFX_windowWidth;
            int height = m_PFX_windowHeight;
            if (bottomBuffer != null) {
                int posX2 = g2.getClipX();
                int posY2 = g2.getClipY();
                int width2 = g2.getClipWidth();
                int height2 = g2.getClipHeight();
                SetClip(m_PFX_windowX, m_PFX_windowY, m_PFX_windowWidth, m_PFX_windowHeight);
                g2.drawImage(bottomBuffer, 0, 0, 0);
                SetClip(posX2, posY2, width2, height2);
                posX = m_PFX_windowX;
                posY = m_PFX_windowY;
                width = m_PFX_windowWidth;
                height = m_PFX_windowHeight;
            }
            int maxBlock = buffer.length / width;
            int block = maxBlock;
            int blockRest = height;
            int blockSize = block * width;
            int alpha = m_PFX_params[1][1];
            int alpha2 = alpha >> 10;
            while (blockRest > 0) {
                if (blockRest < maxBlock) {
                    block = blockRest;
                    blockRest = 0;
                    blockSize = block * width;
                }
                PFX_ReadPixelData(buffer, 0, width, posX, posY, width, block);
                PFX_ProcessBlendSimple(buffer, alpha2, blockSize);
                PFX_WritePixelData(buffer, 0, width, posX, posY, width, block, true);
                blockRest -= block;
                posY += block;
            }
            m_PFX_params[1][4] = 1;
        }
    }

    static final void PFX_ApplyFullScreenMultiplicative(Graphics g2, int color, int[] buffer) {
        if (GLLibConfig.pfx_useEffectFullScreenMultiplicative) {
            int posX = m_PFX_windowX;
            int posY = m_PFX_windowY;
            int width = m_PFX_windowWidth;
            int height = m_PFX_windowHeight;
            int maxBlock = buffer.length / width;
            int yy = 0;
            boolean done = false;
            while (!done) {
                int block = height - yy;
                if (block > maxBlock) {
                    block = maxBlock - 1;
                } else {
                    done = true;
                }
                PFX_ReadPixelData(buffer, 0, width, posX, posY + yy, width, block);
                PFX_MultiplicativeBlock(width * block, buffer, color);
                PFX_WritePixelData(buffer, 0, width, posX, posY + yy, width, block, false);
                yy += block;
            }
        }
    }

    static final void PFX_InitGlowArea(int size, int[] buffer) {
        if (GLLibConfig.pfx_useSpriteEffectGlow) {
            while (size > 0) {
                size--;
                buffer[size] = 0;
            }
            PFX_ReadPixelData(buffer, m_PFX_params[7][18], m_PFX_params[7][16], m_PFX_params[7][14], m_PFX_params[7][15], m_PFX_params[7][16], m_PFX_params[7][17]);
        }
    }

    static final void PFX_ApplyGlow(Graphics g2, int offset, int hspread, int vspread, int intensity, int[] buffer) {
        if (GLLibConfig.pfx_useSpriteEffectGlow) {
            PFX_ProcessGlowBlock(buffer, buffer, offset, hspread, vspread, intensity, m_PFX_params[7][16], m_PFX_params[7][17], m_PFX_params[7][18]);
            PFX_WritePixelData(buffer, offset, m_PFX_params[7][16], m_PFX_params[7][14], m_PFX_params[7][15], m_PFX_params[7][16], m_PFX_params[7][17], false);
        }
    }

    static final short[] PFX_ProcessSpriteEffects(short[] source, int x, int y, int w, int h, int flags, boolean hasAlpha, boolean multiAlpha) {
        m_PFX_hasAlpha = hasAlpha;
        m_PFX_sizeX = w;
        m_PFX_sizeY = h;
        if ((m_PFX_type & GLPixEffects.k_EFFECTS_SPRITE_NEED_TRANSFORM_MASK) != 0) {
            if ((flags & 4) != 0) {
                m_PFX_sizeX = h;
                m_PFX_sizeY = w;
                w = m_PFX_sizeX;
                h = m_PFX_sizeY;
            }
            source = ASprite.TransformRGB(source, w, h, flags);
        }
        short[] pixelBuffer = ASprite.GetPixelBuffer_short(source);
        if ((m_PFX_type & 512) != 0) {
            if (GLLibConfig.pfx_useSpriteEffectScale) {
                return PFX_ProcessScaling(source, pixelBuffer, w, h, m_PFX_params[9][1], m_PFX_params[9][2], hasAlpha, PFX_UpdateMultiAlpha(multiAlpha, m_PFX_params[9][0]));
            }
            return null;
        }
        if ((m_PFX_type & kLenNumHighSymbols) != 0) {
            if (GLLibConfig.pfx_useSpriteEffectBlend) {
                return PFX_ProcessBlend(source, pixelBuffer, w * h, m_PFX_params[8][1], hasAlpha, PFX_UpdateMultiAlpha(multiAlpha, m_PFX_params[8][0]));
            }
            return null;
        }
        if ((m_PFX_type & 32) != 0) {
            if (GLLibConfig.pfx_useSpriteEffectGrayscale) {
                return PFX_ProcessGrayscaleEffect(source, pixelBuffer, w * h, m_PFX_params[5][1], hasAlpha, PFX_UpdateMultiAlpha(multiAlpha, m_PFX_params[5][0]));
            }
            return null;
        }
        if ((m_PFX_type & 64) != 0) {
            if (GLLibConfig.pfx_useSpriteEffectShine) {
                return PFX_ProcessShineEffect(source, pixelBuffer, x, y, w, h, flags, PFX_UpdateMultiAlpha(multiAlpha, m_PFX_params[6][0]));
            }
            return null;
        }
        if ((m_PFX_type & 8) != 0) {
            if (GLLibConfig.pfx_useSpriteEffectAdditive) {
                return PFX_ProcessPixelEffect(source, pixelBuffer, x, y, w, h, flags, (m_PFX_type & 8) != 0, (m_PFX_type & 16) != 0, true);
            }
            return null;
        }
        if ((m_PFX_type & 16) == 0 || !GLLibConfig.pfx_useSpriteEffectMultiplicative) {
            return null;
        }
        return PFX_ProcessPixelEffect(source, pixelBuffer, x, y, w, h, flags, (m_PFX_type & 8) != 0, (m_PFX_type & 16) != 0, true);
    }

    public static final short[] PFX_ProcessPixelEffect(short[] source, short[] buffer, int posX, int posY, int sWidth, int sHeight, int flags, boolean bAdditive, boolean bMultiplicative, boolean bReadPixels) {
        int sourcePos;
        int srcX = 0;
        int srcY = 0;
        int width = sWidth;
        int height = sHeight;
        int cx = g.getClipX();
        int cy = g.getClipY();
        int cw = g.getClipWidth();
        int ch = g.getClipHeight();
        if ((flags & 4) != 0) {
            width = sHeight;
            height = sWidth;
        }
        int widthClipped = width;
        int heightClipped = height;
        if (posY + heightClipped > ch + cy) {
            heightClipped = (ch + cy) - posY;
        }
        if (posX + widthClipped > cw + cx) {
            widthClipped = (cw + cx) - posX;
        }
        if (posX < cx) {
            srcX = cx - posX;
            widthClipped = width - srcX;
            posX = 0;
        }
        if (posY < cy) {
            srcY = cy - posY;
            heightClipped = height - srcY;
            posY = 0;
        }
        if (width <= 0) {
            return source;
        }
        if (height <= 0) {
            return source;
        }
        int i = height * (width + 1);
        if (bReadPixels) {
            PFX_ReadPixelData(buffer, 0, widthClipped, posX, posY, widthClipped, heightClipped);
        }
        if (widthClipped != width || heightClipped != height) {
            for (int i2 = heightClipped - 1; i2 >= 0; i2--) {
                System.arraycopy(buffer, i2 * widthClipped, buffer, srcX + ((i2 + srcY) * width), widthClipped);
            }
        }
        int pos = 0;
        if ((flags & 4) != 0) {
            int xStart = 0;
            int xEnd = height;
            int xDiferential = 1;
            if ((flags & 1) != 0) {
                xStart = height - 1;
                xEnd = -1;
                xDiferential = -1;
            }
            int i3 = xStart;
            while (true) {
                int x = i3;
                if (x == xEnd) {
                    break;
                }
                if ((flags & 2) != 0) {
                    sourcePos = x;
                } else {
                    sourcePos = x + ((width - 1) * height);
                }
                int dstPos = 0;
                if (bAdditive) {
                    if ((flags & 2) != 0) {
                        dstPos = PFX_ProcessAdditiveColumnInverse(source, sourcePos, buffer, pos, width, height, 0);
                    } else {
                        dstPos = PFX_ProcessAdditiveColumn(source, sourcePos, buffer, pos, width, height, 0);
                    }
                }
                if (bMultiplicative) {
                    if ((flags & 2) != 0) {
                        dstPos = PFX_ProcessMultiplicativeLineInverse(source, sourcePos, buffer, pos, width);
                    } else {
                        dstPos = PFX_ProcessMultiplicativeLine(source, sourcePos, buffer, pos, width);
                    }
                }
                pos = dstPos;
                i3 = x + xDiferential;
            }
        } else {
            int yStart = 0;
            int yEnd = height;
            int yDiferential = 1;
            if ((flags & 2) != 0) {
                yStart = height - 1;
                yEnd = -1;
                yDiferential = -1;
            }
            int i4 = yStart;
            while (true) {
                int y = i4;
                if (y == yEnd) {
                    break;
                }
                int sourcePos2 = y * sWidth;
                int dstPos2 = 0;
                if (bAdditive) {
                    if ((flags & 1) != 0) {
                        dstPos2 = PFX_ProcessAdditiveLineInverse(source, sourcePos2, buffer, pos, width, 0);
                    } else {
                        dstPos2 = PFX_ProcessAdditiveLine(source, sourcePos2, buffer, pos, width, 0);
                    }
                }
                if (bMultiplicative) {
                    if ((flags & 1) != 0) {
                        dstPos2 = PFX_ProcessMultiplicativeLineInverse(source, sourcePos2, buffer, pos, width);
                    } else {
                        dstPos2 = PFX_ProcessMultiplicativeLine(source, sourcePos2, buffer, pos, width);
                    }
                }
                pos = dstPos2;
                i4 = y + yDiferential;
            }
        }
        m_PFX_sizeX = width;
        m_PFX_sizeY = height;
        m_PFX_hasAlpha = false;
        return buffer;
    }

    static void PFX_ApplyFullScreenBlur(Graphics g2, short[] buffer) {
        if (!GLLibConfig.pfx_useEffectFullScreenBlur || buffer == null) {
            return;
        }
        int x = m_PFX_windowX;
        int y = m_PFX_windowY;
        int width = m_PFX_windowWidth;
        int height = m_PFX_windowHeight;
        int type = m_PFX_params[0][0];
        int amount = m_PFX_params[0][2] >> 10;
        int maxBlock = buffer.length / width;
        int yy = 0;
        boolean done = false;
        short lastPixel = 0;
        if (type == 1) {
            int block = maxBlock - 1;
            while (!done) {
                if (height - yy < maxBlock) {
                    done = true;
                }
                PFX_ReadPixelData(buffer, 0, width, x, y + yy, width, block);
                if (yy == 0) {
                    lastPixel = buffer[0];
                }
                lastPixel = PFX_BlurLBlock(width * block, buffer, amount, (int) lastPixel);
                PFX_WritePixelData(buffer, 0, width, x, y + yy, width, block, false);
                yy += block;
            }
            return;
        }
        if (type == 0) {
            int yy2 = height - (maxBlock - 1);
            int block2 = maxBlock - 1;
            while (!done) {
                if (yy2 < 0) {
                    block2 = (maxBlock - 1) + yy2;
                    yy2 = 0;
                    done = true;
                }
                PFX_ReadPixelData(buffer, 0, width, x, y + yy2, width, block2);
                if (yy2 == height - (maxBlock - 1)) {
                    lastPixel = buffer[(width * block2) - 1];
                }
                lastPixel = PFX_BlurRBlock(width * block2, buffer, amount, (int) lastPixel);
                PFX_WritePixelData(buffer, 0, width, x, y + yy2, width, block2, false);
                yy2 -= block2;
            }
        }
    }

    static final void PFX_PaintFullScreenBlend(Graphics g2, Image bottomBuffer, short[] buffer) {
        if (GLLibConfig.pfx_useEffectFullScreenBlend) {
            int posX = m_PFX_windowX;
            int posY = m_PFX_windowY;
            int width = m_PFX_windowWidth;
            int height = m_PFX_windowHeight;
            if (bottomBuffer != null) {
                int posX2 = g2.getClipX();
                int posY2 = g2.getClipY();
                int width2 = g2.getClipWidth();
                int height2 = g2.getClipHeight();
                SetClip(m_PFX_windowX, m_PFX_windowY, m_PFX_windowWidth, m_PFX_windowHeight);
                g2.drawImage(bottomBuffer, 0, 0, 0);
                SetClip(posX2, posY2, width2, height2);
                posX = m_PFX_windowX;
                posY = m_PFX_windowY;
                width = m_PFX_windowWidth;
                height = m_PFX_windowHeight;
            }
            int maxBlock = buffer.length / width;
            int block = maxBlock;
            int blockRest = height;
            int blockSize = block * width;
            int alpha = m_PFX_params[1][1];
            int alpha2 = alpha >> 10;
            while (blockRest > 0) {
                if (blockRest < maxBlock) {
                    block = blockRest;
                    blockRest = 0;
                    blockSize = block * width;
                }
                PFX_ReadPixelData(buffer, 0, width, posX, posY, width, block);
                PFX_ProcessBlendSimple(buffer, alpha2, blockSize);
                PFX_WritePixelData(buffer, 0, width, posX, posY, width, block, true);
                blockRest -= block;
                posY += block;
            }
            m_PFX_params[1][4] = 1;
        }
    }

    static final void PFX_ApplyFullScreenMultiplicative(Graphics g2, int color, short[] buffer) {
        if (GLLibConfig.pfx_useEffectFullScreenMultiplicative) {
            int posX = m_PFX_windowX;
            int posY = m_PFX_windowY;
            int width = m_PFX_windowWidth;
            int height = m_PFX_windowHeight;
            int maxBlock = buffer.length / width;
            int yy = 0;
            boolean done = false;
            while (!done) {
                int block = height - yy;
                if (block > maxBlock) {
                    block = maxBlock - 1;
                } else {
                    done = true;
                }
                PFX_ReadPixelData(buffer, 0, width, posX, posY + yy, width, block);
                PFX_MultiplicativeBlock(width * block, buffer, color);
                PFX_WritePixelData(buffer, 0, width, posX, posY + yy, width, block, false);
                yy += block;
            }
        }
    }

    static final void PFX_InitGlowArea(int size, short[] buffer) {
        if (GLLibConfig.pfx_useSpriteEffectGlow) {
            while (size > 0) {
                size--;
                buffer[size] = 0;
            }
            PFX_ReadPixelData(buffer, m_PFX_params[7][18], m_PFX_params[7][16], m_PFX_params[7][14], m_PFX_params[7][15], m_PFX_params[7][16], m_PFX_params[7][17]);
        }
    }

    static final void PFX_ApplyGlow(Graphics g2, int offset, int hspread, int vspread, int intensity, short[] buffer) {
        if (GLLibConfig.pfx_useSpriteEffectGlow) {
            PFX_ProcessGlowBlock(buffer, buffer, offset, hspread, vspread, intensity, m_PFX_params[7][16], m_PFX_params[7][17], m_PFX_params[7][18]);
            PFX_WritePixelData(buffer, offset, m_PFX_params[7][16], m_PFX_params[7][14], m_PFX_params[7][15], m_PFX_params[7][16], m_PFX_params[7][17], false);
        }
    }
}
