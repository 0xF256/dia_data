package defpackage;

/* loaded from: GLLib.jar:GLLibPathFinding.class */
class GLLibPathFinding {
    public static final int kDirUp = 0;
    public static final int kDirDown = 1;
    public static final int kDirLeft = 2;
    public static final int kDirRight = 3;
    public static final int kDirUpLeft = 4;
    public static final int kDirUpRight = 5;
    public static final int kDirDownLeft = 6;
    public static final int kDirDownRight = 7;
    private static int[] kDirPrecalc = {0, -1, 0, 1, -1, 0, 1, 0, -1, -1, 1, -1, -1, 1, 1, 1};
    private short[] m_nodeParent;
    private short[] m_nodePrev;
    private short[] m_nodeNext;
    private short[] m_nodeG;
    private short[] m_nodeH;
    private int m_nCostMove;
    private int m_nCostMoveDiag;
    private int m_nCostChangeDir;
    private int m_nUseDirectionCount;
    private int m_nMapW;
    private int m_nMapH;
    private byte[] m_pPhysMap;
    private int m_nPhysMapMask;
    private short[] m_path;
    private int m_pathIdx;
    private int m_openedSortedList;
    private boolean m_init = false;

    public void PathFinding_Init(int nMapWidth, int nMapHeight, byte[] pPhysicalMap, int nCostMove, int nCostMoveDiag, int nCostChangeDir, int nDirCount) {
        PathFinding_Init(nMapWidth, nMapHeight, pPhysicalMap, nCostMove, nCostMoveDiag, nCostChangeDir, nDirCount, -1);
    }

    public void PathFinding_Init(int nMapWidth, int nMapHeight, byte[] pPhysicalMap, int nCostMove, int nCostMoveDiag, int nCostChangeDir, int nDirCount, int nCollisionMask) {
        GLLib.Assert(nDirCount == 4 || nDirCount == 8, "PathFinding_Init nDirCount should be 4 or 8.");
        this.m_nMapW = nMapWidth;
        this.m_nMapH = nMapHeight;
        this.m_pPhysMap = pPhysicalMap;
        this.m_nPhysMapMask = nCollisionMask;
        this.m_nCostMove = nCostMove;
        this.m_nCostMoveDiag = nCostMoveDiag;
        this.m_nCostChangeDir = nCostChangeDir;
        this.m_nUseDirectionCount = nDirCount;
        this.m_nodeParent = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_nodePrev = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_nodeNext = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_nodeG = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_nodeH = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_openedSortedList = -1;
        this.m_path = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_pathIdx = -1;
        this.m_init = true;
    }

    public void PathFinding_Exec(int start_x, int start_y, int start_dir, int end_x, int end_y) {
        int nMoveCost;
        int h;
        GLLib.Assert(this.m_init, "GLLibPathFinding not initialized");
        int dir = start_dir;
        if (GLLibConfig.pathfinding_Debug) {
            GLLib.Dbg("------------- execPathFinding -------------");
            GLLib.Dbg(new StringBuffer().append("execPathFinding from (").append(start_x).append(", ").append(start_y).append(") to (").append(end_x).append(", ").append(end_y).append(")").toString());
        }
        for (int i = 0; i < GLLibConfig.pathfinding_MaxNode; i++) {
            this.m_nodeParent[i] = -1;
            this.m_nodePrev[i] = -1;
            this.m_nodeNext[i] = -1;
            this.m_nodeG[i] = 0;
            this.m_nodeH[i] = 0;
        }
        this.m_openedSortedList = -1;
        for (int i2 = 0; i2 < GLLibConfig.pathfinding_MaxNode; i2++) {
            this.m_path[i2] = 0;
        }
        int n_idx = (start_y * this.m_nMapW) + start_x;
        while (true) {
            if (n_idx == -1) {
                break;
            }
            listRem(n_idx);
            this.m_nodeG[n_idx] = -1;
            this.m_nodeH[n_idx] = -1;
            int node_x = n_idx % this.m_nMapW;
            int node_y = n_idx / this.m_nMapW;
            if (node_x == end_x && node_y == end_y) {
                if (GLLibConfig.pathfinding_Debug) {
                    GLLib.Dbg("a path has been found");
                }
            } else {
                if (GLLibConfig.pathfinding_Debug) {
                    GLLib.Dbg(new StringBuffer().append("current node[").append(n_idx).append("] is (").append(node_x).append(", ").append(node_y).append(")").toString());
                }
                int i3 = 0;
                while (i3 < this.m_nUseDirectionCount) {
                    int adj_x = kDirPrecalc[(i3 << 1) + 0];
                    int adj_y = kDirPrecalc[(i3 << 1) + 1];
                    if (adj_x != 0 && adj_y != 0) {
                        nMoveCost = this.m_nCostMoveDiag;
                    } else {
                        nMoveCost = this.m_nCostMove;
                    }
                    int adj_x2 = adj_x + node_x;
                    int adj_y2 = adj_y + node_y;
                    if (GLLibConfig.pathfinding_Debug) {
                        GLLib.Dbg(new StringBuffer().append("position is (").append(adj_x2).append(", ").append(adj_y2).append(")").toString());
                    }
                    if (adj_x2 < 0 || adj_x2 >= this.m_nMapW) {
                        if (GLLibConfig.pathfinding_Debug) {
                            GLLib.Dbg("x position is not in the map");
                        }
                    } else if (adj_y2 < 0 || adj_y2 >= this.m_nMapH) {
                        if (GLLibConfig.pathfinding_Debug) {
                            GLLib.Dbg("y position is not in the map");
                        }
                    } else {
                        if (i3 >= 4) {
                            if (i3 == 4) {
                            }
                        }
                        int a_idx = (adj_y2 * this.m_nMapW) + adj_x2;
                        if (GLLibConfig.pathfinding_Debug) {
                            GLLib.Dbg(new StringBuffer().append("\tadjacent node[").append(a_idx).append("] is (").append(adj_x2).append(", ").append(adj_y2).append(")").toString());
                        }
                        if ((this.m_pPhysMap[(adj_y2 * this.m_nMapW) + adj_x2] & this.m_nPhysMapMask) != 0) {
                            if (GLLibConfig.pathfinding_Debug) {
                                GLLib.Dbg("\tnode is a wall");
                            }
                        } else if (this.m_nodeG[a_idx] == -1) {
                            if (GLLibConfig.pathfinding_Debug) {
                                GLLib.Dbg("\tnode has been already checked");
                            }
                        } else {
                            int nDirCost = dir == i3 ? 0 : this.m_nCostChangeDir;
                            int g = this.m_nodeG[n_idx] + nMoveCost + nDirCost;
                            int dx = Math.abs(adj_x2 - end_x);
                            int dy = Math.abs(adj_y2 - end_y);
                            if (dx > dy) {
                                h = (this.m_nCostMoveDiag * dy) + (this.m_nCostMove * (dx - dy));
                            } else {
                                h = (this.m_nCostMoveDiag * dx) + (this.m_nCostMove * (dy - dx));
                            }
                            if (this.m_nodePrev[a_idx] == -1 && this.m_nodeNext[a_idx] == -1 && this.m_openedSortedList != a_idx) {
                                this.m_nodeParent[a_idx] = (short) n_idx;
                                this.m_nodeG[a_idx] = (short) g;
                                this.m_nodeH[a_idx] = (short) h;
                                if (GLLibConfig.pathfinding_Debug) {
                                    GLLib.Dbg(new StringBuffer().append("\tadd adjacent node to open list (score : ").append(g + h).append(")").toString());
                                }
                                listAdd(a_idx);
                            } else if (this.m_nodeG[a_idx] > g) {
                                this.m_nodeParent[a_idx] = (short) n_idx;
                                this.m_nodeG[a_idx] = (short) g;
                                if (GLLibConfig.pathfinding_Debug) {
                                    GLLib.Dbg("\trelink adjacent node to current node");
                                }
                                listRem(a_idx);
                                listAdd(a_idx);
                            }
                        }
                    }
                    i3++;
                }
                n_idx = this.m_openedSortedList;
                if (GLLibConfig.pathfinding_Debug) {
                    GLLib.Dbg(new StringBuffer().append("change current node to : ").append(n_idx).append(" (").append(n_idx % this.m_nMapW).append(", ").append(n_idx / this.m_nMapW).append(")").toString());
                }
                if (n_idx != -1) {
                    short s = this.m_nodeParent[n_idx];
                    if (n_idx % this.m_nMapW != s % this.m_nMapW) {
                        if (n_idx % this.m_nMapW > s % this.m_nMapW) {
                            dir = 3;
                        } else {
                            dir = 2;
                        }
                    } else if (n_idx / this.m_nMapW > s / this.m_nMapW) {
                        dir = 1;
                    } else {
                        dir = 0;
                    }
                    if (GLLibConfig.pathfinding_Debug) {
                        GLLib.Dbg(new StringBuffer().append("new node[").append(n_idx).append("] (score : ").append(this.m_nodeG[n_idx] + this.m_nodeH[n_idx]).append(") is (").append(n_idx % this.m_nMapW).append(", ").append(n_idx / this.m_nMapW).append(")").toString());
                    }
                }
            }
        }
        if (n_idx == -1) {
            if (GLLibConfig.pathfinding_Debug) {
                GLLib.Dbg("opened list is empty... there is no path");
                GLLib.Dbg("-------------------------------------------");
            }
            this.m_pathIdx = -1;
            return;
        }
        this.m_pathIdx = 0;
        while (n_idx != -1) {
            short[] sArr = this.m_path;
            int i4 = this.m_pathIdx;
            this.m_pathIdx = i4 + 1;
            sArr[i4] = (short) n_idx;
            n_idx = this.m_nodeParent[n_idx];
        }
        this.m_pathIdx--;
        if (GLLibConfig.pathfinding_Debug) {
            GLLib.Dbg("-------------------------------------------");
            for (int i5 = this.m_pathIdx; i5 >= 0; i5--) {
                short s2 = this.m_path[i5];
                int x = s2 % this.m_nMapW;
                int y = s2 / this.m_nMapW;
                GLLib.Dbg(new StringBuffer().append("node [").append(i5).append("]\t= (").append(x).append(", ").append(y).append(")").toString());
            }
            GLLib.Dbg("-------------------------------------------");
        }
    }

    public int PathFinding_GetPathLength() {
        GLLib.Assert(this.m_init, "GLLibPathFinding not initialized");
        return this.m_pathIdx + 1;
    }

    public int PathFinding_GetPathPosition(int nIndex) {
        GLLib.Assert(this.m_init, "GLLibPathFinding not initialized");
        return this.m_path[nIndex];
    }

    public int PathFinding_GetPathPositionX(int nIndex) {
        GLLib.Assert(this.m_init, "GLLibPathFinding not initialized");
        return this.m_path[nIndex] % this.m_nMapW;
    }

    public int PathFinding_GetPathPositionY(int nIndex) {
        GLLib.Assert(this.m_init, "GLLibPathFinding not initialized");
        return this.m_path[nIndex] / this.m_nMapW;
    }

    public void PathFinding_Free(boolean bKeepLastPath) {
        this.m_init = false;
        this.m_nodeParent = null;
        this.m_nodePrev = null;
        this.m_nodeNext = null;
        this.m_nodeG = null;
        this.m_nodeH = null;
        this.m_pPhysMap = null;
        if (!bKeepLastPath) {
            this.m_pathIdx = -1;
            this.m_path = null;
        }
        GLLib.Gc();
    }

    private void listAdd(int i) {
        if (this.m_openedSortedList == -1) {
            this.m_openedSortedList = i;
            return;
        }
        int i2 = this.m_nodeG[i] + this.m_nodeH[i];
        int i3 = this.m_openedSortedList;
        while (true) {
            int i4 = i3;
            if (i4 != -1) {
                if (i2 < this.m_nodeG[i4] + this.m_nodeH[i4]) {
                    if (this.m_nodePrev[i4] == -1) {
                        this.m_openedSortedList = i;
                    } else {
                        this.m_nodeNext[this.m_nodePrev[i4]] = (short) i;
                    }
                    this.m_nodePrev[i] = this.m_nodePrev[i4];
                    this.m_nodeNext[i] = (short) i4;
                    this.m_nodePrev[i4] = (short) i;
                    return;
                }
                if (this.m_nodeNext[i4] != -1) {
                    i3 = this.m_nodeNext[i4];
                } else {
                    this.m_nodeNext[i4] = (short) i;
                    this.m_nodePrev[i] = (short) i4;
                    return;
                }
            } else {
                return;
            }
        }
    }

    private void listRem(int e_idx) {
        if (this.m_nodeNext[e_idx] != -1) {
            this.m_nodePrev[this.m_nodeNext[e_idx]] = this.m_nodePrev[e_idx];
        }
        if (this.m_openedSortedList == e_idx) {
            this.m_openedSortedList = this.m_nodeNext[e_idx];
        } else if (this.m_nodePrev[e_idx] != -1) {
            this.m_nodeNext[this.m_nodePrev[e_idx]] = this.m_nodeNext[e_idx];
        }
        this.m_nodePrev[e_idx] = -1;
        this.m_nodeNext[e_idx] = -1;
    }

    private void listDisplay() {
    }
}
