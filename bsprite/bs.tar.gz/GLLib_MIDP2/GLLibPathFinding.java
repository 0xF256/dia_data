// 
// Decompiled by Procyon v0.6.0
// 

class GLLibPathFinding
{
    public static final int kDirUp = 0;
    public static final int kDirDown = 1;
    public static final int kDirLeft = 2;
    public static final int kDirRight = 3;
    public static final int kDirUpLeft = 4;
    public static final int kDirUpRight = 5;
    public static final int kDirDownLeft = 6;
    public static final int kDirDownRight = 7;
    private static int[] kDirPrecalc;
    private short[] m_nodeParent;
    private short[] m_nodePrev;
    private short[] m_nodeNext;
    private short[] m_nodeG;
    private short[] m_nodeH;
    private int m_nCostMove;
    private int m_nCostMoveDiag;
    private int m_nCostChangeDir;
    private int m_nUseDirectionCount;
    private int m_nMapW;
    private int m_nMapH;
    private byte[] m_pPhysMap;
    private int m_nPhysMapMask;
    private short[] m_path;
    private int m_pathIdx;
    private int m_openedSortedList;
    private boolean m_init;
    
    private int PACK_POS(final int x, final int y) {
        return y * this.m_nMapW + x;
    }
    
    private int UNPACK_X(final int pos) {
        return pos % this.m_nMapW;
    }
    
    private int UNPACK_Y(final int pos) {
        return pos / this.m_nMapW;
    }
    
    public GLLibPathFinding() {
        this.m_init = false;
    }
    
    public void PathFinding_Init(final int nMapWidth, final int nMapHeight, final byte[] pPhysicalMap, final int nCostMove, final int nCostMoveDiag, final int nCostChangeDir, final int nDirCount) {
        this.PathFinding_Init(nMapWidth, nMapHeight, pPhysicalMap, nCostMove, nCostMoveDiag, nCostChangeDir, nDirCount, -1);
    }
    
    public void PathFinding_Init(final int nMapWidth, final int nMapHeight, final byte[] pPhysicalMap, final int nCostMove, final int nCostMoveDiag, final int nCostChangeDir, final int nDirCount, final int nCollisionMask) {
        GLLib.Assert(nDirCount == 4 || nDirCount == 8, "PathFinding_Init nDirCount should be 4 or 8.");
        this.m_nMapW = nMapWidth;
        this.m_nMapH = nMapHeight;
        this.m_pPhysMap = pPhysicalMap;
        this.m_nPhysMapMask = nCollisionMask;
        this.m_nCostMove = nCostMove;
        this.m_nCostMoveDiag = nCostMoveDiag;
        this.m_nCostChangeDir = nCostChangeDir;
        this.m_nUseDirectionCount = nDirCount;
        this.m_nodeParent = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_nodePrev = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_nodeNext = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_nodeG = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_nodeH = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_openedSortedList = -1;
        this.m_path = new short[GLLibConfig.pathfinding_MaxNode];
        this.m_pathIdx = -1;
        this.m_init = true;
    }
    
    public void PathFinding_Exec(final int start_x, final int start_y, final int start_dir, final int end_x, final int end_y) {
        GLLib.Assert(this.m_init, "GLLibPathFinding not initialized");
        int dir = start_dir;
        if (GLLibConfig.pathfinding_Debug) {
            GLLib.Dbg("------------- execPathFinding -------------");
            GLLib.Dbg("execPathFinding from (" + start_x + ", " + start_y + ") to (" + end_x + ", " + end_y + ")");
        }
        for (int i = 0; i < GLLibConfig.pathfinding_MaxNode; ++i) {
            this.m_nodeParent[i] = -1;
            this.m_nodePrev[i] = -1;
            this.m_nodeNext[i] = -1;
            this.m_nodeG[i] = 0;
            this.m_nodeH[i] = 0;
        }
        this.m_openedSortedList = -1;
        for (int i = 0; i < GLLibConfig.pathfinding_MaxNode; ++i) {
            this.m_path[i] = 0;
        }
        int n_idx = this.PACK_POS(start_x, start_y);
        while (n_idx != -1) {
            this.listRem(n_idx);
            this.m_nodeG[n_idx] = -1;
            this.m_nodeH[n_idx] = -1;
            final int node_x = this.UNPACK_X(n_idx);
            final int node_y = this.UNPACK_Y(n_idx);
            if (node_x == end_x && node_y == end_y) {
                if (GLLibConfig.pathfinding_Debug) {
                    GLLib.Dbg("a path has been found");
                    break;
                }
                break;
            }
            else {
                if (GLLibConfig.pathfinding_Debug) {
                    GLLib.Dbg("current node[" + n_idx + "] is (" + node_x + ", " + node_y + ")");
                }
                for (int j = 0; j < this.m_nUseDirectionCount; ++j) {
                    int adj_x = GLLibPathFinding.kDirPrecalc[(j << 1) + 0];
                    int adj_y = GLLibPathFinding.kDirPrecalc[(j << 1) + 1];
                    int nMoveCost;
                    if (adj_x != 0 && adj_y != 0) {
                        nMoveCost = this.m_nCostMoveDiag;
                    }
                    else {
                        nMoveCost = this.m_nCostMove;
                    }
                    adj_x += node_x;
                    adj_y += node_y;
                    if (GLLibConfig.pathfinding_Debug) {
                        GLLib.Dbg("position is (" + adj_x + ", " + adj_y + ")");
                    }
                    if (adj_x < 0 || adj_x >= this.m_nMapW) {
                        if (GLLibConfig.pathfinding_Debug) {
                            GLLib.Dbg("x position is not in the map");
                        }
                    }
                    else if (adj_y < 0 || adj_y >= this.m_nMapH) {
                        if (GLLibConfig.pathfinding_Debug) {
                            GLLib.Dbg("y position is not in the map");
                        }
                    }
                    else {
                        if (j >= 4) {
                            if (j == 4) {
                                if ((this.m_pPhysMap[n_idx - 1] & this.m_nPhysMapMask) != 0x0) {
                                    continue;
                                }
                                if ((this.m_pPhysMap[n_idx - this.m_nMapW] & this.m_nPhysMapMask) != 0x0) {
                                    continue;
                                }
                            }
                            else if (j == 5) {
                                if ((this.m_pPhysMap[n_idx + 1] & this.m_nPhysMapMask) != 0x0) {
                                    continue;
                                }
                                if ((this.m_pPhysMap[n_idx - this.m_nMapW] & this.m_nPhysMapMask) != 0x0) {
                                    continue;
                                }
                            }
                            else if (j == 6) {
                                if ((this.m_pPhysMap[n_idx - 1] & this.m_nPhysMapMask) != 0x0) {
                                    continue;
                                }
                                if ((this.m_pPhysMap[n_idx + this.m_nMapW] & this.m_nPhysMapMask) != 0x0) {
                                    continue;
                                }
                            }
                            else if (j == 7) {
                                if ((this.m_pPhysMap[n_idx + 1] & this.m_nPhysMapMask) != 0x0) {
                                    continue;
                                }
                                if ((this.m_pPhysMap[n_idx + this.m_nMapW] & this.m_nPhysMapMask) != 0x0) {
                                    continue;
                                }
                            }
                        }
                        final int a_idx = this.PACK_POS(adj_x, adj_y);
                        if (GLLibConfig.pathfinding_Debug) {
                            GLLib.Dbg("\tadjacent node[" + a_idx + "] is (" + adj_x + ", " + adj_y + ")");
                        }
                        if ((this.m_pPhysMap[this.PACK_POS(adj_x, adj_y)] & this.m_nPhysMapMask) != 0x0) {
                            if (GLLibConfig.pathfinding_Debug) {
                                GLLib.Dbg("\tnode is a wall");
                            }
                        }
                        else if (this.m_nodeG[a_idx] == -1) {
                            if (GLLibConfig.pathfinding_Debug) {
                                GLLib.Dbg("\tnode has been already checked");
                            }
                        }
                        else {
                            final int nDirCost = (dir == j) ? 0 : this.m_nCostChangeDir;
                            final int g = this.m_nodeG[n_idx] + nMoveCost + nDirCost;
                            final int dx = Math.abs(adj_x - end_x);
                            final int dy = Math.abs(adj_y - end_y);
                            int h;
                            if (dx > dy) {
                                h = this.m_nCostMoveDiag * dy + this.m_nCostMove * (dx - dy);
                            }
                            else {
                                h = this.m_nCostMoveDiag * dx + this.m_nCostMove * (dy - dx);
                            }
                            if (this.m_nodePrev[a_idx] == -1 && this.m_nodeNext[a_idx] == -1 && this.m_openedSortedList != a_idx) {
                                this.m_nodeParent[a_idx] = (short)n_idx;
                                this.m_nodeG[a_idx] = (short)g;
                                this.m_nodeH[a_idx] = (short)h;
                                if (GLLibConfig.pathfinding_Debug) {
                                    GLLib.Dbg("\tadd adjacent node to open list (score : " + (g + h) + ")");
                                }
                                this.listAdd(a_idx);
                            }
                            else if (this.m_nodeG[a_idx] > g) {
                                this.m_nodeParent[a_idx] = (short)n_idx;
                                this.m_nodeG[a_idx] = (short)g;
                                if (GLLibConfig.pathfinding_Debug) {
                                    GLLib.Dbg("\trelink adjacent node to current node");
                                }
                                this.listRem(a_idx);
                                this.listAdd(a_idx);
                            }
                        }
                    }
                }
                n_idx = this.m_openedSortedList;
                if (GLLibConfig.pathfinding_Debug) {
                    GLLib.Dbg("change current node to : " + n_idx + " (" + this.UNPACK_X(n_idx) + ", " + this.UNPACK_Y(n_idx) + ")");
                }
                if (n_idx == -1) {
                    continue;
                }
                final int p_idx = this.m_nodeParent[n_idx];
                if (this.UNPACK_X(n_idx) != this.UNPACK_X(p_idx)) {
                    if (this.UNPACK_X(n_idx) > this.UNPACK_X(p_idx)) {
                        dir = 3;
                    }
                    else {
                        dir = 2;
                    }
                }
                else if (this.UNPACK_Y(n_idx) > this.UNPACK_Y(p_idx)) {
                    dir = 1;
                }
                else {
                    dir = 0;
                }
                if (!GLLibConfig.pathfinding_Debug) {
                    continue;
                }
                GLLib.Dbg("new node[" + n_idx + "] (score : " + (this.m_nodeG[n_idx] + this.m_nodeH[n_idx]) + ") is (" + this.UNPACK_X(n_idx) + ", " + this.UNPACK_Y(n_idx) + ")");
            }
        }
        if (n_idx == -1) {
            if (GLLibConfig.pathfinding_Debug) {
                GLLib.Dbg("opened list is empty... there is no path");
                GLLib.Dbg("-------------------------------------------");
            }
            this.m_pathIdx = -1;
            return;
        }
        this.m_pathIdx = 0;
        while (n_idx != -1) {
            this.m_path[this.m_pathIdx++] = (short)n_idx;
            n_idx = this.m_nodeParent[n_idx];
        }
        --this.m_pathIdx;
        if (GLLibConfig.pathfinding_Debug) {
            GLLib.Dbg("-------------------------------------------");
            for (int j = this.m_pathIdx; j >= 0; --j) {
                final int pos = this.m_path[j];
                final int x = this.UNPACK_X(pos);
                final int y = this.UNPACK_Y(pos);
                GLLib.Dbg("node [" + j + "]\t= (" + x + ", " + y + ")");
            }
            GLLib.Dbg("-------------------------------------------");
        }
    }
    
    public int PathFinding_GetPathLength() {
        GLLib.Assert(this.m_init, "GLLibPathFinding not initialized");
        return this.m_pathIdx + 1;
    }
    
    public int PathFinding_GetPathPosition(final int nIndex) {
        GLLib.Assert(this.m_init, "GLLibPathFinding not initialized");
        return this.m_path[nIndex];
    }
    
    public int PathFinding_GetPathPositionX(final int nIndex) {
        GLLib.Assert(this.m_init, "GLLibPathFinding not initialized");
        return this.UNPACK_X(this.m_path[nIndex]);
    }
    
    public int PathFinding_GetPathPositionY(final int nIndex) {
        GLLib.Assert(this.m_init, "GLLibPathFinding not initialized");
        return this.UNPACK_Y(this.m_path[nIndex]);
    }
    
    public void PathFinding_Free(final boolean bKeepLastPath) {
        this.m_init = false;
        this.m_nodeParent = null;
        this.m_nodePrev = null;
        this.m_nodeNext = null;
        this.m_nodeG = null;
        this.m_nodeH = null;
        this.m_pPhysMap = null;
        if (!bKeepLastPath) {
            this.m_pathIdx = -1;
            this.m_path = null;
        }
        GLLib.Gc();
    }
    
    private void listAdd(final int e_idx) {
        if (this.m_openedSortedList == -1) {
            this.m_openedSortedList = e_idx;
            return;
        }
        final int elm_value = this.m_nodeG[e_idx] + this.m_nodeH[e_idx];
        for (int n_idx = this.m_openedSortedList; n_idx != -1; n_idx = this.m_nodeNext[n_idx]) {
            final int cur_value = this.m_nodeG[n_idx] + this.m_nodeH[n_idx];
            if (elm_value < cur_value) {
                if (this.m_nodePrev[n_idx] == -1) {
                    this.m_openedSortedList = e_idx;
                }
                else {
                    final int p_idx = this.m_nodePrev[n_idx];
                    this.m_nodeNext[p_idx] = (short)e_idx;
                }
                this.m_nodePrev[e_idx] = this.m_nodePrev[n_idx];
                this.m_nodeNext[e_idx] = (short)n_idx;
                this.m_nodePrev[n_idx] = (short)e_idx;
                return;
            }
            if (this.m_nodeNext[n_idx] == -1) {
                this.m_nodeNext[n_idx] = (short)e_idx;
                this.m_nodePrev[e_idx] = (short)n_idx;
                return;
            }
        }
    }
    
    private void listRem(final int e_idx) {
        if (this.m_nodeNext[e_idx] != -1) {
            final int n_idx = this.m_nodeNext[e_idx];
            this.m_nodePrev[n_idx] = this.m_nodePrev[e_idx];
        }
        if (this.m_openedSortedList == e_idx) {
            this.m_openedSortedList = this.m_nodeNext[e_idx];
        }
        else if (this.m_nodePrev[e_idx] != -1) {
            final int p_idx = this.m_nodePrev[e_idx];
            this.m_nodeNext[p_idx] = this.m_nodeNext[e_idx];
        }
        this.m_nodePrev[e_idx] = -1;
        this.m_nodeNext[e_idx] = -1;
    }
    
    private void listDisplay() {
        int n_idx = this.m_openedSortedList;
        GLLib.Dbg("************* listDisplay *************");
        while (n_idx != -1) {
            GLLib.Dbg("elm index[" + n_idx + "] (" + this.UNPACK_X(n_idx) + ", " + this.UNPACK_Y(n_idx) + ") with value = " + (this.m_nodeG[n_idx] + this.m_nodeH[n_idx]));
            n_idx = this.m_nodeNext[n_idx];
        }
        GLLib.Dbg("***************************************");
    }
    
    static {
        GLLibPathFinding.kDirPrecalc = new int[] { 0, -1, 0, 1, -1, 0, 1, 0, -1, -1, 1, -1, -1, 1, 1, 1 };
    }
}
