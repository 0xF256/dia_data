// 
// Decompiled by Procyon v0.6.0
// 

public interface MessageType
{
    public static final byte BASIC_MESSAGE_TYPE_UNKNOWN = 0;
    public static final byte BASIC_MESSAGE_TYPE_GAME = 103;
    public static final byte BASIC_MESSAGE_TYPE_CONNECT = 115;
    public static final byte CONNECT_MESSAGE_INIT_WRITE = 119;
    public static final byte CONNECT_MESSAGE_INIT_READ = 114;
    public static final byte CONNECT_MESSAGE_SUCCESS = 115;
    public static final byte CONNECT_MESSAGE_ERROR = 101;
    public static final byte CONNECT_MESSAGE_DISCONNECT = 120;
    public static final byte GAME_MESSAGE_REQUEST = 114;
    public static final byte GAME_MESSAGE_PUSH = 112;
    public static final byte GAME_MESSAGE_IN_GAME = 103;
    public static final byte GAME_MESSAGE_IN_GAME_TOALL = 104;
    public static final byte GAME_MESSAGE_ERROR = 101;
    public static final byte GAME_MESSAGE_KEEP_ALIVE = 97;
    public static final byte REQUEST_MESSAGE_LOGIN = 105;
    public static final byte REQUEST_MESSAGE_CREATE_SESSION = 99;
    public static final byte REQUEST_MESSAGE_LIST_SESSIONS = 108;
    public static final byte REQUEST_MESSAGE_GET_QUICK_SESSION = 117;
    public static final byte REQUEST_MESSAGE_JOIN_SESSION = 106;
    public static final byte REQUEST_MESSAGE_LEAVE_SESSION = 113;
    public static final byte REQUEST_MESSAGE_KICK_OUT_PLAYER = 107;
    public static final byte REQUEST_MESSAGE_START_GAME = 115;
    public static final byte REQUEST_MESSAGE_FINISH_GAME = 102;
    public static final byte REQUEST_MESSAGE_GET_PLAYER_INFO = 119;
    public static final byte REQUEST_MESSAGE_GET_PLAYER_DATA = 121;
    public static final byte REQUEST_MESSAGE_PROXY = 103;
    public static final byte RESPONSE_MESSAGE_SUCCESS = 115;
    public static final byte RESPONSE_MESSAGE_ERROR = 101;
    public static final byte ERROR_INVALID_INPUT = 105;
    public static final byte ERROR_NO_SESSION = 115;
    public static final byte ERROR_SESSION_CLOSED = 99;
    public static final byte ERROR_NOT_MASTER = 109;
    public static final byte ERROR_LOGIN_NICKNAME_USED = 110;
    public static final byte ERROR_LOGIN_INVALID_NICKNAME = 113;
    public static final byte ERROR_LOGIN_AUTHENTICATION_FAILED = 97;
    public static final byte ERROR_CREATE_SESSION_INVALID_NAME = 118;
    public static final byte ERROR_CREATE_SESSION_NAME_USED = 117;
    public static final byte ERROR_BLOCKED_SESSION = 98;
    public static final byte ERROR_LIST_SESSION_INVALID_INDEX = 108;
    public static final byte ERROR_JOIN_SESSION_TOO_MANY_PLAYERS = 106;
    public static final byte ERROR_NO_PLAYER = 107;
    public static final byte ERROR_KICK_OUT_PLAYER_IS_MASTER = 100;
    public static final byte ERROR_START_GAME_NOT_ENOUGH_PLAYERS = 103;
    public static final byte PUSH_MESSAGE_JOIN_SESSION = 106;
    public static final byte PUSH_MESSAGE_LEAVE_SESSION = 108;
    public static final byte PUSH_MESSAGE_KICK_OUT = 107;
    public static final byte PUSH_MESSAGE_START_GAME = 115;
    public static final byte PUSH_MESSAGE_FINISH_GAME = 102;
    public static final byte PLAYER_STATUS_NOT_REGISTERED = 110;
    public static final byte PLAYER_STATUS_OFFLINE = 102;
    public static final byte PLAYER_STATUS_ONLINE = 111;
    public static final byte PLAYER_STATUS_ONLINE_IN_SESSION = 115;
    public static final byte PLAYER_STATUS_ONLINE_PLAYING = 112;
    public static final byte PLAYER_STATUS_HAS_PSD = 104;
    public static final byte PLAYER_STATUS_HAS_NO_PSD = 100;
}
