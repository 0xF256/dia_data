import javax.microedition.media.Controllable;
import javax.microedition.media.control.RateControl;
import javax.microedition.media.control.TempoControl;
import javax.microedition.media.control.MIDIControl;
import javax.microedition.media.control.VolumeControl;
import java.io.InputStream;
import javax.microedition.media.Manager;
import java.io.ByteArrayInputStream;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.media.Player;

// 
// Decompiled by Procyon v0.6.0
// 

class GLLibPlayer implements Runnable
{
    int posX;
    int posY;
    int curFlags;
    ASprite sprite;
    private int curAnim;
    private int curFrame;
    public int curTime;
    private int nbLoop;
    private boolean animIsOver;
    private static int k_animBaseFrameTime;
    private static final boolean k_snd_verbose = false;
    private static final int k_snd_nbChannel;
    private static final int k_snd_max_volume = 100;
    private static final int k_snd_command_dummy = 0;
    private static final int k_snd_command_prepare = 1;
    private static final int k_snd_command_free = 2;
    private static final int k_snd_command_play = 3;
    private static final int k_snd_command_stop = 4;
    private static final int k_snd_command_pause = 5;
    private static final int k_snd_command_resume = 6;
    private static final int k_snd_command_amount = 7;
    private static final int k_snd_state_unprepared = 0;
    private static final int k_snd_state_ready = 1;
    private static final int k_snd_state_playing = 2;
    private static final int k_snd_state_paused = 3;
    private static final int k_snd_queue_command = 0;
    private static final int k_snd_queue_index = 1;
    private static final int k_snd_queue_priority = 2;
    private static final int k_snd_queue_volume = 3;
    private static final int k_snd_queue_loop = 4;
    private static final int k_snd_queue_size = 5;
    private static final int k_snd_max_queue_length = 7;
    static final int k_snd_priority_highest = 0;
    static final int k_snd_priority_normal = 7;
    static final int k_snd_priority_lowest = 15;
    static int s_snd_masterVolume;
    static int s_snd_maxNbSoundSlot;
    private static boolean s_snd_isSoundEngineInitialized;
    private static byte[][] s_snd_sndSlot;
    private static int[] s_snd_sndType;
    private static int[] s_snd_sndDuration;
    private static Player[] s_snd_Player;
    private static Player[] s_snd_PlayerSlot;
    private static long[] s_snd_playTime;
    private static int[] s_snd_index;
    private static int[] s_snd_priority;
    private static int[] s_snd_state;
    private static int[] s_snd_volume;
    private static int[] s_snd_loop;
    private static Thread s_pThread;
    private static GLLibPlayer s_pSoundPlayerIns;
    private static int[] s_snd_queue;
    private static int[] s_snd_queue_pointer;
    private static int[] s_snd_queue_size;
    static String[] s_data_mimeType;
    public static final int WRAP_CLAMP = 0;
    public static final int WRAP_REPEAT = 1;
    private static boolean s_bTilesetPlayerInitialized;
    private static int s_TilesetMaxLayerCount;
    private static final int k_TilesetInfoDestWidth = 0;
    private static final int k_TilesetInfoDestHeight = 1;
    private static final int k_TilesetInfoTileWidth = 2;
    private static final int k_TilesetInfoTileWidthShift = 3;
    private static final int k_TilesetInfoTileWidthMask = 4;
    private static final int k_TilesetInfoTileHeight = 5;
    private static final int k_TilesetInfoTileHeightShift = 6;
    private static final int k_TilesetInfoTileHeightMask = 7;
    private static final int k_TilesetInfoCOUNT = 8;
    private static final int k_TilesetLayerInitialized = 0;
    private static final int k_TilesetLayerEnabled = 1;
    private static final int k_TilesetLayerTileCountWidth = 2;
    private static final int k_TilesetLayerTileCountHeight = 3;
    private static final int k_TilesetLayerWidth = 4;
    private static final int k_TilesetLayerHeight = 5;
    private static final int k_TilesetLayerCBWidth = 6;
    private static final int k_TilesetLayerCBHeight = 7;
    private static final int k_TilesetLayerFirstTileX = 8;
    private static final int k_TilesetLayerFirstTileY = 9;
    private static final int k_TilesetLayerLastTileX = 10;
    private static final int k_TilesetLayerLastTileY = 11;
    private static final int k_TilesetLayerCamX = 12;
    private static final int k_TilesetLayerCamY = 13;
    private static final int k_TilesetLayerFlag = 14;
    private static final int k_TilesetLayerCOUNT = 15;
    private static final int k_TilesetLayerImageCB = 0;
    private static final int k_TilesetLayerImageCOUNT = 1;
    private static final int k_TilesetLayerGraphicsCB = 0;
    private static final int k_TilesetLayerGraphicsCOUNT = 1;
    private static final int k_TilesetLayerDataMap = 0;
    private static final int k_TilesetLayerDataFlip = 1;
    private static final int k_TilesetLayerDataCOUNT = 2;
    private static int[] s_TilesetInfo;
    private static int[][] s_TilesetLayerInfo;
    private static byte[][][] s_TilesetLayerData;
    private static Image[][] s_TilesetLayerImage;
    private static Graphics[][] s_TilesetLayerGraphics;
    private static ASprite[] s_TilesetSprite;
    private static final int flag_wrappingX = 1;
    private static final int flag_wrappingY = 2;
    private static final int flag_useCB = 4;
    private static final int flag_origin = 8;
    
    GLLibPlayer() {
        this.Reset();
    }
    
    GLLibPlayer(final ASprite sprite, final int x, final int y) {
        if (GLLibConfig.sprite_animFPS > 1000) {
            GLLib.Assert(false, "GLLibPlayer : Invalid value of GLLibConfig.sprite_animFPS > 1000");
        }
        this.Reset();
        this.posX = x;
        this.posY = y;
        this.SetSprite(sprite);
    }
    
    void Reset() {
        this.posX = 0;
        this.posY = 0;
        this.curAnim = -1;
        this.curFrame = 0;
        this.sprite = null;
        this.curFlags = 0;
        this.curTime = 0;
        this.nbLoop = 1;
        this.animIsOver = true;
    }
    
    final void SetPos(final int x, final int y) {
        this.posX = x;
        this.posY = y;
    }
    
    final ASprite GetSprite() {
        return this.sprite;
    }
    
    void SetSprite(final ASprite sprite) {
        this.sprite = sprite;
        this.SetAnim(-1, -1);
    }
    
    final void SetAnim(final int anim) {
        GLLib.Warning("GLLibPlayer.SetAnim(int anim) . this function is deprecated, use GLLibPlayer.SetAnim(int anim, int nbLoop) instead");
        this.SetAnim(anim, -1);
    }
    
    void SetAnim(final int anim, final int nbLoop) {
        if (this.sprite == null) {
            GLLib.Assert(false, "GLLibPlayer.SetAnim().sprite is not set");
        }
        if (anim >= this.GetNbanim()) {
            GLLib.Assert(false, "GLLibPlayer.SetAnim().anim out of range");
        }
        if (nbLoop == 0) {
            GLLib.Assert(false, "GLLibPlayer.SetAnim().nbLoop is invalid");
        }
        if (this.animIsOver || anim != this.curAnim) {
            this.curAnim = anim;
            this.SetFrame(0);
            this.nbLoop = nbLoop - 1;
            this.animIsOver = false;
        }
    }
    
    final int GetAnim() {
        return this.curAnim;
    }
    
    int SetFrame(int frame) {
        if (this.sprite == null) {
            GLLib.Assert(false, "GLLibPlayer.SetFrame().sprite is not set");
        }
        if (frame < 0) {
            GLLib.Assert(false, "GLLibPlayer.SetFrame().frame is negative");
        }
        if (this.curAnim < 0) {
            return -1;
        }
        for (int nbFrame = this.GetNbFrame(); frame > nbFrame; frame -= nbFrame) {}
        this.curFrame = frame;
        this.curTime = 0;
        return frame;
    }
    
    final int GetFrame() {
        return this.curFrame;
    }
    
    final void SetTransform(final int transform) {
        switch (transform) {
            case 0: {
                this.curFlags = 0;
                break;
            }
            case 2: {
                this.curFlags = 1;
                break;
            }
            case 1: {
                this.curFlags = 2;
                break;
            }
            case 3: {
                this.curFlags = 3;
                break;
            }
            case 5: {
                this.curFlags = 4;
                break;
            }
            case 6: {
                this.curFlags = 7;
                break;
            }
            case 7: {
                this.curFlags = 6;
                break;
            }
            case 4: {
                this.curFlags = 5;
                break;
            }
        }
    }
    
    final int GetTransform() {
        switch (this.curFlags) {
            case 0: {
                return 0;
            }
            case 1: {
                return 2;
            }
            case 2: {
                return 1;
            }
            case 3: {
                return 3;
            }
            case 4: {
                return 5;
            }
            case 7: {
                return 6;
            }
            case 6: {
                return 7;
            }
            case 5: {
                return 4;
            }
            default: {
                return -1;
            }
        }
    }
    
    int GetNbanim() {
        if (this.sprite == null) {
            GLLib.Assert(false, "GLLibPlayer.GetNbanim().sprite is not set");
        }
        return this.sprite._anims_naf.length;
    }
    
    int GetNbFrame() {
        if (this.sprite == null) {
            GLLib.Assert(false, "GLLibPlayer.GetNbFrame().sprite is not set");
        }
        if (this.curAnim >= 0) {
            return this.sprite.GetAFrames(this.curAnim);
        }
        return -1;
    }
    
    final int GetDuration() {
        if (this.sprite == null) {
            GLLib.Assert(false, "GLLibPlayer.GetDuration().sprite is not set");
        }
        if (this.curAnim >= 0) {
            return this.sprite.GetAFrameTime(this.curAnim, this.curFrame) * GLLibPlayer.k_animBaseFrameTime;
        }
        return 0;
    }
    
    boolean IsAnimOver() {
        if (this.sprite == null) {
            GLLib.Assert(false, "GLLibPlayer.isAnimOver().sprite is not set");
        }
        return this.curAnim < 0 || (this.nbLoop >= 0 && this.animIsOver);
    }
    
    void Render() {
        if (this.sprite == null) {
            GLLib.Assert(false, "GLLibPlayer.render().sprite is not set");
        }
        if (this.curAnim < 0) {
            return;
        }
        this.sprite.PaintAFrame(GLLib.g, this.curAnim, this.curFrame, this.posX, this.posY, this.curFlags, 0, 0);
    }
    
    final void Update() {
        GLLib.Warning("GLLibPlayer.Update() . this function is deprecated, use GLLibPlayer.Update(int DT) instead");
        if (GLLibConfig.sprite_animFPS == 1000) {
            this.Update(1);
        }
        else {
            this.Update(GLLib.s_game_frameDT);
        }
    }
    
    void Update(final int DT) {
        if (DT < 0) {
            GLLib.Assert(false, "GLLibPlayer.Update.DT is negative");
        }
        if (GLLibConfig.sprite_animFPS == 1000) {
            if (DT > 1) {
                GLLib.Warning("GLLibPlayer.Update was called with DT larger than 1, the player is currently working as Frame Based Player");
            }
        }
        else if (DT == 1) {
            GLLib.Warning("GLLibPlayer.Update was called with DT equal 1, the player is currently working as a Time Based Player, it should be more than 1 ms ?");
        }
        if (this.animIsOver || this.curAnim < 0) {
            return;
        }
        this.curTime += DT;
        int duration = this.GetDuration();
        if (duration == 0) {
            GLLib.Assert(false, "GLLibPlayer.Update.frame " + this.curFrame + " of animation " + this.curAnim + " has a duration of 0");
        }
        while (this.curTime >= duration) {
            this.curTime -= duration;
            if (this.curFrame < this.sprite.GetAFrames(this.curAnim) - 1) {
                ++this.curFrame;
            }
            else {
                if (this.nbLoop == 0) {
                    this.animIsOver = true;
                    break;
                }
                if (this.nbLoop > 0) {
                    --this.nbLoop;
                }
                this.curFrame = 0;
            }
            duration = this.GetDuration();
            if (duration == 0) {
                GLLib.Assert(false, "GLLibPlayer.Update.frame " + this.curFrame + " of animation " + this.curAnim + " has a duration of 0");
            }
        }
    }
    
    private static int SndQueue_NormalizeIndex(int index) {
        while (index >= 7) {
            index -= 7;
        }
        while (index < 0) {
            index += 7;
        }
        return index;
    }
    
    private static int SndQueue_GetIndex(final int channel, final int index) {
        return channel * 7 * 5 + index * 5;
    }
    
    private static int SndQueue_GetData(final int channel, final int index) {
        return GLLibPlayer.s_snd_queue[SndQueue_GetIndex(channel, GLLibPlayer.s_snd_queue_pointer[channel]) + index];
    }
    
    private static void SndQueue_Push(final int channel, final int command, final int index, final int priority, final int volume, final int loop) {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return;
        }
        if (GLLibPlayer.s_snd_queue_size[channel] >= 7) {
            GLLib.Assert(false, "SndQueue_Push: Too many sound requests given before Snd_Update!");
        }
        final int start = GLLibPlayer.s_snd_queue_pointer[channel];
        final int size = GLLibPlayer.s_snd_queue_size[channel];
        final int end = SndQueue_NormalizeIndex(start + size);
        for (int i = 0; i < size; ++i) {
            int idx = SndQueue_NormalizeIndex(end - i - 1);
            idx = SndQueue_GetIndex(channel, idx);
            if (GLLibPlayer.s_snd_queue[idx + 0] == command) {
                if ((command != 3 && command != 1) || GLLibPlayer.s_snd_queue[idx + 2] >= priority) {
                    GLLibPlayer.s_snd_queue[idx + 0] = 0;
                }
            }
        }
        int idx = SndQueue_GetIndex(channel, end);
        GLLibPlayer.s_snd_queue[idx + 0] = command;
        GLLibPlayer.s_snd_queue[idx + 1] = index;
        GLLibPlayer.s_snd_queue[idx + 2] = priority;
        GLLibPlayer.s_snd_queue[idx + 3] = volume;
        GLLibPlayer.s_snd_queue[idx + 4] = loop;
        final int[] s_snd_queue_size = GLLibPlayer.s_snd_queue_size;
        ++s_snd_queue_size[channel];
    }
    
    private static void SndQueue_Push(final int channel, final int command) {
        SndQueue_Push(channel, command, -1, -1, -1, -1);
    }
    
    private static void SndQueue_Pop(final int channel) {
        GLLibPlayer.s_snd_queue_pointer[channel] = SndQueue_NormalizeIndex(GLLibPlayer.s_snd_queue_pointer[channel] + 1);
        final int[] s_snd_queue_size = GLLibPlayer.s_snd_queue_size;
        --s_snd_queue_size[channel];
    }
    
    static void Snd_Init(final int nbSoundSlot) throws Exception {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        GLLib.Dbg("SOUND : Init : JSR135");
        GLLibPlayer.s_snd_Player = new Player[GLLibPlayer.k_snd_nbChannel];
        if (GLLibConfig.sound_useCachedPlayers) {
            GLLibPlayer.s_snd_PlayerSlot = new Player[nbSoundSlot];
        }
        GLLibPlayer.s_snd_index = new int[GLLibPlayer.k_snd_nbChannel];
        GLLibPlayer.s_snd_priority = new int[GLLibPlayer.k_snd_nbChannel];
        GLLibPlayer.s_snd_state = new int[GLLibPlayer.k_snd_nbChannel];
        GLLibPlayer.s_snd_volume = new int[GLLibPlayer.k_snd_nbChannel];
        GLLibPlayer.s_snd_loop = new int[GLLibPlayer.k_snd_nbChannel];
        GLLibPlayer.s_snd_queue = new int[GLLibPlayer.k_snd_nbChannel * 7 * 5];
        GLLibPlayer.s_snd_queue_pointer = new int[GLLibPlayer.k_snd_nbChannel];
        GLLibPlayer.s_snd_queue_size = new int[GLLibPlayer.k_snd_nbChannel];
        for (int i = 0; i < GLLibPlayer.k_snd_nbChannel; ++i) {
            GLLibPlayer.s_snd_index[i] = -1;
            GLLibPlayer.s_snd_queue_pointer[i] = 0;
            GLLibPlayer.s_snd_queue_size[i] = 0;
        }
        GLLibPlayer.s_snd_maxNbSoundSlot = nbSoundSlot;
        GLLibPlayer.s_snd_sndSlot = new byte[GLLibPlayer.s_snd_maxNbSoundSlot][];
        GLLibPlayer.s_snd_sndType = new int[GLLibPlayer.s_snd_maxNbSoundSlot];
        if (GLLibConfig.sound_useFakeMediaDuration) {
            GLLibPlayer.s_snd_sndDuration = new int[GLLibPlayer.s_snd_maxNbSoundSlot];
            GLLibPlayer.s_snd_playTime = new long[GLLibPlayer.k_snd_nbChannel];
        }
        GLLibPlayer.s_snd_masterVolume = 100;
        GLLibPlayer.s_snd_isSoundEngineInitialized = true;
        if (GLLibConfig.sound_enableThread) {
            GLLibPlayer.s_pSoundPlayerIns = new GLLibPlayer();
            (GLLibPlayer.s_pThread = new Thread(GLLibPlayer.s_pSoundPlayerIns)).start();
        }
    }
    
    static void Snd_Quit() throws Exception {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        Snd_StopAllSounds();
        for (int i = 0; i < GLLibPlayer.k_snd_nbChannel; ++i) {
            Snd_FreeChannelExec(i);
        }
        GLLibPlayer.s_snd_Player = null;
        GLLibPlayer.s_snd_isSoundEngineInitialized = false;
        for (int i = 0; i < GLLibPlayer.s_snd_maxNbSoundSlot; ++i) {
            GLLibPlayer.s_snd_sndSlot[i] = null;
        }
        GLLibPlayer.s_snd_sndSlot = null;
        GLLibPlayer.s_snd_sndType = null;
        if (GLLibConfig.sound_useFakeMediaDuration) {
            GLLibPlayer.s_snd_sndDuration = null;
            GLLibPlayer.s_snd_playTime = null;
        }
        if (GLLibConfig.sound_useCachedPlayers) {
            for (int i = 0; i < GLLibPlayer.s_snd_maxNbSoundSlot; ++i) {
                GLLibPlayer.s_snd_PlayerSlot[i] = null;
            }
        }
        GLLibPlayer.s_snd_index = null;
        GLLibPlayer.s_snd_priority = null;
        GLLibPlayer.s_snd_state = null;
        GLLibPlayer.s_snd_volume = null;
        GLLibPlayer.s_snd_loop = null;
        GLLibPlayer.s_pThread = null;
        GLLibPlayer.s_snd_queue = null;
        GLLibPlayer.s_snd_queue_pointer = null;
        GLLibPlayer.s_snd_queue_size = null;
        GLLib.Gc();
    }
    
    static void Snd_LoadSound(final String dataFileName, final int resourceIndex) throws Exception {
        Snd_LoadSound(dataFileName, resourceIndex, true);
    }
    
    static void Snd_LoadSound(final String dataFileName, final int resourceIndex, final boolean bCacheThisSound) throws Exception {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return;
        }
        if (resourceIndex >= GLLibPlayer.s_snd_sndSlot.length) {
            GLLib.Assert(false, "resourceIndex is larger that slot count. Read the Warning in the doc.");
        }
        if (resourceIndex < 0) {
            return;
        }
        if (GLLibPlayer.s_snd_sndSlot == null) {
            GLLib.Assert(false, "Snd_LoadSound.snd not correctly initialized");
        }
        GLLib.Pack_Open(dataFileName);
        final byte[] pData = GLLib.Pack_ReadData(resourceIndex);
        Snd_LoadSound(pData, GLLib.s_pack_lastDataReadMimeType, resourceIndex, bCacheThisSound);
    }
    
    static void Snd_LoadSound(final byte[] soundData, final int nMIME, final int index) throws Exception {
        Snd_LoadSound(soundData, nMIME, index, true);
    }
    
    static void Snd_LoadSound(final byte[] soundData, final int nMIME, final int index, final boolean bCacheThisSound) throws Exception {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return;
        }
        if (index >= GLLibPlayer.s_snd_sndSlot.length) {
            GLLib.Assert(false, "index is larger that slot count. Read the Warning in the doc.");
        }
        GLLibPlayer.s_snd_sndSlot[index] = soundData;
        GLLibPlayer.s_snd_sndType[index] = nMIME;
        if (GLLibConfig.sound_useCachedPlayers && bCacheThisSound) {
            GLLibPlayer.s_snd_PlayerSlot[index] = Manager.createPlayer((InputStream)new ByteArrayInputStream(GLLibPlayer.s_snd_sndSlot[index]), GLLib.GetMIME(GLLibPlayer.s_snd_sndType[index]));
            if (GLLibConfig.sound_useRealizedPlayers) {
                GLLibPlayer.s_snd_PlayerSlot[index].realize();
                if (GLLibConfig.sound_usePrefetchedPlayers) {
                    GLLibPlayer.s_snd_PlayerSlot[index].prefetch();
                }
            }
        }
    }
    
    static void Snd_UnLoadSound(final int index) throws Exception {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return;
        }
        if (GLLibPlayer.s_snd_sndSlot == null) {
            GLLib.Assert(false, "Snd_unLoadSound.array is not initialised");
        }
        if (index < 0) {
            return;
        }
        GLLibPlayer.s_snd_sndSlot[index] = null;
        if (GLLibConfig.sound_useCachedPlayers) {
            GLLibPlayer.s_snd_PlayerSlot[index] = null;
        }
        GLLib.Gc();
    }
    
    static final void Snd_FreeChannel(final int channel) {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        SndQueue_Push(channel, 2, -1, -1, -1, -1);
    }
    
    static void Snd_PrepareSound(final int channel, final int index, final int priority) {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        if (index < 0) {
            return;
        }
        SndQueue_Push(channel, 1, index, priority, -1, -1);
    }
    
    static void Snd_Play(final int channel, final int index, final int loop, final int volume, final int priority) {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        if (loop < 0) {
            GLLib.Assert(false, "Snd_play.invalid loop number");
        }
        if (index < 0 || volume == 0) {
            return;
        }
        SndQueue_Push(channel, 3, index, priority, volume, loop);
    }
    
    static final void Snd_Stop(final int channel) {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        SndQueue_Push(channel, 4);
    }
    
    static final void Snd_Pause(final int channel) {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        SndQueue_Push(channel, 5);
    }
    
    static final void Snd_Resume(final int channel) {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        SndQueue_Push(channel, 6);
    }
    
    private static void Snd_PrepareExec(final int channel) throws Exception {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        final int index = SndQueue_GetData(channel, 1);
        final int priority = SndQueue_GetData(channel, 2);
        if (GLLibPlayer.s_snd_state[channel] == 2 && GLLibPlayer.s_snd_priority[channel] < priority) {
            return;
        }
        if (GLLibPlayer.s_snd_index[channel] == index && GLLibPlayer.s_snd_state[channel] != 0) {
            return;
        }
        Snd_FreeChannelExec(channel);
        if (GLLibConfig.sound_useCachedPlayers) {
            GLLibPlayer.s_snd_Player[channel] = GLLibPlayer.s_snd_PlayerSlot[index];
            if (GLLibPlayer.s_snd_Player[channel] == null) {
                GLLibPlayer.s_snd_Player[channel] = Manager.createPlayer((InputStream)new ByteArrayInputStream(GLLibPlayer.s_snd_sndSlot[index]), GLLib.GetMIME(GLLibPlayer.s_snd_sndType[index]));
            }
        }
        else {
            GLLibPlayer.s_snd_Player[channel] = Manager.createPlayer((InputStream)new ByteArrayInputStream(GLLibPlayer.s_snd_sndSlot[index]), GLLib.GetMIME(GLLibPlayer.s_snd_sndType[index]));
        }
        if (GLLibPlayer.s_snd_Player[channel] == null) {
            GLLib.Dbg("    ERROR.player is null 1092");
            return;
        }
        if (!GLLibConfig.sound_useRealizedPlayers) {
            GLLibPlayer.s_snd_Player[channel].realize();
        }
        if (!GLLibConfig.sound_usePrefetchedPlayers) {
            GLLibPlayer.s_snd_Player[channel].prefetch();
        }
        GLLibPlayer.s_snd_state[channel] = 1;
        GLLibPlayer.s_snd_index[channel] = index;
    }
    
    private static void Snd_PlayExec(final int channel) throws Exception {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        Snd_PrepareExec(channel);
        if (GLLibPlayer.s_snd_state[channel] != 1 || GLLibPlayer.s_snd_Player[channel] == null) {
            return;
        }
        final int index = SndQueue_GetData(channel, 1);
        final int priority = SndQueue_GetData(channel, 2);
        final int loop = SndQueue_GetData(channel, 4);
        final int volume = SndQueue_GetData(channel, 3);
        if (loop == 0) {
            GLLibPlayer.s_snd_Player[channel].setLoopCount(-1);
        }
        else {
            GLLibPlayer.s_snd_Player[channel].setLoopCount(loop);
        }
        if (GLLibConfig.sound_useSetLevel) {
            ((VolumeControl)((Controllable)GLLibPlayer.s_snd_Player[channel]).getControl("VolumeControl")).setLevel(volume * GLLibPlayer.s_snd_masterVolume * 100 / 10000);
        }
        if (GLLibConfig.sound_useSetMediaTimeBeforePlay) {
            GLLibPlayer.s_snd_Player[channel].setMediaTime(0L);
        }
        GLLibPlayer.s_snd_Player[channel].start();
        GLLibPlayer.s_snd_state[channel] = 2;
        GLLibPlayer.s_snd_volume[channel] = volume;
        GLLibPlayer.s_snd_loop[channel] = loop;
        GLLibPlayer.s_snd_priority[channel] = priority;
        GLLibPlayer.s_snd_index[channel] = index;
        if (GLLibConfig.sound_useFakeMediaDuration) {
            GLLibPlayer.s_snd_playTime[channel] = System.currentTimeMillis();
        }
    }
    
    static void Snd_SetMasterVolume(final int volume) throws Exception {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return;
        }
        GLLibPlayer.s_snd_masterVolume = volume;
        try {
            for (int channel = 0; channel < GLLibPlayer.k_snd_nbChannel; ++channel) {
                if (GLLibPlayer.s_snd_Player[channel] != null) {
                    if (GLLibPlayer.s_snd_Player[channel] != null && GLLibConfig.sound_useSetLevel) {
                        ((VolumeControl)((Controllable)GLLibPlayer.s_snd_Player[channel]).getControl("VolumeControl")).setLevel(GLLibPlayer.s_snd_volume[channel] * GLLibPlayer.s_snd_masterVolume * 100 / 10000);
                    }
                }
            }
        }
        catch (final Exception ex) {}
    }
    
    static int Snd_GetChannelVolume(final int channel) throws Exception {
        if (!GLLibConfig.sound_enable) {
            return 0;
        }
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return 0;
        }
        try {
            if (GLLibPlayer.s_snd_Player[channel] == null) {
                return 0;
            }
            return ((VolumeControl)((Controllable)GLLibPlayer.s_snd_Player[channel]).getControl("VolumeControl")).getLevel() * 100 * 100 / (GLLibPlayer.s_snd_masterVolume * 100);
        }
        catch (final Exception e) {
            return 0;
        }
    }
    
    private static void Snd_StopExec(final int channel) throws Exception {
        if (GLLibPlayer.s_snd_Player[channel] == null) {
            return;
        }
        GLLibPlayer.s_snd_Player[channel].stop();
        GLLibPlayer.s_snd_state[channel] = 1;
        if (GLLibConfig.sound_useFreeChannelOnStop) {
            Snd_FreeChannelExec(channel);
        }
        if (GLLibConfig.sound_useFakeMediaDuration) {
            GLLibPlayer.s_snd_playTime[channel] = 0L;
        }
    }
    
    private static void Snd_PauseExec(final int channel) throws Exception {
        if (GLLibPlayer.s_snd_state[channel] != 2) {
            return;
        }
        if (GLLibPlayer.s_snd_Player[channel] == null) {
            GLLib.Assert(false, "Snd_pauseExec.player is null 1413");
        }
        if (GLLibPlayer.s_snd_Player[channel] == null) {
            return;
        }
        if (GLLibPlayer.s_snd_Player[channel].getState() != 400) {
            GLLib.Assert(false, "Snd_pauseExec.player wasn't playing");
        }
        GLLibPlayer.s_snd_Player[channel].stop();
        GLLibPlayer.s_snd_state[channel] = 3;
    }
    
    private static void Snd_ResumeExec(final int channel) throws Exception {
        if (GLLibPlayer.s_snd_state[channel] != 3) {
            return;
        }
        if (GLLibPlayer.s_snd_Player[channel] == null) {
            GLLib.Assert(false, "Snd_resumeExec.player is null 1457");
        }
        if (GLLibPlayer.s_snd_Player[channel] == null) {
            return;
        }
        GLLibPlayer.s_snd_Player[channel].start();
        GLLibPlayer.s_snd_state[channel] = 2;
    }
    
    static void Snd_Update() {
        if (GLLibConfig.sound_enableThread) {
            if (GLLibPlayer.s_pThread != null && !GLLibPlayer.s_pThread.isAlive()) {
                GLLibPlayer.s_pThread.start();
            }
        }
        else {
            Snd_Update_Exec();
        }
    }
    
    private static void Snd_Update_Exec() {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return;
        }
        for (int channel = 0; channel < GLLibPlayer.k_snd_nbChannel; ++channel) {
            if (GLLibPlayer.s_snd_queue_size[channel] > 0 && GLLibPlayer.s_snd_state[channel] == 2) {
                boolean isPlaying;
                try {
                    isPlaying = Snd_IsPlaying(channel);
                }
                catch (final Exception e) {
                    GLLib.Dbg("Snd_update.error on channel (" + channel + ")." + e);
                    isPlaying = false;
                }
                if (!isPlaying) {
                    GLLibPlayer.s_snd_state[channel] = 1;
                }
            }
            while (GLLibPlayer.s_snd_queue_size[channel] > 0) {
                try {
                    final int command = SndQueue_GetData(channel, 0);
                    switch (command) {
                        case 1: {
                            Snd_PrepareExec(channel);
                            break;
                        }
                        case 2: {
                            Snd_FreeChannelExec(channel);
                            break;
                        }
                        case 3: {
                            Snd_PlayExec(channel);
                            break;
                        }
                        case 4: {
                            Snd_StopExec(channel);
                            break;
                        }
                        case 5: {
                            Snd_PauseExec(channel);
                            break;
                        }
                        case 6: {
                            Snd_ResumeExec(channel);
                            break;
                        }
                    }
                }
                catch (final Exception e2) {
                    GLLib.Dbg("Snd_update.error on channel (" + channel + ")." + e2);
                    e2.printStackTrace();
                }
                SndQueue_Pop(channel);
            }
        }
    }
    
    public void run() {
        while (GLLibPlayer.s_pThread != null) {
            Snd_Update_Exec();
            try {
                Thread.sleep(1000 / GLLibConfig.FPSLimiter);
            }
            catch (final Exception e) {}
        }
    }
    
    protected static boolean Snd_IsPlaying(final int channel) throws Exception {
        if (!GLLibConfig.sound_enable) {
            return false;
        }
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return false;
        }
        if (GLLibPlayer.s_snd_Player[channel] == null) {
            return false;
        }
        if (GLLibConfig.sound_useFakeMediaDuration) {
            final int index = Snd_GetCurrentSoundIndex(channel);
            if (index < 0) {
                return false;
            }
            if (System.currentTimeMillis() - GLLibPlayer.s_snd_playTime[channel] > GLLibPlayer.s_snd_sndDuration[index] * GLLibPlayer.s_snd_loop[channel]) {
                return false;
            }
        }
        else if (GLLibPlayer.s_snd_Player[channel].getState() != 400) {
            return false;
        }
        return true;
    }
    
    static void Snd_SetMediaDuration(final int index, final int duration) throws Exception {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        if (!GLLibConfig.sound_useFakeMediaDuration) {
            return;
        }
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return;
        }
        if (index < 0) {
            return;
        }
        GLLibPlayer.s_snd_sndDuration[index] = duration;
    }
    
    private static void Snd_FreeChannelExec(final int channel) throws Exception {
        if (!GLLibConfig.sound_enable) {
            return;
        }
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return;
        }
        if (GLLibPlayer.s_snd_Player[channel] != null) {
            GLLibPlayer.s_snd_Player[channel].stop();
            if (!GLLibConfig.sound_usePrefetchedPlayers) {
                GLLibPlayer.s_snd_Player[channel].deallocate();
            }
            if (!GLLibConfig.sound_useCachedPlayers) {
                GLLibPlayer.s_snd_Player[channel].close();
            }
            else {
                final int index = SndQueue_GetData(channel, 1);
                if (index < 0 || GLLibPlayer.s_snd_PlayerSlot[index] == null) {
                    GLLibPlayer.s_snd_Player[channel].close();
                }
            }
            GLLibPlayer.s_snd_Player[channel] = null;
            GLLib.Gc();
        }
        GLLibPlayer.s_snd_state[channel] = 0;
    }
    
    static void Snd_StopAllSounds() {
        for (int i = 0; i < GLLibPlayer.k_snd_nbChannel; ++i) {
            Snd_Stop(i);
        }
        if (!GLLibConfig.sound_enableThread) {
            Snd_Update();
        }
        else if (GLLib.s_game_isPaused) {
            Snd_Update_Exec();
        }
    }
    
    static int Snd_GetCurrentSoundIndex(final int nChannel) {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return -1;
        }
        if (GLLibPlayer.s_snd_index != null) {
            return GLLibPlayer.s_snd_index[nChannel];
        }
        return -1;
    }
    
    static long Snd_MediaTimeGet(final int channel) {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return -1L;
        }
        try {
            final long t = GLLibPlayer.s_snd_Player[channel].getMediaTime();
            return t;
        }
        catch (final Exception e) {
            return -1L;
        }
    }
    
    static long Snd_MediaTimeSet(final int channel, final long time) {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return -1L;
        }
        try {
            final long t = GLLibPlayer.s_snd_Player[channel].setMediaTime(time);
            return t;
        }
        catch (final Exception e) {
            return -1L;
        }
    }
    
    static boolean Snd_MidiSetChannelVolume(final int channel, final int MIDIChannel, final int volume) throws Exception {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return false;
        }
        final int MIDICONTROL_MAIN_VOLUME = 7;
        final int MIDICONTROL_CONTROL_CHANGE = 176;
        if (GLLibConfig.sound_useJSR135) {
            final MIDIControl midiControl = (MIDIControl)((Controllable)GLLibPlayer.s_snd_Player[channel]).getControl("MIDIControl");
            if (midiControl != null) {
                midiControl.shortMidiEvent(0xB0 | MIDIChannel, 7, volume);
                return true;
            }
        }
        return false;
    }
    
    static void Snd_MidiPlayNote(final int channel, final int MIDIChannel, final int note, final int volume) throws Exception {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return;
        }
        if (GLLibConfig.sound_useJSR135) {
            final int MIDICONTROL_NOTE_ON = 144;
            final MIDIControl midiControl = (MIDIControl)((Controllable)GLLibPlayer.s_snd_Player[channel]).getControl("MIDIControl");
            if (midiControl == null) {
                return;
            }
            midiControl.shortMidiEvent(0x90 | MIDIChannel, note, volume);
        }
    }
    
    static int Snd_TempoGet(final int channel) throws Exception {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return -1;
        }
        if (GLLibConfig.sound_useJSR135) {
            try {
                final TempoControl tempoControl = (TempoControl)((Controllable)GLLibPlayer.s_snd_Player[channel]).getControl("TempoControl");
                if (tempoControl != null) {
                    return tempoControl.getTempo();
                }
            }
            catch (final Exception ex) {}
        }
        return -1;
    }
    
    static boolean Snd_TempoSet(final int channel, final int tempo) throws Exception {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return false;
        }
        if (GLLibConfig.sound_useJSR135) {
            final TempoControl tempoControl = (TempoControl)((Controllable)GLLibPlayer.s_snd_Player[channel]).getControl("TempoControl");
            if (tempoControl != null) {
                tempoControl.setTempo(tempo);
                return true;
            }
        }
        return false;
    }
    
    static int Snd_RateGet(final int channel) {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return -1;
        }
        if (GLLibConfig.sound_useJSR135) {
            try {
                final RateControl rateControl = (RateControl)((Controllable)GLLibPlayer.s_snd_Player[channel]).getControl("RateControl");
                if (rateControl != null) {
                    return rateControl.getRate();
                }
            }
            catch (final Exception ex) {}
        }
        return -1;
    }
    
    static boolean Snd_RateSet(final int channel, final int rate) throws Exception {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return false;
        }
        if (GLLibConfig.sound_useJSR135) {
            final RateControl rateControl = (RateControl)((Controllable)GLLibPlayer.s_snd_Player[channel]).getControl("RateControl");
            if (rateControl != null) {
                rateControl.setRate(rate);
                return true;
            }
        }
        return false;
    }
    
    static int Snd_RateGetMax(final int channel) throws Exception {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return 100000;
        }
        if (GLLibConfig.sound_useJSR135) {
            final RateControl rateControl = (RateControl)((Controllable)GLLibPlayer.s_snd_Player[channel]).getControl("RateControl");
            if (rateControl != null) {
                return rateControl.getMaxRate();
            }
        }
        return 100000;
    }
    
    static int Snd_RateGetMin(final int channel) throws Exception {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return 100000;
        }
        if (GLLibConfig.sound_useJSR135) {
            final RateControl rateControl = (RateControl)((Controllable)GLLibPlayer.s_snd_Player[channel]).getControl("RateControl");
            if (rateControl != null) {
                return rateControl.getMinRate();
            }
        }
        return 100000;
    }
    
    static long Snd_DurationGet(final int channel) throws Exception {
        if (!GLLibPlayer.s_snd_isSoundEngineInitialized) {
            return 0L;
        }
        if (GLLibConfig.sound_useJSR135) {
            return GLLibPlayer.s_snd_Player[channel].getDuration();
        }
        return 0L;
    }
    
    Object Snd_GetChannelPlayer(final int channel) {
        if (!GLLibConfig.sound_enable) {
            return null;
        }
        return GLLibPlayer.s_snd_Player[channel];
    }
    
    static void Snd_ForceExecOnThreadOnGamePause() {
        if (GLLibConfig.sound_enableThread && GLLib.s_game_isPaused) {
            Snd_Update_Exec();
        }
    }
    
    static void Tileset_Init(final int nDestWidth, final int nDestHeight, int nTileWidth, int nTileHeight) {
        GLLibPlayer.s_TilesetInfo = new int[8];
        GLLibPlayer.s_TilesetLayerInfo = new int[GLLibPlayer.s_TilesetMaxLayerCount][15];
        GLLibPlayer.s_TilesetLayerData = new byte[GLLibPlayer.s_TilesetMaxLayerCount][2][];
        GLLibPlayer.s_TilesetLayerImage = new Image[GLLibPlayer.s_TilesetMaxLayerCount][1];
        GLLibPlayer.s_TilesetLayerGraphics = new Graphics[GLLibPlayer.s_TilesetMaxLayerCount][1];
        GLLibPlayer.s_TilesetSprite = new ASprite[GLLibPlayer.s_TilesetMaxLayerCount];
        GLLibPlayer.s_TilesetInfo[0] = nDestWidth;
        GLLibPlayer.s_TilesetInfo[1] = nDestHeight;
        if (GLLibConfig.tileset_useTileShift) {
            final int w = nTileWidth;
            final int h = nTileHeight;
            nTileWidth = GLLib.Math_Log2(nTileWidth);
            nTileHeight = GLLib.Math_Log2(nTileHeight);
            if (1 << nTileWidth != w) {
                GLLib.Assert(false, "Tileset_Init. using GLLibConfig.tileset_UseTileShift with non power of 2 tile width" + nTileWidth);
            }
            if (1 << nTileHeight != h) {
                GLLib.Assert(false, "Tileset_Init. using GLLibConfig.tileset_UseTileShift with non power of 2 tile height" + nTileHeight);
            }
            GLLibPlayer.s_TilesetInfo[3] = nTileWidth;
            GLLibPlayer.s_TilesetInfo[2] = 1 << nTileWidth;
            GLLibPlayer.s_TilesetInfo[4] = GLLibPlayer.s_TilesetInfo[2] - 1;
            GLLibPlayer.s_TilesetInfo[6] = nTileHeight;
            GLLibPlayer.s_TilesetInfo[5] = 1 << nTileHeight;
            GLLibPlayer.s_TilesetInfo[7] = GLLibPlayer.s_TilesetInfo[5] - 1;
        }
        else {
            GLLibPlayer.s_TilesetInfo[2] = nTileWidth;
            GLLibPlayer.s_TilesetInfo[4] = 0;
            GLLibPlayer.s_TilesetInfo[5] = nTileHeight;
            GLLibPlayer.s_TilesetInfo[7] = 0;
        }
        GLLibPlayer.s_bTilesetPlayerInitialized = true;
    }
    
    private static final boolean isFlag(final int nLayer, final int flag) {
        return (GLLibPlayer.s_TilesetLayerInfo[nLayer][14] & flag) != 0x0;
    }
    
    private static final void setFlag(final int nLayer, final int flag, final boolean value) {
        if (value) {
            final int[] array = GLLibPlayer.s_TilesetLayerInfo[nLayer];
            final int n = 14;
            array[n] |= flag;
        }
        else {
            final int[] array2 = GLLibPlayer.s_TilesetLayerInfo[nLayer];
            final int n2 = 14;
            array2[n2] &= ~flag;
        }
    }
    
    static void Tileset_LoadLayer(final int nLayer, final byte[] MapSizes, final byte[] MapData, final byte[] MapFlip, final ASprite MapSprite, final boolean bUseCB, final int origin, final int wrappingX, final int wrappingY) {
        if (bUseCB) {
            Tileset_LoadLayer(nLayer, MapSizes, MapData, MapFlip, MapSprite, nLayer, origin, wrappingX, wrappingY);
        }
        else {
            Tileset_LoadLayer(nLayer, MapSizes, MapData, MapFlip, MapSprite, -1, origin, wrappingX, wrappingY);
        }
    }
    
    static void Tileset_LoadLayer(final int nLayer, final byte[] MapSizes, final byte[] MapData, final byte[] MapFlip, final ASprite MapSprite, final int iUseCB, final int origin, final int wrappingX, final int wrappingY) {
        if (MapSizes == null) {
            GLLib.Assert(false, "GLLibPlayer.Tileset_LoadLayer.MapSizes is null");
        }
        if (MapData == null) {
            GLLib.Assert(false, "GLLibPlayer.Tileset_LoadLayer.MapData is null");
        }
        if (MapSprite == null) {
            GLLib.Assert(false, "GLLibPlayer.Tileset_LoadLayer.MapSprite is null");
        }
        if (wrappingX != 0 && wrappingX != 1) {
            GLLib.Assert(false, "GLLibPlayer.Tileset_LoadLayer. X wrapping is not valid");
        }
        if (wrappingY != 0 && wrappingY != 1) {
            GLLib.Assert(false, "GLLibPlayer.Tileset_LoadLayer. Y wrapping is not valid");
        }
        if (origin != 16 && origin != 32) {
            GLLib.Assert(false, "GLLibPlayer.Tileset_LoadLayer. origin is not valid");
        }
        if (MapFlip == null) {
            GLLib.Dbg("WARNING GLLibPlayer.Tileset_LoadLayer.MapFlip is null, no flip will occur");
        }
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            return;
        }
        Tileset_Destroy(nLayer, false);
        GLLibPlayer.s_TilesetLayerData[nLayer][0] = MapData;
        GLLibPlayer.s_TilesetLayerData[nLayer][1] = MapFlip;
        GLLibPlayer.s_TilesetLayerInfo[nLayer][2] = GLLib.Mem_GetShort(MapSizes, 0);
        GLLibPlayer.s_TilesetLayerInfo[nLayer][3] = GLLib.Mem_GetShort(MapSizes, 2);
        GLLibPlayer.s_TilesetLayerInfo[nLayer][4] = GLLibPlayer.s_TilesetLayerInfo[nLayer][2] * GLLibPlayer.s_TilesetInfo[2];
        GLLibPlayer.s_TilesetLayerInfo[nLayer][5] = GLLibPlayer.s_TilesetLayerInfo[nLayer][3] * GLLibPlayer.s_TilesetInfo[5];
        GLLibPlayer.s_TilesetSprite[nLayer] = MapSprite;
        if (iUseCB > -1) {
            try {
                if (GLLibConfig.tileset_useTileShift) {
                    GLLibPlayer.s_TilesetLayerInfo[nLayer][6] = (GLLibPlayer.s_TilesetInfo[0] & ~GLLibPlayer.s_TilesetInfo[4]) + 1 * GLLibPlayer.s_TilesetInfo[2];
                    GLLibPlayer.s_TilesetLayerInfo[nLayer][7] = (GLLibPlayer.s_TilesetInfo[1] & ~GLLibPlayer.s_TilesetInfo[7]) + 1 * GLLibPlayer.s_TilesetInfo[5];
                    if (GLLibPlayer.s_TilesetLayerInfo[nLayer][6] - GLLibPlayer.s_TilesetInfo[0] < GLLibPlayer.s_TilesetInfo[2]) {
                        final int[] array = GLLibPlayer.s_TilesetLayerInfo[nLayer];
                        final int n = 6;
                        array[n] += GLLibPlayer.s_TilesetInfo[2];
                    }
                    if (GLLibPlayer.s_TilesetLayerInfo[nLayer][7] - GLLibPlayer.s_TilesetInfo[1] < GLLibPlayer.s_TilesetInfo[5]) {
                        final int[] array2 = GLLibPlayer.s_TilesetLayerInfo[nLayer];
                        final int n2 = 7;
                        array2[n2] += GLLibPlayer.s_TilesetInfo[5];
                    }
                }
                else {
                    final int nRestX = GLLibPlayer.s_TilesetInfo[0] % GLLibPlayer.s_TilesetInfo[2];
                    final int nAddX = 1 + ((nRestX != 0) ? 1 : 0);
                    GLLibPlayer.s_TilesetLayerInfo[nLayer][6] = GLLibPlayer.s_TilesetInfo[0] - nRestX + nAddX * GLLibPlayer.s_TilesetInfo[2];
                    final int nRestY = GLLibPlayer.s_TilesetInfo[1] % GLLibPlayer.s_TilesetInfo[5];
                    final int nAddY = 1 + ((nRestY != 0) ? 1 : 0);
                    GLLibPlayer.s_TilesetLayerInfo[nLayer][7] = GLLibPlayer.s_TilesetInfo[1] - nRestY + nAddY * GLLibPlayer.s_TilesetInfo[5];
                }
                if (iUseCB == nLayer) {
                    if (GLLibPlayer.s_TilesetLayerImage[nLayer][0] == null || GLLibPlayer.s_TilesetLayerImage[nLayer][0].getWidth() != GLLibPlayer.s_TilesetLayerInfo[nLayer][6] || GLLibPlayer.s_TilesetLayerImage[nLayer][0].getHeight() != GLLibPlayer.s_TilesetLayerInfo[nLayer][7]) {
                        GLLibPlayer.s_TilesetLayerImage[nLayer][0] = Image.createImage(GLLibPlayer.s_TilesetLayerInfo[nLayer][6], GLLibPlayer.s_TilesetLayerInfo[nLayer][7]);
                        GLLibPlayer.s_TilesetLayerGraphics[nLayer][0] = GLLibPlayer.s_TilesetLayerImage[nLayer][0].getGraphics();
                    }
                }
                else {
                    if (GLLibPlayer.s_TilesetLayerImage[iUseCB][0] == null) {
                        GLLib.Assert(false, "GLLibPlayer.Tileset_LoadLayer. layer " + iUseCB + " has no circular buffer allocated");
                    }
                    GLLibPlayer.s_TilesetLayerImage[nLayer][0] = GLLibPlayer.s_TilesetLayerImage[iUseCB][0];
                    GLLibPlayer.s_TilesetLayerGraphics[nLayer][0] = GLLibPlayer.s_TilesetLayerGraphics[iUseCB][0];
                }
                setFlag(nLayer, 4, true);
            }
            catch (final Exception e) {
                GLLib.Assert(false, "GLLibPlayer.Tileset_LoadLayer.pb while ceating circular buffer : " + e.toString());
            }
        }
        GLLibPlayer.s_TilesetLayerInfo[nLayer][8] = -1;
        GLLibPlayer.s_TilesetLayerInfo[nLayer][9] = -1;
        GLLibPlayer.s_TilesetLayerInfo[nLayer][10] = -1;
        GLLibPlayer.s_TilesetLayerInfo[nLayer][11] = -1;
        GLLibPlayer.s_TilesetLayerInfo[nLayer][0] = 1;
        GLLibPlayer.s_TilesetLayerInfo[nLayer][1] = 1;
        GLLibPlayer.s_TilesetLayerInfo[nLayer][12] = 0;
        GLLibPlayer.s_TilesetLayerInfo[nLayer][13] = 0;
        setFlag(nLayer, 1, wrappingX == 1);
        setFlag(nLayer, 2, wrappingY == 1);
        setFlag(nLayer, 8, origin == 32);
    }
    
    static void Tileset_Destroy(final int nLayer) {
        Tileset_Destroy(nLayer, true);
    }
    
    static void Tileset_Destroy(final int nLayer, final boolean bFreeBufferImage) {
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            return;
        }
        GLLibPlayer.s_TilesetLayerInfo[nLayer] = new int[15];
        if (bFreeBufferImage) {
            GLLibPlayer.s_TilesetLayerImage[nLayer] = new Image[1];
            GLLibPlayer.s_TilesetLayerGraphics[nLayer] = new Graphics[1];
        }
        GLLibPlayer.s_TilesetLayerData[nLayer] = new byte[2][];
        GLLibPlayer.s_TilesetSprite[nLayer] = null;
    }
    
    static void Tileset_Draw(final Graphics g, final int nLayer) {
        Tileset_Draw(g, 0, 0, nLayer);
    }
    
    static void Tileset_Draw(final Graphics g, final int dx, final int dy, final int nLayer) {
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            return;
        }
        int cx = 0;
        int cy = 0;
        int cw = 0;
        int ch = 0;
        if (g != null) {
            cx = g.getClipX();
            cy = g.getClipY();
            cw = g.getClipWidth();
            ch = g.getClipHeight();
        }
        final int destWidth = GLLibPlayer.s_TilesetInfo[0];
        final int destHeight = GLLibPlayer.s_TilesetInfo[1];
        if (nLayer == -1) {
            for (int i = 0; i < GLLibPlayer.s_TilesetMaxLayerCount; ++i) {
                Tileset_Draw(g, i);
            }
            return;
        }
        if (GLLibPlayer.s_TilesetLayerInfo[nLayer][0] != 1 || GLLibPlayer.s_TilesetLayerInfo[nLayer][1] != 1) {
            return;
        }
        GLLib.Profiler_BeginNamedEvent("Tileset_Draw");
        int originX = GLLibPlayer.s_TilesetLayerInfo[nLayer][12];
        int originY = GLLibPlayer.s_TilesetLayerInfo[nLayer][13];
        if (isFlag(nLayer, 4)) {
            int firstTileX;
            int firstTileY;
            int lastTileX;
            int lastTileY;
            if (GLLibConfig.tileset_useTileShift) {
                firstTileX = originX >> GLLibPlayer.s_TilesetInfo[3];
                firstTileY = originY >> GLLibPlayer.s_TilesetInfo[6];
                lastTileX = originX + GLLibPlayer.s_TilesetInfo[0] >> GLLibPlayer.s_TilesetInfo[3];
                lastTileY = originY + GLLibPlayer.s_TilesetInfo[1] >> GLLibPlayer.s_TilesetInfo[6];
            }
            else {
                int nTmpStartX = originX;
                int nTmpStartY = originY;
                if (nTmpStartX < 0) {
                    nTmpStartX -= GLLibPlayer.s_TilesetInfo[2];
                }
                if (nTmpStartY < 0) {
                    nTmpStartY -= GLLibPlayer.s_TilesetInfo[5];
                }
                firstTileX = nTmpStartX / GLLibPlayer.s_TilesetInfo[2];
                firstTileY = nTmpStartY / GLLibPlayer.s_TilesetInfo[5];
                lastTileX = firstTileX + GLLibPlayer.s_TilesetLayerInfo[nLayer][6] / GLLibPlayer.s_TilesetInfo[2] - 1;
                lastTileY = firstTileY + GLLibPlayer.s_TilesetLayerInfo[nLayer][7] / GLLibPlayer.s_TilesetInfo[5] - 1;
            }
            if (GLLibPlayer.s_TilesetLayerInfo[nLayer][8] != firstTileX || GLLibPlayer.s_TilesetLayerInfo[nLayer][10] != lastTileX) {
                int start;
                int end;
                if (GLLibPlayer.s_TilesetLayerInfo[nLayer][8] < firstTileX || GLLibPlayer.s_TilesetLayerInfo[nLayer][10] < lastTileX) {
                    if (GLLibPlayer.s_TilesetLayerInfo[nLayer][10] < firstTileX) {
                        start = firstTileX;
                        end = lastTileX;
                    }
                    else {
                        start = GLLibPlayer.s_TilesetLayerInfo[nLayer][10] + 1;
                        end = lastTileX;
                    }
                }
                else if (GLLibPlayer.s_TilesetLayerInfo[nLayer][8] > lastTileX) {
                    start = firstTileX;
                    end = lastTileX;
                }
                else {
                    start = firstTileX;
                    end = GLLibPlayer.s_TilesetLayerInfo[nLayer][8] - 1;
                }
                Tileset_UpdateBuffer(GLLibPlayer.s_TilesetLayerGraphics[nLayer][0], nLayer, start, firstTileY, end - start, lastTileY - firstTileY, 0, 0);
                GLLibPlayer.s_TilesetLayerInfo[nLayer][8] = firstTileX;
                GLLibPlayer.s_TilesetLayerInfo[nLayer][10] = lastTileX;
            }
            if (GLLibPlayer.s_TilesetLayerInfo[nLayer][9] != firstTileY || GLLibPlayer.s_TilesetLayerInfo[nLayer][11] != lastTileY) {
                int start;
                int end;
                if (GLLibPlayer.s_TilesetLayerInfo[nLayer][9] < firstTileY || GLLibPlayer.s_TilesetLayerInfo[nLayer][11] < lastTileY) {
                    if (GLLibPlayer.s_TilesetLayerInfo[nLayer][11] < firstTileY) {
                        start = firstTileY;
                        end = lastTileY;
                    }
                    else {
                        start = GLLibPlayer.s_TilesetLayerInfo[nLayer][11] + 1;
                        end = lastTileY;
                    }
                }
                else if (GLLibPlayer.s_TilesetLayerInfo[nLayer][9] > lastTileY) {
                    start = firstTileY;
                    end = lastTileY;
                }
                else {
                    start = firstTileY;
                    end = GLLibPlayer.s_TilesetLayerInfo[nLayer][9] - 1;
                }
                Tileset_UpdateBuffer(GLLibPlayer.s_TilesetLayerGraphics[nLayer][0], nLayer, firstTileX, start, lastTileX - firstTileX, end - start, 0, 0);
                GLLibPlayer.s_TilesetLayerInfo[nLayer][9] = firstTileY;
                GLLibPlayer.s_TilesetLayerInfo[nLayer][11] = lastTileY;
            }
            if (g != null) {
                while (originX < 0) {
                    originX += GLLibPlayer.s_TilesetLayerInfo[nLayer][6];
                }
                while (originY < 0) {
                    originY += GLLibPlayer.s_TilesetLayerInfo[nLayer][7];
                }
                final int modX0 = originX % GLLibPlayer.s_TilesetLayerInfo[nLayer][6];
                final int modY0 = originY % GLLibPlayer.s_TilesetLayerInfo[nLayer][7];
                final int modX2 = (originX + destWidth) % GLLibPlayer.s_TilesetLayerInfo[nLayer][6];
                final int modY2 = (originY + destHeight) % GLLibPlayer.s_TilesetLayerInfo[nLayer][7];
                if (modX2 > modX0) {
                    if (modY2 > modY0) {
                        Tileset_Draw2Screen(g, nLayer, modX0, modY0, destWidth, destHeight, 0 + dx, 0 + dy);
                    }
                    else {
                        Tileset_Draw2Screen(g, nLayer, modX0, modY0, destWidth, destHeight - modY2, 0 + dx, 0 + dy);
                        Tileset_Draw2Screen(g, nLayer, modX0, 0, destWidth, modY2, 0 + dx, destHeight - modY2 + dy);
                    }
                }
                else if (modY2 > modY0) {
                    Tileset_Draw2Screen(g, nLayer, modX0, modY0, destWidth - modX2, destHeight, 0 + dx, 0 + dy);
                    Tileset_Draw2Screen(g, nLayer, 0, modY0, modX2, destHeight, destWidth - modX2 + dx, 0 + dy);
                }
                else {
                    Tileset_Draw2Screen(g, nLayer, modX0, modY0, destWidth - modX2, destHeight - modY2, 0 + dx, 0 + dy);
                    Tileset_Draw2Screen(g, nLayer, modX0, 0, destWidth - modX2, modY2, 0 + dx, destHeight - modY2 + dy);
                    Tileset_Draw2Screen(g, nLayer, 0, modY0, modX2, destHeight - modY2, destWidth - modX2 + dx, 0 + dy);
                    Tileset_Draw2Screen(g, nLayer, 0, 0, modX2, modY2, destWidth - modX2 + dx, destHeight - modY2 + dy);
                }
            }
        }
        else {
            int tileX0;
            int tileY0;
            int nbTileX;
            int nbTileY;
            int offsetX;
            int offsetY;
            if (GLLibConfig.tileset_useTileShift) {
                tileX0 = originX >> GLLibPlayer.s_TilesetInfo[3];
                tileY0 = originY >> GLLibPlayer.s_TilesetInfo[6];
                nbTileX = destWidth >> GLLibPlayer.s_TilesetInfo[3];
                if (nbTileX << GLLibPlayer.s_TilesetInfo[3] < destWidth) {
                    ++nbTileX;
                }
                nbTileY = destHeight >> GLLibPlayer.s_TilesetInfo[6];
                if (nbTileY << GLLibPlayer.s_TilesetInfo[6] < destHeight) {
                    ++nbTileY;
                }
                offsetX = (tileX0 << GLLibPlayer.s_TilesetInfo[3]) - originX;
                offsetY = (tileY0 << GLLibPlayer.s_TilesetInfo[6]) - originY;
            }
            else {
                int nTmpStartX2 = originX;
                int nTmpStartY2 = originY;
                if (nTmpStartX2 < 0) {
                    nTmpStartX2 -= GLLibPlayer.s_TilesetInfo[2];
                }
                if (nTmpStartY2 < 0) {
                    nTmpStartY2 -= GLLibPlayer.s_TilesetInfo[5];
                }
                tileX0 = nTmpStartX2 / GLLibPlayer.s_TilesetInfo[2];
                tileY0 = nTmpStartY2 / GLLibPlayer.s_TilesetInfo[5];
                nbTileX = destWidth / GLLibPlayer.s_TilesetInfo[2];
                if (nbTileX * GLLibPlayer.s_TilesetInfo[2] < destWidth) {
                    ++nbTileX;
                }
                nbTileY = destHeight / GLLibPlayer.s_TilesetInfo[5];
                if (nbTileY * GLLibPlayer.s_TilesetInfo[5] < destHeight) {
                    ++nbTileY;
                }
                offsetX = tileX0 * GLLibPlayer.s_TilesetInfo[2] - originX;
                offsetY = tileY0 * GLLibPlayer.s_TilesetInfo[5] - originY;
            }
            Tileset_UpdateBuffer(g, nLayer, tileX0, tileY0, nbTileX, nbTileY, offsetX + dx, offsetY + dy);
        }
        if (g != null) {
            g.setClip(cx, cy, cw, ch);
        }
        GLLib.Profiler_EndNamedEvent();
    }
    
    private static void Tileset_Draw2Screen(final Graphics g, final int nLayer, final int srcX, final int srcY, final int width, final int height, final int destX, final int destY) {
        g.setClip(destX, destY, width, height);
        g.drawImage(GLLibPlayer.s_TilesetLayerImage[nLayer][0], destX - srcX, destY - srcY, 0);
    }
    
    static void Tileset_Update(final int nLayer) {
        GLLib.Warning("GLLibPlayer.Tileset_Update(int nLayer) . this function is deprecated, you can stop using it");
    }
    
    private static void Tileset_UpdateBuffer(final Graphics gDest, final int nLayer, int tileX0, int tileY0, int nbTileX, int nbTileY, final int offsetX, final int offsetY) {
        final boolean useCB = isFlag(nLayer, 4);
        final boolean repeatX = isFlag(nLayer, 1);
        final boolean repeatY = isFlag(nLayer, 2);
        final int tileMapWidth = GLLibPlayer.s_TilesetLayerInfo[nLayer][2];
        final int tileMapHeight = GLLibPlayer.s_TilesetLayerInfo[nLayer][3];
        final byte[] dataArray = GLLibPlayer.s_TilesetLayerData[nLayer][0];
        final byte[] flagArray = GLLibPlayer.s_TilesetLayerData[nLayer][1];
        final int tileWidth = GLLibPlayer.s_TilesetInfo[2];
        final int tileHeight = GLLibPlayer.s_TilesetInfo[5];
        int originDestX;
        int destY;
        if (useCB) {
            if (GLLibConfig.tileset_useTileShift) {
                originDestX = (tileX0 << GLLibPlayer.s_TilesetInfo[3]) % GLLibPlayer.s_TilesetLayerInfo[nLayer][6] + offsetX;
                destY = (tileY0 << GLLibPlayer.s_TilesetInfo[6]) % GLLibPlayer.s_TilesetLayerInfo[nLayer][7] + offsetY;
            }
            else {
                originDestX = tileX0 * GLLibPlayer.s_TilesetInfo[2] % GLLibPlayer.s_TilesetLayerInfo[nLayer][6] + offsetX;
                destY = tileY0 * GLLibPlayer.s_TilesetInfo[5] % GLLibPlayer.s_TilesetLayerInfo[nLayer][7] + offsetY;
            }
            if (originDestX < 0) {
                originDestX += GLLibPlayer.s_TilesetLayerInfo[nLayer][6];
            }
            if (destY < 0) {
                destY += GLLibPlayer.s_TilesetLayerInfo[nLayer][7];
            }
        }
        else {
            originDestX = offsetX;
            destY = offsetY;
        }
        if (repeatX) {
            while (tileX0 < 0) {
                tileX0 += tileMapWidth;
            }
            while (tileX0 >= tileMapWidth) {
                tileX0 -= tileMapWidth;
            }
        }
        else {
            if (tileX0 < 0) {
                nbTileX += tileX0;
                tileX0 = 0;
            }
            if (tileX0 + nbTileX >= tileMapWidth) {
                nbTileX = tileMapWidth - tileX0;
            }
        }
        if (repeatY) {
            while (tileY0 < 0) {
                tileY0 += tileMapHeight;
            }
            while (tileY0 >= tileMapHeight) {
                tileY0 -= tileMapHeight;
            }
        }
        else {
            if (tileY0 < 0) {
                nbTileY += tileY0;
                tileY0 = 0;
            }
            if (tileY0 + nbTileY >= tileMapHeight) {
                nbTileY = tileMapHeight - tileY0;
                if (nbTileY == 0) {
                    return;
                }
            }
        }
        while (nbTileY-- >= 0) {
            int destX = originDestX;
            int nbX = nbTileX;
            int tileX = tileX0;
            while (nbX-- >= 0) {
                final int offsetCur = tileX + tileY0 * tileMapWidth;
                if (offsetCur < dataArray.length) {
                    int data;
                    boolean emptyIndex;
                    if (GLLibConfig.tileset_useIndexAsShort) {
                        data = (GLLib.Mem_GetShort(dataArray, offsetCur << 1) & 0xFFFF);
                        emptyIndex = (data == 65535);
                    }
                    else {
                        data = (dataArray[offsetCur] & 0xFF);
                        emptyIndex = (data == 255);
                    }
                    if (!emptyIndex) {
                        int flag;
                        if (flagArray == null) {
                            flag = 0;
                        }
                        else {
                            flag = (flagArray[offsetCur] & 0xFF);
                        }
                        if (GLLibPlayer.s_TilesetSprite[nLayer].GetFrameCount() == 0) {
                            GLLibPlayer.s_TilesetSprite[nLayer].PaintModule(gDest, data, destX, destY, flag);
                        }
                        else {
                            int tx = destX;
                            int ty = destY;
                            if (GLLibConfig.sprite_useTransfFlip) {
                                if ((flag & 0x1) != 0x0) {
                                    tx += GLLibPlayer.s_TilesetInfo[2];
                                }
                                if ((flag & 0x2) != 0x0) {
                                    ty += GLLibPlayer.s_TilesetInfo[5];
                                }
                            }
                            GLLibPlayer.s_TilesetSprite[nLayer].PaintFrame(gDest, data, tx, ty, flag);
                        }
                    }
                }
                if (++tileX >= tileMapWidth) {
                    if (!repeatX) {
                        break;
                    }
                    tileX = 0;
                }
                destX += tileWidth;
                if (useCB && destX >= GLLibPlayer.s_TilesetLayerInfo[nLayer][6]) {
                    destX = 0;
                }
            }
            if (++tileY0 >= tileMapHeight) {
                if (!repeatY) {
                    break;
                }
                tileY0 = 0;
            }
            destY += tileHeight;
            if (useCB && destY >= GLLibPlayer.s_TilesetLayerInfo[nLayer][7]) {
                destY = 0;
            }
        }
    }
    
    private static final int Tileset_GetTranslatedOriginY(final int nLayer, final int y) {
        if (isFlag(nLayer, 8)) {
            return GLLibPlayer.s_TilesetLayerInfo[nLayer][5] - GLLibPlayer.s_TilesetInfo[1] - y;
        }
        return y;
    }
    
    static final void Tileset_SetCamera(final int nLayer, final int x, final int y) {
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            GLLib.Assert(false, "Tileset_SetCamera: Tileset player is not initialized");
            return;
        }
        if (nLayer < 0 || nLayer >= GLLibPlayer.s_TilesetMaxLayerCount) {
            GLLib.Assert(false, "Tileset_SetCamera: nLayer invalid : " + nLayer);
            return;
        }
        if (GLLibPlayer.s_TilesetLayerInfo[nLayer][0] != 1 || GLLibPlayer.s_TilesetLayerInfo[nLayer][1] != 1) {
            GLLib.Assert(false, "Tileset_SetCamera: nLayer in not initialized or not enabled.");
            return;
        }
        GLLibPlayer.s_TilesetLayerInfo[nLayer][12] = x;
        GLLibPlayer.s_TilesetLayerInfo[nLayer][13] = Tileset_GetTranslatedOriginY(nLayer, y);
        if (!isFlag(nLayer, 1)) {
            if (GLLibPlayer.s_TilesetLayerInfo[nLayer][12] < 0) {
                GLLibPlayer.s_TilesetLayerInfo[nLayer][12] = 0;
            }
            else if (GLLibPlayer.s_TilesetLayerInfo[nLayer][12] + GLLibPlayer.s_TilesetInfo[0] > GLLibPlayer.s_TilesetLayerInfo[nLayer][4]) {
                GLLibPlayer.s_TilesetLayerInfo[nLayer][12] = GLLibPlayer.s_TilesetLayerInfo[nLayer][4] - GLLibPlayer.s_TilesetInfo[0];
            }
        }
        if (!isFlag(nLayer, 2)) {
            if (GLLibPlayer.s_TilesetLayerInfo[nLayer][13] < 0) {
                GLLibPlayer.s_TilesetLayerInfo[nLayer][13] = 0;
            }
            else if (GLLibPlayer.s_TilesetLayerInfo[nLayer][13] + GLLibPlayer.s_TilesetInfo[1] > GLLibPlayer.s_TilesetLayerInfo[nLayer][5]) {
                GLLibPlayer.s_TilesetLayerInfo[nLayer][13] = GLLibPlayer.s_TilesetLayerInfo[nLayer][5] - GLLibPlayer.s_TilesetInfo[1];
            }
        }
    }
    
    static final int[] Tileset_GetCamera(final int nLayer) {
        GLLib.Warning("GLLibPlayer.Tileset_GetCamera(int nLayer) . this function is deprecated, use GLLibPlayer.Tileset_GetCameraX(int nLayer) and GLLibPlayer.Tileset_GetCameraY(int nLayer) instead");
        final int[] res = { Tileset_GetCameraX(nLayer), Tileset_GetCameraY(nLayer) };
        return res;
    }
    
    static final int Tileset_GetCameraX(final int nLayer) {
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            GLLib.Assert(false, "Tileset_GetCamera: Tileset player is not initialized");
            return -1;
        }
        if (nLayer < 0 || nLayer >= GLLibPlayer.s_TilesetMaxLayerCount) {
            GLLib.Assert(false, "Tileset_GetCamera: nLayer invalid : " + nLayer);
            return -1;
        }
        if (GLLibPlayer.s_TilesetLayerInfo[nLayer][0] != 1 || GLLibPlayer.s_TilesetLayerInfo[nLayer][1] != 1) {
            GLLib.Assert(false, "Tileset_GetCamera: nLayer in not initialized or not enabled.");
            return -1;
        }
        return GLLibPlayer.s_TilesetLayerInfo[nLayer][12];
    }
    
    static final int Tileset_GetCameraY(final int nLayer) {
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            GLLib.Assert(false, "Tileset_GetCamera: Tileset player is not initialized");
            return -1;
        }
        if (nLayer < 0 || nLayer >= GLLibPlayer.s_TilesetMaxLayerCount) {
            GLLib.Assert(false, "Tileset_GetCamera: nLayer invalid : " + nLayer);
            return -1;
        }
        if (GLLibPlayer.s_TilesetLayerInfo[nLayer][0] != 1 || GLLibPlayer.s_TilesetLayerInfo[nLayer][1] != 1) {
            GLLib.Assert(false, "Tileset_GetCamera: nLayer in not initialized or not enabled.");
            return -1;
        }
        if (isFlag(nLayer, 8)) {
            return GLLibPlayer.s_TilesetLayerInfo[nLayer][5] - GLLibPlayer.s_TilesetInfo[1] - GLLibPlayer.s_TilesetLayerInfo[nLayer][13];
        }
        return GLLibPlayer.s_TilesetLayerInfo[nLayer][13];
    }
    
    static final int Tileset_GetLayerWidth(final int nLayer) {
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            GLLib.Assert(false, "Tileset_GetLayerWidth: Tileset player is not initialized");
            return -1;
        }
        if (nLayer < 0 || nLayer >= GLLibPlayer.s_TilesetMaxLayerCount) {
            GLLib.Assert(false, "Tileset_GetLayerWidth: nLayer invalid : " + nLayer);
            return -1;
        }
        if (GLLibPlayer.s_TilesetLayerInfo[nLayer][0] != 1 || GLLibPlayer.s_TilesetLayerInfo[nLayer][1] != 1) {
            GLLib.Assert(false, "Tileset_GetLayerWidth: nLayer in not initialized or not enabled.");
            return -1;
        }
        return GLLibPlayer.s_TilesetLayerInfo[nLayer][4];
    }
    
    static final int Tileset_GetLayerHeight(final int nLayer) {
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            GLLib.Assert(false, "Tileset_GetLayerHeight: Tileset player is not initialized");
            return -1;
        }
        if (nLayer < 0 || nLayer >= GLLibPlayer.s_TilesetMaxLayerCount) {
            GLLib.Assert(false, "Tileset_GetLayerHeight: nLayer invalid : " + nLayer);
            return -1;
        }
        if (GLLibPlayer.s_TilesetLayerInfo[nLayer][0] != 1 || GLLibPlayer.s_TilesetLayerInfo[nLayer][1] != 1) {
            GLLib.Assert(false, "Tileset_GetLayerHeight: nLayer in not initialized or not enabled.");
            return -1;
        }
        return GLLibPlayer.s_TilesetLayerInfo[nLayer][5];
    }
    
    static final int Tileset_GetLayerTileCountWidth(final int nLayer) {
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            GLLib.Assert(false, "Tileset_GetLayerTileCountWidth: Tileset player is not initialized");
            return -1;
        }
        if (nLayer < 0 || nLayer >= GLLibPlayer.s_TilesetMaxLayerCount) {
            GLLib.Assert(false, "Tileset_GetLayerTileCountWidth: nLayer invalid : " + nLayer);
            return -1;
        }
        if (GLLibPlayer.s_TilesetLayerInfo[nLayer][0] != 1 || GLLibPlayer.s_TilesetLayerInfo[nLayer][1] != 1) {
            GLLib.Assert(false, "Tileset_GetLayerTileCountWidth: nLayer in not initialized or not enabled.");
            return -1;
        }
        return GLLibPlayer.s_TilesetLayerInfo[nLayer][2];
    }
    
    static final int Tileset_GetLayerTileCountHeight(final int nLayer) {
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            GLLib.Assert(false, "Tileset_GetLayerTileCountHeight: Tileset player is not initialized");
            return -1;
        }
        if (nLayer < 0 || nLayer >= GLLibPlayer.s_TilesetMaxLayerCount) {
            GLLib.Assert(false, "Tileset_GetLayerTileCountHeight: nLayer invalid : " + nLayer);
            return -1;
        }
        if (GLLibPlayer.s_TilesetLayerInfo[nLayer][0] != 1 || GLLibPlayer.s_TilesetLayerInfo[nLayer][1] != 1) {
            GLLib.Assert(false, "Tileset_GetLayerTileCountHeight: nLayer in not initialized or not enabled.");
            return -1;
        }
        return GLLibPlayer.s_TilesetLayerInfo[nLayer][3];
    }
    
    static final int Tileset_GetTile(final int nLayer, final int x, int y) {
        y = Tileset_GetTranslatedOriginY(nLayer, y);
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            GLLib.Assert(false, "Tileset_GetTile: Tileset player is not initialized");
            return -1;
        }
        if (nLayer < 0 || nLayer >= GLLibPlayer.s_TilesetMaxLayerCount) {
            GLLib.Assert(false, "Tileset_GetTile: nLayer invalid : " + nLayer);
            return -1;
        }
        if (GLLibPlayer.s_TilesetLayerInfo[nLayer][0] != 1 || GLLibPlayer.s_TilesetLayerInfo[nLayer][1] != 1) {
            GLLib.Assert(false, "Tileset_GetTile: nLayer in not initialized or not enabled.");
            return -1;
        }
        if (x < 0 || x > GLLibPlayer.s_TilesetLayerInfo[nLayer][2]) {
            GLLib.Assert(false, "Tileset_GetTile: x value out of bound [" + x + "]  0 <= x < " + GLLibPlayer.s_TilesetLayerInfo[nLayer][2]);
            return -1;
        }
        if (y < 0 || y > GLLibPlayer.s_TilesetLayerInfo[nLayer][3]) {
            GLLib.Assert(false, "Tileset_GetTile: y value out of bound [" + y + "]  0 <= y < " + GLLibPlayer.s_TilesetLayerInfo[nLayer][3]);
            return -1;
        }
        if (GLLibConfig.tileset_useIndexAsShort) {
            return GLLib.Mem_GetShort(GLLibPlayer.s_TilesetLayerData[nLayer][0], y * GLLibPlayer.s_TilesetLayerInfo[nLayer][2] + x << 1) & 0xFFFF;
        }
        return GLLibPlayer.s_TilesetLayerData[nLayer][0][y * GLLibPlayer.s_TilesetLayerInfo[nLayer][2] + x] & 0xFF;
    }
    
    static final int Tileset_GetTileFlags(final int nLayer, final int x, int y) {
        y = Tileset_GetTranslatedOriginY(nLayer, y);
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            GLLib.Assert(false, "Tileset_GetTileFlags: Tileset player is not initialized");
            return -1;
        }
        if (nLayer < 0 || nLayer >= GLLibPlayer.s_TilesetMaxLayerCount) {
            GLLib.Assert(false, "Tileset_GetTileFlags: nLayer invalid : " + nLayer);
            return -1;
        }
        if (GLLibPlayer.s_TilesetLayerInfo[nLayer][0] != 1 || GLLibPlayer.s_TilesetLayerInfo[nLayer][1] != 1) {
            GLLib.Assert(false, "Tileset_GetTileFlags: nLayer in not initialized or not enabled.");
            return -1;
        }
        if (x < 0 || x > GLLibPlayer.s_TilesetLayerInfo[nLayer][2]) {
            GLLib.Assert(false, "Tileset_GetTileFlags: x value out of bound [" + x + "]  0 <= x < " + GLLibPlayer.s_TilesetLayerInfo[nLayer][2]);
            return -1;
        }
        if (y < 0 || y > GLLibPlayer.s_TilesetLayerInfo[nLayer][3]) {
            GLLib.Assert(false, "Tileset_GetTileFlags: y value out of bound [" + y + "]  0 <= y < " + GLLibPlayer.s_TilesetLayerInfo[nLayer][3]);
            return -1;
        }
        if (GLLibPlayer.s_TilesetLayerData[nLayer][1] == null) {
            return 0;
        }
        return GLLibPlayer.s_TilesetLayerData[nLayer][1][y * GLLibPlayer.s_TilesetLayerInfo[nLayer][2] + x] & 0xFF;
    }
    
    static final Image Tileset_GetBufferImage(final int p_iLayer) {
        return Tileset_GetBufferImage(p_iLayer, 0);
    }
    
    static final Image Tileset_GetBufferImage(final int p_iLayer, final int p_iImage) {
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            GLLib.Assert(false, "Tileset_GetBufferImage: Tileset player is not initialized");
            return null;
        }
        if (p_iLayer < 0 || p_iLayer >= GLLibPlayer.s_TilesetMaxLayerCount) {
            GLLib.Assert(false, "Tileset_GetBufferImage: p_iLayer invalid : " + p_iLayer);
            return null;
        }
        if (p_iImage < 0 || p_iImage >= 1) {
            GLLib.Assert(false, "Tileset_GetBufferImage: p_iImage invalid : " + p_iImage);
            return null;
        }
        return GLLibPlayer.s_TilesetLayerImage[p_iLayer][p_iImage];
    }
    
    static final Graphics Tileset_GetBufferGraphics(final int p_iLayer) {
        return Tileset_GetBufferGraphics(p_iLayer, 0);
    }
    
    static final Graphics Tileset_GetBufferGraphics(final int p_iLayer, final int p_iImage) {
        if (!GLLibPlayer.s_bTilesetPlayerInitialized) {
            GLLib.Assert(false, "Tileset_GetBufferGraphics: Tileset player is not initialized");
            return null;
        }
        if (p_iLayer < 0 || p_iLayer >= GLLibPlayer.s_TilesetMaxLayerCount) {
            GLLib.Assert(false, "Tileset_GetBufferGraphics: p_iLayer invalid : " + p_iLayer);
            return null;
        }
        if (p_iImage < 0 || p_iImage >= 1) {
            GLLib.Assert(false, "Tileset_GetBufferGraphics: p_iImage invalid : " + p_iImage);
            return null;
        }
        return GLLibPlayer.s_TilesetLayerGraphics[p_iLayer][p_iImage];
    }
    
    static {
        GLLibPlayer.k_animBaseFrameTime = 1000 / GLLibConfig.sprite_animFPS;
        k_snd_nbChannel = GLLibConfig.sound_numberOfChannels;
        GLLibPlayer.s_bTilesetPlayerInitialized = false;
        GLLibPlayer.s_TilesetMaxLayerCount = GLLibConfig.tileset_maxLayerCount;
    }
}
