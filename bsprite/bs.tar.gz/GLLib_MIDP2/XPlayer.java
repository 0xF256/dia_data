import java.util.Random;
import javax.microedition.rms.RecordStore;
import javax.microedition.midlet.MIDlet;
import java.util.Vector;

// 
// Decompiled by Procyon v0.6.0
// 

public final class XPlayer
{
    public static final byte SCORE_TYPE_POINTS = 1;
    public static final byte SCORE_TYPE_TIME = 2;
    private static final byte FUNCTION_LOGIN_REGISTER = 11;
    private static final byte FUNCTION_UPLOAD_SCORE = 0;
    private static final byte FUNCTION_GET_RANKINGS = 12;
    private static final byte FUNCTION_GET_RANKINGS_AROUND_PLAYER = 13;
    private static final byte FUNCTION_CHANGE_USERNAME = 14;
    private static final byte FUNCTION_RATE_GAME = 8;
    private static final byte FUNCTION_RECOMMEND_GAME_TO_BUDDIES = 9;
    private static final byte FUNCTION_GET_STATS = 10;
    private static String GGI;
    public static final int NOT_A_NUMBER = -666666;
    private HTTP whttp;
    private int leaderboardSize;
    private String[] leaderboardPlayerNames;
    private int[] leaderboardPlayerPositions;
    private int[] leaderboardPlayerScores;
    private int[][] leaderboardPlayerScoreDatas;
    private int leaderboardSupplementalDataFieldsNumber;
    private int currentPlayerLeaderboardPosition;
    private int currentPlayerLeaderboardScore;
    private int[] currentPlayerLeaderboardScoreData;
    private String multipleScoresRequestBuffer;
    private String url;
    private String username;
    private String uid;
    private boolean is_logged_in;
    private int newRankAfterScoreSending;
    public static long callstarttime;
    private int lastErrorCode;
    private String phoneNumber;
    private int bestRank;
    private int highScore;
    private int[] highScoreData;
    private int lowScore;
    private int[] lowScoreData;
    private int avgScore;
    private int numberOfGamesPlayed;
    private String lastTimePlayed;
    private int crtPosWrite;
    private int crtPosRead;
    private byte[] msgData;
    private TCP wtcp;
    private String url_tcp;
    private byte m_MPConnectLevel;
    private boolean m_MPHasOpponentFinished;
    private String[] m_lNameList;
    private String[] m_lBinaryDataList;
    private byte[] m_lByteDataList;
    private byte noitems;
    private int nosessionsbase;
    private String found_player_name;
    private byte found_player_status;
    private String found_player_session_name;
    private byte found_player_session_number_of_players;
    private String requested_player_data;
    private String requested_player_nickname;
    private byte m_type;
    private byte m_subtype;
    private byte[] m_data;
    private Vector incomingGameData;
    private String currentsessionname;
    private String currentsessiondata;
    public boolean isGameMessageInQueue;
    
    public XPlayer(final MIDlet midlet) {
        this.leaderboardSize = -666666;
        this.leaderboardPlayerNames = null;
        this.leaderboardPlayerPositions = null;
        this.leaderboardPlayerScores = null;
        this.leaderboardPlayerScoreDatas = null;
        this.leaderboardSupplementalDataFieldsNumber = 0;
        this.currentPlayerLeaderboardPosition = -666666;
        this.currentPlayerLeaderboardScore = -666666;
        this.currentPlayerLeaderboardScoreData = null;
        this.multipleScoresRequestBuffer = null;
        this.is_logged_in = false;
        this.bestRank = -666666;
        this.highScore = -666666;
        this.highScoreData = null;
        this.lowScore = -666666;
        this.lowScoreData = null;
        this.avgScore = -666666;
        this.numberOfGamesPlayed = -666666;
        this.lastTimePlayed = null;
        this.m_MPConnectLevel = 0;
        this.m_MPHasOpponentFinished = false;
        this.noitems = 0;
        this.nosessionsbase = 0;
        this.currentsessionname = null;
        this.currentsessiondata = null;
        this.isGameMessageInQueue = false;
        this.url = midlet.getAppProperty("XPlayerURL");
        XPlayer.GGI = midlet.getAppProperty("GGI");
        if (this.url == null || XPlayer.GGI == null) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Please check that you have fields XPlayerURL, XPlayMPURL, GGI in .jad file");
            }
            return;
        }
        this.whttp = new HTTP();
        if (GLLibConfig.xplayer_CARRIER_USSPRINT || GLLibConfig.xplayer_CARRIER_MXTELCEL) {
            final HTTP whttp = this.whttp;
            HTTP.clientId = midlet.getAppProperty("ClientId");
            final HTTP whttp2 = this.whttp;
            if (HTTP.clientId != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
                final StringBuffer append = new StringBuffer().append("WARNING ClientId=");
                final HTTP whttp3 = this.whttp;
                GLLib.Dbg(append.append(HTTP.clientId).append(", ERASE IN PRODUCTION jad").toString());
            }
        }
        if (GLLibConfig.xplayer_CARRIER_USNEXTEL) {
            final HTTP whttp4 = this.whttp;
            HTTP.upsubid = midlet.getAppProperty("UPSUBID");
            final HTTP whttp5 = this.whttp;
            if (HTTP.upsubid != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
                final StringBuffer append2 = new StringBuffer().append("WARNING UPSUBID=");
                final HTTP whttp6 = this.whttp;
                GLLib.Dbg(append2.append(HTTP.upsubid).append(", ERASE IN PRODUCTION jad").toString());
            }
        }
        if (GLLibConfig.xplayer_CARRIER_USVIRGIN) {
            final HTTP whttp7 = this.whttp;
            HTTP.x_up_calling_line_id = midlet.getAppProperty("x-up-calling-line-id");
            final HTTP whttp8 = this.whttp;
            if (HTTP.x_up_calling_line_id != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
                final StringBuffer append3 = new StringBuffer().append("WARNING x-up-calling-line-id=");
                final HTTP whttp9 = this.whttp;
                GLLib.Dbg(append3.append(HTTP.x_up_calling_line_id).append(", ERASE IN PRODUCTION jad").toString());
            }
        }
        if (GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE || GLLibConfig.xplayer_CARRIER_USVIRGIN) {
            final HTTP whttp10 = this.whttp;
            HTTP.x_up_subno = midlet.getAppProperty("x-up-subno");
            final HTTP whttp11 = this.whttp;
            if (HTTP.x_up_subno != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
                final StringBuffer append4 = new StringBuffer().append("WARNING x-up-subno=");
                final HTTP whttp12 = this.whttp;
                GLLib.Dbg(append4.append(HTTP.x_up_subno).append(", ERASE IN PRODUCTION jad").toString());
            }
        }
        if (GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE) {
            final HTTP whttp13 = this.whttp;
            HTTP.CarrierDeviceId = midlet.getAppProperty("CarrierDeviceId");
            final HTTP whttp14 = this.whttp;
            if (HTTP.CarrierDeviceId != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
                final StringBuffer append5 = new StringBuffer().append("WARNING CarrierDeviceId=");
                final HTTP whttp15 = this.whttp;
                GLLib.Dbg(append5.append(HTTP.CarrierDeviceId).append(", ERASE IN PRODUCTION jad").toString());
            }
        }
        if (GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN) {
            this.phoneNumber = new String("");
        }
        if (GLLibConfig.xplayer_ENABLE_MULTIPLAYER) {
            this.url_tcp = midlet.getAppProperty("XPlayMPURL");
            if (this.url_tcp == null) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Please check that you have fields XPlayerURL, XPlayMPURL, GGI in .jad file");
                }
                return;
            }
            this.wtcp = new TCP(this.url_tcp);
            this.crtPosWrite = 0;
            this.crtPosRead = 0;
            this.msgData = new byte[255];
        }
        this.username = new String("");
        this.newRankAfterScoreSending = -666666;
        this.is_logged_in = false;
        this.init();
    }
    
    private void init() {
        this.clearLeaderboard();
        RecordStore rs = null;
        try {
            rs = RecordStore.openRecordStore("UUID", true);
            if (rs.getNumRecords() >= 1) {
                final byte[] the_uid = rs.getRecord(1);
                this.uid = new String(the_uid);
            }
            else {
                this.uid = this.GenerateUID();
                final byte[] the_uid = this.uid.getBytes();
                if (rs.getNumRecords() >= 1) {
                    rs.setRecord(1, the_uid, 0, the_uid.length);
                }
                else {
                    rs.addRecord(the_uid, 0, the_uid.length);
                }
            }
        }
        catch (final Exception e) {}
        finally {
            try {
                rs.closeRecordStore();
            }
            catch (final Exception ex) {}
        }
    }
    
    private String GenerateUID() {
        final byte[] b = new byte[20];
        final Random random = new Random();
        random.setSeed(System.currentTimeMillis());
        for (int i = 0; i < 20; ++i) {
            int random_number = random.nextInt() % 35;
            if (random_number < 0) {
                random_number = -random_number;
            }
            b[i] = (byte)random_number;
            if (b[i] < 10) {
                final byte[] array = b;
                final int n = i;
                array[n] += 48;
            }
            else {
                final byte[] array2 = b;
                final int n2 = i;
                array2[n2] += 87;
            }
        }
        final String retval = new String(b);
        GLLib.Gc();
        return retval + Integer.toString((int)System.currentTimeMillis() / 1000);
    }
    
    public boolean isLoggedIn() {
        return this.is_logged_in;
    }
    
    public void setUsername(final String name) {
        this.username = new String(name);
    }
    
    public String getUsername() {
        return this.username;
    }
    
    public int getNewRankAfterScoreSending() {
        return this.newRankAfterScoreSending;
    }
    
    public int getLastError() {
        if (this.whttp.isInProgress()) {
            return -1;
        }
        if (this.whttp.m_bError) {
            return -2;
        }
        return this.lastErrorCode;
    }
    
    public void cancel() {
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = 0L;
        }
        this.whttp.cancel();
    }
    
    public void cleanup() {
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = 0L;
        }
        this.whttp.cleanup();
    }
    
    private String String2Blob(final String str) {
        final byte[] bs = str.getBytes();
        int nBlobPos = 0;
        int nSPos = 0;
        int nBitsNotUsed = 8;
        int nBlobLength = str.length() * 8 / 6;
        if (str.length() * 8 % 6 != 0) {
            nBlobLength += 2;
        }
        else {
            ++nBlobLength;
        }
        final byte[] sBlob = new byte[nBlobLength];
        for (int k = 0; k < nBlobLength; ++k) {
            sBlob[k] = 0;
        }
        while (nSPos < str.length()) {
            byte nKeyIndex = (byte)(bs[nSPos] & 0x7F);
            nKeyIndex >>= (byte)(8 - nBitsNotUsed);
            if (nBitsNotUsed < 6) {
                if (++nSPos < str.length()) {
                    nKeyIndex |= (byte)(bs[nSPos] << nBitsNotUsed);
                    nBitsNotUsed += 2;
                }
            }
            else {
                nBitsNotUsed -= 6;
                if (nBitsNotUsed == 0) {
                    nBitsNotUsed = 8;
                    ++nSPos;
                }
            }
            nKeyIndex &= 0x3F;
            sBlob[nBlobPos] = this.SSEncDec_GetCharFromKeyByIndex(nKeyIndex);
            ++nBlobPos;
        }
        final String retval = new String(sBlob, 0, nBlobPos);
        return retval;
    }
    
    private byte SSEncDec_GetCharFromKeyByIndex(final byte nKeyIndex) {
        if (nKeyIndex < 26) {
            return (byte)(nKeyIndex + 97);
        }
        if (nKeyIndex < 52) {
            return (byte)(nKeyIndex + 39);
        }
        if (nKeyIndex < 62) {
            return (byte)(nKeyIndex - 4);
        }
        if (nKeyIndex == 62) {
            return 95;
        }
        return 45;
    }
    
    private String getValue(final String src, int pos) {
        int start = 0;
        final int ini_pos = pos;
        int end = src.indexOf(124, start + 1);
        while (pos > 0) {
            if (start == -1) {
                return null;
            }
            start = end;
            end = src.indexOf(124, start + 1);
            --pos;
        }
        if (start == -1) {
            return null;
        }
        if (end == -1) {
            end = src.length();
        }
        if (ini_pos > 0) {
            ++start;
        }
        if (start == end) {
            return "";
        }
        if (start > end) {
            return null;
        }
        try {
            final char[] buf = new char[end - start];
            src.getChars(start, end, buf, 0);
            final String value = new String(buf);
            return value;
        }
        catch (final IndexOutOfBoundsException e) {
            return null;
        }
    }
    
    public void sendChangeUsername() {
        String tmp_request = "";
        if (GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN) {
            tmp_request = "f|14|i|" + XPlayer.GGI + "|n|" + this.username + "|p|" + this.phoneNumber + "|u|" + this.uid + "|";
        }
        else {
            tmp_request = "f|14|i|" + XPlayer.GGI + "|n|" + this.username + "|u|" + this.uid + "|";
        }
        final String request = this.String2Blob(tmp_request);
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, request);
    }
    
    public void sendLogin(final String playerData) {
        String tmp_request = "";
        if (GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN) {
            tmp_request = "f|11|i|" + XPlayer.GGI + "|n|" + this.username + "|p|" + this.phoneNumber + "|u|" + this.uid + "|";
        }
        else {
            tmp_request = "f|11|i|" + XPlayer.GGI + "|n|" + this.username + "|u|" + this.uid + "|";
        }
        if (playerData != null) {
            tmp_request = tmp_request + "b|" + playerData + "|";
        }
        final String request = this.String2Blob(tmp_request);
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, request);
    }
    
    public void handleLogin() {
        this.handleLoginChangeUsername(11);
    }
    
    public void handleChangeUsername() {
        this.handleLoginChangeUsername(14);
    }
    
    private void handleLoginChangeUsername(final int _function) {
        if (_function != 11 && _function != 14) {
            return;
        }
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - XPlayer.callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                this.cancel();
                this.lastErrorCode = -2;
            }
            return;
        }
        if (this.whttp.m_bError) {
            return;
        }
        if (this.whttp.m_response != null) {
            String tmpHR = this.getValue(this.whttp.m_response, 0);
            if (tmpHR.compareTo("f") != 0) {
                return;
            }
            tmpHR = this.getValue(this.whttp.m_response, 1);
            if (tmpHR == null) {
                return;
            }
            if (Integer.parseInt(tmpHR) != _function) {
                return;
            }
            tmpHR = this.getValue(this.whttp.m_response, 3);
            if (tmpHR == null) {
                return;
            }
            if (tmpHR.compareTo("e") == 0) {
                tmpHR = this.getValue(this.whttp.m_response, 4);
                this.lastErrorCode = Integer.parseInt(tmpHR);
                if (this.lastErrorCode == 3) {
                    tmpHR = this.getValue(this.whttp.m_response, 5);
                    if (tmpHR != null && tmpHR.compareTo("d") == 0) {
                        tmpHR = this.getValue(this.whttp.m_response, 6);
                        if (tmpHR.compareTo("5 M7 error, contact Online Team") == 0) {
                            this.lastErrorCode = -2;
                        }
                    }
                }
                else if (this.lastErrorCode == 5) {
                    this.username = this.getValue(this.whttp.m_response, 6);
                }
                return;
            }
            if (tmpHR.compareTo("s") == 0) {
                this.lastErrorCode = 0;
                this.username = this.getValue(this.whttp.m_response, 5);
                this.is_logged_in = true;
            }
        }
    }
    
    public void sendHighscore(final int score, final int level, final int scoreType) {
        this.whttp.cancel();
        String tmp = "f|0|i|" + XPlayer.GGI + "|u|" + this.uid;
        if (level >= 0) {
            tmp = tmp + "|l|" + level;
        }
        tmp = tmp + "|t|" + scoreType + "|s|" + score + '|';
        final String tmpBlob = tmp = this.String2Blob(tmp);
        this.lastErrorCode = -100;
        this.newRankAfterScoreSending = -666666;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmp);
    }
    
    public void sendHighscoreWithSupplementalData(final int score, int level, final int scoreType, final int[] supplemental_data) {
        this.whttp.cancel();
        String tmp = "f|0|i|" + XPlayer.GGI + "|u|" + this.uid;
        if (level < 0) {
            level = 0;
        }
        tmp = tmp + "|l|" + level + "|t|" + scoreType + "|sl|0|s|" + score;
        for (int i = 0; i < supplemental_data.length; ++i) {
            tmp = tmp + "|l|" + level + "|t|" + scoreType + "|sl|" + (i + 1) + "|s|" + supplemental_data[i];
        }
        tmp += "|";
        final String tmpBlob = tmp = this.String2Blob(tmp);
        this.lastErrorCode = -100;
        this.newRankAfterScoreSending = -666666;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmp);
    }
    
    public void handleHighscore() {
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - XPlayer.callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                this.cancel();
                this.lastErrorCode = -2;
            }
        }
        else {
            if (this.whttp.m_bError) {
                return;
            }
            if (this.whttp.m_response != null) {
                String tmpHR = this.getValue(this.whttp.m_response, 0);
                if (tmpHR.compareTo("f") != 0) {
                    return;
                }
                tmpHR = this.getValue(this.whttp.m_response, 1);
                if (Integer.parseInt(tmpHR) != 0) {
                    return;
                }
                tmpHR = this.getValue(this.whttp.m_response, 3);
                if (tmpHR.compareTo("e") == 0) {
                    tmpHR = this.getValue(this.whttp.m_response, 4);
                    this.lastErrorCode = Integer.parseInt(tmpHR);
                    return;
                }
                if (tmpHR.compareTo("s") == 0) {
                    this.lastErrorCode = 0;
                    int entry = 4;
                    tmpHR = this.getValue(this.whttp.m_response, entry++);
                    if (tmpHR.compareTo("l") == 0) {
                        ++entry;
                        tmpHR = this.getValue(this.whttp.m_response, entry++);
                    }
                    if (tmpHR.compareTo("r") == 0) {
                        tmpHR = this.getValue(this.whttp.m_response, entry);
                        this.newRankAfterScoreSending = Integer.parseInt(tmpHR);
                    }
                }
            }
        }
    }
    
    public void initMultipleScores() {
        this.multipleScoresRequestBuffer = "f|0|i|" + XPlayer.GGI + "|u|" + this.uid;
    }
    
    public void addMultipleScoreEntry(final int score, final int level, final int scoreType) {
        if (this.multipleScoresRequestBuffer == null) {
            return;
        }
        this.multipleScoresRequestBuffer = this.multipleScoresRequestBuffer + "|l|" + level + "|t|" + scoreType + "|s|" + score;
    }
    
    public void addMultipleScoreEntryWithSupplementalData(final int score, final int level, final int scoreType, final int[] supplemental_data) {
        if (this.multipleScoresRequestBuffer == null) {
            return;
        }
        this.multipleScoresRequestBuffer = this.multipleScoresRequestBuffer + "|l|" + level + "|t|" + scoreType + "|sl|0|s|" + score;
        for (int i = 0; i < supplemental_data.length; ++i) {
            this.multipleScoresRequestBuffer = this.multipleScoresRequestBuffer + "|l|" + level + "|t|" + scoreType + "|sl|" + (i + 1) + "|s|" + supplemental_data[i];
        }
    }
    
    public void sendMultipleHighscores() {
        if (this.multipleScoresRequestBuffer == null) {
            return;
        }
        this.whttp.cancel();
        this.multipleScoresRequestBuffer += "|";
        final String tmpBlob = this.String2Blob(this.multipleScoresRequestBuffer);
        this.lastErrorCode = -100;
        this.newRankAfterScoreSending = -666666;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmpBlob);
    }
    
    public void sendRankGet(final int level, final int number_of_players, final int scoreType, final int numberOfSupplementalDataFields) {
        this.whttp.cancel();
        String tmp = "f|12|i|" + XPlayer.GGI + "|u|" + this.uid + "|p|" + number_of_players + "|" + "t|" + scoreType + "|";
        if (level >= 0) {
            tmp = tmp + "l|" + level + "|";
        }
        final String tmpBlob = tmp = this.String2Blob(tmp);
        this.clearLeaderboard();
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = System.currentTimeMillis();
        }
        this.leaderboardSupplementalDataFieldsNumber = numberOfSupplementalDataFields;
        this.whttp.sendByGet(this.url, tmp);
    }
    
    public void handleRankGet() {
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - XPlayer.callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                this.cancel();
                this.lastErrorCode = -2;
            }
            return;
        }
        if (this.whttp.m_bError) {
            return;
        }
        if (this.whttp.m_response != null) {
            String tmpHR = this.getValue(this.whttp.m_response, 0);
            if (tmpHR.compareTo("f") != 0) {
                return;
            }
            tmpHR = this.getValue(this.whttp.m_response, 1);
            if (Integer.parseInt(tmpHR) != 12) {
                return;
            }
            tmpHR = this.getValue(this.whttp.m_response, 3);
            if (tmpHR.compareTo("e") == 0) {
                tmpHR = this.getValue(this.whttp.m_response, 4);
                this.lastErrorCode = Integer.parseInt(tmpHR);
                return;
            }
            if (tmpHR.compareTo("s") == 0) {
                this.lastErrorCode = 0;
                this.clearLeaderboard();
                try {
                    this.processLeaderboardData(this.whttp.m_response);
                }
                catch (final Exception e) {
                    this.lastErrorCode = 40;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        GLLib.Dbg("Error processing leaderboard data: " + e.getMessage());
                    }
                }
            }
        }
    }
    
    public void sendRankGetAroundPlayer(final int level, final int number_of_players_around, final int scoreType, final int numberOfSupplementalDataFields) {
        this.whttp.cancel();
        String tmp = "f|13|i|" + XPlayer.GGI + "|u|" + this.uid + "|p|" + number_of_players_around + "|" + "t|" + scoreType + "|";
        if (level >= 0) {
            tmp = tmp + "l|" + level + "|";
        }
        final String tmpBlob = tmp = this.String2Blob(tmp);
        this.clearLeaderboard();
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = System.currentTimeMillis();
        }
        this.leaderboardSupplementalDataFieldsNumber = numberOfSupplementalDataFields;
        this.whttp.sendByGet(this.url, tmp);
    }
    
    public void handleRankGetAroundPlayer() {
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - XPlayer.callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                this.cancel();
                this.lastErrorCode = -2;
            }
            return;
        }
        if (this.whttp.m_bError) {
            return;
        }
        if (this.whttp.m_response != null) {
            String tmpHR = this.getValue(this.whttp.m_response, 0);
            if (tmpHR.compareTo("f") != 0) {
                return;
            }
            tmpHR = this.getValue(this.whttp.m_response, 1);
            if (Integer.parseInt(tmpHR) != 13) {
                return;
            }
            tmpHR = this.getValue(this.whttp.m_response, 3);
            if (tmpHR.compareTo("e") == 0) {
                tmpHR = this.getValue(this.whttp.m_response, 4);
                this.lastErrorCode = Integer.parseInt(tmpHR);
                return;
            }
            if (tmpHR.compareTo("s") == 0) {
                this.lastErrorCode = 0;
                this.clearLeaderboard();
                try {
                    this.processRankingAroundPlayerData(this.whttp.m_response);
                }
                catch (final Exception e) {
                    this.lastErrorCode = 40;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        GLLib.Dbg("Error processing rank around player data: " + e.getMessage());
                    }
                }
            }
        }
    }
    
    public int getCurrentPlayerLeaderboardPosition() {
        return this.currentPlayerLeaderboardPosition;
    }
    
    public int getCurrentPlayerLeaderboardScore() {
        return this.currentPlayerLeaderboardScore;
    }
    
    public int[] getCurrentPlayerLeaderboardScoreData() {
        return this.currentPlayerLeaderboardScoreData;
    }
    
    public boolean getLeaderboardData(final String[] names, final int[] positions, final int[] scores, final int[][] scoreDatas) {
        if (this.leaderboardSize <= 0 || this.leaderboardPlayerNames == null) {
            return false;
        }
        if (names == null || names.length < this.leaderboardSize || positions == null || positions.length < this.leaderboardSize || scores == null || scores.length < this.leaderboardSize) {
            return false;
        }
        System.arraycopy(this.leaderboardPlayerNames, 0, names, 0, this.leaderboardSize);
        System.arraycopy(this.leaderboardPlayerPositions, 0, positions, 0, this.leaderboardSize);
        System.arraycopy(this.leaderboardPlayerScores, 0, scores, 0, this.leaderboardSize);
        if (this.leaderboardPlayerScoreDatas != null && this.leaderboardSupplementalDataFieldsNumber > 0) {
            if (scoreDatas == null || scoreDatas.length < this.leaderboardSize || scoreDatas[0].length < this.leaderboardSupplementalDataFieldsNumber) {
                return false;
            }
            System.arraycopy(this.leaderboardPlayerScoreDatas, 0, scoreDatas, 0, this.leaderboardSize);
        }
        return true;
    }
    
    public int getLeaderboardSize() {
        if (this.leaderboardPlayerNames == null) {
            return -1;
        }
        return this.leaderboardSize;
    }
    
    public String getLeaderboardEntryPlayerName(final int index) {
        if (index >= this.leaderboardSize || this.leaderboardPlayerNames == null) {
            return null;
        }
        return this.leaderboardPlayerNames[index];
    }
    
    public int getLeaderboardEntryPlayerPosition(final int index) {
        if (index >= this.leaderboardSize || this.leaderboardPlayerPositions == null) {
            return -1;
        }
        return this.leaderboardPlayerPositions[index];
    }
    
    public int getLeaderboardEntryPlayerScore(final int index) {
        if (index >= this.leaderboardSize || this.leaderboardPlayerScores == null) {
            return -666666;
        }
        return this.leaderboardPlayerScores[index];
    }
    
    public int[] getLeaderboardEntryPlayerScoreData(final int index) {
        if (index >= this.leaderboardSize || this.leaderboardPlayerScoreDatas == null) {
            return null;
        }
        return this.leaderboardPlayerScoreDatas[index];
    }
    
    private void processLeaderboardData(final String leaderboardData) {
        int index = 4;
        String tmpHR = this.getValue(leaderboardData, index++);
        int count = 0;
        if (tmpHR.compareTo("y") == 0) {
            tmpHR = this.getValue(leaderboardData, index++);
            this.currentPlayerLeaderboardPosition = Integer.parseInt(tmpHR);
            if (this.currentPlayerLeaderboardPosition < 0) {
                this.currentPlayerLeaderboardPosition = -666666;
                this.currentPlayerLeaderboardPosition = -666666;
                this.currentPlayerLeaderboardScore = -666666;
                this.currentPlayerLeaderboardScoreData = null;
                index += 2 + this.leaderboardSupplementalDataFieldsNumber;
                count -= 3 + this.leaderboardSupplementalDataFieldsNumber;
            }
            else {
                ++index;
                tmpHR = this.getValue(leaderboardData, index++);
                this.currentPlayerLeaderboardScore = Integer.parseInt(tmpHR);
                if (this.leaderboardSupplementalDataFieldsNumber > 0) {
                    this.currentPlayerLeaderboardScoreData = new int[this.leaderboardSupplementalDataFieldsNumber];
                }
                for (int i = 0; i < this.leaderboardSupplementalDataFieldsNumber; ++i) {
                    tmpHR = this.getValue(leaderboardData, index++);
                    this.currentPlayerLeaderboardScoreData[i] = Integer.parseInt(tmpHR);
                }
            }
        }
        else if (tmpHR.compareTo("n") != 0) {
            return;
        }
        int start;
        for (start = 0, start = leaderboardData.indexOf(124, start + 1); start != -1; start = leaderboardData.indexOf(124, start + 1)) {
            ++count;
        }
        count -= 4;
        if (this.currentPlayerLeaderboardPosition >= 0) {
            count -= 3 + this.leaderboardSupplementalDataFieldsNumber;
        }
        this.leaderboardSize = count / (3 + this.leaderboardSupplementalDataFieldsNumber);
        if (this.leaderboardSize <= 0) {
            return;
        }
        this.leaderboardPlayerNames = new String[this.leaderboardSize];
        this.leaderboardPlayerPositions = new int[this.leaderboardSize];
        this.leaderboardPlayerScores = new int[this.leaderboardSize];
        if (this.leaderboardSupplementalDataFieldsNumber > 0) {
            this.leaderboardPlayerScoreDatas = new int[this.leaderboardSize][this.leaderboardSupplementalDataFieldsNumber];
        }
        for (int j = 0; j < this.leaderboardSize; ++j) {
            tmpHR = this.getValue(leaderboardData, index++);
            this.leaderboardPlayerPositions[j] = Integer.parseInt(tmpHR);
            tmpHR = this.getValue(leaderboardData, index++);
            this.leaderboardPlayerNames[j] = new String(tmpHR);
            tmpHR = this.getValue(leaderboardData, index++);
            this.leaderboardPlayerScores[j] = Integer.parseInt(tmpHR);
            for (int k = 0; k < this.leaderboardSupplementalDataFieldsNumber; ++k) {
                tmpHR = this.getValue(leaderboardData, index++);
                this.leaderboardPlayerScoreDatas[j][k] = Integer.parseInt(tmpHR);
            }
        }
    }
    
    private void processRankingAroundPlayerData(final String rankingData) {
        int start = 0;
        int count = 0;
        for (start = rankingData.indexOf(124, start + 1); start != -1; start = rankingData.indexOf(124, start + 1)) {
            ++count;
        }
        count -= 3;
        this.leaderboardSize = count / (3 + this.leaderboardSupplementalDataFieldsNumber);
        if (this.leaderboardSize <= 0) {
            return;
        }
        this.leaderboardPlayerNames = new String[this.leaderboardSize];
        this.leaderboardPlayerPositions = new int[this.leaderboardSize];
        this.leaderboardPlayerScores = new int[this.leaderboardSize];
        if (this.leaderboardSupplementalDataFieldsNumber > 0) {
            this.leaderboardPlayerScoreDatas = new int[this.leaderboardSize][this.leaderboardSupplementalDataFieldsNumber];
        }
        int index = 4;
        for (int i = 0; i < this.leaderboardSize; ++i) {
            String tmpHR = this.getValue(rankingData, index++);
            this.leaderboardPlayerPositions[i] = Integer.parseInt(tmpHR);
            tmpHR = this.getValue(rankingData, index++);
            this.leaderboardPlayerNames[i] = new String(tmpHR);
            tmpHR = this.getValue(rankingData, index++);
            this.leaderboardPlayerScores[i] = Integer.parseInt(tmpHR);
            for (int j = 0; j < this.leaderboardSupplementalDataFieldsNumber; ++j) {
                tmpHR = this.getValue(rankingData, index++);
                this.leaderboardPlayerScoreDatas[i][j] = Integer.parseInt(tmpHR);
            }
        }
    }
    
    private void clearLeaderboard() {
        this.leaderboardPlayerNames = null;
        this.leaderboardPlayerPositions = null;
        this.leaderboardPlayerScores = null;
        this.leaderboardPlayerScoreDatas = null;
        this.currentPlayerLeaderboardPosition = -666666;
        this.currentPlayerLeaderboardScore = -666666;
        this.currentPlayerLeaderboardScoreData = null;
        this.leaderboardSize = -666666;
        GLLib.Gc();
    }
    
    public void setPhoneNumber(final String phoneNr) {
        this.phoneNumber = new String(phoneNr);
    }
    
    public void sendStatsGet(final int level, final int numberOfSupplementalDataFields) {
        this.whttp.cancel();
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        String tmp = "f|10|i|" + XPlayer.GGI + "|u|" + this.uid + "|l|" + level + "|";
        final String tmpBlob = tmp = this.String2Blob(tmp);
        this.lastErrorCode = 0;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = System.currentTimeMillis();
        }
        this.leaderboardSupplementalDataFieldsNumber = numberOfSupplementalDataFields;
        this.whttp.sendByGet(this.url, tmp);
    }
    
    public void handleStatsGet() {
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - XPlayer.callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                this.cancel();
                this.lastErrorCode = -2;
            }
            return;
        }
        if (this.whttp.m_bError) {
            return;
        }
        if (this.whttp.m_response != null) {
            int j = 0;
            String tmpHR = this.getValue(this.whttp.m_response, j++);
            if (tmpHR.compareTo("f") != 0) {
                return;
            }
            tmpHR = this.getValue(this.whttp.m_response, j++);
            try {
                if (Integer.parseInt(tmpHR) != 10) {
                    return;
                }
                ++j;
                tmpHR = this.getValue(this.whttp.m_response, j++);
                if (tmpHR.compareTo("e") == 0) {
                    tmpHR = this.getValue(this.whttp.m_response, j++);
                    this.lastErrorCode = Integer.parseInt(tmpHR);
                    return;
                }
                if (tmpHR.compareTo("s") == 0) {
                    this.lastErrorCode = 0;
                    tmpHR = this.getValue(this.whttp.m_response, j++);
                    this.bestRank = Integer.parseInt(tmpHR);
                    tmpHR = this.getValue(this.whttp.m_response, j++);
                    this.highScore = Integer.parseInt(tmpHR);
                    if (this.leaderboardSupplementalDataFieldsNumber > 0) {
                        this.highScoreData = new int[this.leaderboardSupplementalDataFieldsNumber];
                    }
                    for (int i = 0; i < this.leaderboardSupplementalDataFieldsNumber; ++i) {
                        tmpHR = this.getValue(this.whttp.m_response, j++);
                        this.highScoreData[i] = Integer.parseInt(tmpHR);
                    }
                    tmpHR = this.getValue(this.whttp.m_response, j++);
                    this.lowScore = Integer.parseInt(tmpHR);
                    if (this.leaderboardSupplementalDataFieldsNumber > 0) {
                        this.lowScoreData = new int[this.leaderboardSupplementalDataFieldsNumber];
                    }
                    for (int i = 0; i < this.leaderboardSupplementalDataFieldsNumber; ++i) {
                        tmpHR = this.getValue(this.whttp.m_response, j++);
                        this.lowScoreData[i] = Integer.parseInt(tmpHR);
                    }
                    tmpHR = this.getValue(this.whttp.m_response, j++);
                    this.avgScore = Integer.parseInt(tmpHR);
                    tmpHR = this.getValue(this.whttp.m_response, j++);
                    this.numberOfGamesPlayed = Integer.parseInt(tmpHR);
                    this.lastTimePlayed = this.getValue(this.whttp.m_response, j++);
                }
            }
            catch (final Exception e) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("EERRRR");
                }
            }
        }
    }
    
    public void getPlayerStats(final int[] bestRankArr, final int[] highScoreArr, final int[] lowScoreArr, final int[] avgScoreArr, final int[] numberOfGamesPlayerdArr, final String[] lastTimePlayedArr, final int[] lowScoreDataArr, final int[] highScoreDataArr) {
        bestRankArr[0] = this.bestRank;
        highScoreArr[0] = this.highScore;
        for (int i = 0; i < this.leaderboardSupplementalDataFieldsNumber; ++i) {
            highScoreDataArr[i] = this.highScoreData[i];
        }
        lowScoreArr[0] = this.lowScore;
        for (int i = 0; i < this.leaderboardSupplementalDataFieldsNumber; ++i) {
            lowScoreDataArr[i] = this.lowScoreData[i];
        }
        avgScoreArr[0] = this.avgScore;
        numberOfGamesPlayerdArr[0] = this.numberOfGamesPlayed;
        lastTimePlayedArr[0] = this.lastTimePlayed;
    }
    
    public int getMyBestRank() {
        return this.bestRank;
    }
    
    public int getMyHighScore() {
        return this.highScore;
    }
    
    public int getMyLowScore() {
        return this.lowScore;
    }
    
    public int[] getMyLowScoreData() {
        return this.lowScoreData;
    }
    
    public int[] getMyHighScoreData() {
        return this.highScoreData;
    }
    
    public int getMyAvgScore() {
        return this.avgScore;
    }
    
    public int getMyNumberOfGamesPlayed() {
        return this.numberOfGamesPlayed;
    }
    
    public String getMyLastTimePlayed() {
        return this.lastTimePlayed;
    }
    
    public void sendRateGame(final int rating) {
        this.whttp.cancel();
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        String tmp = "f|8|i|" + XPlayer.GGI + "|u|" + this.uid + "|s|" + rating + "|";
        final String tmpBlob = tmp = this.String2Blob(tmp);
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmp);
    }
    
    public void handleRateGame() {
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - XPlayer.callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                this.cancel();
                this.lastErrorCode = -2;
            }
            return;
        }
        if (this.whttp.m_bError) {
            return;
        }
        if (this.whttp.m_response != null) {
            String tmpHR = this.getValue(this.whttp.m_response, 0);
            if (tmpHR.compareTo("f") != 0) {
                return;
            }
            tmpHR = this.getValue(this.whttp.m_response, 1);
            if (Integer.parseInt(tmpHR) != 8) {
                return;
            }
            tmpHR = this.getValue(this.whttp.m_response, 3);
            if (tmpHR.compareTo("e") == 0) {
                tmpHR = this.getValue(this.whttp.m_response, 4);
                this.lastErrorCode = Integer.parseInt(tmpHR);
                return;
            }
            if (tmpHR.compareTo("s") == 0) {
                this.lastErrorCode = 0;
            }
        }
    }
    
    public void sendRecommendGame() {
        this.whttp.cancel();
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        String tmp = "f|9|i|" + XPlayer.GGI + "|u|" + this.uid + "|";
        final String tmpBlob = tmp = this.String2Blob(tmp);
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            XPlayer.callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmp);
    }
    
    public void handleRecommendGame() {
        if (!(GLLibConfig.xplayer_CARRIER_USSPRINT | GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE | GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE | GLLibConfig.xplayer_CARRIER_USNEXTEL | GLLibConfig.xplayer_CARRIER_USVIRGIN)) {
            GLLib.Dbg("sendStatsGet is only supported for M7 Networks hosted games.");
            this.lastErrorCode = -3;
            return;
        }
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - XPlayer.callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                this.cancel();
                this.lastErrorCode = -2;
            }
            return;
        }
        if (this.whttp.m_bError) {
            return;
        }
        if (this.whttp.m_response != null) {
            String tmpHR = this.getValue(this.whttp.m_response, 1);
            if (Integer.parseInt(tmpHR) != 9) {
                return;
            }
            tmpHR = this.getValue(this.whttp.m_response, 3);
            if (tmpHR.compareTo("e") == 0) {
                tmpHR = this.getValue(this.whttp.m_response, 4);
                this.lastErrorCode = Integer.parseInt(tmpHR);
                return;
            }
            if (tmpHR.compareTo("s") == 0) {
                this.lastErrorCode = 0;
            }
        }
    }
    
    public void setData(final byte[] data) {
        System.arraycopy(data, 0, this.msgData, 0, data.length);
        this.crtPosWrite = data.length;
        this.crtPosRead = 0;
    }
    
    public byte[] getData() {
        final byte[] retval = new byte[this.crtPosWrite];
        System.arraycopy(this.msgData, 0, retval, 0, this.crtPosWrite);
        this.crtPosWrite = 0;
        this.crtPosRead = 0;
        return retval;
    }
    
    public void clearData() {
        this.m_type = 0;
        this.m_subtype = 0;
        this.crtPosWrite = 0;
        this.crtPosRead = 0;
    }
    
    public int getLength() {
        return this.crtPosWrite;
    }
    
    public void addByte(final byte data) throws Exception {
        if (this.msgData != null && this.crtPosWrite < this.msgData.length) {
            this.msgData[this.crtPosWrite++] = data;
            return;
        }
        throw new Exception("Xplayer.addByte.Error adding byte to current data");
    }
    
    public byte getByte() throws Exception {
        if (this.msgData != null && this.crtPosRead < this.crtPosWrite) {
            return this.msgData[this.crtPosRead++];
        }
        throw new Exception("Xplayer.getByte.Error retrieving byte from current data");
    }
    
    public void addShort(final short data) throws Exception {
        if (this.msgData != null && this.crtPosWrite < this.msgData.length - 1) {
            this.msgData[this.crtPosWrite++] = (byte)((data & 0xFF00) >> 8);
            this.msgData[this.crtPosWrite++] = (byte)(data & 0xFF);
            return;
        }
        throw new Exception("Xplayer.addShort.Error add short to current data");
    }
    
    public short getShort() throws Exception {
        if (this.msgData != null && this.crtPosRead < this.crtPosWrite - 1) {
            final short ret = (short)((this.msgData[this.crtPosRead] << 8 & 0xFF00) | (this.msgData[this.crtPosRead + 1] & 0xFF));
            this.crtPosRead += 2;
            return ret;
        }
        throw new Exception("Xplayer.getShort.Error retrieve short from current data");
    }
    
    public void addInt(final int data) throws Exception {
        if (this.msgData != null && this.crtPosWrite < this.msgData.length - 3) {
            this.msgData[this.crtPosWrite++] = (byte)(data >>> 24);
            this.msgData[this.crtPosWrite++] = (byte)(data >>> 16);
            this.msgData[this.crtPosWrite++] = (byte)(data >>> 8);
            this.msgData[this.crtPosWrite++] = (byte)(data >>> 0);
            return;
        }
        throw new Exception("Xplayer.addInt.Error add int to current data");
    }
    
    public int getInt() throws Exception {
        if (this.msgData != null && this.crtPosRead < this.crtPosWrite - 3) {
            int ret = 0;
            ret |= (this.msgData[this.crtPosRead] << 24 & 0xFF000000);
            ret |= (this.msgData[this.crtPosRead + 1] << 16 & 0xFF0000);
            ret |= (this.msgData[this.crtPosRead + 2] << 8 & 0xFF00);
            ret |= (this.msgData[this.crtPosRead + 3] << 0 & 0xFF);
            this.crtPosRead += 4;
            return ret;
        }
        throw new Exception("Xplayer.getInt.Error retrieve int from current data");
    }
    
    public void addByteArray(final byte size, final int dataOffset, final byte[] data) throws Exception {
        if (this.msgData != null && this.crtPosWrite < this.msgData.length - size) {
            this.msgData[this.crtPosWrite++] = size;
            System.arraycopy(data, dataOffset, this.msgData, this.crtPosWrite, size);
            this.crtPosWrite += size;
            return;
        }
        throw new Exception("Xplayer.addByteArray.Error adding byte array to current data");
    }
    
    public byte[] getByteArray() throws Exception {
        byte size = 0;
        if (this.msgData == null || this.crtPosRead >= this.crtPosWrite) {
            throw new Exception("Xplayer.getByteArray.Error getting byte array size from current data");
        }
        size = this.msgData[this.crtPosRead++];
        if (this.crtPosRead < this.crtPosWrite - size + 1) {
            final byte[] data = new byte[size];
            System.arraycopy(this.msgData, this.crtPosRead, data, 0, size);
            this.crtPosRead += size;
            return data;
        }
        throw new Exception("Xplayer.getByteArray.Error adding byte array to current data");
    }
    
    public byte[] getByteArray(final int dataOffset, final byte[] datadest) throws Exception {
        byte size = 0;
        if (this.msgData == null || this.crtPosRead >= this.crtPosWrite) {
            throw new Exception("Error getting byte array size from current data");
        }
        size = this.msgData[this.crtPosRead++];
        if (this.crtPosRead < this.crtPosWrite - size + 1) {
            System.arraycopy(this.msgData, this.crtPosRead, datadest, dataOffset, size);
            this.crtPosRead += size;
            return datadest;
        }
        throw new Exception("Error adding byte array to current data");
    }
    
    public void addString(final String data) throws Exception {
        final byte[] db = data.getBytes();
        if (db.length > 255) {
            throw new Exception("Error adding string to current data");
        }
        this.addByteArray((byte)db.length, 0, db);
    }
    
    public String getString() throws Exception {
        return new String(this.getByteArray());
    }
    
    public final boolean mpIsConnected() {
        return this.m_MPConnectLevel >= 1;
    }
    
    public final boolean mpIsLoggedIn() {
        return this.m_MPConnectLevel >= 2;
    }
    
    public final boolean mpIsInSession() {
        return this.m_MPConnectLevel >= 3;
    }
    
    public final boolean mpIsInGame() {
        return this.m_MPConnectLevel >= 5;
    }
    
    public final boolean mpIsMaster() {
        return this.m_MPConnectLevel == 4 || this.m_MPConnectLevel == 6;
    }
    
    public final boolean mpHasOpponnentFinished() {
        return this.m_MPHasOpponentFinished;
    }
    
    private boolean mpProcessIncomingMessages() {
        if (System.currentTimeMillis() - XPlayer.callstarttime > GLLibConfig.xplayer_KEEP_ALIVE_TIME) {
            this.mpSendKeepAlive();
        }
        if (!this.wtcp.m_connected) {
            this.m_MPConnectLevel = 0;
            if (this.wtcp.m_bError) {
                this.lastErrorCode = -2;
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("XPLAYER: TCP says " + this.wtcp.m_bErrorString);
                }
            }
            return true;
        }
        this.m_data = this.wtcp.recvPacket();
        if (this.m_data == null) {
            if (!this.wtcp.m_connected) {
                this.m_MPConnectLevel = 0;
                if (this.wtcp.m_bError) {
                    this.lastErrorCode = -2;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        GLLib.Dbg("XPLAYER: TCP says " + this.wtcp.m_bErrorString);
                    }
                }
            }
            return false;
        }
        this.setData(this.m_data);
        try {
            this.m_type = this.getByte();
            this.m_subtype = 0;
            switch (this.m_type) {
                case 115: {
                    switch (this.m_subtype = this.getByte()) {
                        case 101:
                        case 115:
                        case 120: {
                            return true;
                        }
                        default: {
                            throw new Exception("Unknown message type");
                        }
                    }
                    break;
                }
                case 103: {
                    switch (this.m_subtype = this.getByte()) {
                        case 114: {
                            return true;
                        }
                        case 112: {
                            this.mpProcessPushMessages();
                            return false;
                        }
                        case 103:
                        case 104: {
                            this.incomingGameData.addElement(this.m_data);
                            return false;
                        }
                        case 97: {
                            return false;
                        }
                        default: {
                            throw new Exception("Unknown message type");
                        }
                    }
                    break;
                }
                default: {
                    throw new Exception("Unknown message type");
                }
            }
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
            return false;
        }
    }
    
    private void mpProcessPushMessages() throws Exception {
        if (!this.mpIsInSession()) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Push message outside session !");
            }
            return;
        }
        int newlen = 0;
        final byte result = this.getByte();
        switch (result) {
            case 107: {
                this.m_MPConnectLevel = 2;
                break;
            }
            case 108: {
                String name;
                int pos;
                for (name = this.getString(), pos = 0; pos < this.m_lNameList.length && !name.toLowerCase().equals(this.m_lNameList[pos].toLowerCase()); ++pos) {}
                if (pos == this.m_lNameList.length) {
                    return;
                }
                final String[] newnamelist = new String[this.m_lNameList.length - 1];
                final byte[] newbytedatalist = new byte[this.m_lNameList.length - 1];
                int cnt = 0;
                int cnt2 = 0;
                while (cnt < this.m_lNameList.length) {
                    if (cnt == pos) {
                        ++cnt;
                    }
                    else {
                        newnamelist[cnt2] = this.m_lNameList[cnt];
                        newbytedatalist[cnt2] = this.m_lByteDataList[cnt];
                        ++cnt;
                        ++cnt2;
                    }
                }
                this.m_lNameList = newnamelist;
                this.m_lByteDataList = newbytedatalist;
                this.noitems = (byte)this.m_lNameList.length;
                break;
            }
            case 106: {
                final byte index = this.getByte();
                final String name = this.getString();
                if (this.m_lNameList != null) {
                    newlen = this.m_lNameList.length + 1;
                }
                else {
                    newlen = 1;
                }
                final String[] newnamelist = new String[newlen];
                final byte[] newbytedatalist = new byte[newlen];
                int cnt;
                for (cnt = 0; cnt < newlen - 1; ++cnt) {
                    newnamelist[cnt] = this.m_lNameList[cnt];
                    newbytedatalist[cnt] = this.m_lByteDataList[cnt];
                }
                newnamelist[cnt] = name;
                newbytedatalist[cnt] = index;
                this.m_lNameList = newnamelist;
                this.m_lByteDataList = newbytedatalist;
                this.noitems = (byte)this.m_lNameList.length;
                break;
            }
            case 115: {
                if (this.m_MPConnectLevel == 4) {
                    break;
                }
                final byte index = this.getByte();
                this.m_lNameList = new String[index];
                this.m_lByteDataList = new byte[index];
                for (int cnt = 0; cnt < index; ++cnt) {
                    this.m_lNameList[cnt] = this.getString();
                    this.m_lByteDataList[cnt] = (byte)(cnt + 1);
                }
                this.noitems = (byte)this.m_lNameList.length;
                if (this.m_MPConnectLevel == 3) {
                    this.m_MPConnectLevel = 5;
                    this.m_MPHasOpponentFinished = false;
                }
                else {
                    this.lastErrorCode = 51;
                }
                this.incomingGameData = new Vector();
                break;
            }
            case 102: {
                this.m_MPHasOpponentFinished = true;
                break;
            }
        }
    }
    
    private void mpPrepareGameRequest(final byte type) throws Exception {
        this.clearData();
        this.addByte((byte)103);
        this.addByte((byte)114);
        this.addByte(type);
    }
    
    public void mpPrepareGameData() throws Exception {
        if (!this.mpIsInGame()) {
            this.lastErrorCode = 50;
            return;
        }
        this.lastErrorCode = -1;
        this.clearData();
        this.addByte((byte)103);
        this.addByte((byte)103);
    }
    
    public void mpSendGameData() {
        if (!this.mpIsInGame() || this.lastErrorCode != -1) {
            this.lastErrorCode = 50;
            return;
        }
        this.lastErrorCode = 0;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleGameData() throws Exception {
        this.isGameMessageInQueue = false;
        if (!this.mpIsInGame()) {
            this.lastErrorCode = 50;
            return;
        }
        if (this.mpProcessIncomingMessages()) {
            return;
        }
        if (this.incomingGameData.size() > 0) {
            this.m_data = this.incomingGameData.firstElement();
            this.incomingGameData.removeElementAt(0);
            this.isGameMessageInQueue = true;
        }
        else {
            this.m_data = null;
        }
    }
    
    public void mpSendDisconnect() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: send disconnect");
        }
        this.clearData();
        try {
            this.addByte((byte)115);
            this.addByte((byte)120);
        }
        catch (final Exception e) {
            GLLib.Dbg(e.getMessage());
            return;
        }
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleDisconnect() {
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: receive disconnect");
        }
        if (this.m_type == 115 && this.m_subtype == 120) {
            this.mpDisconnect();
        }
        this.lastErrorCode = 0;
    }
    
    public void mpDisconnect() {
        this.wtcp.disconnect();
        this.m_MPConnectLevel = 0;
    }
    
    public void mpHandleUpdates() {
        this.mpProcessIncomingMessages();
    }
    
    public void mpSendEstablishConnection() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: Establish connection");
        }
        if (this.mpIsConnected()) {
            this.lastErrorCode = 50;
            return;
        }
        final int sig = new Random().nextInt();
        this.wtcp.connect();
        this.clearData();
        try {
            this.addByte((byte)115);
            this.addByte((byte)114);
            this.addInt(sig);
        }
        catch (final Exception e) {
            GLLib.Dbg(e.getMessage());
            return;
        }
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        this.clearData();
        try {
            this.addByte((byte)115);
            this.addByte((byte)119);
            this.addInt(sig);
        }
        catch (final Exception e) {
            GLLib.Dbg(e.getMessage());
            return;
        }
        this.wtcp.sendEstablishConnectionPackageOnReceive(this.getData());
    }
    
    public void mpHandleEstablishConnection() {
        if (this.mpIsConnected()) {
            this.lastErrorCode = 50;
            return;
        }
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (this.m_type == 115) {
            switch (this.m_subtype) {
                case 115: {
                    this.m_MPConnectLevel = 1;
                    this.lastErrorCode = 0;
                    break;
                }
                case 101: {
                    this.m_MPConnectLevel = 0;
                    this.lastErrorCode = -2;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        GLLib.Dbg("XPLAYER: TCP says " + this.wtcp.m_bErrorString);
                        break;
                    }
                    break;
                }
            }
        }
    }
    
    public void mpSendLogin() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: Logging in");
        }
        if (!this.mpIsConnected() || this.mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.mpPrepareGameRequest((byte)105);
            this.addString("" + XPlayer.GGI + "-" + this.uid);
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
            return;
        }
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpSendLogin(final String player_data) {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: Logging in");
        }
        if (!this.mpIsConnected() || this.mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.mpPrepareGameRequest((byte)105);
            this.addString("" + XPlayer.GGI + "-" + this.uid);
            this.addString(player_data);
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
            return;
        }
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleLogin() {
        if (!this.mpIsConnected() || this.mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = this.getByte();
            if (result != 105) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Bad response LOGIN" + new String(this.m_data));
                }
                this.lastErrorCode = 51;
                return;
            }
            result = this.getByte();
            if (result == 115) {
                this.m_MPConnectLevel = 2;
                this.lastErrorCode = 0;
            }
            else {
                this.lastErrorCode = 3;
            }
        }
        catch (final Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
        }
    }
    
    public void mpSendQuickGame() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: Quick game");
        }
        if (!this.mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.mpPrepareGameRequest((byte)117);
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
            return;
        }
        this.m_lBinaryDataList = null;
        this.m_lNameList = null;
        this.noitems = 0;
        this.nosessionsbase = 0;
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpSendListSession(final byte numberOfSessions, final byte firstSessionIndex) {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("XPLAYER: List session");
        }
        if (!this.mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.noitems = numberOfSessions;
            this.nosessionsbase = firstSessionIndex;
            if (this.noitems <= 0) {
                this.noitems = 1;
            }
            if (this.nosessionsbase < 0) {
                this.nosessionsbase = 0;
            }
            this.mpPrepareGameRequest((byte)108);
            this.addByte(this.noitems);
            this.addInt(this.nosessionsbase);
        }
        catch (final Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("Error: " + e.getMessage());
            }
            return;
        }
        this.m_lBinaryDataList = null;
        this.m_lNameList = null;
        this.noitems = 0;
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleListSession() {
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (!this.mpIsLoggedIn()) {
            this.lastErrorCode = 50;
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = this.getByte();
            if (result != 117 && result != 108) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Bad response LIST" + new String(this.m_data));
                }
                this.lastErrorCode = 51;
                return;
            }
            result = this.getByte();
            if (result == 115) {
                this.noitems = this.getByte();
                this.nosessionsbase = this.getInt();
                if (this.noitems > 0) {
                    this.m_lNameList = new String[this.noitems];
                    this.m_lByteDataList = new byte[this.noitems];
                    this.m_lBinaryDataList = new String[this.noitems];
                    for (int cnt = 0; cnt < this.noitems; ++cnt) {
                        this.m_lNameList[cnt] = this.getString();
                        this.m_lByteDataList[cnt] = this.getByte();
                    }
                    for (int cnt = 0; cnt < this.noitems; ++cnt) {
                        this.m_lBinaryDataList[cnt] = this.getString();
                    }
                }
                this.lastErrorCode = 0;
            }
            else {
                this.lastErrorCode = 3;
            }
        }
        catch (final Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
        }
    }
    
    public void mpSendCreateSession(final String sessionname, final String sessiondata) {
        if (!this.mpIsLoggedIn() || this.mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.mpPrepareGameRequest((byte)99);
            this.addString(sessionname);
            if (sessiondata != null) {
                this.addString(sessiondata);
            }
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("Error: " + e.getMessage());
            }
            return;
        }
        this.currentsessionname = sessionname;
        this.currentsessiondata = sessiondata;
        this.m_lBinaryDataList = null;
        this.m_lNameList = null;
        this.noitems = 0;
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleCreateSession() {
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (!this.mpIsLoggedIn() || this.mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = this.getByte();
            if (result != 99) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Bad response CREATE" + new String(this.m_data));
                }
                this.lastErrorCode = 51;
                return;
            }
            result = this.getByte();
            if (result == 115) {
                this.m_MPConnectLevel = 4;
                this.noitems = 1;
                this.m_lNameList = new String[this.noitems];
                this.m_lByteDataList = new byte[this.noitems];
                for (int cnt = 0; cnt < this.noitems; ++cnt) {
                    this.m_lNameList[cnt] = this.username;
                    this.m_lByteDataList[cnt] = 1;
                }
                this.lastErrorCode = 0;
            }
            else {
                this.lastErrorCode = 54;
            }
        }
        catch (final Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
        }
    }
    
    public void mpSendJoinSession(final String sessionname) {
        if (!this.mpIsLoggedIn() || this.mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.mpPrepareGameRequest((byte)106);
            this.addString(sessionname);
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
            return;
        }
        this.currentsessionname = sessionname;
        this.m_lBinaryDataList = null;
        this.m_lNameList = null;
        this.noitems = 0;
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleJoinSession() {
        if (!this.mpIsLoggedIn() || this.mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = this.getByte();
            if (result != 106) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Bad response JOIN" + new String(this.m_data));
                }
                this.lastErrorCode = 51;
                return;
            }
            result = this.getByte();
            if (result == 115) {
                this.m_MPConnectLevel = 3;
                this.lastErrorCode = 0;
                this.noitems = this.getByte();
                this.m_lNameList = new String[this.noitems];
                this.m_lByteDataList = new byte[this.noitems];
                for (int cnt = 0; cnt < this.noitems; ++cnt) {
                    this.m_lNameList[cnt] = this.getString();
                    this.m_lByteDataList[cnt] = (byte)(cnt + 1);
                }
                this.currentsessiondata = this.getString();
                if (this.currentsessiondata.length() == 0) {
                    this.currentsessiondata = null;
                }
            }
            else {
                this.lastErrorCode = 54;
            }
        }
        catch (final Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
        }
    }
    
    public void mpSendLeaveSession() {
        if (!this.mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.mpPrepareGameRequest((byte)113);
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
            return;
        }
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleLeaveSession() {
        if (!this.mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = this.getByte();
            if (result != 113) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Bad response LEAVE" + new String(this.m_data));
                }
                this.lastErrorCode = 51;
                return;
            }
            result = this.getByte();
            if (result == 115) {
                this.m_MPConnectLevel = 2;
                this.lastErrorCode = 0;
            }
            else {
                this.lastErrorCode = 3;
            }
        }
        catch (final Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
        }
    }
    
    public void mpSendKickOutPlayer(final String playerName) {
        if (!this.mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.mpPrepareGameRequest((byte)107);
            this.addString(playerName);
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
            return;
        }
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleKickOutPlayer(final String name) {
        if (!this.mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = this.getByte();
            if (result != 107) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Bad response KICK OUT" + new String(this.m_data));
                }
                this.lastErrorCode = 51;
                return;
            }
            result = this.getByte();
            if (result == 115) {
                final int newlen = 0;
                int pos;
                for (pos = 0; pos < this.m_lNameList.length && !name.toLowerCase().equals(this.m_lNameList[pos].toLowerCase()); ++pos) {}
                if (pos == this.m_lNameList.length) {
                    this.lastErrorCode = 0;
                    return;
                }
                final String[] newlist = new String[this.m_lNameList.length - 1];
                final byte[] newdata = new byte[this.m_lNameList.length - 1];
                int cnt = 0;
                int cnt2 = 0;
                while (cnt < this.m_lNameList.length) {
                    if (cnt == pos) {
                        ++cnt;
                    }
                    else {
                        newlist[cnt2] = this.m_lNameList[cnt];
                        newdata[cnt2] = this.m_lByteDataList[cnt];
                        ++cnt;
                        ++cnt2;
                    }
                }
                this.m_lNameList = newlist;
                this.m_lByteDataList = newdata;
                this.noitems = (byte)this.m_lNameList.length;
                this.lastErrorCode = 0;
            }
            else {
                this.lastErrorCode = 3;
            }
        }
        catch (final Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
        }
    }
    
    public void mpSendStartGame() {
        if (!this.mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.mpPrepareGameRequest((byte)115);
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
            return;
        }
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleStartGame() {
        if (this.mpIsInGame()) {
            if (!this.mpProcessIncomingMessages()) {
                return;
            }
            if (this.m_type != 103 || this.m_subtype != 114) {
                return;
            }
            try {
                final byte result = this.getByte();
                if (result != 115) {
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        GLLib.Dbg("Bad response START while in game" + new String(this.m_data));
                    }
                    this.lastErrorCode = 51;
                    return;
                }
            }
            catch (final Exception e) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Error: " + e.getMessage());
                }
                return;
            }
            this.lastErrorCode = 0;
            this.incomingGameData = new Vector();
        }
        if (!this.mpIsInSession()) {
            this.lastErrorCode = 50;
            return;
        }
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = this.getByte();
            if (result != 115) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Bad response START" + new String(this.m_data));
                }
                this.lastErrorCode = 51;
                return;
            }
            result = this.getByte();
            if (result == 115) {
                if (this.m_MPConnectLevel == 3) {
                    this.m_MPConnectLevel = 5;
                }
                else if (this.m_MPConnectLevel == 4) {
                    this.m_MPConnectLevel = 6;
                }
                this.m_MPHasOpponentFinished = false;
                this.noitems = this.getByte();
                this.m_lNameList = new String[this.noitems];
                this.m_lByteDataList = new byte[this.noitems];
                for (int cnt = 0; cnt < this.noitems; ++cnt) {
                    this.m_lNameList[cnt] = this.getString();
                    this.m_lByteDataList[cnt] = (byte)(cnt + 1);
                }
                this.incomingGameData = new Vector();
                this.lastErrorCode = 0;
            }
            else {
                this.lastErrorCode = 54;
            }
        }
        catch (final Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
        }
    }
    
    public void mpSendFinishGame() {
        if (!this.mpIsInGame()) {
            return;
        }
        try {
            this.mpPrepareGameRequest((byte)102);
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
            return;
        }
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleFinishGame() {
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = this.getByte();
            if (result != 102) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Bad response FINISH" + new String(this.m_data));
                }
                this.lastErrorCode = 51;
            }
            result = this.getByte();
            if (result == 115) {
                this.m_MPConnectLevel = 2;
                this.lastErrorCode = 0;
            }
            else {
                this.lastErrorCode = 54;
            }
        }
        catch (final Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
        }
    }
    
    public void mpSendFindPlayer(final String playerName) {
        if (!this.mpIsConnected()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.mpPrepareGameRequest((byte)119);
            this.addString(playerName);
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
            return;
        }
        this.found_player_session_name = null;
        this.found_player_session_number_of_players = -1;
        this.found_player_status = -1;
        this.found_player_name = playerName;
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleFindPlayer() {
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = this.getByte();
            if (result != 119) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Bad response find player" + new String(this.m_data));
                }
                this.lastErrorCode = 40;
                return;
            }
            result = this.getByte();
            if (result == 115) {
                this.found_player_status = this.getByte();
                if (this.found_player_status == 115 || this.found_player_status == 112) {
                    this.found_player_session_name = this.getString();
                    this.found_player_session_number_of_players = this.getByte();
                }
                this.lastErrorCode = 0;
            }
            else {
                this.lastErrorCode = 54;
            }
        }
        catch (final Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
        }
    }
    
    public void mpSendGetPlayerData(final String playerName) {
        if (!this.mpIsConnected()) {
            this.lastErrorCode = 50;
            return;
        }
        try {
            this.mpPrepareGameRequest((byte)121);
            this.addString(playerName);
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
            return;
        }
        this.requested_player_data = null;
        this.requested_player_nickname = playerName;
        this.lastErrorCode = -1;
        this.whttp.m_bError = false;
        this.wtcp.sendPacket(this.getData());
        XPlayer.callstarttime = System.currentTimeMillis();
    }
    
    public void mpHandleGetPlayerData() {
        if (!this.mpProcessIncomingMessages()) {
            return;
        }
        if (this.m_type != 103 || this.m_subtype != 114) {
            return;
        }
        try {
            byte result = this.getByte();
            if (result != 121) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("Bad response find player" + new String(this.m_data));
                }
                this.lastErrorCode = 40;
                return;
            }
            result = this.getByte();
            if (result == 115) {
                result = this.getByte();
                if (result == 104) {
                    this.requested_player_data = this.getString();
                    this.lastErrorCode = 0;
                }
                else if (result == 100) {
                    this.lastErrorCode = 0;
                }
                else {
                    this.lastErrorCode = 40;
                }
            }
            else {
                this.lastErrorCode = 54;
            }
        }
        catch (final Exception e) {
            this.lastErrorCode = 40;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Error: " + e.getMessage());
            }
        }
    }
    
    private boolean mpSendKeepAlive() {
        try {
            this.clearData();
            this.addByte((byte)103);
            this.addByte((byte)97);
            this.wtcp.sendPacket(this.getData());
            XPlayer.callstarttime = System.currentTimeMillis();
        }
        catch (final Exception ex) {}
        return true;
    }
    
    public String[] getNameList() {
        return this.m_lNameList;
    }
    
    public String[] getDataList() {
        return this.m_lBinaryDataList;
    }
    
    public byte[] getByteDataList() {
        return this.m_lByteDataList;
    }
    
    public String getSessionName() {
        return this.currentsessionname;
    }
    
    public String getSessionData() {
        return this.currentsessiondata;
    }
    
    public int getNumberOfItems() {
        return this.noitems;
    }
    
    public int getFirstSessionIndex() {
        return this.nosessionsbase;
    }
    
    public String getFoundPlayerName() {
        return this.found_player_name;
    }
    
    public byte getFoundPlayerStatus() {
        return this.found_player_status;
    }
    
    public String getFoundPlayerSessionName() {
        return this.found_player_session_name;
    }
    
    public byte getFoundPlayerSessionNumberOfPlayers() {
        return this.found_player_session_number_of_players;
    }
    
    public String getRequestedPlayerData() {
        return this.requested_player_data;
    }
    
    public String getRequestedPlayerNickname() {
        return this.requested_player_nickname;
    }
    
    interface ConnectLevel
    {
        public static final byte NOT_CONNECTED = 0;
        public static final byte NOT_LOGGED_IN = 1;
        public static final byte IN_CONNECTED = 2;
        public static final byte IN_SESSION = 3;
        public static final byte IN_SESSION_MASTER = 4;
        public static final byte IN_GAME = 5;
        public static final byte IN_GAME_MASTER = 6;
    }
    
    public interface MessageType
    {
        public static final byte BASIC_MESSAGE_TYPE_UNKNOWN = 0;
        public static final byte BASIC_MESSAGE_TYPE_GAME = 103;
        public static final byte BASIC_MESSAGE_TYPE_CONNECT = 115;
        public static final byte CONNECT_MESSAGE_INIT_WRITE = 119;
        public static final byte CONNECT_MESSAGE_INIT_READ = 114;
        public static final byte CONNECT_MESSAGE_SUCCESS = 115;
        public static final byte CONNECT_MESSAGE_ERROR = 101;
        public static final byte CONNECT_MESSAGE_DISCONNECT = 120;
        public static final byte GAME_MESSAGE_REQUEST = 114;
        public static final byte GAME_MESSAGE_PUSH = 112;
        public static final byte GAME_MESSAGE_IN_GAME = 103;
        public static final byte GAME_MESSAGE_IN_GAME_TOALL = 104;
        public static final byte GAME_MESSAGE_ERROR = 101;
        public static final byte GAME_MESSAGE_KEEP_ALIVE = 97;
        public static final byte REQUEST_MESSAGE_LOGIN = 105;
        public static final byte REQUEST_MESSAGE_CREATE_SESSION = 99;
        public static final byte REQUEST_MESSAGE_LIST_SESSIONS = 108;
        public static final byte REQUEST_MESSAGE_GET_QUICK_SESSION = 117;
        public static final byte REQUEST_MESSAGE_JOIN_SESSION = 106;
        public static final byte REQUEST_MESSAGE_LEAVE_SESSION = 113;
        public static final byte REQUEST_MESSAGE_KICK_OUT_PLAYER = 107;
        public static final byte REQUEST_MESSAGE_START_GAME = 115;
        public static final byte REQUEST_MESSAGE_FINISH_GAME = 102;
        public static final byte REQUEST_MESSAGE_GET_PLAYER_INFO = 119;
        public static final byte REQUEST_MESSAGE_GET_PLAYER_DATA = 121;
        public static final byte RESPONSE_MESSAGE_SUCCESS = 115;
        public static final byte RESPONSE_MESSAGE_ERROR = 101;
        public static final byte ERROR_INVALID_INPUT = 105;
        public static final byte ERROR_NO_SESSION = 115;
        public static final byte ERROR_SESSION_CLOSED = 99;
        public static final byte ERROR_NOT_MASTER = 109;
        public static final byte ERROR_LOGIN_NICKNAME_USED = 110;
        public static final byte ERROR_LOGIN_INVALID_NICKNAME = 113;
        public static final byte ERROR_LOGIN_AUTHENTICATION_FAILED = 97;
        public static final byte ERROR_CREATE_SESSION_INVALID_NAME = 118;
        public static final byte ERROR_CREATE_SESSION_NAME_USED = 117;
        public static final byte ERROR_BLOCKED_SESSION = 98;
        public static final byte ERROR_LIST_SESSION_INVALID_INDEX = 108;
        public static final byte ERROR_JOIN_SESSION_TOO_MANY_PLAYERS = 106;
        public static final byte ERROR_NO_PLAYER = 107;
        public static final byte ERROR_KICK_OUT_PLAYER_IS_MASTER = 100;
        public static final byte ERROR_START_GAME_NOT_ENOUGH_PLAYERS = 103;
        public static final byte PUSH_MESSAGE_JOIN_SESSION = 106;
        public static final byte PUSH_MESSAGE_LEAVE_SESSION = 108;
        public static final byte PUSH_MESSAGE_KICK_OUT = 107;
        public static final byte PUSH_MESSAGE_START_GAME = 115;
        public static final byte PUSH_MESSAGE_FINISH_GAME = 102;
        public static final byte PLAYER_STATUS_NOT_REGISTERED = 110;
        public static final byte PLAYER_STATUS_OFFLINE = 102;
        public static final byte PLAYER_STATUS_ONLINE = 111;
        public static final byte PLAYER_STATUS_ONLINE_IN_SESSION = 115;
        public static final byte PLAYER_STATUS_ONLINE_PLAYING = 112;
        public static final byte PLAYER_STATUS_HAS_PSD = 104;
        public static final byte PLAYER_STATUS_HAS_NO_PSD = 100;
    }
    
    public interface Error
    {
        public static final int ERROR_INIT = -100;
        public static final byte ERROR_NOT_M7_ENABLED = -3;
        public static final byte ERROR_CONNECTION = -2;
        public static final byte ERROR_PENDING = -1;
        public static final byte ERROR_NONE = 0;
        public static final byte ERROR_NO_UUID = 1;
        public static final byte ERROR_NO_NICKNAME = 2;
        public static final byte ERROR_REGISTER_FAILED = 3;
        public static final byte ERROR_NOT_REGISTERED = 4;
        public static final byte ERROR_NICK_TAKEN = 5;
        public static final byte ERROR_SCORE_UPLOAD_FAILED = 21;
        public static final byte ERROR_GET_RANKINGS_FAILED = 22;
        public static final byte ERROR_RATE_GAME_FAILED = 23;
        public static final byte ERROR_RECOMMEND_GAME_FAILED = 24;
        public static final byte ERROR_NO_PHONE_NUMBER = 25;
        public static final byte ERROR_NO_CLIENT_ID = 26;
        public static final byte ERROR_INVALID_GGI = 27;
        public static final byte ERROR_GET_STATS_FAILED = 29;
        public static final byte ERROR_SUPPLEMENTAL_DATA_NEEDED = 31;
        public static final byte ERROR_VALIDATE_LICENSE_FAILED = 32;
        public static final byte ERROR_CHANGE_USERNAME_FAILED = 33;
        public static final byte ERROR_BAD_RESPONSE = 40;
        public static final byte ERROR_WRONGFULL_QSTATE = 50;
        public static final byte ERROR_WRONGFULL_RSTATE = 51;
        public static final byte ERROR_START_GAME = 52;
        public static final byte ERROR_JOIN_GAME = 53;
        public static final byte ERROR_REQUEST_FAILED = 54;
    }
}
