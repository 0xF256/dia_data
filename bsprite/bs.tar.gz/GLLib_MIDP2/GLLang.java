// 
// Decompiled by Procyon v0.6.0
// 

interface GLLang
{
    public static final int EN = 0;
    public static final int DE = 1;
    public static final int FR = 2;
    public static final int IT = 3;
    public static final int ES = 4;
    public static final int BR = 5;
    public static final int PT = 6;
    public static final int JP = 7;
    public static final int CN = 8;
    public static final int KR = 9;
    public static final int RU = 10;
    public static final int TR = 11;
    public static final int PL = 12;
    public static final int CZ = 13;
}
