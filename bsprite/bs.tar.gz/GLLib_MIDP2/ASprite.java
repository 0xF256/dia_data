import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.Graphics;

// 
// Decompiled by Procyon v0.6.0
// 

public class ASprite
{
    static final short BSPRITE_v003 = 991;
    static final short BSPRITE_v004 = 1247;
    static final short BSPRITE_v005 = 1503;
    static final short SUPPORTED_VERSION = 1503;
    static final int BS_MODULES = 1;
    static final int BS_MODULES_XY = 2;
    static final int BS_MODULES_IMG = 4;
    static final int BS_MODULES_WH_SHORT = 16;
    static final int BS_MODULES_XY_SHORT = 32;
    static final int BS_MODULES_USAGE = 64;
    static final int BS_IMAGE_SIZE_INT = 128;
    static final int BS_FRAMES = 256;
    static final int BS_FM_OFF_SHORT = 1024;
    static final int BS_NFM_1_BYTE = 2048;
    static final int BS_SKIP_FRAME_RC = 4096;
    static final int BS_FRAME_COLL_RC = 8192;
    static final int BS_FM_PALETTE = 16384;
    static final int BS_FRAME_RECTS = 32768;
    static final int BS_ANIMS = 65536;
    static final int BS_NO_AF_START = 131072;
    static final int BS_AF_OFF_SHORT = 262144;
    static final int BS_NAF_1_BYTE = 524288;
    static final int BS_MODULE_IMAGES_FX = 8388608;
    static final int BS_MODULE_IMAGES = 16777216;
    static final int BS_PNG_CRC = 33554432;
    static final int BS_KEEP_PAL = 67108864;
    static final int BS_TRANSP_FIRST = 134217728;
    static final int BS_TRANSP_LAST = 268435456;
    static final int BS_SINGLE_IMAGE = 536870912;
    static final int BS_MODULE_USAGE = 1073741824;
    static final int BS_GIF_HEADER = Integer.MIN_VALUE;
    static final int BS_DEFAULT_DOJA = -2130640575;
    static final int BS_DEFAULT_MIDP2 = 16843009;
    static final int BS_DEFAULT_NOKIA = 16843009;
    static final int BS_DEFAULT_MIDP1 = 65795;
    static final int BS_DEFAULT_MIDP1b = 50397441;
    static final int BS_DEFAULT_MIDP1c = 536936707;
    static final short PIXEL_FORMAT_8888 = -30584;
    static final short PIXEL_FORMAT_4444 = 17476;
    static final short PIXEL_FORMAT_1555 = 21781;
    static final short PIXEL_FORMAT_0565 = 25861;
    static final short ENCODE_FORMAT_I2 = 512;
    static final short ENCODE_FORMAT_I4 = 1024;
    static final short ENCODE_FORMAT_I16 = 5632;
    static final short ENCODE_FORMAT_I256 = 22018;
    static final short ENCODE_FORMAT_I64RLE = 25840;
    static final short ENCODE_FORMAT_I127RLE = 10225;
    static final short ENCODE_FORMAT_I256RLE = 22258;
    static final byte FLAG_FLIP_X = 1;
    static final byte FLAG_FLIP_Y = 2;
    static final byte FLAG_ROT_90 = 4;
    static final byte FLAG_USER0 = 16;
    static final byte FLAG_USER1 = 32;
    static final byte FLAG_HYPER_FM = 16;
    static final int FLAG_INDEX_EX_MASK = 192;
    static final int INDEX_MASK = 1023;
    static final int INDEX_EX_MASK = 768;
    static final int INDEX_EX_SHIFT = 2;
    static final byte FLAG_OFFSET_FM = 16;
    static final byte FLAG_OFFSET_AF = 32;
    static final int OPERATION_DRAW = 0;
    static final int OPERATION_COMPUTERECT = 1;
    static final int OPERATION_RECORD = 2;
    static final int OPERATION_MARK = 3;
    static final int RESIZE_NONE = 0;
    static final int RESIZE_CREATERGB = 1;
    static final int RESIZE_DRAW_ON_MUTABLE = 2;
    static final int RESIZE_NOT_CACHED = 3;
    static final int MD_IMAGE = 0;
    static final int MD_RECT = 1;
    static final int MD_FILL_RECT = 2;
    static final int MD_ARC = 3;
    static final int MD_FILL_ARC = 4;
    static final int MD_MARKER = 5;
    static final int MD_TRIANGLE = 6;
    static final int MD_FILL_TRIANGLE = 7;
    static final int MAX_TRANSFORMATION_FLAGS = 8;
    public static final int BLOCK_INFO_SIZE = 11;
    public static final int PNG_INFO_SIZE = 57;
    public static final int HEADER_LEVEL0_MAX_WBITS = 30938;
    public static final int BASE = 65521;
    public static final int NMAX = 5552;
    protected static final byte[] MAGIC;
    protected static final byte[] IHDR;
    protected static final byte[] PLTE;
    protected static final byte[] tRNS;
    protected static final byte[] IDAT;
    protected static final byte[] IEND;
    protected static final byte[] INFO32;
    protected static final byte[] INFO8;
    protected static final byte[] MAGIC_IEND;
    static final byte[] MAGIC_IDAT_h;
    static byte[] _buffer_index;
    static byte[] _png_index;
    static byte[] _png_result;
    static int _png_size;
    static int _png_start_crc;
    static int mod;
    public static int[] crcTable;
    public static final int CRC32_POLYNOMIAL = -306674912;
    static int currentChunkType;
    int _cur_pal;
    static final int SCALE_SHIFT = 16;
    static final int RESIZE_REF_240x320 = 0;
    static final int RESIZE_REF_176x220 = 1;
    static final int RESIZE_REF_240x256 = 2;
    static int mResizeRef;
    static boolean s_bBilinear;
    static boolean s_bAspectRatio;
    int wRef;
    int hRef;
    int wTarget;
    int hTarget;
    int xRatio;
    int yRatio;
    boolean mResizeCorrectY;
    int _cur_pool;
    static short[][] _poolCacheStack;
    static int[] _poolCacheStackIndex;
    static int[] _poolCacheStackMax;
    static ASprite[][] _poolCacheSprites;
    static int _text_w;
    static int _text_h;
    static byte[] s_MapChar;
    private byte[] _pMapChar;
    private short[][] _pMapCharShort;
    private short _nDivider;
    private int _nLineSpacing;
    private int _nFontHeight;
    private int _nFontAscent;
    private int _nFontDescent;
    private int _nSpaceWidth;
    private int _nCharSpacing;
    private int _nLineHeight;
    private boolean _bUnderline;
    private boolean _bBold;
    private int[] nALetterRect;
    static short[] _warpTextInfo;
    static int _index1;
    static int _index2;
    int _old_pal;
    static final int k_itoa_buffer_size = 33;
    static char[] _itoa_buffer;
    public static final int PAL_ORIGINAL = -1;
    public static final int PAL_INVISIBLE = 0;
    public static final int PAL_RED_YELLOW = 1;
    public static final int PAL_BLUE_CYAN = 2;
    public static final int PAL_GREEN = 3;
    public static final int PAL_GREY = 4;
    public static final int PAL_BLEND_BLACK = 5;
    Object[][] _aryPrecomputedImages;
    short[][] _aryPrecomputedX;
    short[][] _aryPrecomputedY;
    short[][] _aryPrecomputedSizeX;
    short[][] _aryPrecomputedSizeY;
    short[][] _aryPrecomputedImgX;
    short[][] _aryPrecomputedImgY;
    int[][] _aryPrecomputedFlags;
    static int record_index;
    static int record_frame;
    static int _operation;
    static int[] temp_int;
    static short[] temp_short;
    static byte[] temp_byte;
    static int[] transform_int;
    int _nModules;
    byte[] _modules_x_byte;
    byte[] _modules_y_byte;
    short[] _modules_x_short;
    short[] _modules_y_short;
    short[] _modules_w_scaled;
    short[] _modules_h_scaled;
    short[] _modules_w_short;
    short[] _modules_h_short;
    byte[] _modules_w_byte;
    byte[] _modules_h_byte;
    short[] _modules_extra_info;
    short[] _modules_extra_pointer;
    byte[] _frames_nfm;
    short[] _frames_fm_start;
    byte[] _frames_rc;
    short[] _frames_rc_short;
    byte[] _frames_col;
    short[] _frames_col_short;
    byte[] _frames_rects;
    short[] _frames_rects_short;
    short[] _frames_rects_start;
    byte[] _fmodules;
    byte[] _fmodules_id;
    short[] _fmodules_ox_short;
    short[] _fmodules_oy_short;
    byte[] _fmodules_ox_byte;
    byte[] _fmodules_oy_byte;
    byte[] _fmodules_pal;
    byte[] _fmodules_flags;
    byte[] _anims_naf;
    short[] _anims_af_start;
    byte[] _aframes;
    byte[] _aframes_frame;
    byte[] _aframes_time;
    short[] _aframes_ox_short;
    short[] _aframes_oy_short;
    byte[] _aframes_ox_byte;
    byte[] _aframes_oy_byte;
    byte[] _aframes_flags;
    short[][] _map;
    private int _cur_map;
    int[] _w_pos;
    int[] _header_size;
    byte[][] _gifHeader;
    byte[] _modules_data;
    short[] _modules_data_off_short;
    int[] _modules_data_off_int;
    int _bs_flags;
    short[][] _pal_short;
    int[][] _pal_int;
    byte[][] _transp;
    byte[] _pal_data;
    int _palettes;
    int _colors;
    private int _crt_pal;
    boolean _alpha;
    short _data_format;
    int _i64rle_color_mask;
    int _i64rle_color_bits;
    boolean _bTraceNow;
    static Graphics _graphics;
    short[][][] _modules_image_shortAAA;
    Image[][][] _module_image_imageAAA;
    int[][][] _module_image_intAAA;
    Image[][] _module_image_imageAA;
    Image[] _main_image;
    int[] _PNG_packed_PLTE_CRC;
    int[] _PNG_packed_tRNS_CRC;
    int[] _PNG_packed_IHDR_CRC;
    int[] _PNG_packed_IDAT_ADLER;
    int[] _PNG_packed_IDAT_CRC;
    static int _images_count;
    static int _images_size;
    static int mem;
    static final int[] midp2_flags;
    byte[] _module_types;
    byte[] _module_colors_byte;
    int[] _module_colors_int;
    byte[] _modules_usage;
    static int s_resizeType;
    static int _rectX1;
    static int _rectY1;
    static int _rectX2;
    static int _rectY2;
    static int[] s_rc;
    
    static void DrawLine(final Graphics g, final int x1, final int y1, final int x2, final int y2, final int color, final int radius, final int initial) {
        int ix = 0;
        int iy = 0;
        final int old_color = g.getColor();
        g.setColor(color);
        int currX = x1;
        int currY = y1;
        int dx = x2 - x1;
        int dy = y2 - y1;
        if (dx >= 0) {
            ix = 1;
        }
        if (dx < 0) {
            ix = -1;
            dx = Math.abs(dx);
        }
        if (dy >= 0) {
            iy = 1;
        }
        if (dy < 0) {
            iy = -1;
            dy = Math.abs(dy);
        }
        final int dx2 = dx * 2;
        final int dy2 = dy * 2;
        int dist = 0;
        final int maxdist = (5 - initial) * radius;
        if (dx > dy) {
            int err = dy2 - dx;
            for (int i = 0; i <= dx; ++i) {
                if (dist == maxdist) {
                    if (!GLLibConfig.sprite_fillRoundRectBug) {
                        g.fillRoundRect(currX - radius, currY - radius, radius * 2, radius * 2, 30, 30);
                    }
                    else {
                        g.fillRect(currX - radius, currY - radius + 1, radius << 1, (radius << 1) - 2);
                        g.fillRect(currX - radius + 1, currY - radius, (radius << 1) - 2, radius << 1);
                    }
                }
                dist += ix * ix + iy * iy;
                if (dist > 6 * radius) {
                    dist = 0;
                }
                if (err >= 0) {
                    err -= dx2;
                    currY += iy;
                }
                err += dy2;
                currX += ix;
            }
        }
        else {
            int err = dx2 - dy;
            for (int i = 0; i <= dy; ++i) {
                if (dist == maxdist) {
                    if (!GLLibConfig.sprite_fillRoundRectBug) {
                        g.fillRoundRect(currX - radius, currY - radius, radius * 2, radius * 2, 30, 30);
                    }
                    else {
                        g.fillRect(currX - radius, currY - radius + 1, radius << 1, (radius << 1) - 2);
                        g.fillRect(currX - radius + 1, currY - radius, (radius << 1) - 2, radius << 1);
                    }
                }
                dist += ix * ix + iy * iy;
                if (dist > 6 * radius) {
                    dist = 0;
                }
                if (err >= 0) {
                    err -= dy2;
                    currX += ix;
                }
                err += dx2;
                currY += iy;
            }
        }
        g.setColor(old_color);
    }
    
    void unload() {
        if (GLLibConfig.sprite_useModuleXYShort) {
            this._modules_y_short = null;
            this._modules_x_short = null;
        }
        else {
            this._modules_x_byte = null;
            this._modules_y_byte = null;
        }
        if (GLLibConfig.sprite_useModuleWHShort) {
            this._modules_w_short = null;
            this._modules_h_short = null;
        }
        else {
            this._modules_w_byte = null;
            this._modules_h_byte = null;
        }
        this._frames_nfm = null;
        this._frames_fm_start = null;
        this._frames_rc = null;
        this._frames_rc_short = null;
        this._frames_col = null;
        this._frames_col_short = null;
        this._frames_rects = null;
        this._frames_rects_short = null;
        this._frames_rects_start = null;
        this._fmodules = null;
        this._anims_naf = null;
        this._anims_af_start = null;
        this._aframes = null;
        if (this._map != null) {
            for (int i = 0; i < this._map.length; ++i) {
                this._map[i] = null;
            }
        }
        if (GLLibConfig.sprite_useNokiaUI) {
            if (this._pal_short != null) {
                for (int i = 0; i < this._pal_short.length; ++i) {
                    this._pal_short[i] = null;
                }
            }
        }
        else if (GLLibConfig.sprite_useCreateRGB && this._pal_int != null) {
            for (int i = 0; i < this._pal_int.length; ++i) {
                this._pal_int[i] = null;
            }
        }
        if (this._transp != null) {
            for (int i = 0; i < this._transp.length; ++i) {
                this._transp[i] = null;
            }
        }
        this._pal_data = null;
        this._modules_data = null;
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            this._modules_data_off_short = null;
        }
        else {
            this._modules_data_off_int = null;
        }
        if (GLLibConfig.sprite_useNokiaUI) {
            if (this._modules_image_shortAAA != null) {
                for (int i = 0; i < this._modules_image_shortAAA.length; ++i) {
                    this._modules_image_shortAAA[i] = null;
                }
            }
        }
        else if (GLLibConfig.sprite_useCacheRGBArrays) {
            if (this._module_image_intAAA != null) {
                for (int i = 0; i < this._module_image_intAAA.length; ++i) {
                    this._module_image_intAAA[i] = null;
                }
            }
        }
        else if (this._module_image_imageAA != null) {
            for (int i = 0; i < this._module_image_imageAA.length; ++i) {
                this._module_image_imageAA[i] = null;
            }
        }
        this._main_image = null;
        this._PNG_packed_PLTE_CRC = null;
        this._PNG_packed_tRNS_CRC = null;
        this._PNG_packed_IHDR_CRC = null;
        this._PNG_packed_IDAT_ADLER = null;
        this._PNG_packed_IDAT_CRC = null;
    }
    
    void Load(final byte[] file, final int offset) {
        this.Load(file, offset, 16777215, 1, null);
    }
    
    void Load(final byte[] file, final int offset, final int pal_flags, final int tr_flags) {
        if (GLLibConfig.sprite_useDynamicPng) {
            this.Load(file, offset, pal_flags, tr_flags, null);
        }
    }
    
    void Load(final byte[] file, final int offset, final Image sprImage) {
        if (GLLibConfig.sprite_useExternImage) {
            this.Load(file, offset, 16777215, 1, sprImage);
        }
    }
    
    private int LoadModules(int offset, final byte[] file) {
        this._nModules = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println("nModules = " + this._nModules);
        }
        if (this._nModules > 0) {
            if ((GLLibConfig.sprite_useModuleXY || GLLibConfig.sprite_useModuleXYShort) && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x22) != 0x0)) {
                if (GLLibConfig.sprite_useModuleXYShort) {
                    this._modules_x_short = new short[this._nModules];
                    this._modules_y_short = new short[this._nModules];
                }
                else {
                    this._modules_x_byte = new byte[this._nModules];
                    this._modules_y_byte = new byte[this._nModules];
                }
            }
            if (GLLibConfig.sprite_useModuleWHShort) {
                this._modules_w_short = new short[this._nModules];
                this._modules_h_short = new short[this._nModules];
            }
            else {
                this._modules_w_byte = new byte[this._nModules];
                this._modules_h_byte = new byte[this._nModules];
            }
            int tmpExtraInfoCount = 0;
            int tmpExtraInfoSize = 0;
            short[][] tmpExtraInfo = null;
            if (GLLibConfig.sprite_useMultipleModuleTypes) {
                this._module_types = new byte[this._nModules];
                if (GLLibConfig.sprite_useModuleColorAsByte) {
                    this._module_colors_byte = new byte[this._nModules];
                }
                else {
                    this._module_colors_int = new int[this._nModules];
                }
            }
            boolean bLoadAModuleColor = false;
            boolean bLoadAModulePosition = false;
            boolean bLoadAModuleSize = false;
            boolean bLoadAModuleArc = false;
            boolean bLoadAModuleTriangle = false;
            for (int i = 0; i < this._nModules; ++i) {
                bLoadAModuleArc = false;
                bLoadAModuleTriangle = false;
                if (GLLibConfig.sprite_useMultipleModuleTypes) {
                    if ((file[offset] & 0xFF) == 0x0) {
                        ++offset;
                        this._module_types[i] = 0;
                        bLoadAModuleColor = false;
                        bLoadAModulePosition = true;
                        bLoadAModuleSize = true;
                    }
                    else if ((file[offset] & 0xFF) == 0xFF) {
                        ++offset;
                        this._module_types[i] = 1;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = true;
                    }
                    else if ((file[offset] & 0xFF) == 0xFE) {
                        ++offset;
                        this._module_types[i] = 2;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = true;
                    }
                    else if ((file[offset] & 0xFF) == 0xFD) {
                        ++offset;
                        this._module_types[i] = 5;
                        bLoadAModuleColor = false;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = true;
                    }
                    else if ((file[offset] & 0xFF) == 0xFC) {
                        ++offset;
                        this._module_types[i] = 3;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = true;
                        bLoadAModuleArc = true;
                    }
                    else if ((file[offset] & 0xFF) == 0xFB) {
                        ++offset;
                        this._module_types[i] = 4;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = true;
                        bLoadAModuleArc = true;
                    }
                    else if ((file[offset] & 0xFF) == 0xFA) {
                        ++offset;
                        this._module_types[i] = 6;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = false;
                        bLoadAModuleTriangle = true;
                    }
                    else if ((file[offset] & 0xFF) == 0xF9) {
                        ++offset;
                        this._module_types[i] = 7;
                        bLoadAModuleColor = true;
                        bLoadAModulePosition = false;
                        bLoadAModuleSize = false;
                        bLoadAModuleTriangle = true;
                    }
                    else {
                        GLLib.Assert(false, "Invalid module type : " + (file[offset] & 0xFF) + "   module #" + i);
                    }
                }
                else if ((file[offset] & 0xFF) == 0x0) {
                    ++offset;
                    bLoadAModuleColor = false;
                    bLoadAModulePosition = true;
                    bLoadAModuleSize = true;
                }
                else {
                    GLLib.Assert(false, "Invalid module type : " + (file[offset] & 0xFF) + "   module #" + i);
                }
                if (GLLibConfig.sprite_useMultipleModuleTypes && bLoadAModuleColor) {
                    if (GLLibConfig.sprite_useModuleColorAsByte) {
                        this._module_colors_byte[i] = file[offset++];
                        offset += 3;
                    }
                    else {
                        this._module_colors_int[i] = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
                    }
                }
                if (bLoadAModulePosition) {
                    if (GLLibConfig.sprite_useModuleXY) {
                        if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x2) != 0x0) {
                            this._modules_x_byte[i] = file[offset++];
                            this._modules_y_byte[i] = file[offset++];
                        }
                    }
                    else if (GLLibConfig.sprite_useModuleXYShort && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x20) != 0x0)) {
                        this._modules_x_short[i] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                        this._modules_y_short[i] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                    }
                }
                if (bLoadAModuleSize) {
                    if (GLLibConfig.sprite_useModuleWHShort) {
                        if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 0x10) == 0x0) {
                            this._modules_w_short[i] = (short)(file[offset++] & 0xFF);
                            this._modules_h_short[i] = (short)(file[offset++] & 0xFF);
                        }
                        else {
                            this._modules_w_short[i] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                            this._modules_h_short[i] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                        }
                    }
                    else {
                        this._modules_w_byte[i] = file[offset++];
                        this._modules_h_byte[i] = file[offset++];
                    }
                }
                if (GLLibConfig.sprite_useMultipleModuleTypes) {
                    if (bLoadAModuleArc) {
                        if (tmpExtraInfo == null) {
                            tmpExtraInfo = new short[this._nModules][];
                        }
                        final short[] aShort = { (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8)), (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8)) };
                        tmpExtraInfo[i] = aShort;
                        ++tmpExtraInfoCount;
                        tmpExtraInfoSize += 2;
                    }
                    if (bLoadAModuleTriangle) {
                        if (tmpExtraInfo == null) {
                            tmpExtraInfo = new short[this._nModules][];
                        }
                        final short[] aShort = { (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8)), (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8)), (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8)), (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8)) };
                        tmpExtraInfo[i] = aShort;
                        ++tmpExtraInfoCount;
                        tmpExtraInfoSize += 4;
                    }
                }
            }
            if (GLLibConfig.sprite_useMultipleModuleTypes) {
                if (tmpExtraInfoCount > 0) {
                    this._modules_extra_info = new short[tmpExtraInfoSize];
                    this._modules_extra_pointer = new short[tmpExtraInfoCount << 1];
                    int xCount = 0;
                    short xOffset = 0;
                    for (short m = 0; m < this._nModules; ++m) {
                        int nSize;
                        if (this._module_types[m] == 3 || this._module_types[m] == 4) {
                            nSize = 2;
                        }
                        else if (this._module_types[m] == 6 || this._module_types[m] == 7) {
                            nSize = 4;
                        }
                        else {
                            nSize = -1;
                        }
                        if (nSize > 0) {
                            this._modules_extra_pointer[(xCount << 1) + 0] = m;
                            this._modules_extra_pointer[(xCount << 1) + 1] = xOffset;
                            for (int x = 0; x < nSize; ++x) {
                                this._modules_extra_info[xOffset] = tmpExtraInfo[m][x];
                                ++xOffset;
                            }
                            tmpExtraInfo[m] = null;
                            ++xCount;
                        }
                    }
                }
                tmpExtraInfo = null;
            }
        }
        if (GLLibConfig.sprite_useModuleUsageFromSprite) {
            this._modules_usage = new byte[this._nModules];
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("Module usage... offset = " + offset + " _nModules = " + this._nModules);
            }
            if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x40000000) != 0x0) {
                System.arraycopy(file, offset, this._modules_usage, 0, this._nModules);
                offset += this._nModules;
            }
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("...Module usage");
            }
        }
        return offset;
    }
    
    private int LoadFModules(int offset, final byte[] file) {
        final int nFModules = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println("nFModules = " + nFModules);
        }
        if (nFModules > 0) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                System.arraycopy(file, offset, this._fmodules = new byte[nFModules << 2], 0, this._fmodules.length);
                offset += this._fmodules.length;
            }
            else {
                this._fmodules_id = new byte[nFModules];
                if (GLLibConfig.sprite_useFMOffShort) {
                    this._fmodules_ox_short = new short[nFModules];
                    this._fmodules_oy_short = new short[nFModules];
                }
                else {
                    this._fmodules_ox_byte = new byte[nFModules];
                    this._fmodules_oy_byte = new byte[nFModules];
                }
                this._fmodules_flags = new byte[nFModules];
                if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x4000) != 0x0)) {
                    this._fmodules_pal = new byte[nFModules];
                }
                for (int i = 0; i < nFModules; ++i) {
                    this._fmodules_id[i] = file[offset++];
                    if (GLLibConfig.sprite_useFMOffShort) {
                        if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 0x400) == 0x0) {
                            this._fmodules_ox_short[i] = file[offset++];
                            this._fmodules_oy_short[i] = file[offset++];
                        }
                        else {
                            this._fmodules_ox_short[i] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                            this._fmodules_oy_short[i] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                        }
                    }
                    else {
                        this._fmodules_ox_byte[i] = file[offset++];
                        this._fmodules_oy_byte[i] = file[offset++];
                    }
                    if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x4000) != 0x0)) {
                        this._fmodules_pal[i] = file[offset++];
                    }
                    this._fmodules_flags[i] = file[offset++];
                }
            }
        }
        return offset;
    }
    
    private int LoadFrames(int offset, final byte[] file) {
        if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & 0x8000) != 0x0) {
            final int nRects = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
            if ((this._bs_flags & 0x400) == 0x0) {
                System.arraycopy(file, offset, this._frames_rects = new byte[nRects << 2], 0, nRects << 2);
                offset += nRects << 2;
            }
            else {
                this._frames_rects_short = new short[nRects << 2];
                offset = this.readArray2Short(file, offset, this._frames_rects_short, 0, nRects << 2, false, false);
            }
        }
        final int nFrames = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println("nFrames = " + nFrames + "    @ offset " + (offset - 2));
        }
        if (nFrames > 0) {
            this._frames_nfm = new byte[nFrames];
            this._frames_fm_start = new short[nFrames];
            short frame_start = 0;
            if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & 0x8000) != 0x0) {
                this._frames_rects_start = new short[nFrames + 1];
            }
            short frames_rects_offset = 0;
            for (int i = 0; i < nFrames; ++i) {
                if (GLLibConfig.sprite_debugLoading) {
                    System.out.println("    " + i + "    @ offset " + offset);
                }
                this._frames_nfm[i] = file[offset++];
                if (!GLLibConfig.sprite_alwaysBsNfm1Byte) {
                    final int tmp = file[offset++];
                }
                if (GLLibConfig.sprite_alwaysBsNoFmStart) {
                    this._frames_fm_start[i] = frame_start;
                    frame_start += (short)(this._frames_nfm[i] & 0xFF);
                }
                else {
                    this._frames_fm_start[i] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                }
                if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & 0x8000) != 0x0 && (this._bs_flags & 0x8000) != 0x0) {
                    this._frames_rects_start[i] = frames_rects_offset;
                    frames_rects_offset += file[offset++];
                }
            }
            if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & 0x8000) != 0x0) {
                this._frames_rects_start[this._frames_rects_start.length - 1] = frames_rects_offset;
            }
            if (!GLLibConfig.sprite_alwaysBsSkipFrameRc) {
                if (GLLibConfig.sprite_usePrecomputedFrameRect) {
                    final int nFrames2 = nFrames << 2;
                    if ((this._bs_flags & 0x400) == 0x0) {
                        this._frames_rc = new byte[nFrames2];
                        for (int j = 0; j < nFrames2; ++j) {
                            this._frames_rc[j] = file[offset++];
                        }
                    }
                    else {
                        this._frames_rc_short = new short[nFrames2];
                        for (int j = 0; j < nFrames2; ++j) {
                            this._frames_rc_short[j] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                        }
                    }
                }
                else if ((this._bs_flags & 0x400) == 0x0) {
                    offset += nFrames << 2;
                }
                else {
                    offset += nFrames << 3;
                }
            }
            else if (GLLibConfig.sprite_usePrecomputedFrameRect) {}
            if (GLLibConfig.sprite_useFrameCollRC && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x2000) != 0x0)) {
                final int nFrames2 = nFrames << 2;
                if ((this._bs_flags & 0x400) == 0x0) {
                    this._frames_col = new byte[nFrames2];
                    for (int j = 0; j < nFrames2; ++j) {
                        this._frames_col[j] = file[offset++];
                    }
                }
                else {
                    this._frames_col_short = new short[nFrames2];
                    for (int j = 0; j < nFrames2; ++j) {
                        this._frames_col_short[j] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                    }
                }
            }
        }
        return offset;
    }
    
    private int LoadAFrames(int offset, final byte[] file) {
        final int nAFrames = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println("nAFrames = " + nAFrames);
        }
        if (nAFrames > 0) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                System.arraycopy(file, offset, this._aframes = new byte[nAFrames * 5], 0, this._aframes.length);
                offset += this._aframes.length;
            }
            else {
                this._aframes_frame = new byte[nAFrames];
                this._aframes_time = new byte[nAFrames];
                if (GLLibConfig.sprite_useAfOffShort) {
                    this._aframes_ox_short = new short[nAFrames];
                    this._aframes_oy_short = new short[nAFrames];
                }
                else {
                    this._aframes_ox_byte = new byte[nAFrames];
                    this._aframes_oy_byte = new byte[nAFrames];
                }
                this._aframes_flags = new byte[nAFrames];
                for (int i = 0; i < nAFrames; ++i) {
                    this._aframes_frame[i] = file[offset++];
                    this._aframes_time[i] = file[offset++];
                    if (GLLibConfig.sprite_useAfOffShort) {
                        if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 0x40000) == 0x0) {
                            this._aframes_ox_short[i] = file[offset++];
                            this._aframes_oy_short[i] = file[offset++];
                        }
                        else {
                            this._aframes_ox_short[i] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                            this._aframes_oy_short[i] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                        }
                    }
                    else {
                        this._aframes_ox_byte[i] = file[offset++];
                        this._aframes_oy_byte[i] = file[offset++];
                    }
                    this._aframes_flags[i] = file[offset++];
                }
            }
        }
        return offset;
    }
    
    private int LoadAnims(int offset, final byte[] file) {
        final int nAnims = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println("nAnims = " + nAnims);
        }
        if (nAnims > 0) {
            this._anims_naf = new byte[nAnims];
            this._anims_af_start = new short[nAnims];
            short af_start = 0;
            for (int i = 0; i < nAnims; ++i) {
                this._anims_naf[i] = file[offset++];
                if (!GLLibConfig.sprite_alwaysBsNfm1Byte) {
                    final int tmp = file[offset++];
                }
                if (GLLibConfig.sprite_alwaysBsNoAfStart) {
                    this._anims_af_start[i] = af_start;
                    af_start += this._anims_naf[i];
                }
                else {
                    this._anims_af_start[i] = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                }
            }
        }
        return offset;
    }
    
    void Load(final byte[] file, int offset, final int pal_flags, final int tr_flags, final Image sprImage) {
        try {
            if (file == null) {
                GLLib.Assert(false, "Cant load sprite, file[] is null");
                return;
            }
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("ASprite.Load(" + file.length + " bytes, " + offset + ")..." + this);
            }
            if (!GLLibConfig.sprite_useDeactivateSystemGc) {
                System.gc();
            }
            final short bs_version = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("bs_version = 0x" + Integer.toHexString(bs_version));
            }
            if (bs_version != 1503) {
                GLLib.Assert(false, "ASprite.Load.Invalid BSprite version !  GLLib supports only (0x" + Integer.toHexString(1503) + ")    this sprite version (0x" + Integer.toHexString(bs_version) + ")");
            }
            this._bs_flags = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("bs_flags = 0x" + Integer.toHexString(this._bs_flags));
            }
            if (GLLibConfig.sprite_useNonInterlaced) {
                offset = this.LoadModules_NI(offset, file);
                offset = this.LoadFModules_NI(offset, file);
                offset = this.LoadFrames_NI(offset, file);
                offset = this.LoadAFrames_NI(offset, file);
                offset = this.LoadAnims_NI(offset, file);
            }
            else {
                offset = this.LoadModules(offset, file);
                offset = this.LoadFModules(offset, file);
                offset = this.LoadFrames(offset, file);
                offset = this.LoadAFrames(offset, file);
                offset = this.LoadAnims(offset, file);
            }
            if (this._nModules <= 0) {
                if (GLLibConfig.sprite_debugErrors) {
                    System.out.println("WARNING: sprite with num modules = " + this._nModules);
                }
                if (!GLLibConfig.sprite_useDeactivateSystemGc) {
                    System.gc();
                }
                return;
            }
            if (GLLibConfig.sprite_ModuleMapping_useModuleImages && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x1000000) != 0x0)) {
                offset = this.LoadData_useModuleImages(offset, file, pal_flags, tr_flags);
            }
            if (GLLibConfig.sprite_useSingleImageForAllModules && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x20000000) != 0x0)) {
                offset = this.LoadData_useSingleImages(offset, file, pal_flags, tr_flags);
            }
            if (GLLibConfig.sprite_useExternImage) {
                (this._main_image = new Image[GLLibConfig.MAX_SPRITE_PALETTES])[0] = sprImage;
            }
            if (GLLibConfig.sprite_useModuleMapping) {
                this._map = new short[GLLibConfig.MAX_MODULE_MAPPINGS][];
                this._cur_map = -1;
            }
            if (GLLibConfig.sprite_useDynamicPng && !GLLibConfig.sprite_usePrecomputedCRC) {
                if (GLLibConfig.sprite_useNokiaUI) {
                    this._pal_short = null;
                }
                else {
                    this._pal_int = null;
                }
            }
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("--- ok");
            }
            if (!GLLibConfig.sprite_useDeactivateSystemGc) {
                System.gc();
            }
        }
        catch (final Exception e) {
            if (GLLibConfig.sprite_debugErrors) {
                GLLib.Dbg("ASprite.Load()." + e);
            }
            GLLib.Assert(false, "Asprite.Load. error while loading sprite : " + e);
        }
    }
    
    private byte[] GetModulesUsage(final int tr_flags) {
        if (GLLibConfig.sprite_useDynamicPng && !GLLibConfig.sprite_useModuleUsageFromSprite) {
            final int nModules = this._nModules;
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                if (this._fmodules != null) {
                    final short nFModules = (short)(this._fmodules.length / 4);
                }
                else {
                    final short nFModules = 0;
                }
            }
            else if (this._fmodules_id != null) {
                final short nFModules = (short)this._fmodules_id.length;
            }
            else {
                final short nFModules = 0;
            }
            short nFrames;
            if (this._frames_nfm != null) {
                nFrames = (short)this._frames_nfm.length;
            }
            else {
                nFrames = 0;
            }
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                if (this._aframes != null) {
                    final short nAFrames = (short)(this._aframes.length / 5);
                }
                else {
                    final short nAFrames = 0;
                }
            }
            else if (this._aframes_frame != null) {
                final short nAFrames = (short)this._aframes_frame.length;
            }
            else {
                final short nAFrames = 0;
            }
            short nAnims;
            if (this._anims_naf != null) {
                nAnims = (short)this._anims_naf.length;
            }
            else {
                nAnims = 0;
            }
            final byte[] mods_usg = new byte[nModules];
            for (int fr = 0; fr < nFrames; ++fr) {
                this.GetModulesUsageInFrame(fr, 0, tr_flags, mods_usg);
            }
            for (int anim = 0; anim < nAnims; ++anim) {
                final int afr_off = this._anims_af_start[anim];
                for (int afr_idx = 0; afr_idx < this._anims_naf[anim]; ++afr_idx) {
                    final int afr = afr_idx + afr_off;
                    int fr;
                    int af_flags;
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        af_flags = (this._aframes[afr * 5 + 4] & 0xFF);
                        fr = (this._aframes[afr * 5] & 0xFF);
                    }
                    else {
                        af_flags = (this._aframes_flags[afr] & 0xFF);
                        fr = (this._aframes_frame[afr] & 0xFF);
                    }
                    if (GLLibConfig.sprite_useIndexExAframes) {
                        fr |= (af_flags & 0xC0) << 2;
                    }
                    this.GetModulesUsageInFrame(fr, af_flags, tr_flags, mods_usg);
                }
            }
            for (int mod = 0; mod < nModules; ++mod) {
                final byte[] array = mods_usg;
                final int n = mod;
                array[n] |= (byte)tr_flags;
            }
            return mods_usg;
        }
        return null;
    }
    
    private void GetModulesUsageInFrame(final int fr, final int af_flags, final int tr_flags, final byte[] mods_usg) {
        if (GLLibConfig.sprite_useDynamicPng && !GLLibConfig.sprite_useModuleUsageFromSprite) {
            final int fmod_off = this._frames_fm_start[fr] & 0xFFFF;
            for (int fmod_idx = 0; fmod_idx < this._frames_nfm[fr]; ++fmod_idx) {
                final int fmod = fmod_off + fmod_idx;
                int fm_flags;
                int mod;
                if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                    fm_flags = (this._fmodules[fmod * 4 + 3] & 0xFF);
                    mod = (this._fmodules[fmod * 4] & 0xFF);
                }
                else {
                    fm_flags = (this._fmodules_flags[fmod] & 0xFF);
                    mod = (this._fmodules_id[fmod] & 0xFF);
                }
                if (GLLibConfig.sprite_useIndexExFmodules) {
                    mod |= (fm_flags & 0xC0) << 2;
                }
                for (int k = 0; k < GLLibConfig.MAX_FLIP_COUNT; ++k) {
                    if ((tr_flags & 1 << k) != 0x0) {
                        final int tmp_flags = af_flags ^ k;
                        if (mod < mods_usg.length) {
                            final int n = mod;
                            mods_usg[n] |= (byte)(1 << ((fm_flags ^ tmp_flags) & 0x7));
                        }
                    }
                }
            }
        }
    }
    
    void SetModuleMapping(final int map, final byte[] mmp) {
        if (GLLibConfig.sprite_useModuleMapping) {
            if (this._map[map] == null) {
                this._map[map] = new short[this._nModules];
                for (int i = 0; i < this._nModules; ++i) {
                    this._map[map][i] = (short)i;
                }
            }
            if (mmp == null) {
                return;
            }
            int i2;
            int i3;
            for (int off = 0; off < mmp.length; i2 = (mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8), i3 = (mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8), this._map[map][i2] = (short)i3) {}
        }
    }
    
    void SetCurrentMMapping(final int map) {
        if (GLLibConfig.sprite_useModuleMapping) {
            this._cur_map = map;
        }
    }
    
    int GetCurrentMMapping() {
        if (GLLibConfig.sprite_useModuleMapping) {
            return this._cur_map;
        }
        return -1;
    }
    
    int GetAFrameTime(final int anim, final int aframe) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            return this._aframes[(this._anims_af_start[anim] + aframe) * 5 + 1] & 0xFF;
        }
        return this._aframes_time[this._anims_af_start[anim] + aframe] & 0xFF;
    }
    
    int GetAFrameFlags(final int anim, final int aframe) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            return this._aframes[(this._anims_af_start[anim] + aframe) * 5 + 4] & 0xF;
        }
        return this._aframes_flags[this._anims_af_start[anim] + aframe] & 0xF;
    }
    
    int GetAFrames(final int anim) {
        return this._anims_naf[anim] & 0xFF;
    }
    
    int GetFModules(final int frame) {
        return this._frames_nfm[frame] & 0xFF;
    }
    
    int GetModuleX(final int module) {
        if (GLLibConfig.sprite_useModuleXYShort) {
            return this._modules_x_short[module] & 0xFFFF;
        }
        return this._modules_x_byte[module] & 0xFF;
    }
    
    int GetModuleY(final int module) {
        if (GLLibConfig.sprite_useModuleXYShort) {
            return this._modules_y_short[module] & 0xFFFF;
        }
        return this._modules_y_byte[module] & 0xFF;
    }
    
    int GetModuleWidth(final int module) {
        if (GLLibConfig.sprite_useResize && ASprite.s_resizeType != 0) {
            return this._modules_w_scaled[module] & 0xFFFF;
        }
        if (GLLibConfig.sprite_useModuleWHShort) {
            return this._modules_w_short[module] & 0xFFFF;
        }
        return this._modules_w_byte[module] & 0xFF;
    }
    
    int GetModuleHeight(final int module) {
        if (GLLibConfig.sprite_useResize && ASprite.s_resizeType != 0) {
            return this._modules_h_scaled[module] & 0xFFFF;
        }
        if (GLLibConfig.sprite_useModuleWHShort) {
            return this._modules_h_short[module] & 0xFFFF;
        }
        return this._modules_h_byte[module] & 0xFF;
    }
    
    int GetModuleWidthOrg(final int module) {
        if (GLLibConfig.sprite_useModuleWHShort) {
            return this._modules_w_short[module] & 0xFFFF;
        }
        return this._modules_w_byte[module] & 0xFF;
    }
    
    int GetModuleHeightOrg(final int module) {
        if (GLLibConfig.sprite_useModuleWHShort) {
            return this._modules_h_short[module] & 0xFFFF;
        }
        return this._modules_h_byte[module] & 0xFF;
    }
    
    int GetAFramesOX(final int v) {
        if (GLLibConfig.sprite_useAfOffShort) {
            return this._aframes_ox_short[v];
        }
        return this._aframes_ox_byte[v];
    }
    
    int GetAFramesOY(final int v) {
        if (GLLibConfig.sprite_useAfOffShort) {
            return this._aframes_oy_short[v];
        }
        return this._aframes_oy_byte[v];
    }
    
    int GetFModuleOX(final int v) {
        if (GLLibConfig.sprite_useFMOffShort) {
            return this._fmodules_ox_short[v];
        }
        return this._fmodules_ox_byte[v];
    }
    
    int GetFModuleOY(final int v) {
        if (GLLibConfig.sprite_useFMOffShort) {
            return this._fmodules_oy_short[v];
        }
        return this._fmodules_oy_byte[v];
    }
    
    int GetFrameWidth(final int frame) {
        if (!GLLibConfig.sprite_usePrecomputedFrameRect) {
            this.GetFrameRect(ASprite.s_rc, frame, 0, 0, 0);
            return ASprite.s_rc[2] - ASprite.s_rc[0];
        }
        if ((this._bs_flags & 0x400) == 0x0) {
            return this._frames_rc[(frame << 2) + 2] & 0xFF;
        }
        return this._frames_rc_short[(frame << 2) + 2] & 0xFFFF;
    }
    
    int GetFrameHeight(final int frame) {
        if (!GLLibConfig.sprite_usePrecomputedFrameRect) {
            this.GetFrameRect(ASprite.s_rc, frame, 0, 0, 0);
            return ASprite.s_rc[3] - ASprite.s_rc[1];
        }
        if ((this._bs_flags & 0x400) == 0x0) {
            return this._frames_rc[(frame << 2) + 3] & 0xFF;
        }
        return this._frames_rc_short[(frame << 2) + 3] & 0xFFFF;
    }
    
    int GetFrameModule(final int frame, final int fmodule) {
        int fm_flags;
        int index;
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            final int off = this._frames_fm_start[frame] + fmodule << 2;
            fm_flags = (this._fmodules[off + 3] & 0xFF);
            index = (this._fmodules[off] & 0xFF);
        }
        else {
            final int off = this._frames_fm_start[frame] + fmodule;
            fm_flags = (this._fmodules_flags[off] & 0xFF);
            index = (this._fmodules_id[off] & 0xFF);
        }
        if (GLLibConfig.sprite_useIndexExFmodules) {
            index |= (fm_flags & 0xC0) << 2;
        }
        return index;
    }
    
    int GetFrameModuleFlags(final int frame, final int fmodule) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            final int off = this._frames_fm_start[frame] + fmodule << 2;
            return this._fmodules[off + 3] & 0xFF;
        }
        return this._fmodules_flags[this._frames_fm_start[frame] + fmodule] & 0xFF;
    }
    
    int GetFrameModulePalette(final int frame, final int fmodule) {
        int offset = 0;
        int pal = 0;
        if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x4000) != 0x0)) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                offset = this._frames_fm_start[frame] + fmodule << 2;
            }
            else {
                offset = this._frames_fm_start[frame] + fmodule;
            }
            pal = this._fmodules_pal[offset];
        }
        else {
            pal = this.GetCurrentPalette();
        }
        return pal;
    }
    
    int GetFrameModuleX(final int frame, final int fmodule) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            final int off = this._frames_fm_start[frame] + fmodule << 2;
            return this._fmodules[off + 1];
        }
        return this.GetFModuleOX(this._frames_fm_start[frame] + fmodule);
    }
    
    int GetFrameModuleY(final int frame, final int fmodule) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            final int off = this._frames_fm_start[frame] + fmodule << 2;
            return this._fmodules[off + 2];
        }
        return this.GetFModuleOY(this._frames_fm_start[frame] + fmodule);
    }
    
    int GetFrameModuleWidth(final int frame, final int fmodule) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            final int off = this._frames_fm_start[frame] + fmodule << 2;
            final int index = this._fmodules[off] & 0xFF;
            return this.GetModuleWidth(index);
        }
        final int index2 = this._fmodules_id[this._frames_fm_start[frame] + fmodule] & 0xFF;
        return this.GetModuleWidth(index2);
    }
    
    int GetFrameModuleHeight(final int frame, final int fmodule) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            final int off = this._frames_fm_start[frame] + fmodule << 2;
            final int index = this._fmodules[off] & 0xFF;
            return this.GetModuleHeight(index);
        }
        final int index2 = this._fmodules_id[this._frames_fm_start[frame] + fmodule] & 0xFF;
        return this.GetModuleHeight(index2);
    }
    
    int GetFrames() {
        return this._frames_nfm.length;
    }
    
    int GetAnimFrame(final int anim, final int aframe) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            final int off = (this._anims_af_start[anim] + aframe) * 5;
            int frame = this._aframes[off] & 0xFF;
            if (GLLibConfig.sprite_useIndexExAframes) {
                frame |= (this._aframes[off + 4] & 0xC0) << 2;
            }
            return frame;
        }
        final int off = this._anims_af_start[anim] + aframe;
        int frame = this._aframes_frame[off] & 0xFF;
        if (GLLibConfig.sprite_useIndexExAframes) {
            frame |= (this._aframes_flags[off] & 0xC0) << 2;
        }
        return frame;
    }
    
    void GetAFrameRect(final int[] rc, final int anim, final int aframe, final int posX, final int posY, final int flags) {
        final Graphics g = null;
        ASprite._rectX1 = Integer.MAX_VALUE;
        ASprite._rectY1 = Integer.MAX_VALUE;
        ASprite._rectX2 = Integer.MIN_VALUE;
        ASprite._rectY2 = Integer.MIN_VALUE;
        ASprite._operation = 1;
        this.PaintAFrame(g, anim, aframe, posX, posY, flags);
        rc[ASprite._operation = 0] = ASprite._rectX1;
        rc[1] = ASprite._rectY1;
        rc[2] = ASprite._rectX2;
        rc[3] = ASprite._rectY2;
    }
    
    void GetFrameRect(final int[] rc, final int frame, final int posX, final int posY, final int flags, final int hx, final int hy) {
        this.GetFrameRect(rc, frame, posX, posY, flags);
    }
    
    void GetFrameRect(final int[] rc, final int frame, final int posX, final int posY, final int flags) {
        final Graphics g = null;
        ASprite._rectX1 = Integer.MAX_VALUE;
        ASprite._rectY1 = Integer.MAX_VALUE;
        ASprite._rectX2 = Integer.MIN_VALUE;
        ASprite._rectY2 = Integer.MIN_VALUE;
        ASprite._operation = 1;
        this.PaintFrame(g, frame, posX, posY, flags);
        rc[ASprite._operation = 0] = ASprite._rectX1;
        rc[1] = ASprite._rectY1;
        rc[2] = ASprite._rectX2;
        rc[3] = ASprite._rectY2;
    }
    
    void GetFModuleRect(final int[] rc, final int frame, final int fmodule, final int posX, final int posY, final int flags, final int hx, final int hy) {
        final Graphics g = null;
        ASprite._rectX1 = Integer.MAX_VALUE;
        ASprite._rectY1 = Integer.MAX_VALUE;
        ASprite._rectX2 = Integer.MIN_VALUE;
        ASprite._rectY2 = Integer.MIN_VALUE;
        ASprite._operation = 1;
        this.PaintFModule(g, frame, fmodule, posX, posY, flags);
        rc[ASprite._operation = 0] = ASprite._rectX1;
        rc[1] = ASprite._rectY1;
        rc[2] = ASprite._rectX2;
        rc[3] = ASprite._rectY2;
    }
    
    void GetModuleRect(final int[] rc, final int module, final int posX, final int posY, final int flags) {
        final Graphics g = null;
        ASprite._rectX1 = Integer.MAX_VALUE;
        ASprite._rectY1 = Integer.MAX_VALUE;
        ASprite._rectX2 = Integer.MIN_VALUE;
        ASprite._rectY2 = Integer.MIN_VALUE;
        ASprite._operation = 1;
        this.PaintModule(g, module, posX, posY, flags);
        rc[ASprite._operation = 0] = ASprite._rectX1;
        rc[1] = ASprite._rectY1;
        rc[2] = ASprite._rectX2;
        rc[3] = ASprite._rectY2;
    }
    
    Image GetModuleImage(final int nModule, final int nPalette) {
        if (this._module_image_imageAA != null && nPalette >= 0 && nPalette < this._module_image_imageAA.length && this._module_image_imageAA[nPalette] != null && nModule >= 0 && nModule < this._module_image_imageAA[nPalette].length) {
            return this._module_image_imageAA[nPalette][nModule];
        }
        if (this._module_image_imageAAA != null && nPalette >= 0 && nPalette < this._module_image_imageAAA.length && this._module_image_imageAAA[nPalette] != null && nModule >= 0 && nModule < this._module_image_imageAAA[nPalette].length) {
            return this._module_image_imageAAA[nPalette][nModule][0];
        }
        return null;
    }
    
    Object GetModuleData(final int nModule, final int nPalette) {
        if (this._modules_image_shortAAA != null && this._modules_image_shortAAA[nPalette] != null) {
            return this._modules_image_shortAAA[nPalette][nModule];
        }
        return null;
    }
    
    Object GetPalette(final int nPalette) {
        if (nPalette >= 0 && nPalette < this._palettes) {
            if (GLLibConfig.sprite_useNokiaUI) {
                if (this._pal_short != null && nPalette < this._pal_short.length) {
                    return this._pal_short[nPalette];
                }
            }
            else if (this._pal_int != null && nPalette < this._pal_int.length) {
                return this._pal_int[nPalette];
            }
        }
        return null;
    }
    
    int GetModuleCount() {
        return this._nModules;
    }
    
    int CountFrameModules(final int frame) {
        int realcount;
        for (int count = realcount = this.GetFModules(frame), fmodule = 0; fmodule < count; ++fmodule) {
            int fm_flags;
            int index;
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                final int off = this._frames_fm_start[frame] + fmodule << 2;
                fm_flags = (this._fmodules[off + 3] & 0xFF);
                index = (this._fmodules[off] & 0xFF);
            }
            else {
                final int off = this._frames_fm_start[frame] + fmodule;
                fm_flags = (this._fmodules_flags[off] & 0xFF);
                index = (this._fmodules_id[off] & 0xFF);
            }
            if ((fm_flags & 0x10) != 0x0) {
                realcount = realcount - 1 + this.CountFrameModules(index);
            }
        }
        return realcount;
    }
    
    private int getStartModuleData(final int module, final int transf) {
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            return this._modules_data_off_short[module] & 0xFFFF;
        }
        return this._modules_data_off_int[module];
    }
    
    private int getLenModuleData(final int m, final int transf) {
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            return (m + 1 == this._modules_data_off_short.length) ? (this._modules_data.length - this._modules_data_off_short[m] & 0xFFFF) : ((this._modules_data_off_short[m] & 0xFFFF) - this._modules_data_off_short[m] & 0xFFFF);
        }
        return (m + 1 == this._modules_data_off_int.length) ? (this._modules_data.length - this._modules_data_off_int[m]) : (this._modules_data_off_int[m] - this._modules_data_off_int[m]);
    }
    
    int GetFrameCount() {
        if (this._frames_nfm == null) {
            return 0;
        }
        return this._frames_nfm.length;
    }
    
    int[] GetFrameMarkers(final int frame) {
        if (GLLibConfig.sprite_useMultipleModuleTypes) {
            final int count = this.GetFModules(frame);
            int countMarker = 0;
            for (int fmodule = 0; fmodule < count; ++fmodule) {
                int fm_flags;
                int index;
                if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                    final int off = this._frames_fm_start[frame] + fmodule << 2;
                    fm_flags = (this._fmodules[off + 3] & 0xFF);
                    index = (this._fmodules[off] & 0xFF);
                }
                else {
                    final int off = this._frames_fm_start[frame] + fmodule;
                    fm_flags = (this._fmodules_flags[off] & 0xFF);
                    index = (this._fmodules_id[off] & 0xFF);
                }
                if ((fm_flags & 0x10) == 0x0 && this._module_types[index] == 5) {
                    ++countMarker;
                }
            }
            if (countMarker > 0) {
                final int[] res = new int[countMarker << 1];
                int pos = 0;
                for (int fmodule2 = 0; fmodule2 < count; ++fmodule2) {
                    int fm_flags;
                    int index;
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        final int off = this._frames_fm_start[frame] + fmodule2 << 2;
                        fm_flags = (this._fmodules[off + 3] & 0xFF);
                        index = (this._fmodules[off] & 0xFF);
                    }
                    else {
                        final int off = this._frames_fm_start[frame] + fmodule2;
                        fm_flags = (this._fmodules_flags[off] & 0xFF);
                        index = (this._fmodules_id[off] & 0xFF);
                    }
                    if ((fm_flags & 0x10) == 0x0 && this._module_types[index] == 5) {
                        res[pos] = this.GetFrameModuleX(frame, fmodule2);
                        res[pos + 1] = this.GetFrameModuleY(frame, fmodule2);
                        pos += 2;
                    }
                }
                return res;
            }
        }
        return null;
    }
    
    int GetFrameRectCount(final int frame) {
        if (GLLibConfig.sprite_useFrameRects && this._frames_rects_start != null) {
            return this._frames_rects_start[frame + 1] - this._frames_rects_start[frame];
        }
        return 0;
    }
    
    void GetFrameRect(final int frame, final int rectIndex, final int[] rect, final int flags) {
        if (GLLibConfig.sprite_useFrameRects && this._frames_rects_start != null && rect != null) {
            int nStart = this._frames_rects_start[frame];
            final int nEnd = this._frames_rects_start[frame + 1];
            final int nCount = nEnd - nStart;
            if (nCount > 0 && rectIndex < nCount) {
                nStart = nStart + rectIndex << 2;
                if (GLLibConfig.sprite_useFMOffShort) {
                    if (this._frames_rects_short != null) {
                        rect[0] = this._frames_rects_short[nStart + 0];
                        rect[1] = this._frames_rects_short[nStart + 1];
                        rect[2] = (this._frames_rects_short[nStart + 2] & 0xFFFF);
                        rect[3] = (this._frames_rects_short[nStart + 3] & 0xFFFF);
                    }
                }
                else if (this._frames_rects != null) {
                    rect[0] = this._frames_rects[nStart + 0];
                    rect[1] = this._frames_rects[nStart + 1];
                    rect[2] = (this._frames_rects[nStart + 2] & 0xFF);
                    rect[3] = (this._frames_rects[nStart + 3] & 0xFF);
                }
                if ((flags & 0x1) != 0x0) {
                    rect[0] = -rect[0] - rect[2];
                }
                if ((flags & 0x2) != 0x0) {
                    rect[1] = -rect[1] - rect[3];
                }
            }
            else {
                rect[1] = (rect[0] = 0);
                rect[3] = (rect[2] = 0);
            }
        }
    }
    
    void GetAFrameRect(final int anim, final int aframe, final int rectIndex, final int[] rect, final int flags) {
        if (GLLibConfig.sprite_useFrameRects) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                final int off = (this._anims_af_start[anim] + aframe) * 5;
                int frame = this._aframes[off] & 0xFF;
                if (GLLibConfig.sprite_useIndexExAframes) {
                    frame |= (this._aframes[off + 4] & 0xC0) << 2;
                }
                this.GetFrameRect(frame, rectIndex, rect, flags ^ (this._aframes[off + 4] & 0xF));
            }
            else {
                final int off = this._anims_af_start[anim] + aframe;
                int frame = this._aframes_frame[off] & 0xFF;
                if (GLLibConfig.sprite_useIndexExAframes) {
                    frame |= (this._aframes_flags[off] & 0xC0) << 2;
                }
                this.GetFrameRect(frame, rectIndex, rect, flags ^ (this._aframes_flags[off] & 0xF));
            }
        }
    }
    
    static void SetGraphics(final Graphics g1) {
    }
    
    void PaintAFrame(final Graphics g, final int anim, final int aframe, final int posX, final int posY, final int flags) {
        this.PaintAFrame(g, anim, aframe, posX, posY, flags, 0, 0);
    }
    
    void PaintAFrame(final Graphics g, final int anim, final int aframe, final int posX, final int posY, final int flags, int hx, int hy) {
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            final int off = (this._anims_af_start[anim] + aframe) * 5;
            int frame = this._aframes[off] & 0xFF;
            if (GLLibConfig.sprite_useIndexExAframes) {
                frame |= (this._aframes[off + 4] & 0xC0) << 2;
            }
            if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                if ((flags & 0x1) != 0x0) {
                    hx += this._aframes[off + 2];
                }
                else {
                    hx -= this._aframes[off + 2];
                }
                if ((flags & 0x2) != 0x0) {
                    hy += this._aframes[off + 3];
                }
                else {
                    hy -= this._aframes[off + 3];
                }
            }
            else {
                hx -= this._aframes[off + 2];
                hy -= this._aframes[off + 3];
            }
            this.PaintFrame(g, frame, posX - hx, posY - hy, flags ^ (this._aframes[off + 4] & 0xF), hx, hy);
        }
        else {
            final int off = this._anims_af_start[anim] + aframe;
            int frame = this._aframes_frame[off] & 0xFF;
            if (GLLibConfig.sprite_useIndexExAframes) {
                frame |= (this._aframes_flags[off] & 0xC0) << 2;
            }
            if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                if ((flags & 0x1) != 0x0) {
                    hx += this.GetAFramesOX(off);
                }
                else {
                    hx -= this.GetAFramesOX(off);
                }
                if ((flags & 0x2) != 0x0) {
                    hy += this.GetAFramesOY(off);
                }
                else {
                    hy -= this.GetAFramesOY(off);
                }
            }
            else {
                hx -= this.GetAFramesOX(off);
                hy -= this.GetAFramesOY(off);
            }
            this.PaintFrame(g, frame, posX - hx, posY - hy, flags ^ (this._aframes_flags[off] & 0xF), hx, hy);
        }
    }
    
    void PaintFrame(final Graphics g, final int frame, final int posX, final int posY, final int flags) {
        this.PaintFrame(g, frame, posX, posY, flags, 0, 0);
    }
    
    void PaintFrame(final Graphics g, final int frame, final int posX, final int posY, final int flags, final int hx, final int hy) {
        for (int nFModules = this._frames_nfm[frame] & 0xFF, fmodule = 0; fmodule < nFModules; ++fmodule) {
            this.PaintFModule(g, frame, fmodule, posX, posY, flags, hx, hy);
        }
    }
    
    void PaintFModule(final Graphics g, final int frame, final int fmodule, final int posX, final int posY, final int flags) {
        this.PaintFModule(g, frame, fmodule, posX, posY, flags, 0, 0);
    }
    
    void PaintFModule(final Graphics g, final int frame, final int fmodule, int posX, int posY, final int flags, final int hx, final int hy) {
        int off;
        int fm_flags;
        int index;
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            off = this._frames_fm_start[frame] + fmodule << 2;
            fm_flags = (this._fmodules[off + 3] & 0xFF);
            index = (this._fmodules[off] & 0xFF);
        }
        else {
            off = this._frames_fm_start[frame] + fmodule;
            fm_flags = (this._fmodules_flags[off] & 0xFF);
            index = (this._fmodules_id[off] & 0xFF);
        }
        if (GLLibConfig.sprite_useIndexExFmodules) {
            index |= (fm_flags & 0xC0) << 2;
        }
        if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x4000) != 0x0)) {
            this._crt_pal = (this._fmodules_pal[off] & 0xFF);
        }
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfRot && (flags & 0x4) != 0x0) {
                if (GLLibConfig.sprite_useHyperFM && (fm_flags & 0x10) != 0x0) {
                    if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                        if ((flags & 0x1) != 0x0) {
                            posY -= this._fmodules[off + 1];
                        }
                        else {
                            posY += this._fmodules[off + 1];
                        }
                        if ((flags & 0x2) != 0x0) {
                            posX -= this._fmodules[off + 2];
                        }
                        else {
                            posX += this._fmodules[off + 2];
                        }
                    }
                    else {
                        posY += this._fmodules[off + 1];
                        posX += this._fmodules[off + 2];
                    }
                }
                else if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                    if ((flags & 0x1) != 0x0) {
                        posY -= this._fmodules[off + 1] + this.GetModuleWidth(index);
                    }
                    else {
                        posY += this._fmodules[off + 1];
                    }
                    if ((flags & 0x2) != 0x0) {
                        posX -= this._fmodules[off + 2] + this.GetModuleHeight(index);
                    }
                    else {
                        posX += this._fmodules[off + 2];
                    }
                }
                else {
                    posY += this._fmodules[off + 1];
                    posX += this._fmodules[off + 2];
                }
            }
            else if (GLLibConfig.sprite_useHyperFM && (fm_flags & 0x10) != 0x0) {
                if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                    if ((flags & 0x1) != 0x0) {
                        posX -= this._fmodules[off + 1];
                    }
                    else {
                        posX += this._fmodules[off + 1];
                    }
                    if ((flags & 0x2) != 0x0) {
                        posY -= this._fmodules[off + 2];
                    }
                    else {
                        posY += this._fmodules[off + 2];
                    }
                }
                else {
                    posX += this._fmodules[off + 1];
                    posY += this._fmodules[off + 2];
                }
            }
            else if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                if ((flags & 0x1) != 0x0) {
                    posX -= this._fmodules[off + 1] + this.GetModuleWidth(index);
                }
                else {
                    posX += this._fmodules[off + 1];
                }
                if ((flags & 0x2) != 0x0) {
                    posY -= this._fmodules[off + 2] + this.GetModuleHeight(index);
                }
                else {
                    posY += this._fmodules[off + 2];
                }
            }
            else {
                posX += this._fmodules[off + 1];
                posY += this._fmodules[off + 2];
            }
        }
        else if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfRot && (flags & 0x4) != 0x0) {
            if (GLLibConfig.sprite_useHyperFM && (fm_flags & 0x10) != 0x0) {
                if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                    if ((flags & 0x1) != 0x0) {
                        posY -= this.GetFModuleOX(off);
                    }
                    else {
                        posY += this.GetFModuleOX(off);
                    }
                    if ((flags & 0x2) != 0x0) {
                        posX -= this.GetFModuleOY(off);
                    }
                    else {
                        posX += this.GetFModuleOY(off);
                    }
                }
                else {
                    posY += this.GetFModuleOX(off);
                    posX += this.GetFModuleOY(off);
                }
            }
            else if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                if ((flags & 0x1) != 0x0) {
                    posY -= this.GetFModuleOX(off) + this.GetModuleWidth(index);
                }
                else {
                    posY += this.GetFModuleOX(off);
                }
                if ((flags & 0x2) != 0x0) {
                    posX -= this.GetFModuleOY(off) + this.GetModuleHeight(index);
                }
                else {
                    posX += this.GetFModuleOY(off);
                }
            }
            else {
                posY += this.GetFModuleOX(off);
                posX += this.GetFModuleOY(off);
            }
        }
        else if (GLLibConfig.sprite_useHyperFM && (fm_flags & 0x10) != 0x0) {
            if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
                if ((flags & 0x1) != 0x0) {
                    posX -= this.GetFModuleOX(off);
                }
                else {
                    posX += this.GetFModuleOX(off);
                }
                if ((flags & 0x2) != 0x0) {
                    posY -= this.GetFModuleOY(off);
                }
                else {
                    posY += this.GetFModuleOY(off);
                }
            }
            else {
                posX += this.GetFModuleOX(off);
                posY += this.GetFModuleOY(off);
            }
        }
        else if (!GLLibConfig.sprite_useLoadImageWithoutTransf && GLLibConfig.sprite_useTransfFlip) {
            if ((flags & 0x1) != 0x0) {
                posX -= this.GetFModuleOX(off) + this.GetModuleWidth(index);
            }
            else {
                posX += this.GetFModuleOX(off);
            }
            if ((flags & 0x2) != 0x0) {
                posY -= this.GetFModuleOY(off) + this.GetModuleHeight(index);
            }
            else {
                posY += this.GetFModuleOY(off);
            }
        }
        else {
            posX += this.GetFModuleOX(off);
            posY += this.GetFModuleOY(off);
        }
        if (GLLibConfig.sprite_useHyperFM && (fm_flags & 0x10) != 0x0) {
            this.PaintFrame(g, index, posX, posY, flags ^ (fm_flags & 0xF), hx, hy);
        }
        else {
            this.PaintModule(g, index, posX, posY, flags ^ (fm_flags & 0xF));
        }
    }
    
    private int LoadModules_NI(int offset, final byte[] file) {
        this._nModules = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println("nModules = " + this._nModules);
        }
        if (this._nModules > 0) {
            if ((GLLibConfig.sprite_useModuleXY || GLLibConfig.sprite_useModuleXYShort) && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x22) != 0x0)) {
                if (GLLibConfig.sprite_useModuleXYShort) {
                    this._modules_x_short = new short[this._nModules];
                    this._modules_y_short = new short[this._nModules];
                }
                else {
                    this._modules_x_byte = new byte[this._nModules];
                    this._modules_y_byte = new byte[this._nModules];
                }
            }
            if (GLLibConfig.sprite_useModuleWHShort) {
                this._modules_w_short = new short[this._nModules];
                this._modules_h_short = new short[this._nModules];
            }
            else {
                this._modules_w_byte = new byte[this._nModules];
                this._modules_h_byte = new byte[this._nModules];
            }
            if (GLLibConfig.sprite_useMultipleModuleTypes) {
                this._module_types = new byte[this._nModules];
                if (GLLibConfig.sprite_useModuleColorAsByte) {
                    this._module_colors_byte = new byte[this._nModules];
                }
                else {
                    this._module_colors_int = new int[this._nModules];
                }
            }
            if (GLLibConfig.sprite_useMultipleModuleTypes && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x4) != 0x0)) {
                System.arraycopy(file, offset, this._module_types, 0, this._nModules);
                offset += this._nModules;
            }
            if (GLLibConfig.sprite_useModuleXY) {
                if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x2) != 0x0) {
                    System.arraycopy(file, offset, this._modules_x_byte, 0, this._nModules);
                    offset += this._nModules;
                    System.arraycopy(file, offset, this._modules_y_byte, 0, this._nModules);
                    offset += this._nModules;
                }
            }
            else if (GLLibConfig.sprite_useModuleXYShort && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x20) != 0x0)) {
                offset = this.readArray2Short(file, offset, this._modules_x_short, 0, this._nModules, false, false);
                offset = this.readArray2Short(file, offset, this._modules_y_short, 0, this._nModules, false, false);
            }
            if (GLLibConfig.sprite_useModuleWHShort) {
                if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 0x10) == 0x0) {
                    offset = this.readArray2Short(file, offset, this._modules_w_short, 0, this._nModules, true, true);
                    offset = this.readArray2Short(file, offset, this._modules_h_short, 0, this._nModules, true, true);
                }
                else {
                    offset = this.readArray2Short(file, offset, this._modules_w_short, 0, this._nModules, false, false);
                    offset = this.readArray2Short(file, offset, this._modules_h_short, 0, this._nModules, false, false);
                }
            }
            else {
                System.arraycopy(file, offset, this._modules_w_byte, 0, this._nModules);
                offset += this._nModules;
                System.arraycopy(file, offset, this._modules_h_byte, 0, this._nModules);
                offset += this._nModules;
            }
        }
        if (GLLibConfig.sprite_useModuleUsageFromSprite) {
            this._modules_usage = new byte[this._nModules];
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("Module usage... offset = " + offset + " _nModules = " + this._nModules);
            }
            if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x40000000) != 0x0) {
                System.arraycopy(file, offset, this._modules_usage, 0, this._nModules);
                offset += this._nModules;
            }
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("...Module usage");
            }
        }
        return offset;
    }
    
    private int LoadFModules_NI(int offset, final byte[] file) {
        final int nFModules = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println("nFModules = " + nFModules);
        }
        if (nFModules > 0) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                this._fmodules = new byte[nFModules << 2];
                offset = this.readByteArrayNi(file, offset, this._fmodules, nFModules, 0, 4);
                offset = this.readByteArrayNi(file, offset, this._fmodules, nFModules, 1, 4);
                offset = this.readByteArrayNi(file, offset, this._fmodules, nFModules, 2, 4);
                offset = this.readByteArrayNi(file, offset, this._fmodules, nFModules, 3, 4);
            }
            else {
                this._fmodules_id = new byte[nFModules];
                if (GLLibConfig.sprite_useFMOffShort) {
                    this._fmodules_ox_short = new short[nFModules];
                    this._fmodules_oy_short = new short[nFModules];
                }
                else {
                    this._fmodules_ox_byte = new byte[nFModules];
                    this._fmodules_oy_byte = new byte[nFModules];
                }
                this._fmodules_flags = new byte[nFModules];
                System.arraycopy(file, offset, this._fmodules_id, 0, nFModules);
                offset += nFModules;
                if (GLLibConfig.sprite_useFMOffShort) {
                    if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 0x400) == 0x0) {
                        offset = this.readArray2Short(file, offset, this._fmodules_ox_short, 0, nFModules, true, false);
                        offset = this.readArray2Short(file, offset, this._fmodules_oy_short, 0, nFModules, true, false);
                    }
                    else {
                        offset = this.readArray2Short(file, offset, this._fmodules_ox_short, 0, nFModules, false, false);
                        offset = this.readArray2Short(file, offset, this._fmodules_oy_short, 0, nFModules, false, false);
                    }
                }
                else {
                    System.arraycopy(file, offset, this._fmodules_ox_byte, 0, nFModules);
                    offset += nFModules;
                    System.arraycopy(file, offset, this._fmodules_oy_byte, 0, nFModules);
                    offset += nFModules;
                }
                if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x4000) != 0x0)) {
                    System.arraycopy(file, offset, this._fmodules_pal = new byte[nFModules], 0, nFModules);
                    offset += nFModules;
                }
                System.arraycopy(file, offset, this._fmodules_flags, 0, nFModules);
                offset += nFModules;
            }
        }
        return offset;
    }
    
    private int LoadFrames_NI(int offset, final byte[] file) {
        if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & 0x8000) != 0x0) {
            final int nRects = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
            if ((this._bs_flags & 0x400) == 0x0) {
                System.arraycopy(file, offset, this._frames_rects = new byte[nRects << 2], 0, nRects << 2);
                offset += nRects << 2;
            }
            else {
                this._frames_rects_short = new short[nRects << 2];
                offset = this.readArray2Short(file, offset, this._frames_rects_short, 0, nRects << 2, false, false);
            }
        }
        final int nFrames = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println("nFrames = " + nFrames);
        }
        if (nFrames > 0) {
            this._frames_nfm = new byte[nFrames];
            this._frames_fm_start = new short[nFrames];
            short frame_start = 0;
            if (!GLLibConfig.sprite_alwaysBsNfm1Byte) {
                System.arraycopy(file, offset, this._frames_nfm, 0, nFrames);
                offset += nFrames;
            }
            else {
                System.arraycopy(file, offset, this._frames_nfm, 0, nFrames);
                offset += nFrames;
            }
            if (GLLibConfig.sprite_alwaysBsNoFmStart) {
                for (int i = 0; i < nFrames; ++i) {
                    this._frames_fm_start[i] = frame_start;
                    frame_start += (short)(this._frames_nfm[i] & 0xFF);
                }
            }
            else {
                offset = this.readArray2Short(file, offset, this._frames_fm_start, 0, nFrames, false, false);
            }
            if (GLLibConfig.sprite_useFrameRects && (this._bs_flags & 0x8000) != 0x0) {
                this._frames_rects_start = new short[nFrames + 1];
                short frames_rects_offset = 0;
                for (int j = 0; j < nFrames; ++j) {
                    this._frames_rects_start[j] = frames_rects_offset;
                    frames_rects_offset += file[offset++];
                }
                this._frames_rects_start[this._frames_rects_start.length - 1] = frames_rects_offset;
            }
            if (!GLLibConfig.sprite_alwaysBsSkipFrameRc) {
                if (GLLibConfig.sprite_usePrecomputedFrameRect) {
                    final int nFrames2 = nFrames << 2;
                    if ((this._bs_flags & 0x400) == 0x0) {
                        this._frames_rc = new byte[nFrames2];
                        offset = this.readByteArrayNi(file, offset, this._frames_rc, nFrames, 0, 4);
                        offset = this.readByteArrayNi(file, offset, this._frames_rc, nFrames, 1, 4);
                        offset = this.readByteArrayNi(file, offset, this._frames_rc, nFrames, 2, 4);
                        offset = this.readByteArrayNi(file, offset, this._frames_rc, nFrames, 3, 4);
                    }
                }
                else if ((this._bs_flags & 0x400) == 0x0) {
                    offset += nFrames << 2;
                }
                else {
                    offset += nFrames << 3;
                }
            }
            else if (GLLibConfig.sprite_usePrecomputedFrameRect) {}
            if (GLLibConfig.sprite_useFrameCollRC && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x2000) != 0x0)) {
                final int nFrames2 = nFrames << 2;
                if ((this._bs_flags & 0x400) == 0x0) {
                    this._frames_col = new byte[nFrames2];
                    offset = this.readByteArrayNi(file, offset, this._frames_col, nFrames, 0, 4);
                    offset = this.readByteArrayNi(file, offset, this._frames_col, nFrames, 1, 4);
                    offset = this.readByteArrayNi(file, offset, this._frames_col, nFrames, 2, 4);
                    offset = this.readByteArrayNi(file, offset, this._frames_col, nFrames, 3, 4);
                }
            }
        }
        return offset;
    }
    
    private int LoadAFrames_NI(int offset, final byte[] file) {
        final int nAFrames = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println("nAFrames = " + nAFrames);
        }
        if (nAFrames > 0) {
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                this._aframes = new byte[nAFrames * 5];
                offset = this.readByteArrayNi(file, offset, this._aframes, nAFrames, 0, 5);
                offset = this.readByteArrayNi(file, offset, this._aframes, nAFrames, 1, 5);
                offset = this.readByteArrayNi(file, offset, this._aframes, nAFrames, 2, 5);
                offset = this.readByteArrayNi(file, offset, this._aframes, nAFrames, 3, 5);
                offset = this.readByteArrayNi(file, offset, this._aframes, nAFrames, 4, 5);
            }
            else {
                this._aframes_frame = new byte[nAFrames];
                this._aframes_time = new byte[nAFrames];
                if (GLLibConfig.sprite_useAfOffShort) {
                    this._aframes_ox_short = new short[nAFrames];
                    this._aframes_oy_short = new short[nAFrames];
                }
                else {
                    this._aframes_ox_byte = new byte[nAFrames];
                    this._aframes_oy_byte = new byte[nAFrames];
                }
                this._aframes_flags = new byte[nAFrames];
                System.arraycopy(file, offset, this._aframes_frame, 0, nAFrames);
                offset += nAFrames;
                System.arraycopy(file, offset, this._aframes_time, 0, nAFrames);
                offset += nAFrames;
                if (GLLibConfig.sprite_useAfOffShort) {
                    if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 0x40000) == 0x0) {
                        offset = this.readArray2Short(file, offset, this._aframes_ox_short, 0, nAFrames, true, false);
                        offset = this.readArray2Short(file, offset, this._aframes_ox_short, 0, nAFrames, true, false);
                    }
                    else {
                        offset = this.readArray2Short(file, offset, this._aframes_ox_short, 0, nAFrames, false, false);
                        offset = this.readArray2Short(file, offset, this._aframes_ox_short, 0, nAFrames, false, false);
                    }
                }
                else {
                    System.arraycopy(file, offset, this._aframes_ox_byte, 0, nAFrames);
                    offset += nAFrames;
                    System.arraycopy(file, offset, this._aframes_oy_byte, 0, nAFrames);
                    offset += nAFrames;
                }
                System.arraycopy(file, offset, this._aframes_flags, 0, nAFrames);
                offset += nAFrames;
            }
        }
        return offset;
    }
    
    private int LoadAnims_NI(int offset, final byte[] file) {
        final int nAnims = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
        if (GLLibConfig.sprite_debugLoading) {
            System.out.println("nAnims = " + nAnims);
        }
        if (nAnims > 0) {
            this._anims_naf = new byte[nAnims];
            this._anims_af_start = new short[nAnims];
            short af_start = 0;
            if (!GLLibConfig.sprite_alwaysBsNfm1Byte) {
                System.arraycopy(file, offset, this._anims_naf, 0, nAnims);
                offset += nAnims;
            }
            else {
                System.arraycopy(file, offset, this._anims_naf, 0, nAnims);
                offset += nAnims;
            }
            if (GLLibConfig.sprite_alwaysBsNoAfStart) {
                for (int i = 0; i < nAnims; ++i) {
                    this._anims_af_start[i] = af_start;
                    af_start += this._anims_naf[i];
                }
            }
            else {
                offset = this.readArray2Short(file, offset, this._anims_af_start, 0, nAnims, false, false);
            }
        }
        return offset;
    }
    
    private int LoadData_useModuleImages(int offset, final byte[] file, final int pal_flags, final int tr_flags) {
        if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x1000000) != 0x0) {
            if (offset >= file.length) {
                return offset;
            }
            final short _pixel_format = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("_pixel_format = 0x" + Integer.toHexString(_pixel_format));
            }
            this._palettes = (file[offset++] & 0xFF);
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("_palettes = " + this._palettes);
            }
            this._colors = (file[offset++] & 0xFF);
            if ((GLLibConfig.sprite_useEncodeFormatI256 || GLLibConfig.sprite_useEncodeFormatI256RLE) && this._colors == 0) {
                this._colors = 256;
            }
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("colors = " + this._colors);
            }
            if (GLLibConfig.sprite_useNokiaUI) {
                if (this._pal_short == null) {
                    this._pal_short = new short[GLLibConfig.MAX_SPRITE_PALETTES][];
                }
            }
            else if (this._pal_int == null) {
                this._pal_int = new int[GLLibConfig.MAX_SPRITE_PALETTES][];
            }
            for (int p = 0; p < this._palettes; ++p) {
                if (GLLibConfig.sprite_useDynamicPng && (pal_flags & 1 << p) == 0x0) {
                    offset += ((_pixel_format == -30584) ? (this._colors * 4) : (this._colors * 2));
                }
                else {
                    if (GLLibConfig.sprite_useNokiaUI) {
                        this._pal_short[p] = new short[this._colors];
                    }
                    else {
                        this._pal_int[p] = new int[this._colors];
                    }
                    if (GLLibConfig.sprite_usePixelFormat8888 && _pixel_format == -30584) {
                        for (int c = 0; c < this._colors; ++c) {
                            if (GLLibConfig.sprite_useNokiaUI) {
                                int _4444 = (file[offset++] & 0xF0) >> 4;
                                _4444 += (file[offset++] & 0xF0);
                                _4444 += (file[offset++] & 0xF0) << 4;
                                _4444 += (file[offset++] & 0xF0) << 8;
                                if ((_4444 & 0xF000) != 0xF000) {
                                    this._alpha = true;
                                }
                                this._pal_short[p][c] = (short)(_4444 & 0xFFFF);
                            }
                            else {
                                final int _4445 = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
                                if ((_4445 & 0xFF000000) != 0xFF000000) {
                                    this._alpha = true;
                                }
                                this._pal_int[p][c] = _4445;
                            }
                        }
                    }
                    else if (GLLibConfig.sprite_usePixelFormat4444 && _pixel_format == 17476) {
                        for (int c = 0; c < this._colors; ++c) {
                            final int _4444 = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                            if ((_4444 & 0xF000) != 0xF000) {
                                this._alpha = true;
                            }
                            if (GLLibConfig.sprite_useNokiaUI) {
                                this._pal_short[p][c] = (short)(_4444 & 0xFFFF);
                            }
                            else {
                                this._pal_int[p][c] = ((_4444 & 0xF000) << 16 | (_4444 & 0xF000) << 12 | (_4444 & 0xF00) << 12 | (_4444 & 0xF00) << 8 | (_4444 & 0xF0) << 8 | (_4444 & 0xF0) << 4 | (_4444 & 0xF) << 4 | (_4444 & 0xF));
                            }
                        }
                    }
                    else if (GLLibConfig.sprite_usePixelFormat1555 && _pixel_format == 21781) {
                        for (int c = 0; c < this._colors; ++c) {
                            final int _4446 = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                            int a = -16777216;
                            if ((_4446 & 0x8000) != 0x8000) {
                                a = 0;
                                this._alpha = true;
                            }
                            if (GLLibConfig.sprite_useNokiaUI) {
                                final int tmp_col = a | (_4446 & 0x7C00) << 9 | (_4446 & 0x3E0) << 6 | (_4446 & 0x1F) << 3;
                                this._pal_short[p][c] = (short)((tmp_col >> 24 & 0xF0) << 8 | (tmp_col >> 16 & 0xF0) << 4 | (tmp_col >> 8 & 0xF0) | (tmp_col & 0xF0) >> 4);
                            }
                            else {
                                this._pal_int[p][c] = (a | (_4446 & 0x7C00) << 9 | (_4446 & 0x3E0) << 6 | (_4446 & 0x1F) << 3);
                            }
                        }
                    }
                    else if (GLLibConfig.sprite_usePixelFormat0565 && _pixel_format == 25861) {
                        for (int c = 0; c < this._colors; ++c) {
                            final int _4447 = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                            int a = -16777216;
                            if (_4447 == 63519) {
                                a = 0;
                                this._alpha = true;
                            }
                            if (GLLibConfig.sprite_useNokiaUI) {
                                final int tmp_col = a | (_4447 & 0xF800) << 8 | (_4447 & 0x7E0) << 5 | (_4447 & 0x1F) << 3;
                                this._pal_short[p][c] = (short)((tmp_col >> 24 & 0xF0) << 8 | (tmp_col >> 16 & 0xF0) << 4 | (tmp_col >> 8 & 0xF0) | (tmp_col & 0xF0) >> 4);
                            }
                            else {
                                this._pal_int[p][c] = (a | (_4447 & 0xF800) << 8 | (_4447 & 0x7E0) << 5 | (_4447 & 0x1F) << 3);
                            }
                        }
                    }
                }
            }
            this._data_format = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("_data_format = 0x" + Integer.toHexString(this._data_format));
            }
            if (GLLibConfig.sprite_useEncodeFormatI64RLE && this._data_format == 25840) {
                int clrs = this._colors - 1;
                this._i64rle_color_mask = 1;
                this._i64rle_color_bits = 0;
                while (clrs != 0) {
                    clrs >>= 1;
                    this._i64rle_color_mask <<= 1;
                    ++this._i64rle_color_bits;
                }
                --this._i64rle_color_mask;
            }
            if (this._nModules > 0) {
                if (GLLibConfig.sprite_useDynamicPng) {
                    if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                        if (!GLLibConfig.sprite_useOperationMark && GLLibConfig.sprite_debugLoading) {
                            System.out.println("GLLibConfig.sprite_useOperationMark = true must be defined!");
                        }
                        this.MarkTransformedModules(true, tr_flags);
                        if (this._module_image_imageAAA == null) {
                            this._module_image_imageAAA = new Image[this._palettes][][];
                        }
                    }
                    else if (this._module_image_imageAA == null) {
                        this._module_image_imageAA = new Image[this._palettes][];
                    }
                    for (int p = 0; p < this._palettes; ++p) {
                        if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                            if ((pal_flags & 1 << p) != 0x0 && this._module_image_imageAAA[p] == null) {
                                this._module_image_imageAAA[p] = new Image[this._nModules][];
                                for (int q = 0; q < this._nModules; ++q) {
                                    int flip_max = 1;
                                    for (int r = 0; r < GLLibConfig.MAX_FLIP_COUNT; ++r) {
                                        if (GLLibConfig.sprite_useModuleUsageFromSprite && (this._modules_usage[q] & 1 << r) != 0x0) {
                                            flip_max = r + 1;
                                        }
                                    }
                                    this._module_image_imageAAA[p][q] = new Image[flip_max];
                                }
                            }
                        }
                        else if ((pal_flags & 1 << p) != 0x0 && this._module_image_imageAA[p] == null) {
                            this._module_image_imageAA[p] = new Image[this._nModules];
                        }
                    }
                    if (GLLibConfig.sprite_usePrecomputedCRC) {
                        if (GLLibConfig.sprite_debugLoading) {
                            System.out.println("LoadData with sprite_usePrecomputedCRC");
                        }
                        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                            this._modules_data_off_short = new short[this._nModules];
                        }
                        else {
                            this._modules_data_off_int = new int[this._nModules];
                        }
                        int len = 0;
                        final int offset_old = offset;
                        for (int m = 0; m < this._nModules; ++m) {
                            int size;
                            if ((this._bs_flags & 0x80) != 0x0) {
                                size = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
                            }
                            else {
                                size = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                            }
                            if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                                this._modules_data_off_short[m] = (short)len;
                            }
                            else {
                                this._modules_data_off_int[m] = len;
                            }
                            len += size;
                            offset += size;
                        }
                        offset = offset_old;
                        this._modules_data = new byte[len];
                        for (int m = 0; m < this._nModules; ++m) {
                            int size;
                            if ((this._bs_flags & 0x80) != 0x0) {
                                size = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
                            }
                            else {
                                size = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                            }
                            if (GLLibConfig.sprite_debugLoading) {
                                System.out.println("frame[" + m + "] size = " + size);
                            }
                            System.arraycopy(file, offset, this._modules_data, this.getStartModuleData(m, 0), size);
                            offset += size;
                        }
                        if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x2000000) != 0x0) {
                            this._PNG_packed_PLTE_CRC = new int[this._palettes];
                            this._PNG_packed_tRNS_CRC = new int[this._palettes];
                            this._PNG_packed_IHDR_CRC = new int[this._nModules];
                            this._PNG_packed_IDAT_ADLER = new int[this._nModules];
                            this._PNG_packed_IDAT_CRC = new int[this._nModules];
                            for (int p2 = 0; p2 < this._palettes; ++p2) {
                                this._PNG_packed_PLTE_CRC[p2] = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
                            }
                            for (int p2 = 0; p2 < this._palettes; ++p2) {
                                this._PNG_packed_tRNS_CRC[p2] = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
                            }
                            for (int m = 0; m < this._nModules; ++m) {
                                this._PNG_packed_IHDR_CRC[m] = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
                            }
                            for (int m = 0; m < this._nModules; ++m) {
                                this._PNG_packed_IDAT_ADLER[m] = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
                            }
                            for (int m = 0; m < this._nModules; ++m) {
                                this._PNG_packed_IDAT_CRC[m] = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
                            }
                        }
                    }
                    else {
                        if (GLLibConfig.sprite_debugLoading) {
                            System.out.println("LoadData WITHOUT sprite_usePrecomputedCRC");
                        }
                        boolean bSkipPalette = false;
                        final int offset_modules_data = offset;
                        for (int p2 = 0; p2 < this._palettes; ++p2) {
                            if ((pal_flags & 1 << p2) != 0x0) {
                                bSkipPalette = false;
                                offset = offset_modules_data;
                                for (int mod = 0; mod < this._nModules; ++mod) {
                                    final int mod_dim = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                                    final int offset_old2 = offset;
                                    int sizeX = this.GetModuleWidth(mod);
                                    int sizeY = this.GetModuleHeight(mod);
                                    byte[] image_data = null;
                                    if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                                        for (int k = 0; k < GLLibConfig.MAX_FLIP_COUNT && k < this._module_image_imageAAA[p2][mod].length; ++k) {
                                            if ((!GLLibConfig.sprite_useModuleUsageFromSprite || (1 << k & this._modules_usage[mod]) != 0x0) && this._module_image_imageAAA[p2][mod][k] == null) {
                                                if (image_data == null) {
                                                    image_data = this.DecodeImage_byte(file, offset, sizeX, sizeY);
                                                }
                                                if (GLLibConfig.sprite_useBugFixImageOddSize) {
                                                    sizeX += sizeX % 2;
                                                    sizeY += sizeY % 2;
                                                }
                                                this._module_image_imageAAA[p2][mod][k] = this.BuildPNG8(p2, bSkipPalette, image_data, sizeX, sizeY, k);
                                                bSkipPalette = true;
                                            }
                                        }
                                    }
                                    else if (this._module_image_imageAA[p2][mod] == null) {
                                        if (image_data == null) {
                                            image_data = this.DecodeImage_byte(file, offset, sizeX, sizeY);
                                        }
                                        if (GLLibConfig.sprite_useBugFixImageOddSize) {
                                            sizeX += sizeX % 2;
                                            sizeY += sizeY % 2;
                                        }
                                        this._module_image_imageAA[p2][mod] = this.BuildPNG8(p2, bSkipPalette, image_data, sizeX, sizeY, 0);
                                        bSkipPalette = true;
                                    }
                                    offset = offset_old2 + mod_dim;
                                }
                            }
                        }
                    }
                }
                else {
                    if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                        this._modules_data_off_short = new short[this._nModules];
                    }
                    else {
                        this._modules_data_off_int = new int[this._nModules];
                    }
                    int len2 = 0;
                    final int offset_old3 = offset;
                    for (int i = 0; i < this._nModules; ++i) {
                        int size2;
                        if ((this._bs_flags & 0x80) != 0x0) {
                            size2 = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
                        }
                        else {
                            size2 = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                        }
                        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                            this._modules_data_off_short[i] = (short)len2;
                        }
                        else {
                            this._modules_data_off_int[i] = len2;
                        }
                        len2 += size2;
                        offset += size2;
                    }
                    offset = offset_old3;
                    this._modules_data = new byte[len2];
                    for (int i = 0; i < this._nModules; ++i) {
                        int size2;
                        if ((this._bs_flags & 0x80) != 0x0) {
                            size2 = (file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8) + ((file[offset++] & 0xFF) << 16) + ((file[offset++] & 0xFF) << 24);
                        }
                        else {
                            size2 = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
                        }
                        if (GLLibConfig.sprite_debugLoading) {
                            System.out.println("frame[" + i + "] size = " + size2);
                        }
                        System.arraycopy(file, offset, this._modules_data, this.getStartModuleData(i, 0), size2);
                        offset += size2;
                    }
                }
            }
        }
        return offset;
    }
    
    private int LoadData_useSingleImages(int offset, final byte[] file, final int pal_flags, final int tr_flags) {
        if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x20000000) != 0x0) {
            final int size = (short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8));
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("png size = " + size);
            }
            int image_offset = 0;
            if (GLLibConfig.sprite_useDynamicPng) {
                this._modules_data = file;
                image_offset = offset;
                offset += size;
            }
            else {
                System.arraycopy(file, offset, this._modules_data = new byte[size], 0, size);
                offset += size;
            }
            this._palettes = (file[offset++] & 0xFF);
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("_palettes = " + this._palettes);
            }
            this._colors = (file[offset++] & 0xFF);
            if (this._colors == 0) {
                this._colors = 256;
            }
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("colors = " + this._colors);
            }
            final int pal_size = this._colors * 3 + 4 + this._colors + 4;
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("pal_size = " + pal_size);
            }
            System.arraycopy(file, offset, this._pal_data = new byte[this._palettes * pal_size], 0, this._palettes * pal_size);
            offset += this._palettes * pal_size;
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("...read pal data");
            }
            if (GLLibConfig.sprite_useDynamicPng) {
                if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                    this._module_image_imageAAA = new Image[this._palettes][][];
                }
                else {
                    this._module_image_imageAA = new Image[this._palettes][];
                }
                for (int p = 0; p < this._palettes; ++p) {
                    if ((pal_flags & 1 << p) != 0x0) {
                        final int _PLTE_size = this._colors * 3 + 4;
                        final int _TRNS_size = this._colors + 4;
                        System.arraycopy(this._pal_data, p * (_PLTE_size + _TRNS_size), this._modules_data, 41 + image_offset, _PLTE_size);
                        System.arraycopy(this._pal_data, p * (_PLTE_size + _TRNS_size) + _PLTE_size, this._modules_data, 41 + _PLTE_size + 8 + image_offset, _TRNS_size);
                        if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                            this._module_image_imageAAA[p] = new Image[1][1];
                            this._module_image_imageAAA[p][0][0] = Image.createImage(this._modules_data, image_offset, size);
                            if (GLLibConfig.sprite_debugUsedMemory) {
                                ++ASprite._images_count;
                                ASprite._images_size += this._module_image_imageAAA[p][0][0].getWidth() * this._module_image_imageAAA[p][0][0].getHeight();
                            }
                        }
                        else {
                            (this._module_image_imageAA[p] = new Image[1])[0] = Image.createImage(this._modules_data, image_offset, size);
                            if (GLLibConfig.sprite_debugUsedMemory) {
                                ++ASprite._images_count;
                                ASprite._images_size += this._module_image_imageAA[p][0].getWidth() * this._module_image_imageAA[p][0].getHeight();
                            }
                        }
                    }
                }
                this._pal_data = null;
                this._modules_data = null;
            }
        }
        return offset;
    }
    
    void BuildCacheImages(final int pal, final int m1, int m2, final int pal_copy) {
        if (GLLibConfig.sprite_useNokiaUI) {
            if (this._modules_image_shortAAA == null) {
                this._modules_image_shortAAA = new short[this._palettes][][];
            }
            if (this._modules_image_shortAAA[pal] == null) {
                this._modules_image_shortAAA[pal] = new short[this._nModules][];
            }
        }
        else if (GLLibConfig.sprite_useCacheRGBArrays) {
            if (this._module_image_intAAA == null) {
                this._module_image_intAAA = new int[this._palettes][][];
            }
        }
        else if (this._module_image_imageAA == null) {
            this._module_image_imageAA = new Image[this._palettes][];
        }
        if (GLLibConfig.sprite_useDynamicPng) {
            if (GLLibConfig.sprite_usePrecomputedCRC) {
                if (GLLibConfig.sprite_debugLoading) {
                    System.out.println("BuildCacheImages(" + pal + ", " + m1 + ", " + m2 + ", " + pal_copy + ")... " + this);
                }
                if (this._nModules == 0) {
                    return;
                }
                if (m2 == -1) {
                    m2 = this._nModules - 1;
                }
                if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                    if (this._module_image_imageAAA == null) {
                        this._module_image_imageAAA = new Image[this._palettes][][];
                    }
                    if (this._module_image_imageAAA[pal] == null) {
                        this._module_image_imageAAA[pal] = new Image[this._nModules][1];
                    }
                }
                else {
                    if (this._module_image_imageAA == null) {
                        this._module_image_imageAA = new Image[this._palettes][];
                    }
                    if (this._module_image_imageAA[pal] == null) {
                        this._module_image_imageAA[pal] = new Image[this._nModules];
                    }
                }
                if (pal_copy >= 0) {
                    if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                        for (int i = m1; i <= m2; ++i) {
                            this._module_image_imageAAA[pal][i] = this._module_image_imageAAA[pal_copy][i];
                        }
                    }
                    else {
                        for (int i = m1; i <= m2; ++i) {
                            this._module_image_imageAA[pal][i] = this._module_image_imageAA[pal_copy][i];
                        }
                    }
                }
                else {
                    final int old_pal = this._crt_pal;
                    this._crt_pal = pal;
                    if (!GLLibConfig.sprite_useDeactivateSystemGc) {
                        System.gc();
                    }
                    if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                        for (int j = m1; j <= m2; ++j) {
                            if (!GLLibConfig.sprite_useMultipleModuleTypes || this._module_types[j] == 0) {
                                if (this.GetModuleWidth(j) > 0 && this.GetModuleHeight(j) > 0) {
                                    this._module_image_imageAAA[pal][j][0] = this.BuildPNG8(this._crt_pal, false, j, this.GetModuleWidth(j), this.GetModuleHeight(j), 0);
                                }
                            }
                        }
                    }
                    else {
                        for (int j = m1; j <= m2; ++j) {
                            if (!GLLibConfig.sprite_useMultipleModuleTypes || this._module_types[j] == 0) {
                                if (this.GetModuleWidth(j) > 0 && this.GetModuleHeight(j) > 0) {
                                    this._module_image_imageAA[pal][j] = this.BuildPNG8(this._crt_pal, false, j, this.GetModuleWidth(j), this.GetModuleHeight(j), 0);
                                }
                            }
                        }
                    }
                    if (!GLLibConfig.sprite_useDeactivateSystemGc) {
                        System.gc();
                    }
                    this._crt_pal = old_pal;
                }
                if (!GLLibConfig.sprite_useDeactivateSystemGc) {
                    System.gc();
                }
            }
        }
        else {
            if (GLLibConfig.sprite_debugLoading) {
                System.out.println("BuildCacheImages(" + pal + ", " + m1 + ", " + m2 + ", " + pal_copy + ")... " + this);
            }
            if (this._nModules == 0) {
                return;
            }
            if (m2 == -1) {
                m2 = this._nModules - 1;
            }
            if (GLLibConfig.sprite_ModuleMapping_useModuleImages && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x1000000) != 0x0)) {
                if (GLLibConfig.sprite_useNokiaUI) {
                    if (pal_copy >= 0) {
                        for (int i = m1; i <= m2; ++i) {
                            this._modules_image_shortAAA[pal][i] = this._modules_image_shortAAA[pal_copy][i];
                        }
                    }
                    else {
                        final int old_pal = this._crt_pal;
                        this._crt_pal = pal;
                        if (!GLLibConfig.sprite_useDeactivateSystemGc) {
                            System.gc();
                        }
                        for (int j = m1; j <= m2; ++j) {
                            if (!GLLibConfig.sprite_useModuleUsageFromSprite || this._modules_usage == null || this._modules_usage[j] != 0) {
                                if (!GLLibConfig.sprite_useMultipleModuleTypes || this._module_types[j] == 0) {
                                    final int sizeX = this.GetModuleWidth(j);
                                    final int sizeY = this.GetModuleHeight(j);
                                    if (sizeX > 0) {
                                        if (sizeY > 0) {
                                            final short[] backupTemp = ASprite.temp_short;
                                            try {
                                                final int dim = sizeX * (sizeY + 1) + 10;
                                                ASprite.temp_short = new short[dim];
                                                final short[] image_data = this.DecodeImage_short(j);
                                                if (image_data != null) {
                                                    this._modules_image_shortAAA[pal][j] = image_data;
                                                }
                                            }
                                            catch (final Exception e) {
                                                e.printStackTrace();
                                            }
                                            finally {
                                                ASprite.temp_short = backupTemp;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (!GLLibConfig.sprite_useDeactivateSystemGc) {
                            System.gc();
                        }
                        this._crt_pal = old_pal;
                    }
                }
                else {
                    if (GLLibConfig.sprite_useCacheRGBArrays) {
                        if (this._module_image_intAAA[pal] == null) {
                            this._module_image_intAAA[pal] = new int[this._nModules][];
                        }
                    }
                    else if (this._module_image_imageAA[pal] == null) {
                        this._module_image_imageAA[pal] = new Image[this._nModules];
                    }
                    if (pal_copy >= 0) {
                        for (int i = m1; i <= m2; ++i) {
                            if (GLLibConfig.sprite_useCacheRGBArrays) {
                                this._module_image_intAAA[pal][i] = this._module_image_intAAA[pal_copy][i];
                            }
                            else {
                                this._module_image_imageAA[pal][i] = this._module_image_imageAA[pal_copy][i];
                            }
                        }
                    }
                    else {
                        final int old_pal = this._crt_pal;
                        this._crt_pal = pal;
                        if (!GLLibConfig.sprite_useDeactivateSystemGc) {
                            System.gc();
                        }
                        for (int j = m1; j <= m2; ++j) {
                            if (!GLLibConfig.sprite_useModuleUsageFromSprite || this._modules_usage == null || this._modules_usage[j] != 0) {
                                if (!GLLibConfig.sprite_useMultipleModuleTypes || this._module_types[j] == 0) {
                                    final int sizeX = this.GetModuleWidth(j);
                                    final int sizeY = this.GetModuleHeight(j);
                                    if (sizeX > 0) {
                                        if (sizeY > 0) {
                                            int[] image_data2 = this.DecodeImage_int(j);
                                            if (image_data2 != null) {
                                                boolean bAlpha = false;
                                                for (int size = sizeX * sizeY, ii = 0; ii < size; ++ii) {
                                                    if ((image_data2[ii] & 0xFF000000) != 0xFF000000) {
                                                        bAlpha = true;
                                                        break;
                                                    }
                                                }
                                                if (GLLibConfig.sprite_useCacheRGBArrays) {
                                                    System.arraycopy(image_data2, 0, this._module_image_intAAA[pal][j] = new int[sizeX * sizeY], 0, sizeX * sizeY);
                                                }
                                                else if (GLLibConfig.sprite_useCreateRGBTransparencyBug) {
                                                    this._module_image_imageAA[pal][j] = Image.createRGBImage(image_data2, sizeX, sizeY, true);
                                                }
                                                else {
                                                    this._module_image_imageAA[pal][j] = Image.createRGBImage(image_data2, sizeX, sizeY, bAlpha);
                                                }
                                                if (GLLibConfig.sprite_debugUsedMemory) {
                                                    ++ASprite._images_count;
                                                    ASprite._images_size += sizeX * sizeY;
                                                }
                                                image_data2 = null;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (!GLLibConfig.sprite_useDeactivateSystemGc) {
                            System.gc();
                        }
                        this._crt_pal = old_pal;
                    }
                }
            }
            Label_1747: {
                if (GLLibConfig.sprite_useSingleImageForAllModules) {
                    if (GLLibConfig.sprite_useBSpriteFlags) {
                        if ((this._bs_flags & 0x20000000) == 0x0) {
                            break Label_1747;
                        }
                    }
                    try {
                        if (GLLibConfig.sprite_useCacheRGBArrays) {
                            if (this._module_image_intAAA[pal] == null) {
                                this._module_image_intAAA[pal] = new int[1][];
                            }
                        }
                        else if (this._module_image_imageAA[pal] == null) {
                            this._module_image_imageAA[pal] = new Image[1];
                        }
                        final int _PLTE_size = this._colors * 3 + 4;
                        final int _TRNS_size = this._colors + 4;
                        System.arraycopy(this._pal_data, pal * (_PLTE_size + _TRNS_size), this._modules_data, 41, _PLTE_size);
                        System.arraycopy(this._pal_data, pal * (_PLTE_size + _TRNS_size) + _PLTE_size, this._modules_data, 41 + _PLTE_size + 8, _TRNS_size);
                        if (GLLibConfig.sprite_useCacheRGBArrays) {
                            this._module_image_intAAA[pal][0] = new int[this._modules_data.length];
                            System.arraycopy(this._modules_data, 0, this._module_image_intAAA[pal][0], 0, this._modules_data.length);
                            if (GLLibConfig.sprite_debugUsedMemory) {
                                ++ASprite._images_count;
                                ASprite._images_size += this._modules_data.length;
                            }
                        }
                        else {
                            this._module_image_imageAA[pal][0] = Image.createImage(this._modules_data, 0, this._modules_data.length);
                            if (GLLibConfig.sprite_debugUsedMemory) {
                                ++ASprite._images_count;
                                ASprite._images_size += this._module_image_imageAA[pal][0].getWidth() * this._module_image_imageAA[pal][0].getHeight();
                            }
                        }
                    }
                    catch (final Exception e2) {
                        GLLib.Dbg("exception " + e2);
                    }
                }
            }
            if (!GLLibConfig.sprite_useDeactivateSystemGc) {
                System.gc();
            }
        }
    }
    
    void BuildFrameCacheImages(final int palette, final int frame) {
        for (int numModules = this.GetFModules(frame), m = 0; m < numModules; ++m) {
            final int moduleId = this.GetFrameModule(frame, m);
            final int fm_flags = this.GetFrameModuleFlags(frame, m);
            if (GLLibConfig.sprite_useHyperFM && (fm_flags & 0x10) != 0x0) {
                this.BuildFrameCacheImages(palette, moduleId);
            }
            else {
                int modulePal = palette;
                if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x4000) != 0x0)) {
                    modulePal = this.GetFrameModulePalette(frame, m);
                }
                if (this.GetModuleImage(moduleId, modulePal) == null) {
                    this.BuildCacheImages(modulePal, moduleId, moduleId, -1);
                }
            }
        }
    }
    
    void BuildAnimCacheImages(final int palette, final int anim) {
        for (int numFrames = this.GetAFrames(anim), f = 0; f < numFrames; ++f) {
            final int frameId = this.GetAnimFrame(anim, f);
            this.BuildFrameCacheImages(palette, frameId);
        }
    }
    
    void SetModuleImage(final Image pImg, final int nModule, final int nPalette) {
        if (this._module_image_imageAA != null) {
            if (nPalette >= 0 && nPalette < this._module_image_imageAA.length && this._module_image_imageAA[nPalette] != null && nModule >= 0 && nModule < this._module_image_imageAA[nPalette].length) {
                this._module_image_imageAA[nPalette][nModule] = pImg;
            }
            return;
        }
        if (this._module_image_imageAAA != null) {
            if (nPalette >= 0 && nPalette < this._module_image_imageAAA.length && this._module_image_imageAAA[nPalette] != null && nModule >= 0 && nModule < this._module_image_imageAAA[nPalette].length) {
                this._module_image_imageAAA[nPalette][nModule][0] = pImg;
            }
        }
    }
    
    void SetModuleImagesArray(final Object pData) {
        if (GLLibConfig.sprite_useNokiaUI) {
            this._modules_image_shortAAA = (short[][][])pData;
        }
        else if (GLLibConfig.sprite_useCacheRGBArrays) {
            this._module_image_intAAA = (int[][][])pData;
        }
        else {
            this._module_image_imageAA = (Image[][])pData;
        }
    }
    
    void FreeModuleImage(final int nPal, final int nMod) {
        if (GLLibConfig.sprite_useNokiaUI) {
            if (this._modules_image_shortAAA != null && nPal < this._modules_image_shortAAA.length) {
                if (nMod == -1) {
                    this._modules_image_shortAAA[nPal] = null;
                }
                else if (this._modules_image_shortAAA[nPal] != null) {
                    this._modules_image_shortAAA[nPal][nMod] = null;
                }
            }
        }
        else if (GLLibConfig.sprite_useCacheRGBArrays) {
            if (this._module_image_intAAA != null && nPal < this._module_image_intAAA.length) {
                if (nMod == -1) {
                    this._module_image_intAAA[nPal] = null;
                }
                else if (this._module_image_intAAA[nPal] != null) {
                    this._module_image_intAAA[nPal][nMod] = null;
                }
            }
        }
        else if (GLLibConfig.sprite_useDynamicPng) {
            if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                if (this._module_image_imageAAA != null && nPal < this._module_image_imageAAA.length) {
                    if (nMod == -1) {
                        this._module_image_imageAAA[nPal] = null;
                    }
                    else if (this._module_image_imageAAA[nPal] != null) {
                        this._module_image_imageAAA[nPal][nMod] = null;
                    }
                }
            }
            else if (this._module_image_imageAA != null && nPal < this._module_image_imageAA.length) {
                if (nMod == -1) {
                    this._module_image_imageAA[nPal] = null;
                }
                else if (this._module_image_imageAA[nPal] != null) {
                    this._module_image_imageAA[nPal][nMod] = null;
                }
            }
        }
        else if (this._module_image_imageAA != null && nPal < this._module_image_imageAA.length) {
            if (nMod == -1) {
                this._module_image_imageAA[nPal] = null;
            }
            else if (this._module_image_imageAA[nPal] != null) {
                this._module_image_imageAA[nPal][nMod] = null;
            }
        }
    }
    
    void FreeFrameCacheImages(final int palette, final int frame) {
        for (int numModules = this.GetFModules(frame), m = 0; m < numModules; ++m) {
            final int moduleId = this.GetFrameModule(frame, m);
            final int fm_flags = this.GetFrameModuleFlags(frame, m);
            if (GLLibConfig.sprite_useHyperFM && (fm_flags & 0x10) != 0x0) {
                this.FreeFrameCacheImages(palette, moduleId);
            }
            else {
                int modulePal = palette;
                if (GLLibConfig.sprite_useFMPalette && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x4000) != 0x0)) {
                    modulePal = this.GetFrameModulePalette(frame, m);
                }
                if (this.GetModuleImage(moduleId, modulePal) != null) {
                    this.FreeModuleImage(modulePal, moduleId);
                }
            }
        }
    }
    
    void FreeAnimCacheImages(final int palette, final int anim) {
        for (int numFrames = this.GetAFrames(anim), f = 0; f < numFrames; ++f) {
            final int frameId = this.GetAnimFrame(anim, f);
            this.FreeFrameCacheImages(palette, frameId);
        }
    }
    
    void FreeCacheData() {
        if (GLLibConfig.sprite_useCacheRGBArrays || GLLibConfig.sprite_useDynamicPng) {
            return;
        }
        if (GLLibConfig.sprite_useSingleImageForAllModules) {
            if (GLLibConfig.sprite_debugUsedMemory) {
                --ASprite._images_count;
                ASprite._images_size -= this._modules_data.length;
            }
            if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x20000000) != 0x0) {
                this._pal_data = null;
            }
        }
        this._modules_data = null;
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            this._modules_data_off_short = null;
        }
        else {
            this._modules_data_off_int = null;
        }
        if (!GLLibConfig.sprite_useDeactivateSystemGc) {
            System.gc();
        }
    }
    
    void FreeMemory() {
        if (GLLibConfig.sprite_usePrecomputedCRC) {
            if (GLLibConfig.sprite_useNokiaUI) {
                this._pal_short = null;
            }
            else {
                this._pal_int = null;
            }
            this._transp = null;
            this._modules_data = null;
            if (GLLibConfig.sprite_useModuleDataOffAsShort) {
                this._modules_data_off_short = null;
            }
            else {
                this._modules_data_off_int = null;
            }
            this._PNG_packed_PLTE_CRC = null;
            this._PNG_packed_IHDR_CRC = null;
            this._PNG_packed_IDAT_CRC = null;
            this._PNG_packed_IDAT_ADLER = null;
            this._PNG_packed_tRNS_CRC = null;
            if (GLLibConfig.sprite_useMultipleModuleTypes) {
                this._module_types = null;
                if (GLLibConfig.sprite_useModuleColorAsByte) {
                    this._module_colors_byte = null;
                }
                else {
                    this._module_colors_int = null;
                }
            }
        }
    }
    
    private int GetModuleExtraInfoOffset(final int module) {
        if (this._modules_extra_pointer != null) {
            for (int i = 0; i < this._modules_extra_pointer.length; i += 2) {
                if (this._modules_extra_pointer[i] == module) {
                    return this._modules_extra_pointer[i + 1];
                }
            }
        }
        return -1;
    }
    
    void PaintModule(final Graphics g, int module, int posX, int posY, final int flags) {
        if (this._bTraceNow) {
            System.out.println("PaintModule(g_  " + module + ", " + posX + ", " + posY + ", 0x" + Integer.toHexString(flags) + ")");
        }
        if (GLLibConfig.sprite_useModuleMapping && this._cur_map >= 0) {
            module = this._map[this._cur_map][module];
        }
        if (GLLibConfig.sprite_useMultipleModuleTypes && this._module_types[module] != 0 && g != null) {
            if (GLLibConfig.sprite_useModuleColorAsByte) {
                g.setColor((int)this._module_colors_byte[module]);
            }
            else {
                g.setColor(this._module_colors_int[module]);
            }
            switch (this._module_types[module]) {
                case 2: {
                    g.fillRect(posX, posY, this.GetModuleWidth(module), this.GetModuleHeight(module));
                    break;
                }
                case 1: {
                    g.drawRect(posX, posY, this.GetModuleWidth(module), this.GetModuleHeight(module));
                    break;
                }
                case 3:
                case 4: {
                    final int nOffset = this.GetModuleExtraInfoOffset(module);
                    if (nOffset != -1) {
                        final int sa = this._modules_extra_info[nOffset + 0];
                        final int a = this._modules_extra_info[nOffset + 1];
                        if (this._module_types[module] == 3) {
                            g.drawArc(posX, posY, this.GetModuleWidth(module), this.GetModuleHeight(module), sa, a);
                        }
                        else {
                            g.fillArc(posX, posY, this.GetModuleWidth(module), this.GetModuleHeight(module), sa, a);
                        }
                    }
                    break;
                }
                case 6:
                case 7: {
                    final int nOffset = this.GetModuleExtraInfoOffset(module);
                    if (nOffset != -1) {
                        final int p2x = this._modules_extra_info[nOffset + 0];
                        final int p2y = this._modules_extra_info[nOffset + 1];
                        final int p3x = this._modules_extra_info[nOffset + 2];
                        final int p3y = this._modules_extra_info[nOffset + 3];
                        if (this._module_types[module] == 6) {
                            g.drawLine(posX, posY, posX + p2x, posY + p2y);
                            g.drawLine(posX + p2x, posY + p2y, posX + p3x, posY + p3y);
                            g.drawLine(posX, posY, posX + p3x, posY + p3y);
                        }
                        else {
                            g.fillTriangle(posX, posY, posX + p2x, posY + p2y, posX + p3x, posY + p3y);
                        }
                    }
                    break;
                }
            }
            return;
        }
        if (GLLibConfig.sprite_useOperationMark && ASprite._operation == 3) {
            final byte[] modules_usage = this._modules_usage;
            final int n = module;
            modules_usage[n] |= (byte)(1 << (flags & 0x7));
            return;
        }
        int sizeX = this.GetModuleWidth(module);
        int sizeY = this.GetModuleHeight(module);
        if (GLLibConfig.sprite_useOperationRect && ASprite._operation == 1) {
            if (posX < ASprite._rectX1) {
                ASprite._rectX1 = posX;
            }
            if (posY < ASprite._rectY1) {
                ASprite._rectY1 = posY;
            }
            if (posX + sizeX > ASprite._rectX2) {
                ASprite._rectX2 = posX + sizeX;
            }
            if (posY + sizeY > ASprite._rectY2) {
                ASprite._rectY2 = posY + sizeY;
            }
            return;
        }
        if (GLLibConfig.sprite_useDynamicPng) {
            if (GLLibConfig.sprite_useSingleImageForAllModules && (this._bs_flags & 0x20000000) != 0x0) {
                if (sizeX <= 0 || sizeY <= 0) {
                    return;
                }
                final int cx = g.getClipX();
                final int cy = g.getClipY();
                final int cw = g.getClipWidth();
                final int ch = g.getClipHeight();
                int new_cx = posX;
                int new_cy = posY;
                int new_endcx = posX + sizeX;
                int new_endcy = posY + sizeY;
                if (posX < cx) {
                    new_cx = cx;
                }
                if (posY < cy) {
                    new_cy = cy;
                }
                if (new_endcx > cx + cw) {
                    new_endcx = cx + cw;
                }
                if (new_endcy > cy + ch) {
                    new_endcy = cy + ch;
                }
                if (!GLLibConfig.sprite_fpsRegion) {
                    g.setClip(new_cx, new_cy, new_endcx - new_cx, new_endcy - new_cy);
                }
                if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                    if (GLLibConfig.sprite_useModuleXY) {
                        if (this.CheckOperation(this._module_image_imageAAA[this._crt_pal][0][0], posX, posY, sizeX, sizeY, 0, this._modules_x_byte[module] & 0xFF, this._modules_y_byte[module] & 0xFF)) {
                            g.drawImage(this._module_image_imageAAA[this._crt_pal][0][0], posX - (this._modules_x_byte[module] & 0xFF), posY - (this._modules_y_byte[module] & 0xFF), 0);
                        }
                    }
                    else if (GLLibConfig.sprite_useModuleXYShort && this.CheckOperation(this._module_image_imageAAA[this._crt_pal][0][0], posX, posY, sizeX, sizeY, 0, this._modules_x_short[module], this._modules_y_short[module])) {
                        g.drawImage(this._module_image_imageAAA[this._crt_pal][0][0], posX - this._modules_x_short[module], posY - this._modules_y_short[module], 0);
                    }
                }
                else if (!GLLibConfig.sprite_fpsRegion) {
                    if (GLLibConfig.sprite_useModuleXY) {
                        if (this.CheckOperation(this._module_image_imageAA[this._crt_pal][0], posX, posY, sizeX, sizeY, 0, this._modules_x_byte[module] & 0xFF, this._modules_y_byte[module] & 0xFF)) {
                            g.drawImage(this._module_image_imageAA[this._crt_pal][0], posX - (this._modules_x_byte[module] & 0xFF), posY - (this._modules_y_byte[module] & 0xFF), 0);
                        }
                    }
                    else if (GLLibConfig.sprite_useModuleXYShort && this.CheckOperation(this._module_image_imageAA[this._crt_pal][0], posX, posY, sizeX, sizeY, 0, this._modules_x_short[module], this._modules_y_short[module])) {
                        g.drawImage(this._module_image_imageAA[this._crt_pal][0], posX - this._modules_x_short[module], posY - this._modules_y_short[module], 0);
                    }
                }
                else if (GLLibConfig.sprite_useModuleXY) {
                    if (this.CheckOperation(this._module_image_imageAA[this._crt_pal][0], posX, posY, sizeX, sizeY, 0, this._modules_x_byte[module] & 0xFF, this._modules_y_byte[module] & 0xFF)) {
                        if (GLLibConfig.sprite_drawRegionFlippedBug) {
                            final Image image = Image.createImage(this._module_image_imageAA[this._crt_pal][0], this._modules_x_byte[module] & 0xFF, this._modules_y_byte[module] & 0xFF, sizeX, sizeY, 0);
                            g.drawImage(image, posX, posY, 0);
                        }
                        else {
                            g.drawRegion(this._module_image_imageAA[this._crt_pal][0], this._modules_x_byte[module] & 0xFF, this._modules_y_byte[module] & 0xFF, sizeX, sizeY, 0, posX, posY, 0);
                        }
                    }
                }
                else if (GLLibConfig.sprite_useModuleXYShort && this.CheckOperation(this._module_image_imageAA[this._crt_pal][0], posX, posY, sizeX, sizeY, 0, this._modules_x_short[module], this._modules_y_short[module])) {
                    if (GLLibConfig.sprite_drawRegionFlippedBug) {
                        final Image image = Image.createImage(this._module_image_imageAA[this._crt_pal][0], (int)this._modules_x_short[module], (int)this._modules_y_short[module], sizeX, sizeY, 0);
                        g.drawImage(image, posX, posY, 0);
                    }
                    else {
                        g.drawRegion(this._module_image_imageAA[this._crt_pal][0], (int)this._modules_x_short[module], (int)this._modules_y_short[module], sizeX, sizeY, 0, posX, posY, 0);
                    }
                }
                if (!GLLibConfig.sprite_fpsRegion) {
                    g.setClip(cx, cy, cw, ch);
                }
            }
            else if (!GLLibConfig.sprite_useLoadImageWithoutTransf && (GLLibConfig.sprite_useTransfRot || GLLibConfig.sprite_useTransfFlip)) {
                if (this._module_image_imageAAA == null || this._crt_pal >= this._module_image_imageAAA.length || this._module_image_imageAAA[this._crt_pal] == null || module >= this._module_image_imageAAA[this._crt_pal].length || this._module_image_imageAAA[this._crt_pal][module] == null || flags >= this._module_image_imageAAA[this._crt_pal][module].length || this._module_image_imageAAA[this._crt_pal][module][flags] == null) {
                    GLLib.Assert(false, "Not loaded module image: pal = " + this._crt_pal + " module = " + module + " flags = " + flags);
                }
                int nTmpFlag;
                if (GLLibConfig.sprite_usePrecomputedCRC && GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 0x2000000) != 0x0) {
                    nTmpFlag = 0;
                }
                else {
                    nTmpFlag = flags;
                }
                Image img = null;
                if (nTmpFlag < this._module_image_imageAAA[this._crt_pal][module].length) {
                    img = this._module_image_imageAAA[this._crt_pal][module][nTmpFlag];
                }
                if (img == null) {
                    img = this.BuildPNG8(this._crt_pal, false, module, sizeX, sizeY, nTmpFlag);
                }
                if (this.CheckOperation(img, posX, posY, sizeX, sizeY, 0, 0, 0)) {
                    g.drawImage(img, posX, posY, 0);
                }
            }
            else {
                if (this._module_image_imageAA == null || this._crt_pal >= this._module_image_imageAA.length || this._module_image_imageAA[this._crt_pal] == null || module >= this._module_image_imageAA[this._crt_pal].length) {
                    GLLib.Assert(false, "Not loaded module image: pal = " + this._crt_pal + " module = " + module);
                }
                if (GLLibConfig.sprite_usePrecomputedCRC && GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 0x2000000) != 0x0) {
                    Image img2 = this._module_image_imageAA[this._crt_pal][module];
                    if (img2 == null) {
                        img2 = this.BuildPNG8(this._crt_pal, false, module, sizeX, sizeY, 0);
                    }
                    if (img2 == null) {
                        GLLib.Assert(false, "Not loaded module image");
                    }
                    if (this.CheckOperation(img2, posX, posY, sizeX, sizeY, 0, 0, 0)) {
                        g.drawImage(img2, posX, posY, 0);
                    }
                }
                else if (GLLibConfig.sprite_useLoadImageWithoutTransf) {
                    if (this.CheckOperation(this._module_image_imageAA[this._crt_pal][module], posX, posY, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7], 0, 0)) {
                        if (ASprite.midp2_flags[flags & 0x7] == 0) {
                            g.drawImage(this._module_image_imageAA[this._crt_pal][module], posX, posY, 0);
                        }
                        else if (GLLibConfig.sprite_drawRegionFlippedBug) {
                            final Image image2 = Image.createImage(this._module_image_imageAA[this._crt_pal][module], 0, 0, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7]);
                            g.drawImage(image2, posX, posY, 0);
                        }
                        else {
                            g.drawRegion(this._module_image_imageAA[this._crt_pal][module], 0, 0, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7], posX, posY, 0);
                        }
                    }
                }
                else if (this.CheckOperation(this._module_image_imageAA[this._crt_pal][module], posX, posY, sizeX, sizeY, 0, 0, 0)) {
                    g.drawImage(this._module_image_imageAA[this._crt_pal][module], posX, posY, 0);
                }
            }
        }
        else {
            if (sizeX <= 0 || sizeY <= 0) {
                return;
            }
            if (!GLLibConfig.sprite_useSkipFastVisibilityTest && g != null) {
                final int cx = g.getClipX();
                final int cy = g.getClipY();
                final int cw = g.getClipWidth();
                final int ch = g.getClipHeight();
                if ((flags & 0x4) != 0x0) {
                    final int tmp = sizeX;
                    sizeX = sizeY;
                    sizeY = tmp;
                }
                if (posX + sizeX < cx || posY + sizeY < cy || posX >= cx + cw || posY >= cy + ch) {
                    return;
                }
            }
            final int[] img_intA = null;
            Image img_image = null;
            final short[] img_shortA = null;
            if (GLLibConfig.sprite_useSingleImageForAllModules && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x20000000) != 0x0) && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x20000000) != 0x0)) {
                if (GLLibConfig.sprite_useCacheRGBArrays) {
                    if (this._module_image_intAAA == null || this._module_image_intAAA[this._crt_pal] == null) {
                        this.BuildCacheImages(this._crt_pal, 0, 0, 0);
                    }
                    if (this.CheckOperation(this._module_image_intAAA[this._crt_pal][0], posX, posY, sizeX, sizeY, 0, 0, 0)) {
                        if (GLLibConfig.sprite_drawRGBTransparencyBug) {
                            try {
                                final Image tmp_img = Image.createRGBImage(this._module_image_intAAA[this._crt_pal][0], sizeX, sizeY, this._alpha);
                                g.drawImage(tmp_img, posX, posY, 0);
                            }
                            catch (final Exception e) {
                                GLLib.Dbg("exception " + e);
                            }
                        }
                        else if (GLLibConfig.useDrawPartialRGB) {
                            GLLib.drawPartialRGB(g, this._module_image_intAAA[this._crt_pal][0], sizeX, 0, 0, posX, posY, sizeX, sizeY, this._alpha);
                        }
                        else {
                            g.drawRGB(this._module_image_intAAA[this._crt_pal][0], 0, sizeX, posX, posY, sizeX, sizeY, this._alpha);
                        }
                    }
                }
                else {
                    if (this._module_image_imageAA == null || this._module_image_imageAA[this._crt_pal] == null) {
                        this.BuildCacheImages(this._crt_pal, 0, 0, 0);
                    }
                    int img_x;
                    int img_y;
                    if (GLLibConfig.sprite_useModuleXY) {
                        img_x = (this._modules_x_byte[module] & 0xFF);
                        img_y = (this._modules_y_byte[module] & 0xFF);
                    }
                    else if (GLLibConfig.sprite_useModuleXYShort) {
                        img_x = this._modules_x_short[module];
                        img_y = this._modules_y_short[module];
                    }
                    else {
                        img_x = 0;
                        img_y = 0;
                    }
                    if (GLLibConfig.sprite_useCacheFlipXY) {
                        int selected = ASprite.midp2_flags[flags & 0x7];
                        if (selected > 2) {
                            selected = 0;
                        }
                        img_image = this._module_image_imageAA[this._crt_pal][selected];
                        if (ASprite.midp2_flags[flags & 0x7] == 2) {
                            img_x = img_image.getWidth() - (img_x + sizeX);
                        }
                        else if (ASprite.midp2_flags[flags & 0x7] == 1) {
                            img_y = img_image.getHeight() - (img_y + sizeY);
                        }
                    }
                    else {
                        img_image = this._module_image_imageAA[this._crt_pal][0];
                    }
                    if (GLLibConfig.sprite_useDrawRegionClipping) {
                        final int cx2 = g.getClipX();
                        final int cy2 = g.getClipY();
                        final int cw2 = g.getClipWidth();
                        final int ch2 = g.getClipHeight();
                        int new_cx2 = posX;
                        int new_cy2 = posY;
                        int new_endcx2 = posX + sizeX;
                        int new_endcy2 = posY + sizeY;
                        if (posX < cx2) {
                            new_cx2 = cx2;
                        }
                        if (posY < cy2) {
                            new_cy2 = cy2;
                        }
                        if (new_endcx2 > cx2 + cw2) {
                            new_endcx2 = cx2 + cw2;
                        }
                        if (new_endcy2 > cy2 + ch2) {
                            new_endcy2 = cy2 + ch2;
                        }
                        g.setClip(new_cx2, new_cy2, new_endcx2 - new_cx2, new_endcy2 - new_cy2);
                        if (this.CheckOperation(img_image, posX, posY, sizeX, sizeY, 0, img_x, img_y)) {
                            g.drawImage(img_image, posX - img_x, posY - img_y, 0);
                        }
                        g.setClip(cx2, cy2, cw2, ch2);
                    }
                    else if (this.CheckOperation(img_image, posX, posY, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7], img_x, img_y)) {
                        if (GLLibConfig.sprite_drawRegionFlippedBug) {
                            final Image image3 = Image.createImage(img_image, img_x, img_y, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7]);
                            g.drawImage(image3, posX, posY, 0);
                        }
                        else {
                            g.drawRegion(img_image, img_x, img_y, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7], posX, posY, 0);
                        }
                    }
                }
            }
            if (GLLibConfig.sprite_useExternImage) {
                if (this._main_image != null && this._main_image[this._crt_pal] != null) {
                    img_image = this._main_image[this._crt_pal];
                }
                if (img_image != null) {
                    int img_x = 0;
                    int img_y = 0;
                    if (GLLibConfig.sprite_useModuleXY) {
                        img_x = (this._modules_x_byte[module] & 0xFF);
                        img_y = (this._modules_y_byte[module] & 0xFF);
                    }
                    else if (GLLibConfig.sprite_useModuleXYShort) {
                        img_x = this._modules_x_short[module];
                        img_y = this._modules_y_short[module];
                    }
                    if (this.CheckOperation(img_image, posX, posY, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7], img_x, img_y)) {
                        if (GLLibConfig.sprite_drawRegionFlippedBug) {
                            final Image image3 = Image.createImage(img_image, img_x, img_y, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7]);
                            g.drawImage(image3, posX, posY, 0);
                        }
                        else {
                            g.drawRegion(img_image, img_x, img_y, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7], posX, posY, 0);
                        }
                    }
                }
            }
            if (GLLibConfig.sprite_ModuleMapping_useModuleImages && (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x1000000) != 0x0)) {
                if (!GLLibConfig.sprite_useNokiaUI) {
                    if (!GLLibConfig.sprite_useBSpriteFlags || (this._bs_flags & 0x1000000) != 0x0) {
                        if (this._module_image_imageAA != null && this._module_image_imageAA[this._crt_pal] != null) {
                            img_image = this._module_image_imageAA[this._crt_pal][module];
                        }
                        if (GLLibConfig.sprite_useDynamicPng && GLLibConfig.sprite_usePrecomputedCRC) {
                            if (img_image == null) {
                                img_image = this.BuildPNG8(this._crt_pal, false, this.DecodeImage_byte(module), sizeX, sizeY, 0);
                                if (GLLibConfig.sprite_debugUsedMemory) {
                                    ++ASprite._images_count;
                                    ASprite._images_size += img_image.getWidth() * img_image.getHeight();
                                }
                            }
                            if (img_image == null) {
                                GLLib.Dbg("WARNING_PaintModule : image is NULL   src\\ASprite\\PM_MultiImages.jpp   25");
                                return;
                            }
                            sizeX = img_image.getWidth();
                            sizeY = img_image.getHeight();
                            if (this.CheckOperation(img_image, posX, posY, sizeX, sizeY, 0, 0, 0)) {
                                g.drawImage(img_image, posX, posY, 0);
                            }
                        }
                        else if (GLLibConfig.sprite_useCacheRGBArrays) {
                            if (img_intA != null && flags == 0) {
                                if (this.CheckOperation(img_intA, posX, posY, sizeX, sizeY, 0, 0, 0)) {
                                    if (GLLibConfig.sprite_drawRGBTransparencyBug) {
                                        try {
                                            final Image tmp_img2 = Image.createRGBImage(img_intA, sizeX, sizeY, true);
                                            g.drawImage(tmp_img2, posX, posY, 0);
                                        }
                                        catch (final Exception e2) {
                                            GLLib.Dbg("exception " + e2);
                                        }
                                    }
                                    else if (GLLibConfig.useDrawPartialRGB) {
                                        GLLib.drawPartialRGB(g, img_intA, sizeX, 0, 0, posX, posY, sizeX, sizeY, true);
                                    }
                                    else {
                                        g.drawRGB(img_intA, 0, sizeX, posX, posY, sizeX, sizeY, true);
                                    }
                                }
                                return;
                            }
                            final int[] image_data = this.DecodeImage_int(module);
                            final int[] imageDataTransformed = this.TransformRGB(image_data, sizeX, sizeY, flags);
                            if (this.CheckOperation(imageDataTransformed, posX, posY, sizeX, sizeY, 0, 0, 0)) {
                                if (GLLibConfig.sprite_drawRGBTransparencyBug) {
                                    try {
                                        final Image tmp_img3 = Image.createRGBImage(imageDataTransformed, sizeX, sizeY, true);
                                        g.drawImage(tmp_img3, posX, posY, 0);
                                    }
                                    catch (final Exception e3) {
                                        GLLib.Dbg("exception " + e3);
                                    }
                                }
                                else if (GLLibConfig.useDrawPartialRGB) {
                                    GLLib.drawPartialRGB(g, imageDataTransformed, sizeX, 0, 0, posX, posY, sizeX, sizeY, true);
                                }
                                else {
                                    g.drawRGB(imageDataTransformed, 0, sizeX, posX, posY, sizeX, sizeY, true);
                                }
                            }
                        }
                        else {
                            if (img_image == null) {
                                final int[] image_data = this.DecodeImage_int(module);
                                if (image_data == null) {
                                    if (GLLibConfig.sprite_debugErrors) {
                                        System.out.println("DecodeImage() FAILED !");
                                    }
                                    return;
                                }
                                if (GLLibConfig.sprite_RGBArraysUseDrawRGB) {
                                    final int[] imageDataTransformed = this.TransformRGB(image_data, sizeX, sizeY, flags);
                                    if (GLLibConfig.sprite_useTruncatedRGBBuffer) {
                                        int drawSizeX = sizeX;
                                        int drawSizeY = sizeY;
                                        int drawOffsetX = 0;
                                        int drawOffsetY = 0;
                                        if (posX < 0) {
                                            drawSizeX += posX;
                                            drawOffsetX = -posX;
                                            posX = 0;
                                        }
                                        if (posY < 0) {
                                            drawSizeY += posY;
                                            drawOffsetY = -posY;
                                            posY = 0;
                                        }
                                        if (drawSizeX <= 0 || drawSizeY <= 0) {
                                            return;
                                        }
                                        if (GLLibConfig.sprite_drawRGBTransparencyBug) {
                                            try {
                                                final Image tmp_img4 = Image.createRGBImage(imageDataTransformed, sizeX, sizeY, this._alpha);
                                                g.drawImage(tmp_img4, posX, posY, 0);
                                            }
                                            catch (final Exception e4) {
                                                GLLib.Dbg("exception " + e4);
                                            }
                                        }
                                        else if (GLLibConfig.useDrawPartialRGB) {
                                            GLLib.drawPartialRGB(g, imageDataTransformed, sizeX, 0, 0, posX, posY, drawSizeX, drawSizeY, this._alpha);
                                        }
                                        else {
                                            g.drawRGB(imageDataTransformed, drawOffsetY * sizeX + drawOffsetX, sizeX, posX, posY, drawSizeX, drawSizeY, this._alpha);
                                        }
                                    }
                                    else if (GLLibConfig.sprite_drawRGBTransparencyBug) {
                                        try {
                                            final Image tmp_img3 = Image.createRGBImage(imageDataTransformed, sizeX, sizeY, this._alpha);
                                            g.drawImage(tmp_img3, posX, posY, 0);
                                        }
                                        catch (final Exception e3) {
                                            GLLib.Dbg("exception " + e3);
                                        }
                                    }
                                    else if (GLLibConfig.useDrawPartialRGB) {
                                        GLLib.drawPartialRGB(g, imageDataTransformed, sizeX, 0, 0, posX, posY, sizeX, sizeY, this._alpha);
                                    }
                                    else {
                                        g.drawRGB(imageDataTransformed, 0, sizeX, posX, posY, sizeX, sizeY, this._alpha);
                                    }
                                    return;
                                }
                                img_image = Image.createRGBImage(image_data, sizeX, sizeY, this._alpha);
                            }
                            sizeX = img_image.getWidth();
                            sizeY = img_image.getHeight();
                            this.UpdatePoolCache(module, img_image);
                            if (this.CheckOperation(img_image, posX, posY, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7], 0, 0)) {
                                if (ASprite.midp2_flags[flags & 0x7] == 0) {
                                    g.drawImage(img_image, posX, posY, 0);
                                }
                                else if (GLLibConfig.sprite_drawRegionFlippedBug) {
                                    final Image image4 = Image.createImage(img_image, 0, 0, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7]);
                                    g.drawImage(image4, posX, posY, 0);
                                }
                                else {
                                    g.drawRegion(img_image, 0, 0, sizeX, sizeY, ASprite.midp2_flags[flags & 0x7], posX, posY, 0);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    private static void InitCrcTable() {
        if (GLLibConfig.sprite_useDynamicPng) {
            ASprite._png_result = new byte[GLLibConfig.PNG_BUFFER_SIZE];
            for (int i = 0; i < 256; ++i) {
                int crc = i;
                for (int j = 8; j > 0; --j) {
                    if ((crc & 0x1) == 0x1) {
                        crc = (crc >>> 1 ^ 0xEDB88320);
                    }
                    else {
                        crc >>>= 1;
                    }
                }
                ASprite.crcTable[i] = crc;
            }
        }
    }
    
    private static void PutArray(final byte[] array) {
        if (GLLibConfig.sprite_useDynamicPng) {
            System.arraycopy(array, 0, ASprite._png_result, ASprite._png_size, array.length);
            ASprite._png_size += array.length;
        }
    }
    
    private static void PutInt(final int n) {
        if (GLLibConfig.sprite_useDynamicPng) {
            ASprite._png_result[ASprite._png_size++] = (byte)(n >> 24 & 0xFF);
            ASprite._png_result[ASprite._png_size++] = (byte)(n >> 16 & 0xFF);
            ASprite._png_result[ASprite._png_size++] = (byte)(n >> 8 & 0xFF);
            ASprite._png_result[ASprite._png_size++] = (byte)(n & 0xFF);
        }
    }
    
    private void BeginChunk(final byte[] name, final int len) {
        if (GLLibConfig.sprite_useDynamicPng) {
            PutInt(len);
            ASprite._png_start_crc = ASprite._png_size;
            PutArray(name);
        }
    }
    
    private void EndChunk() {
        if (GLLibConfig.sprite_useDynamicPng) {
            if (GLLibConfig.sprite_usePrecomputedCRC) {
                if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 0x2000000) == 0x0) {
                    PutInt(Crc32(ASprite._png_result, ASprite._png_start_crc, ASprite._png_size - ASprite._png_start_crc, 0));
                }
                else {
                    switch (ASprite.currentChunkType) {
                        case 0: {
                            PutInt(this._PNG_packed_IHDR_CRC[ASprite.mod]);
                            break;
                        }
                        case 1: {
                            PutInt(this._PNG_packed_PLTE_CRC[this._cur_pal]);
                            break;
                        }
                        case 2: {
                            PutInt(this._PNG_packed_tRNS_CRC[this._cur_pal]);
                            break;
                        }
                        case 3: {
                            PutInt(this._PNG_packed_IDAT_CRC[ASprite.mod]);
                            break;
                        }
                    }
                }
                ++ASprite.currentChunkType;
            }
            else {
                PutInt(Crc32(ASprite._png_result, ASprite._png_start_crc, ASprite._png_size - ASprite._png_start_crc, 0));
            }
        }
    }
    
    private Image BuildPNG8(final int pal, final boolean bPalInited, final int module, final int width, final int height, final int flags) {
        if (GLLibConfig.sprite_useDynamicPng) {
            ASprite.mod = module;
            return this.BuildPNG8(pal, bPalInited, this.DecodeImage_byte(module), width, height, flags);
        }
        return null;
    }
    
    private Image BuildPNG8(final int pal, final boolean bPalInited, final byte[] data, int width, int height, final int flags) {
        if (!GLLibConfig.sprite_useDynamicPng) {
            return null;
        }
        long adler = 1L;
        if (GLLibConfig.sprite_usePrecomputedCRC) {
            this._cur_pal = pal;
            ASprite.currentChunkType = 0;
        }
        final int orig_png_size = ASprite._png_size;
        if (width == 0 || height == 0) {
            return null;
        }
        if (GLLibConfig.sprite_useTransfRot && (flags & 0x4) != 0x0) {
            final int i = width;
            width = height;
            height = i;
        }
        ASprite._png_size = 0;
        PutArray(ASprite.MAGIC);
        this.BeginChunk(ASprite.IHDR, 13);
        PutInt(width);
        PutInt(height);
        PutArray(ASprite.INFO8);
        this.EndChunk();
        if (bPalInited) {
            if (GLLibConfig.sprite_useNokiaUI) {
                ASprite._png_size += 12 + this._pal_short[pal].length * 3;
                if (this._alpha) {
                    ASprite._png_size += 12 + this._pal_short[pal].length;
                }
            }
            else {
                ASprite._png_size += 12 + this._pal_int[pal].length * 3;
                if (this._alpha) {
                    ASprite._png_size += 12 + this._pal_int[pal].length;
                }
            }
            if (GLLibConfig.sprite_usePrecomputedCRC) {
                ++ASprite.currentChunkType;
                ++ASprite.currentChunkType;
            }
        }
        else {
            int ssize;
            if (GLLibConfig.sprite_useNokiaUI) {
                ssize = this._pal_short[pal].length;
            }
            else {
                ssize = this._pal_int[pal].length;
            }
            this.BeginChunk(ASprite.PLTE, ssize * 3);
            for (int i = 0; i < ssize; ++i) {
                int pixel;
                if (GLLibConfig.sprite_useNokiaUI) {
                    pixel = this._pal_short[pal][i];
                }
                else {
                    pixel = this._pal_int[pal][i];
                }
                ASprite._png_result[ASprite._png_size++] = (byte)((pixel & 0xFF0000) >>> 16);
                ASprite._png_result[ASprite._png_size++] = (byte)((pixel & 0xFF00) >>> 8);
                ASprite._png_result[ASprite._png_size++] = (byte)(pixel & 0xFF);
            }
            this.EndChunk();
            if (this._alpha) {
                this.BeginChunk(ASprite.tRNS, ssize);
                for (int i = 0; i < ssize; ++i) {
                    if (GLLibConfig.sprite_useNokiaUI) {
                        ASprite._png_result[ASprite._png_size++] = (byte)((this._pal_short[pal][i] & 0xFF000000) >>> 24);
                    }
                    else {
                        ASprite._png_result[ASprite._png_size++] = (byte)((this._pal_int[pal][i] & 0xFF000000) >>> 24);
                    }
                }
                this.EndChunk();
            }
        }
        final int data_size = width * height + height;
        this.BeginChunk(ASprite.IDAT, data_size + 11);
        System.arraycopy(ASprite.MAGIC_IDAT_h, 0, ASprite._png_result, ASprite._png_size, 3);
        ASprite._png_size += 3;
        ASprite._png_result[ASprite._png_size++] = (byte)(data_size & 0xFF);
        ASprite._png_result[ASprite._png_size++] = (byte)((data_size & 0xFF00) >> 8);
        ASprite._png_result[ASprite._png_size++] = (byte)(~data_size & 0xFF);
        ASprite._png_result[ASprite._png_size++] = (byte)((~data_size & 0xFF00) >> 8);
        final int start_block = ASprite._png_size;
        final int nSize = height * width;
        if (nSize >= data.length) {
            GLLib.Dbg("ERROR\t\t: BuildPNG8 data array too small look at, TMP_BUFFER_SIZE constant");
        }
        if (ASprite._png_size + nSize >= ASprite._png_result.length) {
            GLLib.Dbg("ERROR\t\t: BuildPNG8 _png_result array too small look at, PNG_BUFFER_SIZE constant");
        }
        switch (flags & 0x7) {
            case 0: {
                for (int j = 0; j < height; ++j) {
                    ASprite._png_result[ASprite._png_size++] = 0;
                    System.arraycopy(data, j * width, ASprite._png_result, ASprite._png_size, width);
                    ASprite._png_size += width;
                }
                break;
            }
            case 1: {
                if (GLLibConfig.sprite_useTransfFlip) {
                    for (int j = 0; j < height; ++j) {
                        int offset = (j + 1) * width;
                        ASprite._png_result[ASprite._png_size++] = 0;
                        for (int i = 0; i < width; ++i) {
                            ASprite._png_result[ASprite._png_size++] = data[--offset];
                        }
                    }
                    break;
                }
                break;
            }
            case 2: {
                if (GLLibConfig.sprite_useTransfFlip) {
                    for (int j = 0; j < height; ++j) {
                        ASprite._png_result[ASprite._png_size++] = 0;
                        System.arraycopy(data, (height - j - 1) * width, ASprite._png_result, ASprite._png_size, width);
                        ASprite._png_size += width;
                    }
                    break;
                }
                break;
            }
            case 3: {
                if (GLLibConfig.sprite_useTransfFlip) {
                    for (int j = 0; j < height; ++j) {
                        int offset = (height - j) * width;
                        ASprite._png_result[ASprite._png_size++] = 0;
                        for (int i = 0; i < width; ++i) {
                            ASprite._png_result[ASprite._png_size++] = data[--offset];
                        }
                    }
                    break;
                }
                break;
            }
            case 4: {
                if (GLLibConfig.sprite_useTransfRot) {
                    for (int j = 0; j < height; ++j) {
                        ASprite._png_result[ASprite._png_size++] = 0;
                        for (int i = 0; i < width; ++i) {
                            ASprite._png_result[ASprite._png_size++] = data[(width - 1 - i) * height + j];
                        }
                    }
                    break;
                }
                break;
            }
            case 5: {
                if (GLLibConfig.sprite_useTransfRot && GLLibConfig.sprite_useTransfFlip) {
                    for (int j = 0; j < height; ++j) {
                        ASprite._png_result[ASprite._png_size++] = 0;
                        for (int i = 0; i < width; ++i) {
                            ASprite._png_result[ASprite._png_size++] = data[(width - 1 - i) * height + (height - 1 - j)];
                        }
                    }
                    break;
                }
                break;
            }
            case 6: {
                if (GLLibConfig.sprite_useTransfRot && GLLibConfig.sprite_useTransfFlip) {
                    for (int j = 0; j < height; ++j) {
                        ASprite._png_result[ASprite._png_size++] = 0;
                        for (int i = 0; i < width; ++i) {
                            ASprite._png_result[ASprite._png_size++] = data[i * height + j];
                        }
                    }
                    break;
                }
                break;
            }
            case 7: {
                if (GLLibConfig.sprite_useTransfRot && GLLibConfig.sprite_useTransfFlip) {
                    for (int j = 0; j < height; ++j) {
                        ASprite._png_result[ASprite._png_size++] = 0;
                        for (int i = 0; i < width; ++i) {
                            ASprite._png_result[ASprite._png_size++] = data[i * height + (height - 1 - j)];
                        }
                    }
                    break;
                }
                break;
            }
        }
        if (GLLibConfig.sprite_usePrecomputedCRC) {
            if (GLLibConfig.sprite_useBSpriteFlags && (this._bs_flags & 0x2000000) == 0x0) {
                adler = Adler32(adler, ASprite._png_result, start_block, data_size);
                PutInt((int)adler);
            }
            else {
                PutInt(this._PNG_packed_IDAT_ADLER[ASprite.mod]);
            }
        }
        else {
            adler = Adler32(adler, ASprite._png_result, start_block, data_size);
            PutInt((int)adler);
        }
        this.EndChunk();
        PutArray(ASprite.MAGIC_IEND);
        return Image.createImage(ASprite._png_result, 0, ASprite._png_size);
    }
    
    public static int Crc32(final byte[] buffer, int start, int count, int crc) {
        if (GLLibConfig.sprite_useDynamicPng) {
            crc ^= -1;
            while (count-- != 0) {
                crc = (ASprite.crcTable[(crc ^ buffer[start++]) & 0xFF] ^ crc >>> 8);
            }
            return ~crc;
        }
        return 0;
    }
    
    private static long Adler32(final long adler, final byte[] buf, int index, int len) {
        if (GLLibConfig.sprite_useDynamicPng) {
            long s1 = adler & 0xFFFFL;
            long s2 = adler >> 16 & 0xFFFFL;
            while (len > 0) {
                int k = (len < 5552) ? len : 5552;
                len -= k;
                while (k-- > 0) {
                    s1 += (buf[index++] & 0xFF);
                    s2 += s1;
                }
                s1 %= 65521L;
                s2 %= 65521L;
            }
            return s2 << 16 | s1;
        }
        return 0L;
    }
    
    private int[] DecodeImageAndResize(final int module) {
        final int[] img_data = this.DecodeImage_int(module);
        final Graphics g = null;
        if (ASprite.s_resizeType == 2) {}
        return this.Resize(g, img_data, this.GetModuleWidthOrg(module), this.GetModuleHeightOrg(module), this._modules_w_scaled[module], this._modules_h_scaled[module]);
    }
    
    private int[] Resize(final Graphics g, final int[] bTemp, final int nTempWidth, final int nTempHeight, final int nWidth, final int nHeight) {
        return bTemp;
    }
    
    public void SetResizeParameters(final int spriteId, final int resizeMode, final boolean correctY) {
        ASprite.s_bBilinear = true;
        ASprite.s_bAspectRatio = true;
        this.mResizeCorrectY = correctY;
        if (ASprite.mResizeRef == 0) {
            this.wRef = 240;
            this.hRef = 320;
        }
        else if (ASprite.mResizeRef == 1) {
            this.wRef = 176;
            this.hRef = 220;
        }
        else if (ASprite.mResizeRef == 2) {
            this.wRef = 280;
            this.hRef = 320;
        }
        else {
            this.wRef = 176;
            this.hRef = 220;
        }
        this.wTarget = GLLib.GetScreenWidth();
        this.hTarget = GLLib.GetScreenHeight();
        ASprite.s_resizeType = resizeMode;
        if (ASprite.s_bAspectRatio) {
            this.xRatio = (this.wTarget << 16) / this.wRef;
            this.yRatio = (this.hTarget << 16) / this.hRef;
        }
    }
    
    public int scaleX(final int x) {
        int retVal = 0;
        if (ASprite.s_bAspectRatio && this.yRatio > this.xRatio) {
            retVal = x * this.yRatio >> 16;
        }
        else {
            retVal = x * this.wTarget / this.wRef;
        }
        if (retVal == 0) {
            if (x < 0) {
                return -1;
            }
            if (x > 0) {
                return 1;
            }
        }
        return retVal;
    }
    
    public int scaleY(final int y) {
        int retVal = 0;
        if (ASprite.s_bAspectRatio && this.xRatio > this.yRatio) {
            retVal = y * this.xRatio >> 16;
        }
        else {
            retVal = y * this.hTarget / this.hRef;
        }
        if (retVal == 0) {
            if (y < 0) {
                return -1;
            }
            if (y > 0) {
                return 1;
            }
        }
        return retVal;
    }
    
    public void ResizeCoords() {
        this._modules_w_scaled = new short[this._nModules];
        this._modules_h_scaled = new short[this._nModules];
        for (int i = 0; i < this._nModules; ++i) {
            this._modules_w_scaled[i] = (short)this.scaleX(this.GetModuleWidthOrg(i));
            this._modules_h_scaled[i] = (short)this.scaleY(this.GetModuleHeightOrg(i));
        }
        for (int frame = 0; frame < this._frames_nfm.length; ++frame) {
            for (int nFModules = this._frames_nfm[frame] & 0xFF, fmodule = 0; fmodule < nFModules; ++fmodule) {
                if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                    final int off = (this._frames_fm_start[frame] + fmodule) * 5;
                    this._fmodules[off + 1] = (byte)this.scaleX(this._fmodules[off + 1]);
                    this._fmodules[off + 2] = (byte)this.scaleY(this._fmodules[off + 2]);
                }
                else {
                    final int off = this._frames_fm_start[frame] + fmodule;
                    if (GLLibConfig.sprite_useAfOffShort) {
                        this._fmodules_ox_short[off] = (short)this.scaleX(this._fmodules_ox_short[off]);
                        this._fmodules_oy_short[off] = (short)this.scaleY(this._fmodules_oy_short[off]);
                    }
                    else {
                        this._fmodules_ox_byte[off] = (byte)this.scaleX(this._fmodules_ox_byte[off]);
                        this._fmodules_oy_byte[off] = (byte)this.scaleY(this._fmodules_oy_byte[off]);
                    }
                }
            }
        }
        if (this.mResizeCorrectY) {
            for (int frame = 0; frame < this._frames_nfm.length; ++frame) {
                for (int nFModules = this._frames_nfm[frame] & 0xFF, fmodule = 1; fmodule < nFModules; ++fmodule) {
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        final int off = (this._frames_fm_start[frame] + fmodule - 1) * 5;
                        final int off2 = (this._frames_fm_start[frame] + fmodule) * 5;
                        this._fmodules[off2 + 2] = (byte)(this._fmodules[off + 2] + this._modules_h_scaled[this._fmodules[off]]);
                    }
                    else {
                        final int off = this._frames_fm_start[frame] + fmodule - 1;
                        final int off2 = this._frames_fm_start[frame] + fmodule;
                        if (GLLibConfig.sprite_useAfOffShort) {
                            this._fmodules_oy_short[off2] = (short)(this._fmodules_oy_short[off] + this._modules_h_scaled[this._fmodules_id[off]]);
                        }
                        else {
                            this._fmodules_oy_byte[off2] = (byte)(this._fmodules_oy_byte[off] + this._modules_h_scaled[this._fmodules_id[off]]);
                        }
                    }
                }
            }
        }
    }
    
    public static void InitCachePool(final int poolCount) {
        if (GLLibConfig.sprite_useCachePool) {
            ASprite._poolCacheStack = new short[poolCount][];
            ASprite._poolCacheSprites = new ASprite[poolCount][];
            ASprite._poolCacheStackIndex = new int[poolCount];
            ASprite._poolCacheStackMax = new int[poolCount];
        }
    }
    
    public static void InitPoolSize(final int poolIndex, final int size) {
        if (GLLibConfig.sprite_useCachePool) {
            ASprite._poolCacheStackMax[poolIndex] = size;
            ASprite._poolCacheStack[poolIndex] = new short[size];
            ASprite._poolCacheSprites[poolIndex] = new ASprite[size];
            for (int i = 0; i < ASprite._poolCacheStack[poolIndex].length; ++i) {
                ASprite._poolCacheStack[poolIndex][i] = -1;
            }
        }
    }
    
    public static void ResetCachePool(final int poolIndex) {
        if (GLLibConfig.sprite_useCachePool) {
            ASprite._poolCacheStack[poolIndex] = null;
            ASprite._poolCacheSprites[poolIndex] = null;
            ASprite._poolCacheStackIndex[poolIndex] = 0;
            ASprite._poolCacheStackMax[poolIndex] = 0;
        }
    }
    
    public void SetPool(final int poolIndex) {
        if (GLLibConfig.sprite_useCachePool) {
            this._cur_pool = poolIndex;
            if (GLLibConfig.sprite_useDynamicPng) {
                GLLib.Dbg("WARNING_SetPool : The cache pool is nonsupport with GLLibConfig.sprite_useDynamicPng src\\ASprite\\ASprite_CachePool.jpp   77");
            }
            else if (GLLibConfig.sprite_useNokiaUI) {
                if (this._modules_image_shortAAA == null) {
                    this._modules_image_shortAAA = new short[this._palettes][][];
                    for (int i = 0; i < this._palettes; ++i) {
                        this._modules_image_shortAAA[i] = new short[this._nModules][];
                    }
                }
            }
            else if (GLLibConfig.sprite_useCacheRGBArrays || GLLibConfig.sprite_RGBArraysUseDrawRGB) {
                GLLib.Dbg("WARNING_SetPool : The cache pool is nonsupport with GLLibConfig.sprite_useCacheRGBArrays src\\ASprite\\ASprite_CachePool.jpp   96");
            }
            else if (this._module_image_imageAA == null) {
                this._module_image_imageAA = new Image[this._palettes][];
                for (int i = 0; i < this._palettes; ++i) {
                    this._module_image_imageAA[i] = new Image[this._nModules];
                }
            }
        }
    }
    
    private void UpdatePoolCache(final int module, final Object cached) {
        if (GLLibConfig.sprite_useCachePool && this._cur_pool >= 0) {
            if (GLLibConfig.sprite_useNokiaUI) {
                if (this._modules_image_shortAAA[this._crt_pal][module] != null) {
                    return;
                }
            }
            else if (this._module_image_imageAA[this._crt_pal][module] != null) {
                return;
            }
            final int cur_index = ASprite._poolCacheStackIndex[this._cur_pool];
            final int img_index = ASprite._poolCacheStack[this._cur_pool][cur_index];
            final int img_pal = img_index >> 10;
            final int img_module = img_index & 0x3FF;
            if (img_index >= 0) {
                final ASprite sprite = ASprite._poolCacheSprites[this._cur_pool][cur_index];
                if (sprite != null) {
                    if (GLLibConfig.sprite_useNokiaUI) {
                        sprite._modules_image_shortAAA[img_pal][img_module] = null;
                    }
                    else {
                        sprite._module_image_imageAA[img_pal][img_module] = null;
                    }
                }
            }
            final short fake_module = (short)((module & 0x3FF) + (this._crt_pal << 10));
            ASprite._poolCacheStack[this._cur_pool][cur_index] = fake_module;
            ASprite._poolCacheSprites[this._cur_pool][cur_index] = this;
            ASprite._poolCacheStackIndex[this._cur_pool] = (ASprite._poolCacheStackIndex[this._cur_pool] + 1) % ASprite._poolCacheStackMax[this._cur_pool];
            if (GLLibConfig.sprite_useNokiaUI) {
                this._modules_image_shortAAA[this._crt_pal][module] = (short[])cached;
            }
            else {
                this._module_image_imageAA[this._crt_pal][module] = (Image)cached;
            }
        }
    }
    
    Object DecodeImage(final int module) {
        if (GLLibConfig.sprite_useCreateRGB) {
            return this.DecodeImage_int(module);
        }
        if (GLLibConfig.sprite_useNokiaUI) {
            return this.DecodeImage_short(module);
        }
        return this.DecodeImage_byte(module);
    }
    
    private int[] DecodeImage_int(final int module) {
        if (!GLLibConfig.sprite_useCreateRGB) {
            return null;
        }
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            if (this._modules_data_off_short == null) {
                return null;
            }
        }
        else if (this._modules_data_off_int == null) {
            return null;
        }
        if (this._modules_data == null) {
            return null;
        }
        if (GLLibConfig.sprite_useResize && ASprite.s_resizeType != 0 && (this._modules_w_scaled[module] != this.GetModuleWidthOrg(module) || this._modules_h_scaled[module] != this.GetModuleHeightOrg(module))) {
            return this.DecodeImageAndResize(module);
        }
        this.DecodeImage_Algorithm(this._modules_data, this.getStartModuleData(module, 0), this.GetModuleWidth(module), this.GetModuleHeight(module));
        return ASprite.temp_int;
    }
    
    private short[] DecodeImage_short(final int module) {
        if (!GLLibConfig.sprite_useNokiaUI) {
            return null;
        }
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            if (this._modules_data_off_short == null) {
                return null;
            }
        }
        else if (this._modules_data_off_int == null) {
            return null;
        }
        if (this._modules_data == null) {
            return null;
        }
        this.DecodeImage_Algorithm(this._modules_data, this.getStartModuleData(module, 0), this.GetModuleWidth(module), this.GetModuleHeight(module));
        return ASprite.temp_short;
    }
    
    private byte[] DecodeImage_byte(final int module) {
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            if (this._modules_data_off_short == null) {
                GLLib.Dbg("DecodeImage_byte : returning null, because _modules_data_off_short is null");
                return null;
            }
        }
        else if (this._modules_data_off_int == null) {
            GLLib.Dbg("DecodeImage_byte : returning null, because _modules_data_off_int is null");
            return null;
        }
        if (this._modules_data == null) {
            GLLib.Dbg("DecodeImage_byte : returning null, because _modules_data is null");
            return null;
        }
        this.DecodeImage_Algorithm(this._modules_data, this.getStartModuleData(module, 0), this.GetModuleWidth(module), this.GetModuleHeight(module));
        return ASprite.temp_byte;
    }
    
    private byte[] DecodeImage_byte(final byte[] image, final int offset, final int sizeX, final int sizeY) {
        this.DecodeImage_Algorithm(image, offset, sizeX, sizeY);
        return ASprite.temp_byte;
    }
    
    private void DecodeImage_Algorithm(final byte[] image, int si, final int sizeX, final int sizeY) {
        int di = 0;
        final int ds = sizeX * sizeY;
        if (GLLibConfig.sprite_useCreateRGB) {
            if (ASprite.temp_int == null) {
                ASprite.temp_int = new int[GLLibConfig.TMP_BUFFER_SIZE];
            }
            if (sizeX * sizeY > ASprite.temp_int.length) {
                GLLib.Assert(false, "ERROR: sizeX x sizeY > temp_int.length (" + sizeX + " x " + sizeY + " = " + sizeX * sizeY + " > " + ASprite.temp_int.length + ") !!!");
            }
        }
        else if (GLLibConfig.sprite_useNokiaUI) {
            if (ASprite.temp_short == null) {
                ASprite.temp_short = new short[GLLibConfig.TMP_BUFFER_SIZE];
            }
            if (sizeX * sizeY > ASprite.temp_short.length) {
                GLLib.Assert(false, "ERROR: sizeX x sizeY > temp_short.length (" + sizeX + " x " + sizeY + " = " + sizeX * sizeY + " > " + ASprite.temp_short.length + ") !!!");
            }
        }
        else {
            if (ASprite.temp_byte == null) {
                ASprite.temp_byte = new byte[GLLibConfig.TMP_BUFFER_SIZE];
            }
            if (sizeX * sizeY > ASprite.temp_byte.length) {
                GLLib.Assert(false, "ERROR: sizeX x sizeY > temp_byte.length (" + sizeX + " x " + sizeY + " = " + sizeX * sizeY + " > " + ASprite.temp_byte.length + ") !!!");
            }
        }
        short[] pal_short = null;
        int[] pal_int = null;
        if (GLLibConfig.sprite_useNokiaUI) {
            if (this._pal_short == null) {
                return;
            }
            pal_short = this._pal_short[this._crt_pal];
        }
        if (GLLibConfig.sprite_useCreateRGB) {
            if (this._pal_int == null) {
                return;
            }
            pal_int = this._pal_int[this._crt_pal];
        }
        int clr_int = 0;
        short clr_short = 0;
        byte clr_byte = 0;
        if (GLLibConfig.sprite_useEncodeFormatI64RLE && this._data_format == 25840) {
            while (di < ds) {
                int c = image[si++] & 0xFF;
                if (GLLibConfig.sprite_useCreateRGB) {
                    clr_int = pal_int[c & this._i64rle_color_mask];
                }
                else if (GLLibConfig.sprite_useNokiaUI) {
                    clr_short = pal_short[c & this._i64rle_color_mask];
                }
                else {
                    clr_byte = (byte)(c & this._i64rle_color_mask);
                }
                c >>= this._i64rle_color_bits;
                while (c-- >= 0) {
                    if (GLLibConfig.sprite_useCreateRGB) {
                        ASprite.temp_int[di++] = clr_int;
                    }
                    else if (GLLibConfig.sprite_useNokiaUI) {
                        ASprite.temp_short[di++] = clr_short;
                    }
                    else {
                        ASprite.temp_byte[di++] = clr_byte;
                    }
                }
            }
        }
        else if (GLLibConfig.sprite_useEncodeFormatI127RLE && this._data_format == 10225) {
            while (di < ds) {
                int c = image[si++] & 0xFF;
                if (c > 127) {
                    final int c2 = image[si++] & 0xFF;
                    if (GLLibConfig.sprite_useCreateRGB) {
                        clr_int = pal_int[c2];
                    }
                    else if (GLLibConfig.sprite_useNokiaUI) {
                        clr_short = pal_short[c2];
                    }
                    else {
                        clr_byte = (byte)c2;
                    }
                    c -= 128;
                    while (c-- > 0) {
                        if (GLLibConfig.sprite_useCreateRGB) {
                            ASprite.temp_int[di++] = clr_int;
                        }
                        else if (GLLibConfig.sprite_useNokiaUI) {
                            ASprite.temp_short[di++] = clr_short;
                        }
                        else {
                            ASprite.temp_byte[di++] = clr_byte;
                        }
                    }
                }
                else if (GLLibConfig.sprite_useCreateRGB) {
                    ASprite.temp_int[di++] = pal_int[c];
                }
                else if (GLLibConfig.sprite_useNokiaUI) {
                    ASprite.temp_short[di++] = pal_short[c];
                }
                else {
                    ASprite.temp_byte[di++] = (byte)c;
                }
            }
        }
        else if (GLLibConfig.sprite_useEncodeFormatI256RLE && this._data_format == 22258) {
            while (di < ds) {
                int c = image[si++] & 0xFF;
                if (c > 127) {
                    c -= 128;
                    while (c-- > 0) {
                        if (GLLibConfig.sprite_useCreateRGB) {
                            ASprite.temp_int[di++] = pal_int[image[si++] & 0xFF];
                        }
                        else if (GLLibConfig.sprite_useNokiaUI) {
                            ASprite.temp_short[di++] = pal_short[image[si++] & 0xFF];
                        }
                        else {
                            ASprite.temp_byte[di++] = (byte)(image[si++] & 0xFF);
                        }
                    }
                }
                else {
                    if (GLLibConfig.sprite_useCreateRGB) {
                        clr_int = pal_int[image[si++] & 0xFF];
                    }
                    else if (GLLibConfig.sprite_useNokiaUI) {
                        clr_short = pal_short[image[si++] & 0xFF];
                    }
                    else {
                        clr_byte = (byte)(image[si++] & 0xFF);
                    }
                    while (c-- > 0) {
                        if (GLLibConfig.sprite_useCreateRGB) {
                            ASprite.temp_int[di++] = clr_int;
                        }
                        else if (GLLibConfig.sprite_useNokiaUI) {
                            ASprite.temp_short[di++] = clr_short;
                        }
                        else {
                            ASprite.temp_byte[di++] = clr_byte;
                        }
                    }
                }
            }
        }
        else if (GLLibConfig.sprite_useEncodeFormatI16 && this._data_format == 5632) {
            while (di < ds) {
                final int c = image[si++];
                if (GLLibConfig.sprite_useCreateRGB) {
                    ASprite.temp_int[di++] = pal_int[c >> 4 & 0xF];
                    ASprite.temp_int[di++] = pal_int[c & 0xF];
                }
                else if (GLLibConfig.sprite_useNokiaUI) {
                    ASprite.temp_short[di++] = pal_short[c >> 4 & 0xF];
                    ASprite.temp_short[di++] = pal_short[c & 0xF];
                }
                else {
                    ASprite.temp_byte[di++] = (byte)(c >> 4 & 0xF);
                    ASprite.temp_byte[di++] = (byte)(c & 0xF);
                }
            }
        }
        else if (GLLibConfig.sprite_useEncodeFormatI4 && this._data_format == 1024) {
            while (di < ds) {
                final int c = image[si++];
                if (GLLibConfig.sprite_useCreateRGB) {
                    ASprite.temp_int[di++] = pal_int[c >> 6 & 0x3];
                    ASprite.temp_int[di++] = pal_int[c >> 4 & 0x3];
                    ASprite.temp_int[di++] = pal_int[c >> 2 & 0x3];
                    ASprite.temp_int[di++] = pal_int[c & 0x3];
                }
                else if (GLLibConfig.sprite_useNokiaUI) {
                    ASprite.temp_short[di++] = pal_short[c >> 6 & 0x3];
                    ASprite.temp_short[di++] = pal_short[c >> 4 & 0x3];
                    ASprite.temp_short[di++] = pal_short[c >> 2 & 0x3];
                    ASprite.temp_short[di++] = pal_short[c & 0x3];
                }
                else {
                    ASprite.temp_byte[di++] = (byte)(c >> 6 & 0x3);
                    ASprite.temp_byte[di++] = (byte)(c >> 4 & 0x3);
                    ASprite.temp_byte[di++] = (byte)(c >> 2 & 0x3);
                    ASprite.temp_byte[di++] = (byte)(c & 0x3);
                }
            }
        }
        else if (GLLibConfig.sprite_useEncodeFormatI2 && this._data_format == 512) {
            while (di < ds) {
                final int c = image[si++];
                if (GLLibConfig.sprite_useCreateRGB) {
                    ASprite.temp_int[di++] = pal_int[c >> 7 & 0x1];
                    ASprite.temp_int[di++] = pal_int[c >> 6 & 0x1];
                    ASprite.temp_int[di++] = pal_int[c >> 5 & 0x1];
                    ASprite.temp_int[di++] = pal_int[c >> 4 & 0x1];
                    ASprite.temp_int[di++] = pal_int[c >> 3 & 0x1];
                    ASprite.temp_int[di++] = pal_int[c >> 2 & 0x1];
                    ASprite.temp_int[di++] = pal_int[c >> 1 & 0x1];
                    ASprite.temp_int[di++] = pal_int[c & 0x1];
                }
                else if (GLLibConfig.sprite_useNokiaUI) {
                    ASprite.temp_short[di++] = pal_short[c >> 7 & 0x1];
                    ASprite.temp_short[di++] = pal_short[c >> 6 & 0x1];
                    ASprite.temp_short[di++] = pal_short[c >> 5 & 0x1];
                    ASprite.temp_short[di++] = pal_short[c >> 4 & 0x1];
                    ASprite.temp_short[di++] = pal_short[c >> 3 & 0x1];
                    ASprite.temp_short[di++] = pal_short[c >> 2 & 0x1];
                    ASprite.temp_short[di++] = pal_short[c >> 1 & 0x1];
                    ASprite.temp_short[di++] = pal_short[c & 0x1];
                }
                else {
                    ASprite.temp_byte[di++] = (byte)(c >> 7 & 0x1);
                    ASprite.temp_byte[di++] = (byte)(c >> 6 & 0x1);
                    ASprite.temp_byte[di++] = (byte)(c >> 5 & 0x1);
                    ASprite.temp_byte[di++] = (byte)(c >> 4 & 0x1);
                    ASprite.temp_byte[di++] = (byte)(c >> 3 & 0x1);
                    ASprite.temp_byte[di++] = (byte)(c >> 2 & 0x1);
                    ASprite.temp_byte[di++] = (byte)(c >> 1 & 0x1);
                    ASprite.temp_byte[di++] = (byte)(c & 0x1);
                }
            }
        }
        else if (GLLibConfig.sprite_useEncodeFormatI256 && this._data_format == 22018) {
            while (di < ds) {
                if (GLLibConfig.sprite_useCreateRGB) {
                    ASprite.temp_int[di++] = pal_int[image[si++] & 0xFF];
                }
                else if (GLLibConfig.sprite_useNokiaUI) {
                    ASprite.temp_short[di++] = pal_short[image[si++] & 0xFF];
                }
                else {
                    ASprite.temp_byte[di++] = (byte)(image[si++] & 0xFF);
                }
            }
        }
        else {
            switch (this._data_format) {
                case 512: {
                    GLLib.Dbg("    -. ENCODE_FORMAT_I2");
                    break;
                }
                case 1024: {
                    GLLib.Dbg("    -. ENCODE_FORMAT_I4");
                    break;
                }
                case 5632: {
                    GLLib.Dbg("    -. ENCODE_FORMAT_I16");
                    break;
                }
                case 22018: {
                    GLLib.Dbg("    -. ENCODE_FORMAT_I256");
                    break;
                }
                case 25840: {
                    GLLib.Dbg("    -. ENCODE_FORMAT_I64RLE");
                    break;
                }
                case 10225: {
                    GLLib.Dbg("    -. ENCODE_FORMAT_I127RLE");
                    break;
                }
                case 22258: {
                    GLLib.Dbg("    -. ENCODE_FORMAT_I256RLE");
                    break;
                }
            }
            GLLib.Assert(false, "ERROR : sprite encoding Not Enabled, look at your configuration. Encoding requested : " + this._data_format);
        }
        if (GLLibConfig.sprite_useBugFixImageOddSize) {
            if (GLLibConfig.sprite_useCreateRGB) {
                clr_int = 0;
                for (int color = 0; color < this._pal_int[0].length; ++color) {
                    if (this._pal_int[0][color] >> 24 == 0) {
                        clr_int = color;
                        break;
                    }
                }
            }
            else if (GLLibConfig.sprite_useNokiaUI) {
                clr_short = 0;
                for (int color = 0; color < this._pal_short[0].length; ++color) {
                    if (this._pal_short[0][color] >> 24 == 0) {
                        clr_short = (short)color;
                        break;
                    }
                }
            }
            else {
                clr_byte = 0;
                for (int color = 0; color < this._pal_int[0].length; ++color) {
                    if (this._pal_int[0][color] >> 24 == 0) {
                        clr_byte = (byte)color;
                        break;
                    }
                }
            }
            final int newSizeX = sizeX + sizeX % 2;
            final int newSizeY = sizeY + sizeY % 2;
            if (newSizeY != sizeY) {
                for (int x = 0; x < newSizeX; ++x) {
                    if (GLLibConfig.sprite_useCreateRGB) {
                        ASprite.temp_int[sizeY * newSizeX + x] = clr_int;
                    }
                    else if (GLLibConfig.sprite_useNokiaUI) {
                        ASprite.temp_short[sizeY * newSizeX + x] = clr_short;
                    }
                    else {
                        ASprite.temp_byte[sizeY * newSizeX + x] = clr_byte;
                    }
                }
            }
            for (int y = sizeY - 1; y >= 0; --y) {
                if (GLLibConfig.sprite_useCreateRGB) {
                    System.arraycopy(ASprite.temp_int, sizeX * y, ASprite.temp_int, newSizeX * y, sizeX);
                    if (newSizeX != sizeX) {
                        ASprite.temp_int[y * newSizeX + sizeX] = clr_int;
                    }
                }
                else if (GLLibConfig.sprite_useNokiaUI) {
                    System.arraycopy(ASprite.temp_short, sizeX * y, ASprite.temp_short, newSizeX * y, sizeX);
                    if (newSizeX != sizeX) {
                        ASprite.temp_short[y * newSizeX + sizeX] = clr_short;
                    }
                }
                else {
                    System.arraycopy(ASprite.temp_byte, sizeX * y, ASprite.temp_byte, newSizeX * y, sizeX);
                    if (newSizeX != sizeX) {
                        ASprite.temp_byte[y * newSizeX + sizeX] = clr_byte;
                    }
                }
            }
        }
    }
    
    void DecodeImageToByteArray(final byte[] dest, final int module, final boolean img2dRGBA, final boolean half) {
        if (GLLibConfig.sprite_useModuleDataOffAsShort) {
            if (this._modules_data_off_short == null) {
                return;
            }
        }
        else if (this._modules_data_off_int == null) {
            return;
        }
        if (this._modules_data == null) {
            return;
        }
        final int sizeX = this.GetModuleWidth(module);
        final int sizeY = this.GetModuleHeight(module);
        if (dest == null) {
            return;
        }
        byte[] img_data = dest;
        int bytesPerPixel;
        if (img2dRGBA) {
            bytesPerPixel = 4;
        }
        else {
            bytesPerPixel = 3;
        }
        this.DecodeImage_Algorithm(this._modules_data, this.getStartModuleData(module, 0), sizeX, sizeY);
        if (GLLibConfig.sprite_useCreateRGB) {
            img_data = new byte[sizeX * sizeY * bytesPerPixel];
            for (int j = 0; j < sizeY; ++j) {
                for (int i = 0; i < sizeX; ++i) {
                    final int off = i + j * sizeX;
                    img_data[off * bytesPerPixel + 0] = (byte)(ASprite.temp_int[off] >> 0 & 0xFF);
                    img_data[off * bytesPerPixel + 1] = (byte)(ASprite.temp_int[off] >> 8 & 0xFF);
                    img_data[off * bytesPerPixel + 2] = (byte)(ASprite.temp_int[off] >> 16 & 0xFF);
                    if (bytesPerPixel == 4) {
                        img_data[off * bytesPerPixel + 3] = (byte)(ASprite.temp_int[off] >> 24 & 0xFF);
                    }
                }
            }
            if (ASprite.temp_int == null) {
                ASprite.temp_int = new int[GLLibConfig.TMP_BUFFER_SIZE];
            }
            final int width = sizeX >> 1;
            final int height = sizeY >> 1;
            final int x = 0;
            final int y = 0;
            int a0 = 0;
            int a2 = 0;
            int a3 = 0;
            int a4 = 0;
            int di = 0;
            if (half) {
                for (int k = 0; k < height; ++k) {
                    for (int l = 0; l < width; ++l) {
                        int idx = k * 2 * bytesPerPixel * sizeX + l * 2 * bytesPerPixel;
                        final int r0 = img_data[idx] & 0xFF;
                        final int g0 = img_data[idx + 1] & 0xFF;
                        final int b0 = img_data[idx + 2] & 0xFF;
                        if (bytesPerPixel == 4) {
                            a0 = (img_data[idx + 3] & 0xFF);
                        }
                        idx += bytesPerPixel;
                        final int r2 = img_data[idx] & 0xFF;
                        final int g2 = img_data[idx + 1] & 0xFF;
                        final int b2 = img_data[idx + 2] & 0xFF;
                        if (bytesPerPixel == 4) {
                            a2 = (img_data[idx + 3] & 0xFF);
                        }
                        idx = (k * 2 + 1) * bytesPerPixel * sizeX + l * 2 * bytesPerPixel;
                        final int r3 = img_data[idx] & 0xFF;
                        final int g3 = img_data[idx + 1] & 0xFF;
                        final int b3 = img_data[idx + 2] & 0xFF;
                        if (bytesPerPixel == 4) {
                            a3 = (img_data[idx + 3] & 0xFF);
                        }
                        idx += bytesPerPixel;
                        final int r4 = img_data[idx] & 0xFF;
                        final int g4 = img_data[idx + 1] & 0xFF;
                        final int b4 = img_data[idx + 2] & 0xFF;
                        if (bytesPerPixel == 4) {
                            a4 = (img_data[idx + 3] & 0xFF);
                        }
                        final int r5 = r0 + r2 + r3 + r4 >> 2;
                        final int gr = g0 + g2 + g3 + g4 >> 2;
                        final int b5 = b0 + b2 + b3 + b4 >> 2;
                        final int a5 = a0 + a2 + a3 + a4 >> 2;
                        img_data[di++] = (byte)(r5 & 0xFF);
                        img_data[di++] = (byte)(gr & 0xFF);
                        img_data[di++] = (byte)(b5 & 0xFF);
                        if (bytesPerPixel == 4) {
                            img_data[di++] = (byte)(a5 & 0xFF);
                        }
                    }
                }
            }
        }
    }
    
    public static void SetTempBuffer(final Object pArray) {
        if (pArray instanceof int[]) {
            ASprite.temp_int = (int[])pArray;
        }
        else if (pArray instanceof short[]) {
            ASprite.temp_short = (short[])pArray;
        }
        else {
            ASprite.temp_byte = (byte[])pArray;
        }
    }
    
    static int GetCurrentStringWidth() {
        return ASprite._text_w;
    }
    
    static int GetCurrentStringHeight() {
        return ASprite._text_h;
    }
    
    static void SetCharMapStatic(final byte[] pNewMap) {
        ASprite.s_MapChar = pNewMap;
    }
    
    byte[] GetCharMap() {
        return this._pMapChar;
    }
    
    short[][] GetCharMapShort() {
        return this._pMapCharShort;
    }
    
    void SetCharMap(final byte[] pNewMap) {
        if (!GLLibConfig.sprite_newTextRendering) {
            this._pMapChar = pNewMap;
            this.SetLineSpacingToDefault();
            this.SetSpaceWidthToDefault();
            this.SetLineHeightToDefault();
            this.SetCharSpacingToDefault();
        }
    }
    
    void SetCharMap(final short[] pNewMap) {
        if (GLLibConfig.sprite_newTextRendering) {
            this._nDivider = pNewMap[0];
            this._pMapCharShort = new short[this._nDivider][];
            int index = 1;
            for (int i = 0; i < this._nDivider; ++i) {
                (this._pMapCharShort[i] = new short[2])[0] = pNewMap[index++];
                this._pMapCharShort[i][1] = pNewMap[index++];
            }
            int i = index;
            while (i < pNewMap.length) {
                final int insertIndex = pNewMap[i++];
                final int count = pNewMap[i++];
                final short[] newEntry = new short[count * 2 + 2];
                newEntry[0] = this._pMapCharShort[insertIndex][0];
                newEntry[1] = this._pMapCharShort[insertIndex][1];
                for (int j = 0; j < count; ++j) {
                    newEntry[j * 2 + 2] = pNewMap[i++];
                    newEntry[j * 2 + 3] = pNewMap[i++];
                }
                this._pMapCharShort[insertIndex] = newEntry;
            }
            this.SetDefaultFontMetrics();
        }
    }
    
    int GetCharFrame(final int c) {
        final int index = c % this._nDivider;
        if (this._pMapCharShort[index][0] == c) {
            return this._pMapCharShort[index][1];
        }
        int i;
        int length;
        for (i = 2, length = this._pMapCharShort[index].length; i < length && this._pMapCharShort[index][i] != c; i += 2) {}
        if (i >= length) {
            return 1;
        }
        return this._pMapCharShort[index][i + 1];
    }
    
    void SetDefaultFontMetrics() {
        this._nFontAscent = -this.GetFrameModuleY(0, 0);
        this._nFontDescent = this.GetFrameModuleY(0, 1);
        this.SetLineSpacingToDefault();
        this._nFontHeight = this._nFontAscent + this._nFontDescent;
        this.SetSpaceWidthToDefault();
    }
    
    int GetLineSpacing() {
        return this._nLineSpacing;
    }
    
    void SetLineSpacing(final int spacing) {
        this._nLineSpacing = spacing;
    }
    
    void SetLineSpacingToDefault() {
        if (GLLibConfig.sprite_newTextRendering) {
            this._nLineSpacing = this.GetFrameModuleY(0, 2) - this.GetFrameModuleY(0, 1);
        }
        else {
            this._nLineSpacing = this.GetModuleHeight(0) >> 1;
        }
    }
    
    int GetFontHeight() {
        if (GLLibConfig.sprite_newTextRendering) {
            return this._nFontHeight;
        }
        if (GLLibConfig.sprite_useModuleWHShort) {
            return this._modules_h_short[0] & 0xFF;
        }
        return this._modules_h_byte[0] & 0xFF;
    }
    
    int GetSpaceWidth() {
        return this._nSpaceWidth;
    }
    
    void SetSpaceWidth(final int spacing) {
        this._nSpaceWidth = spacing;
    }
    
    void SetSpaceWidthToDefault() {
        if (GLLibConfig.sprite_newTextRendering) {
            this._nSpaceWidth = this.GetFrameModuleX(this.GetCharFrame(32), 0);
        }
        else {
            this._nSpaceWidth = this.GetModuleWidth(0);
        }
    }
    
    int GetCharSpacing() {
        return this._nCharSpacing;
    }
    
    void SetCharSpacing(final int spacing) {
        this._nCharSpacing = spacing;
    }
    
    void SetCharSpacingToDefault() {
        if (GLLibConfig.sprite_newTextRendering) {
            this._nCharSpacing = 0;
        }
        else if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            this._nCharSpacing = this._fmodules[1];
        }
        else {
            this._nCharSpacing = this.GetFModuleOX(0);
        }
    }
    
    int GetLineHeight() {
        if (GLLibConfig.sprite_newTextRendering) {
            return this._nFontHeight;
        }
        return this._nLineHeight;
    }
    
    void SetLineHeight(final int nHeight) {
        this._nLineHeight = nHeight;
    }
    
    void SetLineHeightToDefault() {
        if (GLLibConfig.sprite_newTextRendering) {
            this._nLineHeight = -this.GetFrameModuleY(0, 0) + this.GetFrameModuleY(0, 1);
        }
        else {
            this._nLineHeight = this.GetModuleHeight(0);
        }
    }
    
    boolean GetUnderline() {
        return this._bUnderline;
    }
    
    void SetUnderline(final boolean bUnderline) {
        this._bUnderline = bUnderline;
    }
    
    boolean GetBold() {
        return this._bBold;
    }
    
    void SetBold(final boolean bBold) {
        this._bBold = bBold;
    }
    
    short[] WraptextB(final String s, final int width, final int height) {
        if (ASprite._warpTextInfo == null) {
            ASprite._warpTextInfo = new short[GLLibConfig.MAX_WRAP_TEXT_INFO];
        }
        final int str_len = s.length();
        final int strLines = str_len * this.GetModuleWidth(1) / width;
        short lineSize = 0;
        short cnt = 1;
        short lastSpacePos = 0;
        boolean bSpaceFound = false;
        short distFromLastSpacePos = 0;
        boolean bold = this._bBold;
        int lines = 0;
        for (int i = 0; i < str_len; ++i) {
            final int c = s.charAt(i);
            if (c == 10) {
                ++lines;
            }
        }
        for (int i = 0; i < str_len; ++i) {
            int c = s.charAt(i);
            if (c == 32) {
                lineSize += (short)this.GetSpaceWidth();
                lastSpacePos = (short)i;
                bSpaceFound = true;
                distFromLastSpacePos = 0;
                if (lineSize > width) {
                    bSpaceFound = false;
                    for (int pos = lastSpacePos; pos >= 0 && s.charAt(pos) == ' '; --pos, lineSize -= (short)this.GetSpaceWidth()) {}
                    while (lastSpacePos < str_len && s.charAt(lastSpacePos) == ' ') {
                        ++lastSpacePos;
                    }
                    lastSpacePos = (short)(i = (short)(lastSpacePos - 1));
                    final short[] warpTextInfo = ASprite._warpTextInfo;
                    final short n = cnt;
                    ++cnt;
                    warpTextInfo[n] = (short)(lastSpacePos + 1);
                    final short[] warpTextInfo2 = ASprite._warpTextInfo;
                    final short n2 = cnt;
                    ++cnt;
                    warpTextInfo2[n2] = (short)(lineSize - distFromLastSpacePos);
                    lineSize = 0;
                }
            }
            else if (GLLibConfig.sprite_fontBackslashChangePalette && c == 92) {
                ++i;
                if (s.charAt(i) == '^') {
                    bold = !bold;
                }
            }
            else if (c == 10) {
                final short[] warpTextInfo3 = ASprite._warpTextInfo;
                final short n3 = cnt;
                ++cnt;
                warpTextInfo3[n3] = (short)i;
                final short[] warpTextInfo4 = ASprite._warpTextInfo;
                final short n4 = cnt;
                ++cnt;
                warpTextInfo4[n4] = lineSize;
                lineSize = 0;
                distFromLastSpacePos = 0;
            }
            else {
                if (c < 32) {
                    if (c == 1) {
                        ++i;
                        continue;
                    }
                    if (c != 2) {
                        continue;
                    }
                    ++i;
                    c = s.charAt(i);
                }
                else if (GLLibConfig.sprite_newTextRendering) {
                    c = this.GetCharFrame((short)(c & 0xFFFF));
                }
                else {
                    c = (this._pMapChar[c] & 0xFF);
                }
                int charSize;
                if (GLLibConfig.sprite_newTextRendering) {
                    if (c > this.GetFrameCount()) {
                        if (GLLibConfig.sprite_debugErrors) {
                            System.out.println("Character not available: c = " + c);
                        }
                        c = 0;
                    }
                    charSize = this.GetFrameModuleX(c, 0) + this.GetCharSpacing();
                }
                else if (GLLibConfig.sprite_fontUseOneFramePerLetter) {
                    this.GetFrameRect(this.nALetterRect, c, 0, 0, 0);
                    charSize = this.nALetterRect[2] - this.nALetterRect[0];
                    charSize += this.GetCharSpacing();
                }
                else {
                    if (c >= this.GetFModules(0)) {
                        if (GLLibConfig.sprite_debugErrors) {
                            System.out.println("Character not available: c = " + c);
                        }
                        c = 0;
                    }
                    int m;
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        m = (this._fmodules[c << 2] & 0xFF);
                    }
                    else {
                        m = (this._fmodules_id[c] & 0xFF);
                    }
                    if (m >= this._nModules) {
                        if (GLLibConfig.sprite_debugErrors) {
                            System.out.println("Character module not available: c = " + c + "  m = " + (m >> 1));
                        }
                        m = 0;
                        c = 0;
                    }
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        charSize = this.GetModuleWidth(m) - this._fmodules[(c << 2) + 1] + this.GetCharSpacing();
                    }
                    else {
                        charSize = this.GetModuleWidth(m) - this.GetFModuleOX(c) + this.GetCharSpacing();
                    }
                }
                if (bold) {
                    ++charSize;
                }
                distFromLastSpacePos += (short)charSize;
                lineSize += (short)charSize;
                if (lineSize > width && bSpaceFound) {
                    bSpaceFound = false;
                    for (int pos2 = lastSpacePos; pos2 >= 0 && s.charAt(pos2) == ' '; --pos2, lineSize -= (short)this.GetSpaceWidth()) {}
                    final short[] warpTextInfo5 = ASprite._warpTextInfo;
                    final short n5 = cnt;
                    ++cnt;
                    warpTextInfo5[n5] = (short)(lastSpacePos + 1);
                    final short[] warpTextInfo6 = ASprite._warpTextInfo;
                    final short n6 = cnt;
                    ++cnt;
                    warpTextInfo6[n6] = (short)(lineSize - distFromLastSpacePos);
                    lineSize = 0;
                    i = lastSpacePos;
                }
            }
        }
        if (lineSize != 0) {
            final short[] warpTextInfo7 = ASprite._warpTextInfo;
            final short n7 = cnt;
            ++cnt;
            warpTextInfo7[n7] = (short)str_len;
            final short[] warpTextInfo8 = ASprite._warpTextInfo;
            final short n8 = cnt;
            ++cnt;
            warpTextInfo8[n8] = lineSize;
        }
        ASprite._warpTextInfo[0] = (short)(cnt / 2);
        return ASprite._warpTextInfo;
    }
    
    byte[] TextFitToFixedWidth(final byte[] str, final int text_w) {
        final String s = this.TextFitToFixedWidth(new String(str), text_w);
        return s.getBytes();
    }
    
    String TextFitToFixedWidth(final String str, final int text_w) {
        String string_ret = "";
        int lastEnter = 0;
        final short[] ret = this.WraptextB(str, text_w, 0);
        for (int i = 0; i < ret[0]; ++i) {
            if (lastEnter != 0 && str.charAt(lastEnter) != '\n') {
                string_ret += "\n";
            }
            string_ret += str.substring(lastEnter, ret[(i << 1) + 1]);
            lastEnter = ret[(i << 1) + 1];
        }
        return string_ret;
    }
    
    void DrawPageB(final Graphics g, final String s, final short[] info, final int x, int y, final int startLine, int maxLines, final int anchor) {
        final int lines = info[0];
        final int maxchar = this.GetLineHeight();
        if (maxLines == -1) {
            maxLines = lines;
        }
        if (startLine + maxLines > lines) {
            maxLines = lines - startLine;
        }
        final int th = this.GetLineSpacing() + maxchar;
        if ((anchor & 0x20) != 0x0) {
            y -= th * (maxLines - 1);
        }
        else if ((anchor & 0x2) != 0x0) {
            y -= th * (maxLines - 1) >> 1;
        }
        this._old_pal = this._crt_pal;
        for (int k = 0, j = startLine; j < lines && k <= maxLines - 1; ++j, ++k) {
            ASprite._index1 = ((j > 0) ? info[(j - 1) * 2 + 1] : 0);
            ASprite._index2 = info[j * 2 + 1];
            if (ASprite._index1 < s.length() && s.charAt(ASprite._index1) == '\n') {
                ++ASprite._index1;
            }
            int xx = x;
            int yy = y + k * th;
            if ((anchor & 0x2B) != 0x0) {
                if ((anchor & 0x8) != 0x0) {
                    xx -= info[(j + 1) * 2];
                }
                else if ((anchor & 0x1) != 0x0) {
                    xx -= info[(j + 1) * 2] >> 1;
                }
                if ((anchor & 0x20) != 0x0) {
                    if (GLLibConfig.sprite_newTextRendering) {
                        yy -= this.GetLineHeight();
                    }
                    else {
                        yy -= this.GetModuleHeight(1);
                    }
                }
                else if ((anchor & 0x2) != 0x0) {
                    if (GLLibConfig.sprite_newTextRendering) {
                        yy -= this.GetLineHeight() >> 1;
                    }
                    else {
                        yy -= this.GetModuleHeight(1) >> 1;
                    }
                }
            }
            this.DrawString(g, s, xx, yy, 0, false);
        }
        ASprite._index1 = -1;
        ASprite._index2 = -1;
        this._crt_pal = this._old_pal;
        if (GLLibConfig.sprite_useDrawStringSleep) {
            try {
                Thread.sleep(GLLibConfig.SLEEP_DRAWSTRINGB);
            }
            catch (final Exception ex) {}
        }
    }
    
    static void SetSubString(final int i1, final int i2) {
        ASprite._index1 = i1;
        ASprite._index2 = i2;
    }
    
    void UpdateStringSize(final byte[] bs) {
        this.UpdateStringSize(new String(bs));
    }
    
    void UpdateStringSize(final String s) {
        this.UpdateStringOrCharsSize(s, null);
    }
    
    void UpdateStringOrCharsSize(final String s, final char[] charBuff) {
        if (s == null && charBuff == null) {
            return;
        }
        ASprite._text_w = 0;
        ASprite._text_h = this.GetLineHeight();
        int tw = 0;
        final boolean isDrawString = s != null;
        final int index1 = (ASprite._index1 >= 0) ? ASprite._index1 : 0;
        int index2;
        if (isDrawString) {
            index2 = ((ASprite._index2 >= 0) ? ASprite._index2 : s.length());
        }
        else {
            index2 = ((ASprite._index2 >= 0) ? ASprite._index2 : charBuff.length);
        }
        boolean bold = this._bBold;
        for (int i = index1; i < index2; ++i) {
            int c = isDrawString ? s.charAt(i) : charBuff[i];
            if (GLLibConfig.sprite_fontBackslashChangePalette && c == 92) {
                ++i;
                if ((isDrawString ? s.charAt(i) : charBuff[i]) == '^') {
                    bold = !bold;
                }
            }
            else {
                if (c > 32) {
                    if (GLLibConfig.sprite_debugErrors) {
                        if (GLLibConfig.sprite_newTextRendering) {
                            if (c > this.GetFrameCount()) {
                                System.out.println("Unknown char: " + c);
                                c = 0;
                            }
                            if (this._pMapCharShort == null) {
                                System.out.println("ERROR: _pMapCharShort is null !!!");
                                break;
                            }
                        }
                        else {
                            if (c > 255) {
                                System.out.println("Unknown char: " + c);
                                c = 0;
                            }
                            if (this._pMapChar == null) {
                                System.out.println("ERROR: _pMapChar is null !!!");
                                break;
                            }
                        }
                    }
                    if (GLLibConfig.sprite_newTextRendering) {
                        c = this.GetCharFrame(c);
                    }
                    else {
                        c = (this._pMapChar[c] & 0xFF);
                    }
                }
                else {
                    if (c == 32) {
                        tw += this.GetSpaceWidth();
                        continue;
                    }
                    if (c == 10) {
                        if (tw > ASprite._text_w) {
                            ASprite._text_w = tw;
                        }
                        tw = 0;
                        ASprite._text_h += this.GetLineSpacing() + this.GetLineHeight();
                        continue;
                    }
                    if (c == 1) {
                        ++i;
                        continue;
                    }
                    if (c != 2) {
                        continue;
                    }
                    ++i;
                    c = (isDrawString ? s.charAt(i) : charBuff[i]);
                }
                if (GLLibConfig.sprite_newTextRendering) {
                    if (GLLibConfig.sprite_debugErrors && c > this.GetFrameCount()) {
                        System.out.println("Character not available: c = " + c);
                        c = 0;
                    }
                    tw += this.GetFrameModuleX(c, 0);
                }
                else if (GLLibConfig.sprite_fontUseOneFramePerLetter) {
                    this.GetFrameRect(this.nALetterRect, c, 0, 0, 0);
                    tw += this.nALetterRect[2] - this.nALetterRect[0];
                    tw += this.GetCharSpacing();
                }
                else {
                    if (GLLibConfig.sprite_debugErrors && c >= this.GetFModules(0)) {
                        System.out.println("Character not available: c = " + c);
                        c = 0;
                    }
                    int m;
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        m = (this._fmodules[c << 2] & 0xFF);
                    }
                    else {
                        m = (this._fmodules_id[c] & 0xFF);
                    }
                    if (GLLibConfig.sprite_debugErrors && m >= this._nModules) {
                        System.out.println("Character module not available: c = " + c + "  m = " + m);
                        m = 0;
                        c = 0;
                    }
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        tw += this.GetModuleWidth(m) + this._fmodules[(c << 2) + 1] + this.GetCharSpacing();
                    }
                    else {
                        tw += this.GetModuleWidth(m) + this.GetFModuleOX(c) + this.GetCharSpacing();
                    }
                }
                if (bold) {
                    ++tw;
                }
            }
        }
        if (tw > ASprite._text_w) {
            ASprite._text_w = tw;
        }
        if (GLLibConfig.sprite_newTextRendering) {
            if (ASprite._text_w > 0) {
                ASprite._text_w -= this.GetCharSpacing();
            }
        }
        else if (GLLibConfig.sprite_useSingleArrayForFMAF && ASprite._text_w > 0) {
            ASprite._text_w -= this._fmodules[1];
        }
        else if (ASprite._text_w > 0) {
            ASprite._text_w -= this.GetCharSpacing();
        }
    }
    
    void DrawString(final Graphics g, final byte[] bs, final int x, final int y, final int anchor) {
        this.DrawString(g, new String(bs), x, y, anchor, true);
    }
    
    void DrawString(final Graphics g, final String s, final int x, final int y, final int anchor) {
        this.DrawString(g, s, x, y, anchor, true);
    }
    
    void DrawString(final Graphics g, final byte[] bs, final int x, final int y, final int anchor, final boolean restorecol) {
        this.DrawString(g, new String(bs), x, y, anchor, restorecol);
    }
    
    void DrawString(final Graphics g, final String s, final int x, final int y, final int anchor, final boolean restorecol) {
        this.DrawStringOrChars(g, s, null, x, y, anchor, restorecol);
    }
    
    void DrawStringOrChars(final Graphics g, final String s, final char[] charBuff, int x, int y, final int anchor, final boolean restorecol) {
        GLLib.Profiler_BeginNamedEvent("DrawString");
        if (s == null && charBuff == null) {
            return;
        }
        if (GLLibConfig.sprite_newTextRendering) {
            y += this._nFontAscent;
        }
        else {
            if (GLLibConfig.sprite_fontUseOneFramePerLetter && (!GLLibConfig.sprite_useOperationRecord || !GLLibConfig.sprite_useOperationRect)) {
                GLLib.Assert(false, "DrawString. Configuration flags sprite_useOperationRecord and sprite_useOperationRect must be enabled when using sprite_fontUseOneFramePerLetter");
            }
            if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                y -= this._fmodules[2];
            }
            else {
                y -= this.GetFModuleOY(0);
            }
        }
        final boolean isDrawString = s != null;
        this.UpdateStringOrCharsSize(s, charBuff);
        if ((anchor & 0x2B) != 0x0) {
            if ((anchor & 0x8) != 0x0) {
                x -= ASprite._text_w;
            }
            else if ((anchor & 0x1) != 0x0) {
                x -= ASprite._text_w >> 1;
            }
            if ((anchor & 0x20) != 0x0) {
                y -= ASprite._text_h;
            }
            else if ((anchor & 0x2) != 0x0) {
                y -= ASprite._text_h >> 1;
            }
        }
        int xx = x;
        int yy = y;
        if (restorecol) {
            this._old_pal = this._crt_pal;
        }
        final int index1 = (ASprite._index1 >= 0) ? ASprite._index1 : 0;
        int index2;
        if (isDrawString) {
            index2 = ((ASprite._index2 >= 0) ? ASprite._index2 : s.length());
        }
        else {
            index2 = ((ASprite._index2 >= 0) ? ASprite._index2 : charBuff.length);
        }
        final boolean bTraceFirst = false;
        for (int i = index1; i < index2; ++i) {
            int c = isDrawString ? s.charAt(i) : charBuff[i];
            if (GLLibConfig.sprite_fontBackslashChangePalette && c == 92) {
                ++i;
                final int c2 = isDrawString ? s.charAt(i) : charBuff[i];
                if (c2 == 95) {
                    this._bUnderline = !this._bUnderline;
                }
                else if (c2 == 94) {
                    this._bBold = !this._bBold;
                }
                else {
                    c = (c2 & 0xFF);
                    this.SetCurrentPalette(c - 48);
                }
            }
            else {
                if (c > 32) {
                    if (GLLibConfig.sprite_debugErrors) {
                        if (c > 255) {
                            System.out.println("Unknown char: " + c);
                            c = 0;
                        }
                        if (GLLibConfig.sprite_newTextRendering) {
                            if (this._pMapCharShort == null) {
                                System.out.println("ERROR: _pMapCharShort is null !!!");
                                break;
                            }
                        }
                        else if (this._pMapChar == null) {
                            System.out.println("ERROR: _pMapChar is null !!!");
                            break;
                        }
                    }
                    if (GLLibConfig.sprite_newTextRendering) {
                        c = this.GetCharFrame(c);
                    }
                    else {
                        c = (this._pMapChar[c] & 0xFF);
                    }
                }
                else {
                    if (c == 32) {
                        if (this._bUnderline) {
                            if (GLLibConfig.sprite_newTextRendering) {
                                final int uc = this.GetCharFrame(95);
                                final int ux = xx + (this.GetSpaceWidth() - this.GetFrameModuleX(uc, 0) >> 1);
                                this.PaintFrame(g, uc, ux, yy, 0);
                            }
                            else if (GLLibConfig.sprite_fontUseOneFramePerLetter) {
                                final int uc = this._pMapChar[95] & 0xFF;
                                this.GetFrameRect(this.nALetterRect, uc, 0, 0, 0);
                                final int ux = xx + (this.GetSpaceWidth() - this.nALetterRect[2] >> 1);
                                this.PaintFrame(g, uc, ux, yy, 0, 0, 0);
                            }
                            else {
                                final int uc = this._pMapChar[95] & 0xFF;
                                int um;
                                if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                                    um = (this._fmodules[uc << 2] & 0xFF);
                                }
                                else {
                                    um = (this._fmodules_id[uc] & 0xFF);
                                }
                                final int ux = xx + (this.GetSpaceWidth() - this.GetModuleWidth(um) >> 1);
                                this.PaintFModule(g, 0, uc, ux, yy, 0, 0, 0);
                            }
                        }
                        xx += this.GetSpaceWidth();
                        continue;
                    }
                    if (c == 10) {
                        xx = x;
                        yy += this.GetLineSpacing() + this.GetLineHeight();
                        continue;
                    }
                    if (c == 1) {
                        ++i;
                        final int c2 = isDrawString ? s.charAt(i) : charBuff[i];
                        if (c2 < this._palettes) {
                            this._crt_pal = c2;
                        }
                        if (c2 == 255) {
                            this._crt_pal = this._old_pal;
                        }
                        continue;
                    }
                    else {
                        if (c != 2) {
                            continue;
                        }
                        ++i;
                        c = (isDrawString ? s.charAt(i) : charBuff[i]);
                    }
                }
                if (GLLibConfig.sprite_debugErrors) {
                    if (GLLibConfig.sprite_newTextRendering) {
                        if (c > this.GetFrameCount()) {
                            System.out.println("Character not available: c = " + c);
                            c = 0;
                        }
                    }
                    else if (c >= this.GetFModules(0)) {
                        System.out.println("Character not available: c = " + c);
                        c = 0;
                    }
                }
                if (GLLibConfig.sprite_newTextRendering) {
                    this.PaintFrame(g, c, xx, yy, 0);
                    if (this._bUnderline) {
                        final int uc = this.GetCharFrame(95);
                        final int ux = xx + (this.GetFrameModuleX(c, 0) - this.GetFrameModuleX(uc, 0) >> 1);
                        this.PaintFrame(g, uc, ux, yy, 0);
                    }
                    if (this._bBold) {
                        ++xx;
                        this.PaintFrame(g, c, xx, yy, 0);
                    }
                    xx += this.GetFrameModuleX(c, 0) + this.GetCharSpacing();
                }
                else if (GLLibConfig.sprite_fontUseOneFramePerLetter) {
                    if (this._bUnderline && GLLibConfig.sprite_fontUseOneFramePerLetter) {
                        final int uc = this._pMapChar[95] & 0xFF;
                        this.GetFrameRect(this.nALetterRect, uc, 0, 0, 0);
                        final int ux = xx + (this.GetSpaceWidth() - this.nALetterRect[2] >> 1);
                        this.PaintFrame(g, uc, ux, yy, 0, 0, 0);
                    }
                    this.PaintFrame(g, c, xx, yy, 0, 0, 0);
                    this.GetFrameRect(this.nALetterRect, c, 0, 0, 0);
                    xx += this.nALetterRect[2] - this.nALetterRect[0];
                    xx += this.GetCharSpacing();
                }
                else {
                    int m;
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        m = (this._fmodules[c << 2] & 0xFF);
                    }
                    else {
                        m = (this._fmodules_id[c] & 0xFF);
                    }
                    if (GLLibConfig.sprite_debugErrors && m >= this._nModules) {
                        System.out.println("Character module not available: c = " + c + "  m = " + m);
                        m = 0;
                        c = 0;
                    }
                    if (this._bUnderline) {
                        final int uc = this._pMapChar[95] & 0xFF;
                        int um;
                        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                            um = (this._fmodules[uc << 2] & 0xFF);
                        }
                        else {
                            um = (this._fmodules_id[uc] & 0xFF);
                        }
                        final int ux = xx + (this.GetModuleWidth(m) - this.GetModuleWidth(um) >> 1);
                        this.PaintFModule(g, 0, uc, ux, yy, 0, 0, 0);
                    }
                    this.PaintFModule(g, 0, c, xx, yy, 0, 0, 0);
                    if (GLLibConfig.sprite_useSingleArrayForFMAF) {
                        xx += this.GetModuleWidth(m) + this._fmodules[(c << 2) + 1] + this.GetCharSpacing();
                    }
                    else {
                        xx += this.GetModuleWidth(m) + this.GetFModuleOX(c) + this.GetCharSpacing();
                    }
                }
            }
        }
        if (restorecol) {
            this._crt_pal = this._old_pal;
        }
        GLLib.Profiler_EndNamedEvent();
    }
    
    static int StringTokenize(final String s, final int index1, final int index2, final char token, final int[] indices) {
        int lines = 0;
        indices[0] = index1 - 1;
        for (int i = index1; i < index2; ++i) {
            if (s.charAt(i) == token) {
                indices[++lines] = i;
            }
        }
        indices[++lines] = index2;
        return lines;
    }
    
    void DrawPage(final Graphics g, final byte[] s, final int x, final int y, final int anchor) {
        this.DrawPage(g, new String(s), x, y, anchor, 0, s.length);
    }
    
    void DrawPage(final Graphics g, final String s, final int x, final int y, final int anchor) {
        this.DrawPage(g, s, x, y, anchor, 0, s.length());
    }
    
    void DrawPage(final Graphics g, final String s, final int x, int y, final int anchor, final int start, final int end) {
        final int[] off = new int[100];
        final int lines = StringTokenize(s, start, end, '\n', off);
        final int th = this.GetLineSpacing() + this.GetLineHeight();
        if ((anchor & 0x20) != 0x0) {
            y -= th * (lines - 1);
        }
        else if ((anchor & 0x2) != 0x0) {
            y -= th * (lines - 1) >> 1;
        }
        for (int j = 0; j < lines; ++j) {
            ASprite._index1 = off[j] + 1;
            ASprite._index2 = off[j + 1];
            this.DrawString(g, s, x, y + j * th, anchor, false);
        }
        ASprite._index1 = -1;
        ASprite._index2 = -1;
    }
    
    int getCharSize(final char c) {
        if (c == ' ') {
            return this.GetSpaceWidth();
        }
        if (GLLibConfig.sprite_newTextRendering) {
            final int i = this.GetCharFrame(c);
            return this.GetFrameModuleX(i, 0);
        }
        if (this._pMapChar != null && c > ' ' && c < this._pMapChar.length) {
            final int i = this._pMapChar[c] & 0xFF;
            return (this.GetModuleWidth(this._fmodules[i << 2] & 0xFF) & 0xFF) + this._fmodules[(i << 2) + 1] + this._fmodules[1];
        }
        return 0;
    }
    
    void DrawNumber(final Graphics g, final int num, final int minDigit, final int x, final int y, final int anchor) {
        this.DrawNumber(g, num, 10, minDigit, x, y, anchor, true);
    }
    
    void DrawNumber(final Graphics g, final int num, final int radix, final int minDigit, final int x, final int y, final int anchor, final boolean restorecol) {
        final int charPos = GetChars(ASprite._itoa_buffer, num, radix, minDigit);
        final int oldIndex1 = ASprite._index1;
        final int oldIndex2 = ASprite._index2;
        SetSubString(charPos, 33);
        this.DrawStringOrChars(g, null, ASprite._itoa_buffer, x, y, anchor, restorecol);
        SetSubString(oldIndex1, oldIndex2);
    }
    
    static int GetChars(char[] charBuf, int i, final int radix, final int minDigit) {
        if (charBuf == null) {
            ASprite._itoa_buffer = new char[33];
            charBuf = ASprite._itoa_buffer;
        }
        final int len = charBuf.length;
        int charPos = len - 1;
        final boolean negative = i < 0;
        if (!negative) {
            i = -i;
        }
        while (i <= -radix) {
            charBuf[charPos--] = (char)(48 - i % radix);
            i /= radix;
        }
        charBuf[charPos] = (char)(48 - i);
        while (len - charPos < minDigit) {
            charBuf[--charPos] = '0';
        }
        if (negative) {
            charBuf[--charPos] = '-';
        }
        return charPos;
    }
    
    void UpdateNumberSize(final int num, final int radix, final int minDigit) {
        final int charPos = GetChars(ASprite._itoa_buffer, num, radix, minDigit);
        final int oldIndex1 = ASprite._index1;
        final int oldIndex2 = ASprite._index2;
        SetSubString(charPos, 33);
        this.UpdateStringOrCharsSize(null, ASprite._itoa_buffer);
        SetSubString(oldIndex1, oldIndex2);
    }
    
    void SetCurrentPalette(final int pal) {
        if (pal < this._palettes) {
            this._crt_pal = pal;
        }
    }
    
    int GetCurrentPalette() {
        return this._crt_pal;
    }
    
    static int[] GenPalette(final int type, final int[] pal) {
        if (type < 0) {
            return pal;
        }
        if (type == 0) {
            return null;
        }
        final int[] new_pal = new int[pal.length];
        if ((GLLibConfig.sprite_useGenPalette & 0x2) != 0x0 && type == 1) {
            for (int i = 0; i < pal.length; ++i) {
                new_pal[i] = ((pal[i] | 0xFF3300) & 0xFFFFFF00);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 0x4) != 0x0 && type == 2) {
            for (int i = 0; i < pal.length; ++i) {
                new_pal[i] = ((pal[i] | 0x33FF) & 0xFF00FFFF);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 0x8) != 0x0 && type == 3) {
            for (int i = 0; i < pal.length; ++i) {
                new_pal[i] = ((pal[i] | 0x0) & 0xFF00FF00);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 0x10) != 0x0 && type == 4) {
            for (int i = 0; i < pal.length; ++i) {
                final int a = pal[i] & 0xFF000000;
                final int r = (pal[i] & 0xFF0000) >> 16;
                final int g = (pal[i] & 0xFF00) >> 8;
                final int b = pal[i] & 0xFF;
                new_pal[i] = (a | r + 255 >> 1 << 16 | g >> 1 << 8 | b >> 1);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 0x20) != 0x0 && type == 5) {
            for (int i = 0; i < pal.length; ++i) {
                final int a = pal[i] & 0xFF000000;
                final int r = (pal[i] & 0xFC0000) >> 2;
                final int g = (pal[i] & 0xFC00) >> 2;
                final int b = (pal[i] & 0xFC) >> 2;
                new_pal[i] = (a | r | g | b);
            }
        }
        return new_pal;
    }
    
    static short[] GenPalette(final int type, final short[] pal) {
        if (type < 0) {
            return pal;
        }
        if (type == 0) {
            return null;
        }
        final short[] new_pal = new short[pal.length];
        if ((GLLibConfig.sprite_useGenPalette & 0x2) != 0x0 && type == 1) {
            for (int i = 0; i < pal.length; ++i) {
                new_pal[i] = (short)((pal[i] | 0xF30) & 0xFFF0);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 0x4) != 0x0 && type == 2) {
            for (int i = 0; i < pal.length; ++i) {
                new_pal[i] = (short)((pal[i] | 0x3F) & 0xF0FF);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 0x8) != 0x0 && type == 3) {
            for (int i = 0; i < pal.length; ++i) {
                new_pal[i] = (short)((pal[i] | 0x0) & 0xF0F0);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 0x10) != 0x0 && type == 4) {
            for (int i = 0; i < pal.length; ++i) {
                final int a = pal[i] & 0xF000;
                final int r = (pal[i] & 0xF00) >> 8;
                final int g = (pal[i] & 0xF0) >> 4;
                final int b = pal[i] & 0xF;
                new_pal[i] = (short)(a | r + 15 >> 1 << 8 | g >> 1 << 4 | b >> 1);
            }
        }
        if ((GLLibConfig.sprite_useGenPalette & 0x20) != 0x0 && type == 5) {
            for (int i = 0; i < pal.length; ++i) {
                final int a = pal[i] & 0xF000;
                final int r = (pal[i] & 0xF00) >> 2;
                final int g = (pal[i] & 0xF0) >> 2;
                final int b = (pal[i] & 0xF) >> 2;
                new_pal[i] = (short)(a | r | g | b);
            }
        }
        return new_pal;
    }
    
    void ModifyPaletteAlpha(final int palNb, int alpha) {
        if (GLLibConfig.sprite_useNokiaUI) {
            alpha = (alpha >> 4 & 0xFF);
            for (int i = 0; i < this._pal_short[palNb].length; ++i) {
                if ((this._pal_short[palNb][i] & 0xFFF) != 0xF0F && this._pal_short[palNb][i] >> 12 != 0) {
                    this._pal_short[palNb][i] = (short)((alpha & 0xF) << 12 | (this._pal_short[palNb][i] & 0xFFF));
                }
            }
        }
        else {
            alpha &= 0xFF;
            for (int i = 0; i < this._pal_int[palNb].length; ++i) {
                if ((this._pal_int[palNb][i] & 0xFFFFFF) != 0xFF00FF && this._pal_int[palNb][i] >> 24 != 0) {
                    this._pal_int[palNb][i] = ((alpha & 0xFF) << 24 | (this._pal_int[palNb][i] & 0xFFFFFF));
                }
            }
        }
    }
    
    void ModifyPalette(final int palNb, int color) {
        this._alpha = true;
        if (GLLibConfig.sprite_useNokiaUI) {
            color &= 0xFFF;
            int _4444 = (color & 0xF0) >> 4;
            _4444 += (color & 0xF000) >> 8;
            _4444 += (color & 0xF00000) >> 12;
            for (int i = 0; i < this._pal_short[palNb].length; ++i) {
                if ((this._pal_short[palNb][i] & 0xFFF) != 0xF0F && this._pal_short[palNb][i] >> 12 != 0) {
                    this._pal_short[palNb][i] = (short)((this._pal_short[palNb][i] & 0xF) << 12 | _4444);
                }
            }
        }
        else {
            color &= 0xFFFFFF;
            for (int j = 0; j < this._pal_int[palNb].length; ++j) {
                if ((this._pal_int[palNb][j] & 0xFFFFFF) != 0xFF00FF && this._pal_int[palNb][j] >> 24 != 0) {
                    this._pal_int[palNb][j] = ((this._pal_int[palNb][j] & 0xFF) << 24 | color);
                }
            }
        }
    }
    
    void ModifyPaletteAlphaUsingAltPalette(final int p_iPaletteID, final int p_iAlphaPaletteID) {
        if (p_iPaletteID < 0) {
            GLLib.Assert(false, "ModifyPaletteAlphaUsingAltPalette: trying to modify palette of negative index!");
        }
        if (p_iPaletteID >= this._palettes) {
            GLLib.Assert(false, "ModifyPaletteAlphaUsingAltPalette: trying to modify palette which is out-of-range: " + p_iPaletteID);
        }
        if (p_iAlphaPaletteID < 0) {
            GLLib.Assert(false, "ModifyPaletteAlphaUsingAltPalette: trying to use alpha palette of negative index!");
        }
        if (p_iAlphaPaletteID >= this._palettes) {
            GLLib.Assert(false, "ModifyPaletteAlphaUsingAltPalette: trying to use alpha palette which is out-of-range: " + p_iAlphaPaletteID);
        }
        this._alpha = true;
        if (GLLibConfig.sprite_useNokiaUI) {
            for (int i = 0; i < this._pal_short[p_iPaletteID].length; ++i) {
                if ((this._pal_short[p_iPaletteID][i] & 0xFFF) != 0xF0F && this._pal_short[p_iPaletteID][i] >> 12 != 0) {
                    final short[] array = this._pal_short[p_iPaletteID];
                    final int n = i;
                    array[n] &= 0xFFF;
                    final short[] array2 = this._pal_short[p_iPaletteID];
                    final int n2 = i;
                    array2[n2] |= (short)((this._pal_short[p_iAlphaPaletteID][i] & 0xF00) << 4);
                }
            }
        }
        else {
            for (int i = 0; i < this._pal_int[p_iPaletteID].length; ++i) {
                if ((this._pal_int[p_iPaletteID][i] & 0xFFFFFF) != 0xFF00FF && this._pal_int[p_iPaletteID][i] >> 24 != 0) {
                    final int[] array3 = this._pal_int[p_iPaletteID];
                    final int n3 = i;
                    array3[n3] &= 0xFFFFFF;
                    final int[] array4 = this._pal_int[p_iPaletteID];
                    final int n4 = i;
                    array4[n4] |= (this._pal_int[p_iAlphaPaletteID][i] & 0xFF0000) << 8;
                }
            }
        }
    }
    
    void ModifyPaletteAlphaUsingLastPalette(final int p_iPaletteID) {
        this.ModifyPaletteAlphaUsingAltPalette(p_iPaletteID, this._palettes - 1);
    }
    
    private void MarkTransformedModules(final boolean bUsedByFrames, final int tr_flags) {
        if (GLLibConfig.sprite_useModuleUsageFromSprite && GLLibConfig.sprite_useOperationMark) {
            if (tr_flags != 0) {
                this._modules_usage = new byte[this._nModules];
                for (int i = 0; i < this._nModules; ++i) {
                    this._modules_usage[i] = (byte)tr_flags;
                }
            }
            if (this._frames_nfm == null) {
                return;
            }
            ASprite._operation = 3;
            final Graphics g = null;
            final int num_frames = this._frames_nfm.length;
            final int num_anims = (this._anims_naf == null) ? 0 : this._anims_naf.length;
            if (GLLibConfig.sprite_useModuleMapping) {
                final int old_mmapping = this.GetCurrentMMapping();
                for (int mm = -1; mm < GLLibConfig.MAX_MODULE_MAPPINGS; ++mm) {
                    if (mm < 0 || this._map[mm] != null) {
                        this.SetCurrentMMapping(mm);
                        if (bUsedByFrames) {
                            for (int frame = 0; frame < num_frames; ++frame) {
                                this.PaintFrame(g, frame, 0, 0, 0);
                            }
                        }
                        for (int anim = 0; anim < num_anims; ++anim) {
                            for (int nfrms = this.GetAFrames(anim), frm = 0; frm < nfrms; ++frm) {
                                this.PaintAFrame(g, anim, frm, 0, 0, 0);
                            }
                        }
                    }
                }
                this.SetCurrentMMapping(old_mmapping);
            }
            else {
                if (bUsedByFrames) {
                    for (int frame2 = 0; frame2 < num_frames; ++frame2) {
                        this.PaintFrame(g, frame2, 0, 0, 0);
                    }
                }
                for (int anim2 = 0; anim2 < num_anims; ++anim2) {
                    for (int nfrms2 = this.GetAFrames(anim2), frm2 = 0; frm2 < nfrms2; ++frm2) {
                        this.PaintAFrame(g, anim2, frm2, 0, 0, 0);
                    }
                }
            }
            ASprite._operation = 0;
        }
    }
    
    private boolean RectOperation(final int posX, final int posY, final int sizeX, final int sizeY) {
        if (!GLLibConfig.sprite_useOperationRect) {
            return false;
        }
        if (ASprite._operation == 1) {
            if (posX < ASprite._rectX1) {
                ASprite._rectX1 = posX;
            }
            if (posY < ASprite._rectY1) {
                ASprite._rectY1 = posY;
            }
            if (posX + sizeX > ASprite._rectX2) {
                ASprite._rectX2 = posX + sizeX;
            }
            if (posY + sizeY > ASprite._rectY2) {
                ASprite._rectY2 = posY + sizeY;
            }
            return true;
        }
        return false;
    }
    
    private boolean MarkOperation(final int module, final int flags) {
        if (!GLLibConfig.sprite_useOperationMark) {
            return false;
        }
        if (ASprite._operation == 3) {
            final byte[] modules_usage = this._modules_usage;
            modules_usage[module] |= (byte)(1 << (flags & 0x7));
            return true;
        }
        return false;
    }
    
    private boolean CheckOperation(final Object img, final int posX, final int posY, final int sizeX, final int sizeY, final int flg, final int ImgX, final int ImgY) {
        if (img == null) {
            GLLib.Dbg("ERROR\t\t: CheckOperation img is null");
            return false;
        }
        if (!GLLibConfig.sprite_useOperationRecord) {
            return true;
        }
        if (ASprite._operation == 0) {
            return true;
        }
        if (ASprite._operation == 2) {
            this._aryPrecomputedImages[ASprite.record_frame][ASprite.record_index] = img;
            this._aryPrecomputedX[ASprite.record_frame][ASprite.record_index] = (short)posX;
            this._aryPrecomputedY[ASprite.record_frame][ASprite.record_index] = (short)posY;
            this._aryPrecomputedSizeX[ASprite.record_frame][ASprite.record_index] = (short)sizeX;
            this._aryPrecomputedSizeY[ASprite.record_frame][ASprite.record_index] = (short)sizeY;
            this._aryPrecomputedFlags[ASprite.record_frame][ASprite.record_index] = flg;
            if (!GLLibConfig.sprite_ModuleMapping_useModuleImages) {
                this._aryPrecomputedImgX[ASprite.record_frame][ASprite.record_index] = (short)ImgX;
                this._aryPrecomputedImgY[ASprite.record_frame][ASprite.record_index] = (short)ImgY;
            }
            ++ASprite.record_index;
            return false;
        }
        return false;
    }
    
    void PaintPrecomputedFrame(final Graphics g, final int x, final int y, final int frame) {
        this.PaintPrecomputedFrame1(g, x, y, frame);
    }
    
    void PrecomputeAllFrames(final Graphics g) {
        for (int numfr = this._frames_nfm.length, i = 0; i < numfr; ++i) {
            this.PrecomputeFrame(g, i, 0);
        }
    }
    
    void PrecomputeFrame(final Graphics g, final int frame, final int flags) {
        if (GLLibConfig.sprite_useOperationRecord) {
            if (this._aryPrecomputedImages == null) {
                final int numfr = this._frames_nfm.length;
                this._aryPrecomputedImages = new Object[numfr][];
                this._aryPrecomputedX = new short[numfr][];
                this._aryPrecomputedY = new short[numfr][];
                this._aryPrecomputedSizeX = new short[numfr][];
                this._aryPrecomputedSizeY = new short[numfr][];
                this._aryPrecomputedFlags = new int[numfr][];
                if (!GLLibConfig.sprite_ModuleMapping_useModuleImages) {
                    this._aryPrecomputedImgX = new short[numfr][];
                    this._aryPrecomputedImgY = new short[numfr][];
                }
            }
            final int nmodules = this.CountFrameModules(frame);
            this._aryPrecomputedImages[frame] = new Object[nmodules];
            this._aryPrecomputedX[frame] = new short[nmodules];
            this._aryPrecomputedY[frame] = new short[nmodules];
            this._aryPrecomputedSizeX[frame] = new short[nmodules];
            this._aryPrecomputedSizeY[frame] = new short[nmodules];
            this._aryPrecomputedFlags[frame] = new int[nmodules];
            if (!GLLibConfig.sprite_ModuleMapping_useModuleImages) {
                this._aryPrecomputedImgX[frame] = new short[nmodules];
                this._aryPrecomputedImgY[frame] = new short[nmodules];
            }
            ASprite.record_frame = frame;
            ASprite.record_index = 0;
            ASprite._operation = 2;
            this.PaintFrame(g, frame, 0, 0, flags);
            ASprite._operation = 0;
            ASprite.record_frame = -1;
            ASprite.record_index = -1;
        }
    }
    
    private void PaintPrecomputedFrame1(final Graphics g, final int x, final int y, final int frame) {
        if (GLLibConfig.sprite_useOperationRecord) {
            if (this._aryPrecomputedImages == null || this._aryPrecomputedImages[frame] == null) {
                this.PaintFrame(g, frame, x, y, 0);
                return;
            }
            for (int len = this._aryPrecomputedImages[frame].length, i = 0; i < len; ++i) {
                if (this._aryPrecomputedImages[frame][i] == null) {
                    g.setColor(16711680);
                    g.fillRect(this._aryPrecomputedX[frame][i] + x, this._aryPrecomputedY[frame][i] + y, (int)this._aryPrecomputedSizeX[frame][i], (int)this._aryPrecomputedSizeY[frame][i]);
                }
                else {
                    final Object img = this._aryPrecomputedImages[frame][i];
                    final int x2 = this._aryPrecomputedX[frame][i] + x;
                    final int y2 = this._aryPrecomputedY[frame][i] + y;
                    final int w = this._aryPrecomputedSizeX[frame][i];
                    final int h = this._aryPrecomputedSizeY[frame][i];
                    final int flg = this._aryPrecomputedFlags[frame][i];
                    if (GLLibConfig.sprite_useCacheRGBArrays) {
                        if (!GLLibConfig.sprite_ModuleMapping_useModuleImages) {
                            final int img_x = this._aryPrecomputedImgX[frame][i];
                            final int img_y = this._aryPrecomputedImgY[frame][i];
                            final int cx = g.getClipX();
                            final int cy = g.getClipY();
                            final int cw = g.getClipWidth();
                            final int ch = g.getClipHeight();
                            int new_cx = x2;
                            int new_cy = y2;
                            int new_endcx = x2 + w;
                            int new_endcy = y2 + h;
                            if (x2 < cx) {
                                new_cx = cx;
                            }
                            if (y2 < cy) {
                                new_cy = cy;
                            }
                            if (new_endcx > cx + cw) {
                                new_endcx = cx + cw;
                            }
                            if (new_endcy > cy + ch) {
                                new_endcy = cy + ch;
                            }
                            g.setClip(new_cx, new_cy, new_endcx - new_cx, new_endcy - new_cy);
                            if (GLLibConfig.sprite_drawRGBTransparencyBug) {
                                try {
                                    final Image tmp_img = Image.createRGBImage((int[])img, w, h, this._alpha);
                                    g.drawImage(tmp_img, x2 - img_x, y2 - img_y, 0);
                                }
                                catch (final Exception e) {
                                    GLLib.Dbg("exception " + e);
                                }
                            }
                            else if (GLLibConfig.useDrawPartialRGB) {
                                GLLib.drawPartialRGB(g, (int[])img, w, 0, 0, x2 - img_x, y2 - img_y, w, h, this._alpha);
                            }
                            else {
                                g.drawRGB((int[])img, 0, w, x2 - img_x, y2 - img_y, w, h, this._alpha);
                            }
                            g.setClip(cx, cy, cw, ch);
                        }
                        else if (GLLibConfig.sprite_drawRGBTransparencyBug) {
                            try {
                                final Image tmp_img2 = Image.createRGBImage((int[])img, w, h, this._alpha);
                                g.drawImage(tmp_img2, x2, y2, 0);
                            }
                            catch (final Exception e2) {
                                GLLib.Dbg("exception " + e2);
                            }
                        }
                        else if (GLLibConfig.useDrawPartialRGB) {
                            GLLib.drawPartialRGB(g, (int[])img, w, 0, 0, x2, y2, w, h, this._alpha);
                        }
                        else {
                            g.drawRGB((int[])img, 0, w, x2, y2, w, h, this._alpha);
                        }
                    }
                    else if (!GLLibConfig.sprite_ModuleMapping_useModuleImages) {
                        final int img_x = this._aryPrecomputedImgX[frame][i];
                        final int img_y = this._aryPrecomputedImgY[frame][i];
                        if (flg == 0) {
                            final int cx = g.getClipX();
                            final int cy = g.getClipY();
                            final int cw = g.getClipWidth();
                            final int ch = g.getClipHeight();
                            int new_cx = x2;
                            int new_cy = y2;
                            int new_endcx = x2 + w;
                            int new_endcy = y2 + h;
                            if (x2 < cx) {
                                new_cx = cx;
                            }
                            if (y2 < cy) {
                                new_cy = cy;
                            }
                            if (new_endcx > cx + cw) {
                                new_endcx = cx + cw;
                            }
                            if (new_endcy > cy + ch) {
                                new_endcy = cy + ch;
                            }
                            g.setClip(new_cx, new_cy, new_endcx - new_cx, new_endcy - new_cy);
                            g.drawImage((Image)img, x2 - img_x, y2 - img_y, 0);
                            g.setClip(cx, cy, cw, ch);
                        }
                        else if (GLLibConfig.sprite_drawRegionFlippedBug) {
                            final Image image = Image.createImage((Image)img, img_x, img_y, w, h, flg);
                            g.drawImage(image, x2, y2, 0);
                        }
                        else {
                            g.drawRegion((Image)img, img_x, img_y, w, h, flg, x2, y2, 0);
                        }
                    }
                    else if (flg == 0) {
                        g.drawImage((Image)img, x2, y2, 0);
                    }
                    else if (GLLibConfig.sprite_drawRegionFlippedBug) {
                        final Image image2 = Image.createImage((Image)img, 0, 0, w, h, flg);
                        g.drawImage(image2, x2, y2, 0);
                    }
                    else {
                        g.drawRegion((Image)img, 0, 0, w, h, flg, x2, y2, 0);
                    }
                }
            }
        }
    }
    
    private int readByteArrayNi(final byte[] file, int offset, final byte[] data, final int data_len, final int module_off, final int module_size) {
        for (int i = 0; i < data_len; ++i) {
            data[i * module_size + module_off] = file[offset++];
        }
        return offset;
    }
    
    private int readArray2Short(final byte[] file, int offset, final short[] data, final int data_off, final int data_len, final boolean bByte, final boolean bUnsigned) {
        for (int i = 0; i < data_len; ++i) {
            data[i + data_off] = (bByte ? file[offset++] : ((short)((file[offset++] & 0xFF) + ((file[offset++] & 0xFF) << 8))));
        }
        return offset;
    }
    
    int[] TransformRGB(final int[] image_data, final int sizeX, final int sizeY, final int flags) {
        if ((flags & 0x7) == 0x0) {
            return image_data;
        }
        if (ASprite.transform_int == null) {
            ASprite.transform_int = new int[GLLibConfig.TMP_BUFFER_SIZE];
        }
        int pointer = 0;
        switch (flags & 0x7) {
            case 1: {
                for (int j = 0; j < sizeY; ++j) {
                    int offset = (j + 1) * sizeX;
                    for (int i = 0; i < sizeX; ++i) {
                        ASprite.transform_int[pointer++] = image_data[--offset];
                    }
                }
                break;
            }
            case 2: {
                for (int j = 0; j < sizeY; ++j) {
                    System.arraycopy(image_data, (sizeY - j - 1) * sizeX, ASprite.transform_int, pointer, sizeX);
                    pointer += sizeX;
                }
                break;
            }
            case 3: {
                for (int j = 0; j < sizeY; ++j) {
                    int offset = (sizeY - j) * sizeX;
                    for (int i = 0; i < sizeX; ++i) {
                        ASprite.transform_int[pointer++] = image_data[--offset];
                    }
                }
                break;
            }
            case 4: {
                for (int j = 0; j < sizeY; ++j) {
                    for (int i = 0; i < sizeX; ++i) {
                        ASprite.transform_int[pointer++] = image_data[(sizeX - 1 - i) * sizeY + j];
                    }
                }
                break;
            }
            case 5: {
                for (int j = 0; j < sizeY; ++j) {
                    for (int i = 0; i < sizeX; ++i) {
                        ASprite.transform_int[pointer++] = image_data[(sizeX - 1 - i) * sizeY + (sizeY - 1 - j)];
                    }
                }
                break;
            }
            case 6: {
                for (int j = 0; j < sizeY; ++j) {
                    for (int i = 0; i < sizeX; ++i) {
                        ASprite.transform_int[pointer++] = image_data[i * sizeY + j];
                    }
                }
                break;
            }
            case 7: {
                for (int j = 0; j < sizeY; ++j) {
                    for (int i = 0; i < sizeX; ++i) {
                        ASprite.transform_int[pointer++] = image_data[i * sizeY + (sizeY - 1 - j)];
                    }
                }
                break;
            }
        }
        return ASprite.transform_int;
    }
    
    ASprite() {
        this.mResizeCorrectY = false;
        this._cur_pool = -1;
        this._pMapChar = ASprite.s_MapChar;
        this._bUnderline = false;
        this._bBold = false;
        this.nALetterRect = new int[4];
    }
    
    static {
        MAGIC = new byte[] { -119, 80, 78, 71, 13, 10, 26, 10 };
        IHDR = new byte[] { 73, 72, 68, 82 };
        PLTE = new byte[] { 80, 76, 84, 69 };
        tRNS = new byte[] { 116, 82, 78, 83 };
        IDAT = new byte[] { 73, 68, 65, 84 };
        IEND = new byte[] { 73, 69, 78, 68 };
        INFO32 = new byte[] { 8, 6, 0, 0, 0 };
        INFO8 = new byte[] { 8, 3, 0, 0, 0 };
        MAGIC_IEND = new byte[] { 0, 0, 0, 0, 73, 69, 78, 68, -82, 66, 96, -126 };
        MAGIC_IDAT_h = new byte[] { 120, -100, 1 };
        ASprite.crcTable = new int[256];
        InitCrcTable();
        ASprite.mResizeRef = 0;
        ASprite._index1 = -1;
        ASprite._index2 = -1;
        ASprite.record_index = -1;
        ASprite.record_frame = -1;
        ASprite._operation = 0;
        ASprite.mem = 0;
        midp2_flags = new int[] { 0, 2, 1, 3, 5, 7, 4, 6 };
        ASprite.s_rc = new int[4];
    }
}
