import java.util.Date;
import java.util.Random;
import javax.microedition.rms.RecordStore;
import java.io.PrintStream;
import javax.microedition.midlet.MIDlet;

// 
// Decompiled by Procyon v0.6.0
// 

public final class License
{
    private static final byte FUNCTION_VALIDATE_LICENSE = 40;
    private static String GGI;
    private String url;
    public static final int NOT_A_NUMBER = -666666;
    private HTTP whttp;
    public static long callstarttime;
    private int lastErrorCode;
    
    public License(final MIDlet midlet) {
        if (!GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE) {
            GLLib.Assert(false, "ERROR. GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE must be set to true when using MRC");
        }
        this.url = midlet.getAppProperty("XPlayerURL");
        License.GGI = midlet.getAppProperty("GGI");
        if (this.url == null || License.GGI == null) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("Please check that you have fields XPlayerURL, GGI in .jad file");
            }
            return;
        }
        this.url = this.url.trim();
        License.GGI = License.GGI.trim();
        this.whttp = new HTTP();
        final HTTP whttp = this.whttp;
        HTTP.CarrierDeviceId = midlet.getAppProperty("CarrierDeviceId");
        final HTTP whttp2 = this.whttp;
        if (HTTP.CarrierDeviceId != null && GLLibConfig.xplayer_ENABLE_DEBUG) {
            final PrintStream out = System.out;
            final StringBuffer append = new StringBuffer().append("WARNING CarrierDeviceId=");
            final HTTP whttp3 = this.whttp;
            out.println(append.append(HTTP.CarrierDeviceId).append(", REMOVE the value IN PRODUCTION jad but leave CarrierDeviceId:").toString());
        }
    }
    
    public int getLastError() {
        if (this.whttp.isInProgress()) {
            return -1;
        }
        if (this.whttp.m_bError) {
            return -2;
        }
        return this.lastErrorCode;
    }
    
    public void cancel() {
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            License.callstarttime = 0L;
        }
        this.whttp.cancel();
    }
    
    public void cleanup() {
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            License.callstarttime = 0L;
        }
        this.whttp.cleanup();
    }
    
    private String String2Blob(final String str) {
        final byte[] bs = str.getBytes();
        int nBlobPos = 0;
        int nSPos = 0;
        int nBitsNotUsed = 8;
        int nBlobLength = str.length() * 8 / 6;
        if (str.length() * 8 % 6 != 0) {
            nBlobLength += 2;
        }
        else {
            ++nBlobLength;
        }
        final byte[] sBlob = new byte[nBlobLength];
        for (int k = 0; k < nBlobLength; ++k) {
            sBlob[k] = 0;
        }
        while (nSPos < str.length()) {
            byte nKeyIndex = (byte)(bs[nSPos] & 0x7F);
            nKeyIndex >>= (byte)(8 - nBitsNotUsed);
            if (nBitsNotUsed < 6) {
                if (++nSPos < str.length()) {
                    nKeyIndex |= (byte)(bs[nSPos] << nBitsNotUsed);
                    nBitsNotUsed += 2;
                }
            }
            else {
                nBitsNotUsed -= 6;
            }
            nKeyIndex &= 0x3F;
            sBlob[nBlobPos] = this.SSEncDec_GetCharFromKeyByIndex(nKeyIndex);
            ++nBlobPos;
        }
        final String retval = new String(sBlob, 0, nBlobPos);
        return retval;
    }
    
    private byte SSEncDec_GetCharFromKeyByIndex(final byte nKeyIndex) {
        if (nKeyIndex < 26) {
            return (byte)(nKeyIndex + 97);
        }
        if (nKeyIndex < 52) {
            return (byte)(nKeyIndex + 39);
        }
        if (nKeyIndex < 62) {
            return (byte)(nKeyIndex - 4);
        }
        if (nKeyIndex == 62) {
            return 95;
        }
        return 45;
    }
    
    private String Blob2String(final String blob) {
        final byte[] b = blob.getBytes();
        int nBlobPos = 0;
        int nSPos = 0;
        int nBitsNotSet = 8;
        final int nStrLength = blob.length() * 6 / 8 + 1;
        final byte[] s = new byte[nStrLength];
        for (int k = 0; k < nStrLength; ++k) {
            s[k] = 0;
        }
        for (nBlobPos = 0; nBlobPos < blob.length(); ++nBlobPos) {
            final byte nKeyIndex = this.SSEncDec_GetKeyFromChar(b[nBlobPos]);
            final byte[] array = s;
            final int n = nSPos;
            array[n] |= (byte)(nKeyIndex << 8 - nBitsNotSet);
            if (nBitsNotSet > 6) {
                nBitsNotSet -= 6;
            }
            else if (nSPos < nStrLength - 2) {
                final byte[] array2 = s;
                final int n2 = ++nSPos;
                array2[n2] |= (byte)(nKeyIndex >> nBitsNotSet);
                nBitsNotSet += 2;
            }
        }
        final String retval = new String(s, 0, nStrLength);
        return retval.trim();
    }
    
    private byte SSEncDec_GetKeyFromChar(final byte nChar) {
        if (nChar == 45) {
            return 63;
        }
        if (nChar == 95) {
            return 62;
        }
        if (nChar < 58) {
            return (byte)(nChar + 4);
        }
        if (nChar < 91) {
            return (byte)(nChar - 39);
        }
        return (byte)(nChar - 97);
    }
    
    private String getValue(final String src, int pos) {
        int start = 0;
        final int ini_pos = pos;
        int end = src.indexOf(124, start + 1);
        while (pos > 0) {
            if (start == -1) {
                return null;
            }
            start = end;
            end = src.indexOf(124, start + 1);
            --pos;
        }
        if (start == -1) {
            return null;
        }
        if (end == -1) {
            end = src.length();
        }
        if (ini_pos > 0) {
            ++start;
        }
        if (start == end) {
            return "";
        }
        if (start > end) {
            return null;
        }
        try {
            final char[] buf = new char[end - start];
            src.getChars(start, end, buf, 0);
            final String value = new String(buf);
            return value;
        }
        catch (final IndexOutOfBoundsException e) {
            return null;
        }
    }
    
    private void rmsStoreExpiration(final String lengthTimeValid_str, final String currentTime_str) {
        RecordStore rs = null;
        if (lengthTimeValid_str != null) {
            try {
                rs = RecordStore.openRecordStore("MRC", true);
                final Random key = new Random(Long.parseLong(currentTime_str));
                final String blob_expInfo = this.String2Blob(Integer.toHexString(key.nextInt()) + "|SubExp|" + lengthTimeValid_str + "|" + currentTime_str + "|GL7x|");
                final byte[] tmp_expInfo = blob_expInfo.getBytes();
                if (rs.getNumRecords() >= 1) {
                    rs.setRecord(1, tmp_expInfo, 0, tmp_expInfo.length);
                }
                else {
                    rs.addRecord(tmp_expInfo, 0, tmp_expInfo.length);
                }
            }
            catch (final Exception e) {}
            finally {
                try {
                    rs.closeRecordStore();
                }
                catch (final Exception ex) {}
            }
        }
        try {
            RecordStore.deleteRecordStore("MRC");
        }
        catch (final Exception ex2) {}
    }
    
    private String rmsGetExpiration() {
        RecordStore rs = null;
        String expInfo_str = null;
        try {
            rs = RecordStore.openRecordStore("MRC", true);
            if (rs.getNumRecords() >= 1) {
                final byte[] tmp_expInfo = rs.getRecord(1);
                expInfo_str = new String(tmp_expInfo);
                expInfo_str = this.Blob2String(expInfo_str);
            }
        }
        catch (final Exception e) {}
        finally {
            try {
                rs.closeRecordStore();
            }
            catch (final Exception ex) {}
        }
        return expInfo_str;
    }
    
    public boolean isLicenseValid() {
        if (this.url == null || License.GGI == null) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("XPlayerURL or GGI fields missing. SKIPPING Cingular MRC.");
            }
            return true;
        }
        final String expInfo_str = this.rmsGetExpiration();
        if (expInfo_str == null) {
            return false;
        }
        final String header = this.getValue(expInfo_str, 1);
        final String validForTime_str = this.getValue(expInfo_str, 2);
        final String timeLastMsg_str = this.getValue(expInfo_str, 3);
        final String footer = this.getValue(expInfo_str, 4);
        if (header.compareTo("SubExp") == 0 && validForTime_str != "" && timeLastMsg_str != "" && footer.compareTo("GL7x") == 0) {
            final long lengthTimeValid = Long.parseLong(validForTime_str);
            final long timeLastMsg = Long.parseLong(timeLastMsg_str);
            final Date current_date = new Date();
            final long currentTime = current_date.getTime() / 1000L;
            return currentTime <= timeLastMsg + lengthTimeValid && currentTime >= timeLastMsg;
        }
        return false;
    }
    
    public void sendValidateLicense() {
        this.whttp.cancel();
        final StringBuffer append = new StringBuffer().append("f|40|i|").append(License.GGI).append("|u|");
        final HTTP whttp = this.whttp;
        String tmp = append.append(HTTP.CarrierDeviceId).append("|").toString();
        final String tmpBlob = tmp = this.String2Blob(tmp);
        this.lastErrorCode = -100;
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            License.callstarttime = System.currentTimeMillis();
        }
        this.whttp.sendByGet(this.url, tmp);
    }
    
    public boolean handleValidateLicense() {
        if (this.whttp.isInProgress()) {
            if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - License.callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                this.cancel();
                this.lastErrorCode = -2;
                return true;
            }
            return false;
        }
        else {
            if (this.whttp.m_bError) {
                return true;
            }
            if (this.whttp.m_response != null && this.whttp.m_response != "") {
                if (this.whttp.m_response.indexOf("|") == -1) {
                    this.whttp.m_response = this.Blob2String(this.whttp.m_response);
                }
                String tmpHR = this.getValue(this.whttp.m_response, 1);
                if (Integer.parseInt(tmpHR) != 40) {
                    this.lastErrorCode = 40;
                    return true;
                }
                tmpHR = this.getValue(this.whttp.m_response, 3);
                if (tmpHR.compareTo("e") == 0) {
                    tmpHR = this.getValue(this.whttp.m_response, 4);
                    this.lastErrorCode = Integer.parseInt(tmpHR);
                    return true;
                }
                if (tmpHR.compareTo("s") == 0) {
                    this.lastErrorCode = 0;
                    String lengthTimeValid_str = this.getValue(this.whttp.m_response, 4);
                    lengthTimeValid_str = lengthTimeValid_str.trim();
                    if (lengthTimeValid_str.compareTo("0") == 0) {
                        this.rmsStoreExpiration(null, null);
                    }
                    else {
                        final Date current_date = new Date();
                        final long currentTime = current_date.getTime() / 1000L;
                        final String currentTime_str = Long.toString(currentTime);
                        this.rmsStoreExpiration(lengthTimeValid_str, currentTime_str);
                    }
                    return true;
                }
            }
            this.lastErrorCode = 40;
            return true;
        }
    }
    
    public interface Error
    {
        public static final int ERROR_INIT = -100;
        public static final byte ERROR_CONNECTION = -2;
        public static final byte ERROR_PENDING = -1;
        public static final byte ERROR_NONE = 0;
        public static final byte ERROR_NO_UUID = 1;
        public static final byte ERROR_NO_PHONE_NUMBER = 25;
        public static final byte ERROR_NO_CLIENT_ID = 26;
        public static final byte ERROR_INVALID_GGI = 27;
        public static final byte ERROR_BAD_RESPONSE = 40;
    }
}
