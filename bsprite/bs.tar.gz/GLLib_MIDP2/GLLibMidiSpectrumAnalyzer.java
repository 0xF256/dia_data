// 
// Decompiled by Procyon v0.6.0
// 

public class GLLibMidiSpectrumAnalyzer
{
    private static final byte[] HEADER_CHUNK;
    private static final byte[] TRACK_CHUNK;
    public static final int NO_ERRORS = 0;
    public static final int ERROR_INVALID_HEADER_CHUNK = 1;
    public static final int ERROR_INVALID_TRACK_CHUNK = 2;
    public static final int ERROR_INVALID_FILE_LENGTH = 3;
    public static final int ERROR_INVALID_META_EVENT = 4;
    private static final int EVENT_NOTE_OFF = 128;
    private static final int EVENT_NOTE_ON = 144;
    private static final int EVENT_POLYPHONIC_KEY_PRESSURE = 160;
    private static final int EVENT_CONTROL_CHANGE = 176;
    private static final int EVENT_PROGRAM_CHANGE = 192;
    private static final int EVENT_CHANNEL_KEY_PRESSURE = 208;
    private static final int EVENT_PITCH_BEND = 224;
    private static final int EVENT_META = 240;
    private static final int META_EVENT_SET_SEQUENCE_NUMBRE = 0;
    private static final int META_EVENT_TEXT = 1;
    private static final int META_EVENT_COPYRIGHT = 2;
    private static final int META_EVENT_TRACK_NAME = 3;
    private static final int META_EVENT_INSTRUMENT_NAME = 4;
    private static final int META_EVENT_LYRIC = 5;
    private static final int META_EVENT_MARKER = 6;
    private static final int META_EVENT_CUE_POINT = 7;
    private static final int META_EVENT_TRACK_END = 47;
    private static final int META_EVENT_SET_TEMPO = 81;
    private static final int META_EVENT_SET_TIME_SIGNATURE = 88;
    private static final int META_EVENT_KEY_SIGNATURE = 89;
    private byte[][] m_tracks;
    private byte[] m_data;
    private int m_offset;
    public int m_channelFilter;
    public int m_bars;
    public int[] m_barLevels;
    private int m_maxValue;
    private int m_velocityShift;
    private int m_millisShift;
    private int m_releaseDamping;
    private int m_fileFormat;
    private int m_numberOfTracks;
    private int m_deltaTimeTickPerQuarterNote;
    private int m_tempo;
    public long m_currentTime;
    private long m_lastNoteTime;
    private int m_event;
    private int m_metaEvent;
    
    public GLLibMidiSpectrumAnalyzer(final int bars, final int maxValue, final int velocityShift, final int millisShift, final int releaseDamping) {
        this.m_channelFilter = 15;
        this.m_tempo = 500000;
        this.m_currentTime = 0L;
        this.m_lastNoteTime = 0L;
        this.m_event = 0;
        this.m_metaEvent = 0;
        this.m_barLevels = new int[bars];
        this.m_bars = bars;
        this.m_maxValue = maxValue;
        this.m_velocityShift = velocityShift;
        this.m_millisShift = millisShift;
        this.m_releaseDamping = releaseDamping;
    }
    
    private int MidiSpectrumAnalyzer_PeakByte() {
        return this.m_data[this.m_offset] & 0xFF;
    }
    
    private int MidiSpectrumAnalyzer_ReadByte() {
        return this.m_data[this.m_offset++] & 0xFF;
    }
    
    private int MidiSpectrumAnalyzer_ReadShort() {
        final int value = (this.m_data[this.m_offset + 0] & 0xFF) << 8 | (this.m_data[this.m_offset + 1] & 0xFF) << 0;
        this.m_offset += 2;
        return value;
    }
    
    private int MidiSpectrumAnalyzer_ReadInt() {
        final int value = (this.m_data[this.m_offset + 0] & 0xFF) << 24 | (this.m_data[this.m_offset + 1] & 0xFF) << 16 | (this.m_data[this.m_offset + 2] & 0xFF) << 8 | (this.m_data[this.m_offset + 3] & 0xFF) << 0;
        this.m_offset += 4;
        return value;
    }
    
    private int MidiSpectrumAnalyzer_ReadThreeBytes() {
        final int value = (this.m_data[this.m_offset + 0] & 0xFF) << 16 | (this.m_data[this.m_offset + 1] & 0xFF) << 8 | (this.m_data[this.m_offset + 2] & 0xFF) << 0;
        this.m_offset += 3;
        return value;
    }
    
    private int MidiSpectrumAnalyzer_ReadVariableLength() {
        int value = 0;
        byte b;
        do {
            b = this.m_data[this.m_offset++];
            value = (value << 7) + (b & 0x7F);
        } while ((b & 0x80) == 0x80);
        return value;
    }
    
    public int MidiSpectrumAnalyzer_Parse(final byte[] data) {
        this.m_offset = 0;
        this.m_data = data;
        if (this.m_offset + 16 > data.length) {
            return 1;
        }
        for (int i = 0; i < GLLibMidiSpectrumAnalyzer.HEADER_CHUNK.length; ++i) {
            if (GLLibMidiSpectrumAnalyzer.HEADER_CHUNK[i] != this.MidiSpectrumAnalyzer_ReadByte()) {
                return 1;
            }
        }
        final int headerLength = this.MidiSpectrumAnalyzer_ReadInt();
        if (headerLength != 6) {
            return 1;
        }
        this.m_fileFormat = this.MidiSpectrumAnalyzer_ReadShort();
        this.m_numberOfTracks = this.MidiSpectrumAnalyzer_ReadShort();
        this.m_deltaTimeTickPerQuarterNote = this.MidiSpectrumAnalyzer_ReadShort();
        this.m_tracks = new byte[this.m_numberOfTracks][];
        for (int t = 0; t < this.m_numberOfTracks; ++t) {
            if (this.m_offset + 8 > data.length) {
                return 2;
            }
            for (int j = 0; j < GLLibMidiSpectrumAnalyzer.TRACK_CHUNK.length; ++j) {
                if (GLLibMidiSpectrumAnalyzer.TRACK_CHUNK[j] != this.MidiSpectrumAnalyzer_ReadByte()) {
                    return 2;
                }
            }
            final int trackLength = this.MidiSpectrumAnalyzer_ReadInt();
            if (this.m_offset + trackLength > data.length) {
                return 2;
            }
            this.m_tracks[t] = new byte[trackLength];
            System.arraycopy(data, this.m_offset, this.m_tracks[t], 0, trackLength);
            this.m_offset += trackLength;
        }
        if (this.m_offset < data.length) {
            return 3;
        }
        this.m_data = null;
        this.MidiSpectrumAnalyzer_Reset();
        return 0;
    }
    
    public void MidiSpectrumAnalyzer_Reset() {
        this.m_offset = 0;
        this.m_data = this.m_tracks[0];
        this.m_currentTime = 0L;
        this.m_lastNoteTime = 0L;
    }
    
    public int MidiSpectrumAnalyzer_Update(final long timeMillis) {
        final long deltaTimeMillis = timeMillis - this.m_currentTime;
        this.m_currentTime = timeMillis;
        for (int i = 0; i < this.m_barLevels.length; ++i) {
            final int[] barLevels = this.m_barLevels;
            final int n = i;
            barLevels[n] -= (int)(deltaTimeMillis << this.m_millisShift);
            if (this.m_barLevels[i] < 0) {
                this.m_barLevels[i] = 0;
            }
        }
        if (this.m_offset >= this.m_data.length) {
            return 0;
        }
        do {
            final int offset = this.m_offset;
            final int dtToNextEvent = this.MidiSpectrumAnalyzer_ReadVariableLength();
            final long time = this.MidiSpectrumAnalyzer_GetTicksInMillis(dtToNextEvent);
            if (this.m_currentTime < this.m_lastNoteTime + time) {
                this.m_offset = offset;
                break;
            }
            this.m_lastNoteTime += time;
            if ((this.MidiSpectrumAnalyzer_PeakByte() & 0x80) == 0x80) {
                this.m_event = (this.MidiSpectrumAnalyzer_ReadByte() & 0xFF);
            }
            final int channel = this.m_event & 0xF;
            switch (this.m_event & 0xF0) {
                case 128: {
                    final int noteNumber = this.MidiSpectrumAnalyzer_ReadByte();
                    final int velocity = this.MidiSpectrumAnalyzer_ReadByte();
                    if ((channel & this.m_channelFilter) == 0x0) {
                        continue;
                    }
                    final int bar = this.m_bars * noteNumber / 128;
                    final int[] barLevels2 = this.m_barLevels;
                    final int n2 = bar;
                    barLevels2[n2] -= this.m_releaseDamping;
                    if (this.m_barLevels[bar] >= 0) {
                        continue;
                    }
                    this.m_barLevels[bar] = 0;
                    continue;
                }
                case 144: {
                    final int noteNumber = this.MidiSpectrumAnalyzer_ReadByte();
                    final int velocity = this.MidiSpectrumAnalyzer_ReadByte();
                    if (velocity == 0 && (channel & this.m_channelFilter) != 0x0) {
                        final int bar = this.m_bars * noteNumber / 128;
                        final int[] barLevels3 = this.m_barLevels;
                        final int n3 = bar;
                        barLevels3[n3] -= this.m_releaseDamping;
                        if (this.m_barLevels[bar] < 0) {
                            this.m_barLevels[bar] = 0;
                        }
                    }
                    if ((channel & this.m_channelFilter) == 0x0) {
                        continue;
                    }
                    final int bar = this.m_bars * noteNumber / 128;
                    final int[] barLevels4 = this.m_barLevels;
                    final int n4 = bar;
                    barLevels4[n4] += velocity << this.m_velocityShift;
                    if (this.m_barLevels[bar] <= this.m_maxValue) {
                        continue;
                    }
                    this.m_barLevels[bar] = this.m_maxValue;
                    continue;
                }
                case 160: {
                    final int noteNumber = this.MidiSpectrumAnalyzer_ReadByte();
                    final int velocity = this.MidiSpectrumAnalyzer_ReadByte();
                    continue;
                }
                case 176: {
                    final int controllerNumber = this.MidiSpectrumAnalyzer_ReadByte();
                    final int newValue = this.MidiSpectrumAnalyzer_ReadByte();
                    continue;
                }
                case 192: {
                    final int newProgramNumber = this.MidiSpectrumAnalyzer_ReadByte();
                    continue;
                }
                case 208: {
                    final int channelNumbre = this.MidiSpectrumAnalyzer_ReadByte();
                    continue;
                }
                case 224: {
                    final int pitchWheelValueBottom = this.MidiSpectrumAnalyzer_ReadByte();
                    final int pitchWheelValueTop = this.MidiSpectrumAnalyzer_ReadByte();
                    continue;
                }
                case 240: {
                    switch (this.m_event) {
                        case 255: {
                            this.m_metaEvent = this.MidiSpectrumAnalyzer_ReadByte();
                            final int m_metaEventLength = this.MidiSpectrumAnalyzer_ReadByte();
                            switch (this.m_metaEvent) {
                                case 81: {
                                    this.m_tempo = this.MidiSpectrumAnalyzer_ReadThreeBytes();
                                    continue;
                                }
                                default: {
                                    this.m_offset += m_metaEventLength;
                                    continue;
                                }
                            }
                            break;
                        }
                    }
                    continue;
                }
                default: {
                    System.out.println("\t!!! ERROR - Unsupported m_event");
                    continue;
                }
            }
        } while (this.m_offset < this.m_data.length);
        return 0;
    }
    
    private long MidiSpectrumAnalyzer_GetTicksInMillis(final long ticks) {
        return ticks * 1000L * 60L / (60000000L / this.m_tempo * this.m_deltaTimeTickPerQuarterNote);
    }
    
    static {
        HEADER_CHUNK = "MThd".getBytes();
        TRACK_CHUNK = "MTrk".getBytes();
    }
}
