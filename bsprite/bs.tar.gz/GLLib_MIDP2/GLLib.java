import javax.microedition.rms.RecordStoreException;
import javax.microedition.lcdui.Font;
import java.io.ByteArrayInputStream;
import javax.microedition.lcdui.Displayable;
import javax.microedition.rms.RecordStore;
import java.io.InputStream;
import java.util.Random;
import java.util.Hashtable;
import javax.microedition.lcdui.Image;
import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Canvas;

// 
// Decompiled by Procyon v0.6.0
// 

public abstract class GLLib extends Canvas implements Runnable
{
    public static Graphics g;
    private static Graphics s_lastPaintGraphics;
    static boolean s_game_isPaused;
    static int s_game_state;
    static long s_game_timeWhenFrameStart;
    static long s_game_lastFrameTime;
    static boolean s_game_interruptNotify;
    private static int s_screenWidth;
    private static int s_screenHeight;
    static Display s_display;
    private static boolean s_game_isInPaint;
    static MIDlet s_application;
    private static int m_FPSLimiter;
    private long m_frameCoheranceTimer;
    private Image m_imgBackBuffer;
    private Graphics m_gBackBuffer;
    static int s_game_frameDT;
    private static long s_game_frameDTTimer;
    static int s_game_totalExecutionTime;
    static int s_game_FPSAverage;
    static int s_game_currentFrameNB;
    static GLLib s_gllib_instance;
    static byte[] s_keyState;
    static byte[] s_keyStateRT;
    static int s_keyLastKeyPressUntranslatedCode;
    static int s_keyLastKeyStates;
    static int s_game_keyEventIndex;
    static int s_game_keyJustPressed;
    static long s_game_keyPressedTime;
    static int m_keys_pressed;
    static int m_keys_released;
    static int m_keys_state;
    static int m_current_keys_state;
    static int m_current_keys_pressed;
    static int m_current_keys_released;
    static int m_last_key_pressed;
    private static Hashtable standardKeyTable;
    private static Hashtable gameActionKeyTable;
    static final int s_math_F_1;
    static final int s_math_F_05;
    static Random s_math_random;
    static int s_Math_distPointLineX;
    static int s_Math_distPointLineY;
    static int s_Math_intersectX;
    static int s_Math_intersectY;
    static final int MATH_SEGMENTINTERSECT_DONT_INTERSECT = 0;
    static final int MATH_SEGMENTINTERSECT_COLLINEAR = -1;
    static final int MATH_SEGMENTINTERSECT_DO_INTERSECT = 1;
    private static int Math_quickSortIndices_nbItemPerValue;
    private static int Math_quickSortIndices_itemNb;
    private static int[] Math_quickSortIndices_result;
    private static int[] Math_quickSortIndices_data;
    static int s_math_bezierX;
    static int s_math_bezierY;
    static int s_math_bezierZ;
    private static int[] s_math_cosTable;
    private static int[] s_math_sqrtTable;
    private static int[] s_math_aTanTable;
    static final int Math_AngleMUL;
    static final int Math_Angle90;
    static final int Math_Angle180;
    static final int Math_Angle270;
    static final int Math_Angle360;
    static final int Math_FixedPoint_PI;
    static final int Math_FixedPoint_E;
    private static final int ratioRadiansToDegrees;
    private static final int ratioDegreesToAngleFixedPoint;
    static final int MATH_INTERSECT_NO_INTERSECT = 0;
    static final int MATH_INTERSECT_ONE_POINT = 2;
    static final int MATH_INTERSECT_TWO_POINTS = 4;
    static int[][] s_Math_intersectPoints;
    private static final int ARRAY_BYTE = 0;
    private static final int ARRAY_SHORT = 1;
    private static final int ARRAY_INT = 2;
    private static String s_pack_filename;
    private static InputStream s_pack_is;
    private static int s_pack_curOffset;
    private static short s_pack_nbData;
    private static int[] s_pack_offset;
    private static short s_pack_subPack_nbOf;
    private static short[] s_pack_subPack_fat;
    private static String s_pack_subPack_filename;
    private static int s_pack_subPack_curSubPack;
    static int s_pack_lastDataReadMimeType;
    private static boolean s_pack_lastDataIsCompress;
    private static byte[] s_Pack_SkipBuffer;
    static byte[][] MIME_type;
    private static byte[][] s_pack_BinaryCache;
    private static Hashtable s_pack_HashIndex;
    private static Hashtable s_pack_HashSize;
    static byte[] m_Buffer;
    static int m_inSize;
    static long m_Range;
    static long m_Code;
    static int m_ExtraBytes;
    static byte[] m_outStream;
    static int inputIndex;
    private static short[] m_lzmaInternalData;
    static final int kNumBitModelTotalBits = 11;
    static final int kBitModelTotal = 2048;
    static final int tkNumMoveBits = 5;
    static final int LZMA_BASE_SIZE = 1846;
    static final int LZMA_LIT_SIZE = 768;
    static final int LZMA_RESULT_OK = 0;
    static final int LZMA_RESULT_DATA_ERROR = 1;
    static final int LZMA_RESULT_NOT_ENOUGH_MEM = 2;
    static final int kNumStates = 12;
    static final int kNumPosBitsMax = 4;
    static final int kNumLenToPosStates = 4;
    static final int kNumPosSlotBits = 6;
    static final int kStartPosModelIndex = 4;
    static final int kEndPosModelIndex = 14;
    static final int kNumFullDistances = 128;
    static final int kNumAlignBits = 4;
    static final int kAlignTableSize = 16;
    static final int IsMatch = 0;
    static final int IsRep = 192;
    static final int IsRepG0 = 204;
    static final int IsRepG1 = 216;
    static final int IsRepG2 = 228;
    static final int IsRep0Long = 240;
    static final int PosSlot = 432;
    static final int SpecPos = 688;
    static final int Align = 802;
    static final int LenCoder = 818;
    static final int kNumPosStatesMax = 16;
    static final int kLenNumLowBits = 3;
    static final int kLenNumLowSymbols = 8;
    static final int kLenNumMidBits = 3;
    static final int kLenNumMidSymbols = 8;
    static final int kLenNumHighBits = 8;
    static final int kLenNumHighSymbols = 256;
    static final int kMatchMinLen = 2;
    static final int LenChoice = 0;
    static final int LenChoice2 = 1;
    static final int LenLow = 2;
    static final int LenMid = 130;
    static final int LenHigh = 258;
    static final int kNumLenProbs = 514;
    static final int RepLenCoder = 1332;
    static final int Literal = 1846;
    static final int kNumMoveBits = 5;
    static final int kNumTopBits = 24;
    static final int kTopValue = 16777216;
    static final int HCENTER = 1;
    static final int VCENTER = 2;
    static final int LEFT = 4;
    static final int RIGHT = 8;
    static final int TOP = 16;
    static final int BOTTOM = 32;
    static final int SOLID = 0;
    static final int DOTTED = 1;
    static final int TRANS_NONE = 0;
    static final int TRANS_ROT90 = 5;
    static final int TRANS_ROT180 = 3;
    static final int TRANS_ROT270 = 6;
    static final int TRANS_MIRROR = 2;
    static final int TRANS_MIRROR_ROT90 = 7;
    static final int TRANS_MIRROR_ROT180 = 1;
    static final int TRANS_MIRROR_ROT270 = 4;
    private static long m_nextTimeVibrationAllowed;
    private static int Stream_readOffset;
    static int text_nbString;
    static String text_encoding;
    private static byte[] text_array;
    private static int[] text_arrayOffset;
    private static String[] text_stringCacheArray;
    private static String StrEN;
    private static String StrDE;
    private static String StrFR;
    private static String StrIT;
    private static String StrES;
    private static String StrBR;
    private static String StrPT;
    private static String StrJP;
    private static String StrCN;
    private static String StrKR;
    private static String StrRU;
    private static String StrTR;
    private static String StrPL;
    private static String StrCZ;
    private static RecordStore s_rs;
    private static byte[] s_rms_buffer;
    private static String s_rms_vendor;
    private static String s_rms_midletName;
    static final int PROFILER_MAX_EVENTS = 200;
    private static String[] s_profiler_eventNames;
    private static long[] s_profiler_eventBegins;
    private static long[] s_profiler_eventEnds;
    private static short[] s_profiler_eventDepths;
    private static short[] s_profiler_eventStack;
    private static int s_profiler_eventCount;
    private static int s_profiler_eventStackIndex;
    private static boolean s_profiler_recording;
    private static boolean s_profiler_emulator;
    
    abstract void Game_update() throws Exception;
    
    public void Game_Run() throws Exception {
    }
    
    public GLLib(final Object application, final Object display) {
        this.m_imgBackBuffer = null;
        this.m_gBackBuffer = null;
        Dbg("GLLib.constructor");
        this.CheckAndDumpConfig();
        GLLib.s_gllib_instance = this;
        GLLib.s_game_state = -1;
        GLLib.s_game_isInPaint = true;
        GLLib.s_application = (MIDlet)application;
        GLLib.s_display = (Display)display;
        this.SetupDisplay();
        SetupDefaultKey();
        GLLib.s_game_frameDTTimer = System.currentTimeMillis();
        this.m_frameCoheranceTimer = GLLib.s_game_frameDTTimer;
    }
    
    protected void Init() {
        Dbg("GLLib.init");
        if (GLLib.s_game_state >= 0) {
            return;
        }
        GLLib.s_screenWidth = GLLibConfig.screenWidth;
        GLLib.s_screenHeight = GLLibConfig.screenHeight;
        if (GLLibConfig.useKeyAccumulation) {
            GLLib.s_keyState = new byte[20];
            GLLib.s_keyStateRT = new byte[20];
        }
        if (GLLibConfig.useSoftwareDoubleBuffer) {
            this.m_imgBackBuffer = Image.createImage(((Displayable)this).getWidth(), ((Displayable)this).getHeight());
            this.m_gBackBuffer = this.m_imgBackBuffer.getGraphics();
        }
        Math_RandSetSeed(System.currentTimeMillis());
        GLLib.s_game_state = 0;
        if (GLLibConfig.useCallSerially) {
            GLLib.s_display.callSerially((Runnable)this);
        }
        else {
            new Thread(this).start();
        }
    }
    
    protected Image GetSoftwareDoubleBuffer() {
        if (GLLibConfig.useSoftwareDoubleBuffer) {
            return this.m_imgBackBuffer;
        }
        return null;
    }
    
    protected Graphics GetSoftwareDoubleBufferGraphics() {
        if (GLLibConfig.useSoftwareDoubleBuffer) {
            return this.m_gBackBuffer;
        }
        return null;
    }
    
    protected void UnInit() {
        Dbg("GLLib.deInit");
        if (GLLibConfig.useKeyAccumulation) {
            GLLib.s_keyState = null;
            GLLib.s_keyStateRT = null;
        }
        if (GLLibConfig.useSoftwareDoubleBuffer) {
            this.m_imgBackBuffer = null;
            this.m_gBackBuffer = null;
        }
        GLLib.MIME_type = null;
        Gc();
    }
    
    protected void Pause() {
        GLLib.s_game_isPaused = true;
        Dbg("GLLib.pause");
        if (GLLibConfig.sound_useStopSoundsOnInterrupt) {
            try {
                GLLibPlayer.Snd_StopAllSounds();
                GLLibPlayer.Snd_ForceExecOnThreadOnGamePause();
            }
            catch (final Exception ex) {}
        }
    }
    
    protected void Resume() {
        Dbg("GLLib.resume");
        if (GLLib.s_game_isPaused) {
            final long time = GLLib.s_game_frameDTTimer = (GLLib.s_game_timeWhenFrameStart = System.currentTimeMillis());
            this.m_frameCoheranceTimer = time;
            GLLib.s_game_isPaused = false;
            this.SetupDisplay();
            GLLib.s_game_interruptNotify = true;
            this.repaint();
            ResetKey();
        }
    }
    
    public void hideNotify() {
        this.Pause();
    }
    
    public void showNotify() {
        this.Resume();
    }
    
    public void sizeChanged(final int w, final int h) {
        GLLib.s_screenWidth = w;
        GLLib.s_screenHeight = h;
    }
    
    protected void SetupDisplay() {
        Dbg("GLLib.SetupDisplay");
        if (GLLib.s_display.getCurrent() != this) {
            GLLib.s_display.setCurrent((Displayable)this);
        }
        if (!GLLibConfig.MIDP2forceNonFullScreen) {
            this.setFullScreenMode(true);
        }
    }
    
    protected static void SetupDefaultKey() {
        Game_KeyClearKeyCode();
        GLLib.standardKeyTable.put(new Integer(48), new Integer(6));
        GLLib.standardKeyTable.put(new Integer(49), new Integer(7));
        GLLib.standardKeyTable.put(new Integer(50), new Integer(1));
        GLLib.standardKeyTable.put(new Integer(51), new Integer(9));
        GLLib.standardKeyTable.put(new Integer(52), new Integer(3));
        GLLib.standardKeyTable.put(new Integer(53), new Integer(5));
        GLLib.standardKeyTable.put(new Integer(54), new Integer(4));
        GLLib.standardKeyTable.put(new Integer(55), new Integer(13));
        GLLib.standardKeyTable.put(new Integer(56), new Integer(2));
        GLLib.standardKeyTable.put(new Integer(57), new Integer(15));
        GLLib.standardKeyTable.put(new Integer(35), new Integer(17));
        GLLib.standardKeyTable.put(new Integer(42), new Integer(16));
        if (GLLibConfig.softkeyOKOnLeft) {
            GLLib.standardKeyTable.put(new Integer(GLLibConfig.keycodeLeftSoftkey), new Integer(18));
            GLLib.standardKeyTable.put(new Integer(GLLibConfig.keycodeRightSoftkey), new Integer(19));
        }
        else {
            GLLib.standardKeyTable.put(new Integer(GLLibConfig.keycodeLeftSoftkey), new Integer(19));
            GLLib.standardKeyTable.put(new Integer(GLLibConfig.keycodeRightSoftkey), new Integer(18));
        }
        GLLib.gameActionKeyTable.put(new Integer(GLLibConfig.keycodeFire), new Integer(5));
        GLLib.gameActionKeyTable.put(new Integer(GLLibConfig.keycodeUp), new Integer(1));
        GLLib.gameActionKeyTable.put(new Integer(GLLibConfig.keycodeDown), new Integer(2));
        GLLib.gameActionKeyTable.put(new Integer(GLLibConfig.keycodeLeft), new Integer(3));
        GLLib.gameActionKeyTable.put(new Integer(GLLibConfig.keycodeRight), new Integer(4));
    }
    
    protected void Quit() {
        Dbg("GLLib.quit");
        GLLib.s_game_state = -1;
    }
    
    public void run() {
        if (!GLLibConfig.useCallSerially) {
            Dbg("GLLib.run");
        }
        try {
            if (!GLLibConfig.useCallSerially) {
                this.SetupDisplay();
            }
            GLLib.s_game_isInPaint = false;
            while (GLLib.s_game_state >= 0) {
                if (!GLLib.s_game_isPaused) {
                    this.repaint();
                    if (GLLibConfig.useServiceRepaints) {
                        this.serviceRepaints();
                    }
                    this.Game_Run();
                    long curTime = System.currentTimeMillis();
                    this.m_frameCoheranceTimer = Math.min(this.m_frameCoheranceTimer, curTime);
                    if (GLLibConfig.useSleepInsteadOfYield) {
                        try {
                            Thread.sleep(Math.max(1L, GLLib.m_FPSLimiter - (curTime - this.m_frameCoheranceTimer)));
                        }
                        catch (final Exception e) {}
                    }
                    else {
                        while (curTime - this.m_frameCoheranceTimer < GLLib.m_FPSLimiter) {
                            Thread.yield();
                            curTime = System.currentTimeMillis();
                            this.m_frameCoheranceTimer = Math.min(this.m_frameCoheranceTimer, curTime);
                        }
                    }
                    this.m_frameCoheranceTimer = System.currentTimeMillis();
                }
                else {
                    this.m_frameCoheranceTimer = Math.min(this.m_frameCoheranceTimer, System.currentTimeMillis());
                    if (GLLibConfig.useSleepInsteadOfYield) {
                        try {
                            Thread.sleep(1L);
                        }
                        catch (final Exception e2) {}
                    }
                    else {
                        Thread.yield();
                    }
                }
                if (GLLibConfig.useCallSerially) {
                    GLLib.s_display.callSerially((Runnable)this);
                    return;
                }
            }
        }
        catch (final Exception e2) {
            Dbg("!!FATAL ERROR!! in cGame.run()." + e2);
            e2.printStackTrace();
            GLLib.s_game_state = -1;
        }
        Dbg("GLLib.Quitting main loop");
        this.UnInit();
        if (!GLLibConfig.disableNotifyDestroyed) {
            GLLib.s_application.notifyDestroyed();
        }
    }
    
    public void paint(final Graphics _g) {
        this.Game_Paint(_g);
    }
    
    private void Game_Paint(final Graphics _g) {
        if (GLLibConfig.useFakeInterruptHandling) {
            final long elapsedTime = System.currentTimeMillis() - GLLib.s_game_lastFrameTime;
            GLLib.s_game_lastFrameTime = System.currentTimeMillis();
            if (elapsedTime > GLLibConfig.FakeInterruptThreshold && GLLib.s_game_lastFrameTime != 0L) {
                this.Pause();
                this.Resume();
            }
        }
        if (GLLib.s_game_isPaused || GLLib.s_game_isInPaint) {
            return;
        }
        GLLib.s_game_isInPaint = true;
        this.UpdateKeypad();
        GLLib.s_game_timeWhenFrameStart = System.currentTimeMillis();
        if (GLLibConfig.useFrameDT) {
            GLLib.s_game_frameDT = (int)(GLLib.s_game_timeWhenFrameStart - GLLib.s_game_frameDTTimer);
            if (GLLib.s_game_frameDT < 0) {
                GLLib.s_game_frameDT = 0;
            }
            if (GLLib.s_game_frameDT > 1000) {
                GLLib.s_game_frameDT = 1000;
            }
            GLLib.s_game_frameDTTimer = GLLib.s_game_timeWhenFrameStart;
            GLLib.s_game_totalExecutionTime += GLLib.s_game_frameDT;
            GLLib.s_game_FPSAverage = 100000 * GLLib.s_game_currentFrameNB / (GLLib.s_game_totalExecutionTime + 1);
        }
        ++GLLib.s_game_currentFrameNB;
        try {
            if (GLLibConfig.useSoftwareDoubleBuffer) {
                GLLib.g = (GLLib.s_lastPaintGraphics = this.m_gBackBuffer);
                this.Game_update();
                _g.drawImage(this.m_imgBackBuffer, 0, 0, 20);
            }
            else {
                GLLib.s_lastPaintGraphics = _g;
                GLLib.g = _g;
                this.Game_update();
            }
        }
        catch (final Exception e) {
            Dbg("!!FATAL ERROR!! in Game_paint()." + e);
            e.printStackTrace();
            GLLib.s_game_state = -1;
        }
        if (GLLibConfig.lowMemoryLimit > 0 && Runtime.getRuntime().freeMemory() < GLLibConfig.lowMemoryLimit) {
            System.gc();
        }
        GLLib.s_game_interruptNotify = false;
        GLLib.s_game_isInPaint = false;
    }
    
    void CheckAndDumpConfig() {
        System.out.println("");
        System.out.println("");
        System.out.println("GLLib configuration (after the merge with your GLLibConfiguration.java file):");
        System.out.println("");
        System.out.println("This GLLib was compiled for   : MIDP2");
        System.out.println("");
        if (GLLibConfig.screenWidth != 0) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("screenWidth                                  = " + GLLibConfig.screenWidth);
        if (GLLibConfig.screenHeight != 0) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("screenHeight                                 = " + GLLibConfig.screenHeight);
        if (!GLLibConfig.useSystemGc) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useSystemGc                                  = " + GLLibConfig.useSystemGc);
        if (GLLibConfig.lowMemoryLimit != 0) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("lowMemoryLimit                               = " + GLLibConfig.lowMemoryLimit);
        if (!GLLibConfig.useFrameDT) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useFrameDT                                   = " + GLLibConfig.useFrameDT);
        if (!GLLibConfig.platformRequestOnExit) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("platformRequestOnExit                        = " + GLLibConfig.platformRequestOnExit);
        if (GLLibConfig.disableNotifyDestroyed) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("disableNotifyDestroyed                       = " + GLLibConfig.disableNotifyDestroyed);
        if (GLLibConfig.useSafeFillRect) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useSafeFillRect                              = " + GLLibConfig.useSafeFillRect);
        if (GLLibConfig.useDrawLineClippingBug) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useDrawLineClippingBug                       = " + GLLibConfig.useDrawLineClippingBug);
        if (!GLLibConfig.useSafeDrawRegion) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useSafeDrawRegion                            = " + GLLibConfig.useSafeDrawRegion);
        if (GLLibConfig.useSoftwareDoubleBuffer) {
            System.out.print("*");
            System.out.print("w");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useSoftwareDoubleBuffer                      = " + GLLibConfig.useSoftwareDoubleBuffer);
        if (GLLibConfig.FPSLimiter != 25) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("FPSLimiter                                   = " + GLLibConfig.FPSLimiter);
        if (!GLLibConfig.useSleepInsteadOfYield) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useSleepInsteadOfYield                       = " + GLLibConfig.useSleepInsteadOfYield);
        if (GLLibConfig.useCallSerially) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useCallSerially                              = " + GLLibConfig.useCallSerially);
        if (!GLLibConfig.useServiceRepaints) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useServiceRepaints                           = " + GLLibConfig.useServiceRepaints);
        if (GLLibConfig.useFakeInterruptHandling) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useFakeInterruptHandling                     = " + GLLibConfig.useFakeInterruptHandling);
        if (GLLibConfig.FakeInterruptThreshold != 3000) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    FakeInterruptThreshold                   = " + GLLibConfig.FakeInterruptThreshold);
        if (GLLibConfig.useDrawPartialRGB) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useDrawPartialRGB                            = " + GLLibConfig.useDrawPartialRGB);
        if (GLLibConfig.MIDP2forceNonFullScreen) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("MIDP2forceNonFullScreen                      = " + GLLibConfig.MIDP2forceNonFullScreen);
        if (!GLLibConfig.softkeyOKOnLeft) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("softkeyOKOnLeft                              = " + GLLibConfig.softkeyOKOnLeft);
        if (GLLibConfig.keycodeLeftSoftkey != -6) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("keycodeLeftSoftkey                           = " + GLLibConfig.keycodeLeftSoftkey);
        if (GLLibConfig.keycodeRightSoftkey != -7) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("keycodeRightSoftkey                          = " + GLLibConfig.keycodeRightSoftkey);
        if (GLLibConfig.keycodeFire != -5) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("keycodeFire                                  = " + GLLibConfig.keycodeFire);
        if (GLLibConfig.keycodeUp != -1) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("keycodeUp                                    = " + GLLibConfig.keycodeUp);
        if (GLLibConfig.keycodeDown != -2) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("keycodeDown                                  = " + GLLibConfig.keycodeDown);
        if (GLLibConfig.keycodeLeft != -3) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("keycodeLeft                                  = " + GLLibConfig.keycodeLeft);
        if (GLLibConfig.keycodeRight != -4) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("keycodeRight                                 = " + GLLibConfig.keycodeRight);
        if (!GLLibConfig.useKeyAccumulation) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useKeyAccumulation                           = " + GLLibConfig.useKeyAccumulation);
        if (GLLibConfig.useAbsoluteValueOfKeyCode) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useAbsoluteValueOfKeyCode                    = " + GLLibConfig.useAbsoluteValueOfKeyCode);
        if (GLLibConfig.useBugFixMultipleKeyPressed) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useBugFixMultipleKeyPressed                  = " + GLLibConfig.useBugFixMultipleKeyPressed);
        if (GLLibConfig.useFlashLightInsteadOfVibration) {
            System.out.print("*");
            System.out.print("w");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("useFlashLightInsteadOfVibration              = " + GLLibConfig.useFlashLightInsteadOfVibration);
        if (GLLibConfig.math_fixedPointBase != 8) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("math_fixedPointBase                          = " + GLLibConfig.math_fixedPointBase);
        if (GLLibConfig.math_angleFixedPointBase != 8) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("math_angleFixedPointBase                     = " + GLLibConfig.math_angleFixedPointBase);
        if (!GLLibConfig.math_AtanUseCacheTable) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("math_AtanUseCacheTable                       = " + GLLibConfig.math_AtanUseCacheTable);
        if (!GLLibConfig.text_useStringCache) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("text_useStringCache                          = " + GLLibConfig.text_useStringCache);
        if (GLLibConfig.text_useInternalUTF8Converter) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("text_useInternalUTF8Converter                = " + GLLibConfig.text_useInternalUTF8Converter);
        if (!GLLibConfig.sound_enable) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sound_enable                                 = " + GLLibConfig.sound_enable);
        if (GLLibConfig.sound_numberOfChannels != 2) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sound_numberOfChannels                   = " + GLLibConfig.sound_numberOfChannels);
        if (!GLLibConfig.sound_enableThread) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sound_enableThread                       = " + GLLibConfig.sound_enableThread);
        if (!GLLibConfig.sound_useJSR135) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sound_useJSR135                          = " + GLLibConfig.sound_useJSR135);
        if (GLLibConfig.sound_useCachedPlayers) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sound_useCachedPlayers                   = " + GLLibConfig.sound_useCachedPlayers);
        if (GLLibConfig.sound_useRealizedPlayers) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("        sound_useRealizedPlayers             = " + GLLibConfig.sound_useRealizedPlayers);
        if (GLLibConfig.sound_usePrefetchedPlayers) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("        sound_usePrefetchedPlayers           = " + GLLibConfig.sound_usePrefetchedPlayers);
        if (!GLLibConfig.sound_useSetMediaTimeBeforePlay) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sound_useSetMediaTimeBeforePlay          = " + GLLibConfig.sound_useSetMediaTimeBeforePlay);
        if (GLLibConfig.sound_useFakeMediaDuration) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sound_useFakeMediaDuration               = " + GLLibConfig.sound_useFakeMediaDuration);
        if (GLLibConfig.sound_useFreeChannelOnStop) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sound_useFreeChannelOnStop               = " + GLLibConfig.sound_useFreeChannelOnStop);
        if (!GLLibConfig.sound_useStopSoundsOnInterrupt) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sound_useStopSoundsOnInterrupt           = " + GLLibConfig.sound_useStopSoundsOnInterrupt);
        if (!GLLibConfig.sound_useSetLevel) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sound_useSetLevel                        = " + GLLibConfig.sound_useSetLevel);
        if (GLLibConfig.pack_skipbufferSize != 256) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("pack_skipbufferSize                          = " + GLLibConfig.pack_skipbufferSize);
        if (GLLibConfig.pack_keepLoaded) {
            System.out.print("*");
            System.out.print("w");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("pack_keepLoaded                              = " + GLLibConfig.pack_keepLoaded);
        if (GLLibConfig.pack_dbgDataAccess) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("pack_dbgDataAccess                           = " + GLLibConfig.pack_dbgDataAccess);
        if (GLLibConfig.pack_useBlackBerryGZipDecompression) {
            System.out.print("*");
            System.out.print("E");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("pack_useBlackBerryGZipDecompression          = " + GLLibConfig.pack_useBlackBerryGZipDecompression);
        if (GLLibConfig.pack_supportLZMADecompression) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("pack_supportLZMADecompression                = " + GLLibConfig.pack_supportLZMADecompression);
        if (GLLibConfig.rms_usePackRead) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("rms_usePackRead                              = " + GLLibConfig.rms_usePackRead);
        if (GLLibConfig.rms_useSharing) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("rms_useSharing                               = " + GLLibConfig.rms_useSharing);
        if (!GLLibConfig.tileset_useTileShift) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("tileset_useTileShift                         = " + GLLibConfig.tileset_useTileShift);
        if (GLLibConfig.tileset_maxLayerCount != 4) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("tileset_maxLayerCount                        = " + GLLibConfig.tileset_maxLayerCount);
        if (GLLibConfig.tileset_useIndexAsShort) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("tileset_useIndexAsShort                      = " + GLLibConfig.tileset_useIndexAsShort);
        if (GLLibConfig.sprite_animFPS != 25) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_animFPS                               = " + GLLibConfig.sprite_animFPS);
        if (GLLibConfig.MAX_SPRITE_PALETTES != 16) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("MAX_SPRITE_PALETTES                          = " + GLLibConfig.MAX_SPRITE_PALETTES);
        if (GLLibConfig.MAX_FLIP_COUNT != 3) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("MAX_FLIP_COUNT                               = " + GLLibConfig.MAX_FLIP_COUNT);
        if (GLLibConfig.TMP_BUFFER_SIZE != 256) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("TMP_BUFFER_SIZE                              = " + GLLibConfig.TMP_BUFFER_SIZE);
        if (GLLibConfig.PNG_BUFFER_SIZE != 256) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("PNG_BUFFER_SIZE                              = " + GLLibConfig.PNG_BUFFER_SIZE);
        if (GLLibConfig.FIXED_PRECISION != 8) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("FIXED_PRECISION                              = " + GLLibConfig.FIXED_PRECISION);
        if (GLLibConfig.sprite_useNokiaUI) {
            System.out.print("*");
            System.out.print("E");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useNokiaUI                            = " + GLLibConfig.sprite_useNokiaUI);
        if (GLLibConfig.sprite_useDynamicPng) {
            System.out.print("*");
            System.out.print("w");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useDynamicPng                         = " + GLLibConfig.sprite_useDynamicPng);
        if (GLLibConfig.sprite_usePrecomputedCRC) {
            System.out.print("*");
            System.out.print("w");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sprite_usePrecomputedCRC                 = " + GLLibConfig.sprite_usePrecomputedCRC);
        if (GLLibConfig.sprite_useBSpriteFlags) {
            System.out.print("*");
            System.out.print("w");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("        sprite_useBSpriteFlags               = " + GLLibConfig.sprite_useBSpriteFlags);
        if (!GLLibConfig.sprite_useCreateRGB) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useCreateRGB                          = " + GLLibConfig.sprite_useCreateRGB);
        if (GLLibConfig.sprite_useGifHeader) {
            System.out.print("*");
            System.out.print("w");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useGifHeader                          = " + GLLibConfig.sprite_useGifHeader);
        if (GLLibConfig.sprite_useLoadImageWithoutTransf) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useLoadImageWithoutTransf             = " + GLLibConfig.sprite_useLoadImageWithoutTransf);
        if (GLLibConfig.sprite_useTransfRot) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useTransfRot                          = " + GLLibConfig.sprite_useTransfRot);
        if (GLLibConfig.sprite_useTransfFlip) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useTransfFlip                         = " + GLLibConfig.sprite_useTransfFlip);
        if (GLLibConfig.sprite_usePrecomputedFrameRect) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_usePrecomputedFrameRect               = " + GLLibConfig.sprite_usePrecomputedFrameRect);
        if (GLLibConfig.sprite_useBugFixImageOddSize) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useBugFixImageOddSize                 = " + GLLibConfig.sprite_useBugFixImageOddSize);
        if (GLLibConfig.sprite_useDrawRegionClipping) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useDrawRegionClipping                 = " + GLLibConfig.sprite_useDrawRegionClipping);
        if (GLLibConfig.sprite_useNokia7650DrawPixelBug) {
            System.out.print("*");
            System.out.print("E");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useNokia7650DrawPixelBug              = " + GLLibConfig.sprite_useNokia7650DrawPixelBug);
        if (GLLibConfig.sprite_drawPixelClippingBug) {
            System.out.print("*");
            System.out.print("E");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_drawPixelClippingBug                  = " + GLLibConfig.sprite_drawPixelClippingBug);
        if (GLLibConfig.sprite_fillRoundRectBug) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_fillRoundRectBug                      = " + GLLibConfig.sprite_fillRoundRectBug);
        if (GLLibConfig.sprite_drawRegionFlippedBug) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_drawRegionFlippedBug                  = " + GLLibConfig.sprite_drawRegionFlippedBug);
        if (GLLibConfig.sprite_useDrawStringSleep) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useDrawStringSleep                    = " + GLLibConfig.sprite_useDrawStringSleep);
        if (GLLibConfig.SLEEP_DRAWSTRINGB != 1) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    SLEEP_DRAWSTRINGB                        = " + GLLibConfig.SLEEP_DRAWSTRINGB);
        if (GLLibConfig.sprite_useCreateRGBTransparencyBug) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useCreateRGBTransparencyBug           = " + GLLibConfig.sprite_useCreateRGBTransparencyBug);
        if (GLLibConfig.sprite_drawRGBTransparencyBug) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_drawRGBTransparencyBug                = " + GLLibConfig.sprite_drawRGBTransparencyBug);
        if (GLLibConfig.sprite_useSingleDirectGraphics) {
            System.out.print("*");
            System.out.print("E");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useSingleDirectGraphics               = " + GLLibConfig.sprite_useSingleDirectGraphics);
        if (GLLibConfig.sprite_useSingleImageForAllModules) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useSingleImageForAllModules           = " + GLLibConfig.sprite_useSingleImageForAllModules);
        if (GLLibConfig.sprite_fpsRegion) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sprite_fpsRegion                         = " + GLLibConfig.sprite_fpsRegion);
        if (GLLibConfig.sprite_useCacheFlipXY) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sprite_useCacheFlipXY                    = " + GLLibConfig.sprite_useCacheFlipXY);
        if (!GLLibConfig.sprite_ModuleMapping_useModuleImages) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_ModuleMapping_useModuleImages         = " + GLLibConfig.sprite_ModuleMapping_useModuleImages);
        if (GLLibConfig.sprite_useCacheRGBArrays) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useCacheRGBArrays                     = " + GLLibConfig.sprite_useCacheRGBArrays);
        if (GLLibConfig.sprite_RGBArraysUseDrawRGB) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_RGBArraysUseDrawRGB                   = " + GLLibConfig.sprite_RGBArraysUseDrawRGB);
        if (GLLibConfig.sprite_useTruncatedRGBBuffer) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sprite_useTruncatedRGBBuffer             = " + GLLibConfig.sprite_useTruncatedRGBBuffer);
        if (GLLibConfig.sprite_useSkipFastVisibilityTest) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useSkipFastVisibilityTest             = " + GLLibConfig.sprite_useSkipFastVisibilityTest);
        if (!GLLibConfig.sprite_useModuleMapping) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useModuleMapping                      = " + GLLibConfig.sprite_useModuleMapping);
        if (GLLibConfig.MAX_MODULE_MAPPINGS != 16) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    MAX_MODULE_MAPPINGS                      = " + GLLibConfig.MAX_MODULE_MAPPINGS);
        if (GLLibConfig.sprite_useSingleArrayForFMAF) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useSingleArrayForFMAF                 = " + GLLibConfig.sprite_useSingleArrayForFMAF);
        if (GLLibConfig.sprite_useExternImage) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useExternImage                        = " + GLLibConfig.sprite_useExternImage);
        if (!GLLibConfig.sprite_useModuleDataOffAsShort) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useModuleDataOffAsShort               = " + GLLibConfig.sprite_useModuleDataOffAsShort);
        if (GLLibConfig.sprite_useCachePool) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useCachePool                          = " + GLLibConfig.sprite_useCachePool);
        if (!GLLibConfig.sprite_usePixelFormat8888) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_usePixelFormat8888                    = " + GLLibConfig.sprite_usePixelFormat8888);
        if (!GLLibConfig.sprite_usePixelFormat4444) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_usePixelFormat4444                    = " + GLLibConfig.sprite_usePixelFormat4444);
        if (!GLLibConfig.sprite_usePixelFormat1555) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_usePixelFormat1555                    = " + GLLibConfig.sprite_usePixelFormat1555);
        if (!GLLibConfig.sprite_usePixelFormat0565) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_usePixelFormat0565                    = " + GLLibConfig.sprite_usePixelFormat0565);
        if (!GLLibConfig.sprite_useEncodeFormatI2) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useEncodeFormatI2                     = " + GLLibConfig.sprite_useEncodeFormatI2);
        if (!GLLibConfig.sprite_useEncodeFormatI4) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useEncodeFormatI4                     = " + GLLibConfig.sprite_useEncodeFormatI4);
        if (!GLLibConfig.sprite_useEncodeFormatI16) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useEncodeFormatI16                    = " + GLLibConfig.sprite_useEncodeFormatI16);
        if (!GLLibConfig.sprite_useEncodeFormatI64RLE) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useEncodeFormatI64RLE                 = " + GLLibConfig.sprite_useEncodeFormatI64RLE);
        if (!GLLibConfig.sprite_useEncodeFormatI127RLE) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useEncodeFormatI127RLE                = " + GLLibConfig.sprite_useEncodeFormatI127RLE);
        if (!GLLibConfig.sprite_useEncodeFormatI256RLE) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useEncodeFormatI256RLE                = " + GLLibConfig.sprite_useEncodeFormatI256RLE);
        if (GLLibConfig.sprite_useEncodeFormatI256) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useEncodeFormatI256                   = " + GLLibConfig.sprite_useEncodeFormatI256);
        if (GLLibConfig.sprite_useNonInterlaced) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useNonInterlaced                      = " + GLLibConfig.sprite_useNonInterlaced);
        if (GLLibConfig.sprite_useModuleXY) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useModuleXY                           = " + GLLibConfig.sprite_useModuleXY);
        if (GLLibConfig.sprite_useModuleXYShort) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useModuleXYShort                      = " + GLLibConfig.sprite_useModuleXYShort);
        if (GLLibConfig.sprite_useModuleWHShort) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useModuleWHShort                      = " + GLLibConfig.sprite_useModuleWHShort);
        if (GLLibConfig.sprite_useIndexExFmodules) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useIndexExFmodules                    = " + GLLibConfig.sprite_useIndexExFmodules);
        if (GLLibConfig.sprite_useFMOffShort) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useFMOffShort                         = " + GLLibConfig.sprite_useFMOffShort);
        if (GLLibConfig.sprite_alwaysBsNfm1Byte) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_alwaysBsNfm1Byte                      = " + GLLibConfig.sprite_alwaysBsNfm1Byte);
        if (GLLibConfig.sprite_useFMPalette) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useFMPalette                          = " + GLLibConfig.sprite_useFMPalette);
        if (GLLibConfig.sprite_useHyperFM) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useHyperFM                            = " + GLLibConfig.sprite_useHyperFM);
        if (GLLibConfig.sprite_alwaysBsNoFmStart) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_alwaysBsNoFmStart                     = " + GLLibConfig.sprite_alwaysBsNoFmStart);
        if (GLLibConfig.sprite_useAfOffShort) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useAfOffShort                         = " + GLLibConfig.sprite_useAfOffShort);
        if (GLLibConfig.sprite_alwaysBsNoAfStart) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_alwaysBsNoAfStart                     = " + GLLibConfig.sprite_alwaysBsNoAfStart);
        if (GLLibConfig.sprite_useIndexExAframes) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useIndexExAframes                     = " + GLLibConfig.sprite_useIndexExAframes);
        if (GLLibConfig.sprite_useOperationRecord) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useOperationRecord                    = " + GLLibConfig.sprite_useOperationRecord);
        if (GLLibConfig.sprite_useOperationRect) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useOperationRect                      = " + GLLibConfig.sprite_useOperationRect);
        if (GLLibConfig.sprite_useOperationMark) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useOperationMark                      = " + GLLibConfig.sprite_useOperationMark);
        if (GLLibConfig.sprite_useModuleUsageFromSprite) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useModuleUsageFromSprite              = " + GLLibConfig.sprite_useModuleUsageFromSprite);
        if (GLLibConfig.sprite_fontUseOneFramePerLetter) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_fontUseOneFramePerLetter              = " + GLLibConfig.sprite_fontUseOneFramePerLetter);
        if (GLLibConfig.sprite_fontBackslashChangePalette) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_fontBackslashChangePalette            = " + GLLibConfig.sprite_fontBackslashChangePalette);
        if (GLLibConfig.sprite_useResize) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useResize                             = " + GLLibConfig.sprite_useResize);
        if (GLLibConfig.sprite_useGenPalette != 16) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useGenPalette                         = " + GLLibConfig.sprite_useGenPalette);
        if (GLLibConfig.sprite_useMultipleModuleTypes) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useMultipleModuleTypes                = " + GLLibConfig.sprite_useMultipleModuleTypes);
        if (GLLibConfig.sprite_useModuleColorAsByte) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sprite_useModuleColorAsByte              = " + GLLibConfig.sprite_useModuleColorAsByte);
        if (GLLibConfig.sprite_useFrameRects) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useFrameRects                         = " + GLLibConfig.sprite_useFrameRects);
        if (GLLibConfig.sprite_alwaysBsSkipFrameRc) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    sprite_alwaysBsSkipFrameRc               = " + GLLibConfig.sprite_alwaysBsSkipFrameRc);
        if (GLLibConfig.sprite_useFrameCollRC) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useFrameCollRC                        = " + GLLibConfig.sprite_useFrameCollRC);
        if (GLLibConfig.sprite_useDeactivateSystemGc) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_useDeactivateSystemGc                 = " + GLLibConfig.sprite_useDeactivateSystemGc);
        if (GLLibConfig.sprite_debugLoading) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_debugLoading                          = " + GLLibConfig.sprite_debugLoading);
        if (GLLibConfig.sprite_debugErrors) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_debugErrors                           = " + GLLibConfig.sprite_debugErrors);
        if (GLLibConfig.sprite_debugUsedMemory) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_debugUsedMemory                       = " + GLLibConfig.sprite_debugUsedMemory);
        if (GLLibConfig.sprite_debugModuleUsage) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_debugModuleUsage                      = " + GLLibConfig.sprite_debugModuleUsage);
        if (GLLibConfig.sprite_debugColision) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_debugColision                         = " + GLLibConfig.sprite_debugColision);
        if (!GLLibConfig.sprite_newTextRendering) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("sprite_newTextRendering                      = " + GLLibConfig.sprite_newTextRendering);
        if (GLLibConfig.MAX_WRAP_TEXT_INFO != 100) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("MAX_WRAP_TEXT_INFO                           = " + GLLibConfig.MAX_WRAP_TEXT_INFO);
        if (GLLibConfig.xplayer_XPLAYER_VERSION != 1) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_XPLAYER_VERSION                      = " + GLLibConfig.xplayer_XPLAYER_VERSION);
        if (!GLLibConfig.xplayer_ENABLE_DEBUG) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_ENABLE_DEBUG                         = " + GLLibConfig.xplayer_ENABLE_DEBUG);
        if (GLLibConfig.xplayer_ENABLE_TIMEOUT) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_ENABLE_TIMEOUT                       = " + GLLibConfig.xplayer_ENABLE_TIMEOUT);
        if (GLLibConfig.xplayer_CONN_TIMEOUT != 30000) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    xplayer_CONN_TIMEOUT                     = " + GLLibConfig.xplayer_CONN_TIMEOUT);
        if (GLLibConfig.xplayer_HTTP_NO_CANCEL) {
            System.out.print("*");
            System.out.print("w");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_HTTP_NO_CANCEL                       = " + GLLibConfig.xplayer_HTTP_NO_CANCEL);
        if (GLLibConfig.xplayer_USE_HTTP_POST) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_USE_HTTP_POST                        = " + GLLibConfig.xplayer_USE_HTTP_POST);
        if (GLLibConfig.xplayer_CARRIER_USSPRINT) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_CARRIER_USSPRINT                     = " + GLLibConfig.xplayer_CARRIER_USSPRINT);
        if (GLLibConfig.xplayer_CARRIER_USNEXTEL) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_CARRIER_USNEXTEL                     = " + GLLibConfig.xplayer_CARRIER_USNEXTEL);
        if (GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_CARRIER_USCINGULAR_ORANGE            = " + GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE);
        if (GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_CARRIER_USCINGULAR_BLUE              = " + GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE);
        if (GLLibConfig.xplayer_CARRIER_USVIRGIN) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_CARRIER_USVIRGIN                     = " + GLLibConfig.xplayer_CARRIER_USVIRGIN);
        if (GLLibConfig.xplayer_ENABLE_M7_SUPPORT) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_ENABLE_M7_SUPPORT                    = " + GLLibConfig.xplayer_ENABLE_M7_SUPPORT);
        if (GLLibConfig.xplayer_CARRIER_MXTELCEL) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_CARRIER_MXTELCEL                     = " + GLLibConfig.xplayer_CARRIER_MXTELCEL);
        if (GLLibConfig.xplayer_USE_BUG_FIX_MESSAGE_SIZE) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_USE_BUG_FIX_MESSAGE_SIZE             = " + GLLibConfig.xplayer_USE_BUG_FIX_MESSAGE_SIZE);
        if (GLLibConfig.xplayer_ENABLE_MULTIPLAYER) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("xplayer_ENABLE_MULTIPLAYER                   = " + GLLibConfig.xplayer_ENABLE_MULTIPLAYER);
        if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    xplayer_ENABLE_DUAL_TCP                  = " + GLLibConfig.xplayer_ENABLE_DUAL_TCP);
        if (GLLibConfig.xplayer_ENABLE_PLAYER_SPECIFIC_DATA) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    xplayer_ENABLE_PLAYER_SPECIFIC_DATA      = " + GLLibConfig.xplayer_ENABLE_PLAYER_SPECIFIC_DATA);
        if (GLLibConfig.xplayer_ENABLE_FIND_PLAYER) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    xplayer_ENABLE_FIND_PLAYER               = " + GLLibConfig.xplayer_ENABLE_FIND_PLAYER);
        if (GLLibConfig.xplayer_KEEP_ALIVE_TIME != 7000) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("    xplayer_KEEP_ALIVE_TIME                  = " + GLLibConfig.xplayer_KEEP_ALIVE_TIME);
        if (GLLibConfig.doja_ScratchPad_EOF != -1) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("doja_ScratchPad_EOF                          = " + GLLibConfig.doja_ScratchPad_EOF);
        if (GLLibConfig.doja_ScratchPad_SaveGameFile != -1) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("doja_ScratchPad_SaveGameFile                 = " + GLLibConfig.doja_ScratchPad_SaveGameFile);
        if (GLLibConfig.doja_ScratchPad_CreditsFile != -1) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("doja_ScratchPad_CreditsFile                  = " + GLLibConfig.doja_ScratchPad_CreditsFile);
        if (GLLibConfig.doja_Network_NoError != -1) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("doja_Network_NoError                         = " + GLLibConfig.doja_Network_NoError);
        if (GLLibConfig.doja_Network_ErrorNoNetwork != 0) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("doja_Network_ErrorNoNetwork                  = " + GLLibConfig.doja_Network_ErrorNoNetwork);
        if (GLLibConfig.doja_Network_ErrorNoNetworkAccess != 1) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("doja_Network_ErrorNoNetworkAccess            = " + GLLibConfig.doja_Network_ErrorNoNetworkAccess);
        if (GLLibConfig.doja_Network_ErrorNoCredits != 4) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("doja_Network_ErrorNoCredits                  = " + GLLibConfig.doja_Network_ErrorNoCredits);
        if (GLLibConfig.pathfinding_MaxNode != 400) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("pathfinding_MaxNode                          = " + GLLibConfig.pathfinding_MaxNode);
        if (GLLibConfig.pathfinding_Debug) {
            System.out.print("*");
            System.out.print(" ");
            System.out.print(" ");
        }
        else {
            System.out.print("   ");
        }
        System.out.println("pathfinding_Debug                            = " + GLLibConfig.pathfinding_Debug);
        System.out.println("Legend :");
        System.out.println("* - Different from default");
        System.out.println("w - Different from default, be carefull with this modification");
        System.out.println("E - Different from default, Invalid value for your plateform");
        System.out.println("");
        System.out.println("");
        System.out.println("");
    }
    
    protected void keyPressed(final int keyCode) {
        if (GLLibConfig.useKeyAccumulation) {
            GLLib.s_keyLastKeyPressUntranslatedCode = keyCode;
            final byte i = this.Game_TranslateKeyCode(keyCode);
            if (GLLib.s_keyStateRT[i] > 0) {
                return;
            }
            if (GLLib.s_keyStateRT[i] < 0) {
                GLLib.s_keyStateRT[i] = 0;
            }
            if (GLLib.s_keyStateRT[i] < 126) {
                final byte[] s_keyStateRT = GLLib.s_keyStateRT;
                final byte b = i;
                ++s_keyStateRT[b];
            }
        }
        else {
            if (GLLibConfig.useBugFixMultipleKeyPressed) {
                if (GLLib.m_last_key_pressed != keyCode && GLLib.m_last_key_pressed != -9999) {
                    this.keyReleased(GLLib.m_last_key_pressed);
                }
                GLLib.m_last_key_pressed = keyCode;
            }
            final int keyFlag = 1 << this.Game_TranslateKeyCode(keyCode);
            GLLib.m_current_keys_pressed |= keyFlag;
            GLLib.m_current_keys_state |= keyFlag;
        }
    }
    
    protected void keyReleased(final int keyCode) {
        if (GLLibConfig.useKeyAccumulation) {
            final byte i = this.Game_TranslateKeyCode(keyCode);
            if (GLLib.s_keyStateRT[i] > 0) {
                final byte[] s_keyStateRT = GLLib.s_keyStateRT;
                final byte b = i;
                s_keyStateRT[b] *= -1;
            }
        }
        else {
            if (GLLibConfig.useBugFixMultipleKeyPressed && keyCode == GLLib.m_last_key_pressed) {
                GLLib.m_last_key_pressed = -9999;
            }
            final int keyFlag = 1 << this.Game_TranslateKeyCode(keyCode);
            GLLib.m_current_keys_released |= keyFlag;
            GLLib.m_current_keys_state &= ~keyFlag;
        }
    }
    
    private void UpdateKeypad() {
        if (GLLibConfig.useKeyAccumulation) {
            GLLib.s_game_keyEventIndex = -1;
            GLLib.s_game_keyJustPressed = -1;
            for (int i = 0; i < 20; ++i) {
                GLLib.s_keyState[i] = GLLib.s_keyStateRT[i];
                if (GLLib.s_keyStateRT[i] != 0) {
                    GLLib.s_game_keyEventIndex = i;
                    if (GLLib.s_keyStateRT[i] < 0) {
                        GLLib.s_keyStateRT[i] = 0;
                    }
                    else if (GLLib.s_keyStateRT[i] < 126) {
                        if (GLLib.s_keyStateRT[i] == 1) {
                            GLLib.s_game_keyJustPressed = i;
                            GLLib.s_game_keyPressedTime = GLLib.s_game_timeWhenFrameStart;
                        }
                        final byte[] s_keyStateRT = GLLib.s_keyStateRT;
                        final int n = i;
                        ++s_keyStateRT[n];
                        if (i >= 18) {
                            final byte[] s_keyStateRT2 = GLLib.s_keyStateRT;
                            final int n2 = i;
                            s_keyStateRT2[n2] *= -1;
                        }
                    }
                }
            }
        }
        else {
            GLLib.m_keys_pressed = GLLib.m_current_keys_pressed;
            GLLib.m_keys_released = GLLib.m_current_keys_released;
            GLLib.m_keys_state = GLLib.m_current_keys_state;
            GLLib.m_current_keys_pressed = 0;
            GLLib.m_current_keys_released = 0;
            GLLib.s_game_keyPressedTime = GLLib.s_game_timeWhenFrameStart;
        }
    }
    
    public static void Game_KeyClearKeyCode() {
        GLLib.gameActionKeyTable = new Hashtable();
        GLLib.standardKeyTable = new Hashtable();
    }
    
    public static void Game_KeySetKeyCode(final boolean gameAction, final int keyCode, final int key) {
        Hashtable hashtable = null;
        final Integer ikey = new Integer(keyCode);
        if (gameAction) {
            hashtable = GLLib.gameActionKeyTable;
        }
        else {
            hashtable = GLLib.standardKeyTable;
        }
        final Integer oldAssignation = hashtable.get(ikey);
        if (oldAssignation != null) {
            hashtable.remove(ikey);
        }
        hashtable.put(ikey, new Integer(key));
    }
    
    private byte Game_TranslateKeyCode(int keyCode) {
        if (GLLibConfig.useAbsoluteValueOfKeyCode && keyCode < 0) {
            keyCode *= -1;
        }
        final Integer key = new Integer(keyCode);
        Integer code = GLLib.standardKeyTable.get(key);
        if (code != null) {
            return code.byteValue();
        }
        code = GLLib.gameActionKeyTable.get(key);
        if (code != null) {
            return code.byteValue();
        }
        return 0;
    }
    
    public static void ResetKey() {
        if (GLLibConfig.useKeyAccumulation) {
            if (GLLib.s_keyState != null && GLLib.s_keyStateRT != null) {
                for (int i = 0; i < 20; ++i) {
                    GLLib.s_keyState[i] = 0;
                    GLLib.s_keyStateRT[i] = 0;
                }
            }
        }
        else {
            GLLib.m_keys_pressed = 0;
            GLLib.m_keys_released = 0;
            GLLib.m_keys_state = 0;
            GLLib.m_current_keys_state = 0;
            GLLib.m_current_keys_pressed = 0;
            GLLib.m_current_keys_released = 0;
        }
    }
    
    public static void ResetAKey(final int keyFlag) {
        if (GLLibConfig.useKeyAccumulation) {
            GLLib.s_keyState[keyFlag] = 0;
            GLLib.s_keyStateRT[keyFlag] = 0;
        }
        else if ((GLLib.m_keys_state & 1 << keyFlag) != 0x0) {
            GLLib.m_keys_pressed = 0;
            GLLib.m_keys_released = 0;
            GLLib.m_keys_state = 0;
            GLLib.m_current_keys_state = 0;
            GLLib.m_current_keys_pressed = 0;
            GLLib.m_current_keys_released = 0;
        }
    }
    
    public static int IsAnyKeyDown() {
        if (GLLibConfig.useKeyAccumulation) {
            for (int i = 0; i < 20; ++i) {
                if (GLLib.s_keyState[i] > 0) {
                    return i;
                }
            }
            return -1;
        }
        for (int i = 0; i < 20; ++i) {
            if ((GLLib.m_keys_state & 1 << i) != 0x0) {
                return i;
            }
        }
        return -1;
    }
    
    public static boolean IsKeyDown(final int keyFlag) {
        if (GLLibConfig.useKeyAccumulation) {
            return GLLib.s_keyState[keyFlag] > 0;
        }
        return (GLLib.m_keys_state & 1 << keyFlag) != 0x0;
    }
    
    public static boolean IsKeyUp(final int keyFlag) {
        if (GLLibConfig.useKeyAccumulation) {
            return GLLib.s_keyState[keyFlag] <= 0;
        }
        return (GLLib.m_keys_state & 1 << keyFlag) == 0x0;
    }
    
    public static int WasAnyKeyPressed() {
        if (GLLibConfig.useKeyAccumulation) {
            for (int i = 0; i < 20; ++i) {
                if (GLLib.s_keyState[i] == 1) {
                    return i;
                }
            }
            return -1;
        }
        if (GLLib.m_keys_pressed == 0) {
            return -1;
        }
        for (int i = 0; i < 20; ++i) {
            if ((GLLib.m_keys_pressed & 1 << i) != 0x0) {
                return i;
            }
        }
        return -1;
    }
    
    public static int WasAnyKeyReleased() {
        if (GLLibConfig.useKeyAccumulation) {
            for (int i = 0; i < 20; ++i) {
                if (GLLib.s_keyState[i] < 0) {
                    return i;
                }
            }
            return -1;
        }
        if (GLLib.m_keys_released == 0) {
            return -1;
        }
        for (int i = 0; i < 20; ++i) {
            if ((GLLib.m_keys_released & 1 << i) != 0x0) {
                return i;
            }
        }
        return -1;
    }
    
    public static boolean WasKeyPressed(final int keyFlag) {
        if (GLLibConfig.useKeyAccumulation) {
            return GLLib.s_keyState[keyFlag] == 1;
        }
        return (GLLib.m_keys_pressed & 1 << keyFlag) != 0x0;
    }
    
    public static boolean WasKeyReleased(final int keyFlag) {
        if (GLLibConfig.useKeyAccumulation) {
            return GLLib.s_keyState[keyFlag] < 0;
        }
        return (GLLib.m_keys_released & 1 << keyFlag) != 0x0;
    }
    
    static void Dbg(final String log) {
        System.out.println(log);
    }
    
    static void Assert(final boolean test, final String errMessage) {
        if (!test) {
            Dbg("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            Dbg("ERROR . " + errMessage);
            Dbg("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            new Throwable().printStackTrace();
        }
    }
    
    static void Warning(final String message) {
        Dbg("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        Dbg("WARNING . " + message);
        Dbg("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    }
    
    static void Print(final String log) {
        System.out.print(log);
    }
    
    static void Math_Init(final String packName, final int cos, final int sqrt) throws Exception {
        if (packName == null) {
            Assert(false, "Math_Init.packName is null");
        }
        Pack_Open(packName);
        if (cos >= 0) {
            GLLib.s_math_cosTable = (int[])Pack_ReadArray(cos);
        }
        else {
            GLLib.s_math_cosTable = null;
        }
        if (sqrt >= 0) {
            GLLib.s_math_sqrtTable = (int[])Pack_ReadArray(sqrt);
        }
        else {
            GLLib.s_math_sqrtTable = null;
        }
        Pack_Close();
    }
    
    static void Math_Quit() {
        GLLib.s_math_cosTable = null;
        GLLib.s_math_sqrtTable = null;
        GLLib.s_math_random = null;
        GLLib.s_math_aTanTable = null;
    }
    
    static int Math_FixedPointAdjust(final int a) {
        if (GLLibConfig.math_fixedPointBase > GLLibConfig.math_angleFixedPointBase) {
            return a << GLLibConfig.math_fixedPointBase - GLLibConfig.math_angleFixedPointBase;
        }
        if (GLLibConfig.math_fixedPointBase < GLLibConfig.math_angleFixedPointBase) {
            return a >> GLLibConfig.math_angleFixedPointBase - GLLibConfig.math_fixedPointBase;
        }
        return a;
    }
    
    static int Math_IntToFixedPoint(final int a) {
        return a << GLLibConfig.math_fixedPointBase;
    }
    
    static int Math_FixedPointToInt(final int a) {
        return a + (GLLib.s_math_F_1 >> 1) >> GLLibConfig.math_fixedPointBase;
    }
    
    static int Math_Div10(final int a) {
        return a * 6554 >> 16 - GLLibConfig.math_fixedPointBase;
    }
    
    static int Math_Log2(final int a) {
        if (a < 0) {
            Assert(false, "Math_Log2.value is negative");
        }
        int r;
        for (r = 0; a >> r > 1; ++r) {}
        return r;
    }
    
    static boolean Math_SameSign(final int a, final int b) {
        return (a ^ b) >= 0;
    }
    
    static int Math_Det(final int x1, final int y1, final int x2, final int y2) {
        return x1 * y2 - y1 * x2;
    }
    
    static int Math_DotProduct(final int x1, final int y1, final int x2, final int y2) {
        return x1 * x2 + y1 * y2;
    }
    
    static int Math_NormPow(final int x1, final int y1) {
        return x1 * x1 + y1 * y1;
    }
    
    static int Math_Norm(final int x, final int y, final int iter) {
        final int R = x * x + y * y;
        int x_0 = 1;
        for (int i = 0; i < iter; ++i) {
            x_0 = x_0 + R / x_0 >> 1;
        }
        return x_0;
    }
    
    static final void Math_RandSetSeed(final long seed) {
        if (GLLib.s_math_random == null) {
            GLLib.s_math_random = new Random(seed);
        }
        else {
            GLLib.s_math_random.setSeed(seed);
        }
    }
    
    static int Math_Rand(final int a, final int b) {
        if (GLLib.s_math_random == null) {
            Assert(false, "Math_Rand.GLLib mut be initialised prior to using this function");
        }
        if (a > b) {
            Assert(false, "Math_Rand.a must be <= b");
        }
        if (b != a) {
            int rnd = GLLib.s_math_random.nextInt();
            if (rnd < 0) {
                rnd *= -1;
            }
            return a + rnd % (b - a);
        }
        return b;
    }
    
    static final int Math_Rand() {
        if (GLLib.s_math_random == null) {
            Assert(false, "Math_Rand.GLLib mut be initialised prior to using this function");
        }
        return GLLib.s_math_random.nextInt();
    }
    
    static int Math_DegreeToFixedPointAngle(final int a) {
        return a * GLLib.Math_AngleMUL / 360;
    }
    
    static int Math_FixedPointAngleToDegree(final int a) {
        return a * 360 >> GLLibConfig.math_angleFixedPointBase;
    }
    
    static int Math_Sin(final int a) {
        if (GLLib.s_math_cosTable == null) {
            Assert(false, "!!ERROR!! Math_Sin.s_math_cosTable is null, call Math_Init first");
        }
        return Math_Cos(GLLib.Math_Angle90 - a);
    }
    
    static int Math_Cos(int angle) {
        if (GLLib.s_math_cosTable == null) {
            Assert(false, "!!ERROR!! Math_Cos.s_math_cosTable is null, call Math_Init first");
        }
        if (angle < 0) {
            angle *= -1;
        }
        angle &= GLLib.Math_Angle360 - 1;
        if (angle <= GLLib.Math_Angle90) {
            return GLLib.s_math_cosTable[angle];
        }
        if (angle < GLLib.Math_Angle180) {
            angle = GLLib.Math_Angle180 - angle;
            return -GLLib.s_math_cosTable[angle];
        }
        if (angle <= GLLib.Math_Angle270) {
            angle -= GLLib.Math_Angle180;
            return -GLLib.s_math_cosTable[angle];
        }
        angle = GLLib.Math_Angle360 - angle;
        return GLLib.s_math_cosTable[angle];
    }
    
    static int Math_Tan(final int angle) {
        if (GLLib.s_math_cosTable == null) {
            Assert(false, "!!ERROR!! Math_Tan.s_math_cosTable is null, call Math_Init first");
        }
        final int tan = Math_Cos(angle);
        if (tan == 0) {
            return Integer.MAX_VALUE;
        }
        return Math_IntToFixedPoint(Math_Sin(angle)) / tan;
    }
    
    private static int Math_AtanSlow(final int st, final int end, final int tang) {
        for (int i = st; i < end; ++i) {
            if (Math_Tan(i) <= tang && tang < Math_Tan(i + 1)) {
                return i;
            }
        }
        if (st == GLLib.Math_Angle90 || end == GLLib.Math_Angle90) {
            return GLLib.Math_Angle90;
        }
        if (st == GLLib.Math_Angle270 || end == GLLib.Math_Angle270) {
            return GLLib.Math_Angle270;
        }
        return 0;
    }
    
    static int Math_AtanSlow(final int dx, final int dy) {
        if (dx > 0) {
            if (dy > 0) {
                return Math_AtanSlow(0, GLLib.Math_Angle90, dy * GLLib.s_math_F_1 / dx);
            }
            if (dy == 0) {
                return 0;
            }
            return Math_AtanSlow(GLLib.Math_Angle270, GLLib.Math_Angle360, dy * GLLib.s_math_F_1 / dx);
        }
        else if (dx == 0) {
            if (dy > 0) {
                return GLLib.Math_Angle90;
            }
            if (dy == 0) {
                return 0;
            }
            return GLLib.Math_Angle270;
        }
        else {
            if (dy > 0) {
                return Math_AtanSlow(GLLib.Math_Angle90, GLLib.Math_Angle180, dy * GLLib.s_math_F_1 / dx);
            }
            if (dy == 0) {
                return GLLib.Math_Angle180;
            }
            return Math_AtanSlow(GLLib.Math_Angle180, GLLib.Math_Angle270, dy * GLLib.s_math_F_1 / dx);
        }
    }
    
    static int Math_Atan(int dx, int dy) {
        if (!GLLibConfig.math_AtanUseCacheTable) {
            return Math_AtanSlow(dx, dy);
        }
        if (GLLib.s_math_aTanTable == null) {
            GLLib.s_math_aTanTable = new int[GLLib.s_math_F_1 + 1];
            for (int i = 0; i < GLLib.s_math_F_1 + 1; ++i) {
                GLLib.s_math_aTanTable[i] = Math_AtanSlow(GLLib.s_math_F_1, i);
            }
        }
        if (dx == 0) {
            if (dy > 0) {
                return GLLib.Math_Angle90;
            }
            if (dy == 0) {
                return 0;
            }
            return GLLib.Math_Angle270;
        }
        else if (dx > 0) {
            if (dy >= 0) {
                if (dx >= dy) {
                    final int idx = dy * GLLib.s_math_F_1 / dx;
                    return GLLib.s_math_aTanTable[idx];
                }
                final int idx = dx * GLLib.s_math_F_1 / dy;
                return GLLib.Math_Angle90 - GLLib.s_math_aTanTable[idx];
            }
            else {
                dy *= -1;
                if (dx >= dy) {
                    final int idx = dy * GLLib.s_math_F_1 / dx;
                    return GLLib.Math_Angle360 - GLLib.s_math_aTanTable[idx];
                }
                final int idx = dx * GLLib.s_math_F_1 / dy;
                return GLLib.Math_Angle270 + GLLib.s_math_aTanTable[idx];
            }
        }
        else {
            dx *= -1;
            if (dy >= 0) {
                if (dx >= dy) {
                    final int idx = dy * GLLib.s_math_F_1 / dx;
                    return GLLib.Math_Angle180 - GLLib.s_math_aTanTable[idx];
                }
                final int idx = dx * GLLib.s_math_F_1 / dy;
                return GLLib.Math_Angle90 + GLLib.s_math_aTanTable[idx];
            }
            else {
                dy *= -1;
                if (dx >= dy) {
                    final int idx = dy * GLLib.s_math_F_1 / dx;
                    return GLLib.Math_Angle180 + GLLib.s_math_aTanTable[idx];
                }
                final int idx = dx * GLLib.s_math_F_1 / dy;
                return GLLib.Math_Angle270 - GLLib.s_math_aTanTable[idx];
            }
        }
    }
    
    static int Math_Sqrt(final int x) {
        Assert(GLLib.s_math_sqrtTable != null, "!!ERROR!! Math_sqrt.s_math_sqrtTable is null, call Math_Init first");
        if (x >= 65536) {
            if (x >= 16777216) {
                if (x >= 268435456) {
                    if (x >= 1073741824) {
                        return GLLib.s_math_sqrtTable[x >> 24] << 8;
                    }
                    return GLLib.s_math_sqrtTable[x >> 22] << 7;
                }
                else {
                    if (x >= 67108864) {
                        return GLLib.s_math_sqrtTable[x >> 20] << 6;
                    }
                    return GLLib.s_math_sqrtTable[x >> 18] << 5;
                }
            }
            else if (x >= 1048576) {
                if (x >= 4194304) {
                    return GLLib.s_math_sqrtTable[x >> 16] << 4;
                }
                return GLLib.s_math_sqrtTable[x >> 14] << 3;
            }
            else {
                if (x >= 262144) {
                    return GLLib.s_math_sqrtTable[x >> 12] << 2;
                }
                return GLLib.s_math_sqrtTable[x >> 10] << 1;
            }
        }
        else if (x >= 256) {
            if (x >= 4096) {
                if (x >= 16384) {
                    return GLLib.s_math_sqrtTable[x >> 8];
                }
                return GLLib.s_math_sqrtTable[x >> 6] >> 1;
            }
            else {
                if (x >= 1024) {
                    return GLLib.s_math_sqrtTable[x >> 4] >> 2;
                }
                return GLLib.s_math_sqrtTable[x >> 2] >> 3;
            }
        }
        else {
            if (x >= 0) {
                return GLLib.s_math_sqrtTable[x] >> 4;
            }
            return 0;
        }
    }
    
    static int Math_Sqrt(long val) {
        long g = 0L;
        long b = 32768L;
        long bshft = 15L;
        do {
            final long temp = (g << 1) + b << (int)(bshft--);
            if (val >= temp) {
                g += b;
                val -= temp;
            }
        } while ((b >>= 1) > 0L);
        return (int)g;
    }
    
    static int Math_Sqrt_FixedPoint(final int val, int precisionLoop) {
        int r = val;
        int b = 1073741824 >> 16 - GLLibConfig.math_fixedPointBase;
        int q = 0;
        while (b >= 256 && precisionLoop-- > 0) {
            final int t = q + b;
            if (r >= t) {
                r -= t;
                q = t + b;
            }
            r <<= 1;
            b >>= 1;
        }
        q >>= 8;
        return q;
    }
    
    static boolean Math_RectIntersect(final int Ax0, final int Ay0, final int Ax1, final int Ay1, final int Bx0, final int By0, final int Bx1, final int By1) {
        if (Ax0 > Ax1) {
            Assert(false, "Math_RectIntersect. Ax0 is bigger than Ax1");
        }
        if (Ay0 > Ay1) {
            Assert(false, "Math_RectIntersect. Ay0 is bigger than Ay1");
        }
        if (Bx0 > Bx1) {
            Assert(false, "Math_RectIntersect. Bx0 is bigger than Bx1");
        }
        if (By0 > By1) {
            Assert(false, "Math_RectIntersect. By0 is bigger than By1");
        }
        return Ax1 >= Bx0 && Ax0 <= Bx1 && Ay1 >= By0 && Ay0 <= By1;
    }
    
    static int Math_SegmentIntersect(final int x1, final int y1, final int x2, final int y2, final int x3, final int y3, final int x4, final int y4) {
        final int Ax = x2 - x1;
        final int Bx = x3 - x4;
        int x1lo;
        int x1hi;
        if (Ax < 0) {
            x1lo = x2;
            x1hi = x1;
        }
        else {
            x1hi = x2;
            x1lo = x1;
        }
        if (Bx > 0) {
            if (x1hi < x4 || x3 < x1lo) {
                return 0;
            }
        }
        else if (x1hi < x3 || x4 < x1lo) {
            return 0;
        }
        final int Ay = y2 - y1;
        final int By = y3 - y4;
        int y1lo;
        int y1hi;
        if (Ay < 0) {
            y1lo = y2;
            y1hi = y1;
        }
        else {
            y1hi = y2;
            y1lo = y1;
        }
        if (By > 0) {
            if (y1hi < y4 || y3 < y1lo) {
                return 0;
            }
        }
        else if (y1hi < y3 || y4 < y1lo) {
            return 0;
        }
        final int Cx = x1 - x3;
        final int Cy = y1 - y3;
        final int d = By * Cx - Bx * Cy;
        final int f = Ay * Bx - Ax * By;
        if (f > 0) {
            if (d < 0 || d > f) {
                return 0;
            }
        }
        else if (d > 0 || d < f) {
            return 0;
        }
        final int e = Ax * Cy - Ay * Cx;
        if (f > 0) {
            if (e < 0 || e > f) {
                return 0;
            }
        }
        else if (e > 0 || e < f) {
            return 0;
        }
        if (f == 0) {
            return -1;
        }
        int num = d * Ax;
        int offset = Math_SameSign(num, f) ? (f >> 1) : (-f >> 1);
        GLLib.s_Math_intersectX = x1 + (num + offset) / f;
        num = d * Ay;
        offset = (Math_SameSign(num, f) ? (f >> 1) : (-f >> 1));
        GLLib.s_Math_intersectY = y1 + (num + offset) / f;
        return 1;
    }
    
    static int Math_DistPointLine(final int x0, final int y0, final int x1, final int y1, final int x2, final int y2) throws Exception {
        final int v0x = x1 - x0;
        final int v0y = y1 - y0;
        final int angle0 = Math_Atan(v0x, v0y);
        final int v1x = x2 - x0;
        final int v1y = y2 - y0;
        final int l1 = Math_Sqrt(Math_NormPow(v1x, v1y));
        final int angle2 = Math_Atan(v1x, v1y);
        final int angle3 = Math.abs(angle0 - angle2);
        final int dopp = l1 * Math_Sin(angle3);
        final int dadj = l1 * Math_Cos(angle3);
        GLLib.s_Math_distPointLineX = dadj * Math_Cos(angle0);
        GLLib.s_Math_distPointLineY = dadj * Math_Sin(angle0);
        return dopp;
    }
    
    static void Math_QuickSort(final int[] array) {
        Math_Q_Sort(array, 0, array.length - 1);
    }
    
    private static void Math_Q_Sort(final int[] array, int left, int right) {
        final int l_hold = left;
        final int r_hold = right;
        int pivot = array[left];
        while (left < right) {
            while (array[right] >= pivot && left < right) {
                --right;
            }
            if (left != right) {
                array[left] = array[right];
                ++left;
            }
            while (array[left] <= pivot && left < right) {
                ++left;
            }
            if (left != right) {
                array[right] = array[left];
                --right;
            }
        }
        array[left] = pivot;
        pivot = left;
        left = l_hold;
        right = r_hold;
        if (left < pivot) {
            Math_Q_Sort(array, left, pivot - 1);
        }
        if (right > pivot) {
            Math_Q_Sort(array, pivot + 1, right);
        }
    }
    
    static int[] Math_QuickSortIndices(final int[] data) {
        return Math_QuickSortIndices(data, 1, 0);
    }
    
    static int[] Math_QuickSortIndices(final int[] data, final int nbItemPerValue, final int itemNb) {
        GLLib.Math_quickSortIndices_nbItemPerValue = nbItemPerValue;
        GLLib.Math_quickSortIndices_itemNb = itemNb;
        GLLib.Math_quickSortIndices_data = data;
        final int size = GLLib.Math_quickSortIndices_data.length / GLLib.Math_quickSortIndices_nbItemPerValue;
        if (GLLib.Math_quickSortIndices_result != null && GLLib.Math_quickSortIndices_result.length != size) {
            GLLib.Math_quickSortIndices_result = null;
            Gc();
        }
        if (GLLib.Math_quickSortIndices_result == null) {
            GLLib.Math_quickSortIndices_result = new int[size];
        }
        for (int i = 0; i < size; ++i) {
            GLLib.Math_quickSortIndices_result[i] = i;
        }
        Math_QuickSortIndices(0, size - 1);
        return GLLib.Math_quickSortIndices_result;
    }
    
    private static void Math_QuickSortIndices(int left, int right) {
        final int l_hold = left;
        final int r_hold = right;
        final int pivot_i = GLLib.Math_quickSortIndices_result[left];
        int pivot = GLLib.Math_quickSortIndices_data[pivot_i * GLLib.Math_quickSortIndices_nbItemPerValue + GLLib.Math_quickSortIndices_itemNb];
        while (left < right) {
            while (GLLib.Math_quickSortIndices_data[GLLib.Math_quickSortIndices_result[right] * GLLib.Math_quickSortIndices_nbItemPerValue + GLLib.Math_quickSortIndices_itemNb] >= pivot && left < right) {
                --right;
            }
            if (left != right) {
                GLLib.Math_quickSortIndices_result[left] = GLLib.Math_quickSortIndices_result[right];
                ++left;
            }
            while (GLLib.Math_quickSortIndices_data[GLLib.Math_quickSortIndices_result[left] * GLLib.Math_quickSortIndices_nbItemPerValue + GLLib.Math_quickSortIndices_itemNb] <= pivot && left < right) {
                ++left;
            }
            if (left != right) {
                GLLib.Math_quickSortIndices_result[right] = GLLib.Math_quickSortIndices_result[left];
                --right;
            }
        }
        GLLib.Math_quickSortIndices_result[left] = pivot_i;
        pivot = left;
        left = l_hold;
        right = r_hold;
        if (left < pivot) {
            Math_QuickSortIndices(left, pivot - 1);
        }
        if (right > pivot) {
            Math_QuickSortIndices(pivot + 1, right);
        }
    }
    
    private static int Math_BezierUtility(final int v1, final int v2, final int v3, final int mum1, final int mum12, final int mu2) {
        return (v1 * mum12 + 2 * v2 * mum1 + v3 * mu2) / (1 << GLLibConfig.math_fixedPointBase * 2);
    }
    
    static void Math_Bezier2D(final int x1, final int y1, final int x2, final int y2, final int x3, final int y3, final int interp) {
        final int mu2 = interp * interp;
        int mum1 = GLLib.s_math_F_1 - interp;
        final int mum2 = mum1 * mum1;
        mum1 *= interp;
        GLLib.s_math_bezierX = Math_BezierUtility(x1, x2, x3, mum1, mum2, mu2);
        GLLib.s_math_bezierY = Math_BezierUtility(y1, y2, y3, mum1, mum2, mu2);
    }
    
    static void Math_Bezier3D(final int x1, final int y1, final int z1, final int x2, final int y2, final int z2, final int x3, final int y3, final int z3, final int interp) {
        final int mu2 = interp * interp;
        int mum1 = GLLib.s_math_F_1 - interp;
        final int mum2 = mum1 * mum1;
        mum1 *= interp;
        GLLib.s_math_bezierX = Math_BezierUtility(x1, x2, x3, mum1, mum2, mu2);
        GLLib.s_math_bezierY = Math_BezierUtility(y1, y2, y3, mum1, mum2, mu2);
        GLLib.s_math_bezierZ = Math_BezierUtility(z1, z2, z3, mum1, mum2, mu2);
    }
    
    static int Math_FixedPoint_Add(final int summand1, final int summand2) {
        final long result = summand1 + (long)summand2;
        if (result > 2147483647L) {
            Assert(false, "Math_FixedPoint_Add(): Multiplication Integer Overflow");
        }
        return (int)result;
    }
    
    static int Math_FixedPoint_Subtract(final int minuend, final int subtrahend) {
        final long result = minuend - (long)subtrahend;
        if (result < -2147483648L) {
            Assert(false, "Math_FixedPoint_Add(): Multiplication Integer Overflow");
        }
        return (int)result;
    }
    
    static int Math_FixedPoint_Multiply(final int multiplicand, final int multiplier) {
        final long result = multiplicand * (long)multiplier + (GLLib.s_math_F_1 >> 1) >> GLLibConfig.math_fixedPointBase;
        if (result > 2147483647L) {
            Assert(false, "Math_FixedPoint_Multiply(): Multiplication Integer Overflow");
        }
        return (int)result;
    }
    
    static int Math_FixedPoint_Divide(final int dividend, final int divisor) {
        if (divisor == 0) {
            Assert(false, "Math_FixedPoint_Divide(): Division by Zero");
        }
        return (int)(((long)dividend << GLLibConfig.math_fixedPointBase << 1) / divisor + 1L) >> 1;
    }
    
    static int Math_FixedPoint_Square(final int value) {
        return Math_FixedPoint_Multiply(value, value);
    }
    
    static int Math_FixedPoint_Round(final int value) {
        return value + (GLLib.s_math_F_1 >> 1) >> GLLibConfig.math_fixedPointBase << GLLibConfig.math_fixedPointBase;
    }
    
    static int Math_FixedPoint_Sqrt(final int value) {
        if (value == 0 || value == GLLib.s_math_F_1) {
            return value;
        }
        final int adj = ((GLLibConfig.math_fixedPointBase & 0x1) != 0x0) ? 1 : 0;
        long r = value;
        long b = 1 << 30 - adj;
        long q = 0L;
        while (b >= 256L) {
            final long t = q + b;
            if (r >= t) {
                r -= t;
                q = t + b;
            }
            r <<= 1;
            b >>= 1;
        }
        q >>= 16 - (GLLibConfig.math_fixedPointBase >> 1) - adj;
        return (int)q;
    }
    
    static int Math_FixedPoint_Sqrt(final long value) {
        if (value == 0L || value == GLLib.s_math_F_1) {
            return (int)value;
        }
        if (value < 2147483647L) {
            return Math_FixedPoint_Sqrt((int)value);
        }
        int bshft = 30 - GLLibConfig.math_fixedPointBase;
        int b = 1073741824;
        int g = 0;
        long val = value;
        do {
            final long temp = (long)(g + g + b) << bshft;
            if (val >= temp) {
                g += b;
                val -= temp;
            }
            b >>= 1;
        } while (bshft-- >= 0);
        return g;
    }
    
    static int Math_FixedPoint_NormPow(final int x, final int y) {
        final long result = x * (long)x + y * (long)y + GLLib.s_math_F_05 >> GLLibConfig.math_fixedPointBase;
        if (result > 2147483647L) {
            Assert(false, "Math_FixedPoint_NormPow(): Multiplication Integer Overflow");
        }
        return (int)result;
    }
    
    static int Math_FixedPoint_Norm(final int x, final int y) {
        return Math_FixedPoint_Sqrt(x * (long)x + y * (long)y + GLLib.s_math_F_05 >> GLLibConfig.math_fixedPointBase);
    }
    
    static int Math_FixedPoint_Det(final int x1, final int y1, final int x2, final int y2) {
        return Math_FixedPoint_Multiply(x1, y2) - Math_FixedPoint_Multiply(x2, y1);
    }
    
    static int Math_FixedPoint_DotProduct(final int x1, final int y1, final int x2, final int y2) {
        return Math_FixedPoint_Multiply(x1, x2) + Math_FixedPoint_Multiply(y1, y2);
    }
    
    static int Math_FixedPoint_RadiansToDegrees(final int angle) {
        return Math_FixedPoint_Multiply(angle, GLLib.ratioRadiansToDegrees);
    }
    
    static int Math_FixedPoint_DegreesToRadians(final int angle) {
        return Math_FixedPoint_Divide(angle, GLLib.ratioRadiansToDegrees);
    }
    
    static int Math_FixedPoint_RadiansToAngleFixedPoint(final int angle) {
        return Math_FixedPoint_Multiply(Math_FixedPoint_Multiply(angle, GLLib.ratioRadiansToDegrees), GLLib.ratioDegreesToAngleFixedPoint);
    }
    
    static int Math_FixedPoint_DegreesToAngleFixedPoint(final int angle) {
        return Math_FixedPoint_Multiply(angle, GLLib.ratioDegreesToAngleFixedPoint);
    }
    
    static int Math_FixedPoint_PointLineDistance(final int in_lineX1, final int in_lineY1, final int in_lineX2, final int in_lineY2, final int in_pointX, final int in_pointY) {
        final int dx = in_lineX1 - in_lineX2;
        final int dy = in_lineY1 - in_lineY2;
        int x;
        int y;
        if (dx == 0) {
            x = in_lineX1;
            y = in_pointY;
        }
        else if (dy == 0) {
            x = in_pointX;
            y = in_lineY1;
        }
        else {
            final int m1 = Math_FixedPoint_Divide(dy, dx);
            final int b1 = -Math_FixedPoint_Multiply(m1, in_lineX1) + in_lineY1;
            final int m2 = -Math_FixedPoint_Divide(dx, dy);
            final int b2 = -Math_FixedPoint_Multiply(m2, in_pointX) + in_pointY;
            x = Math_FixedPoint_Divide(b1 - b2, m2 - m1);
            y = Math_FixedPoint_Multiply(m1, x) + b1;
        }
        GLLib.s_Math_distPointLineX = x;
        GLLib.s_Math_distPointLineY = y;
        return Math_FixedPoint_Norm(x - in_pointX, y - in_pointY);
    }
    
    static int Math_FixedPoint_LineCircleIntersect(final int in_x1, final int in_y1, final int in_x2, final int in_y2, final int in_circleX, final int in_circleY, final int in_radius) {
        final int sX = in_x1 - in_circleX;
        final int sY = in_y1 - in_circleY;
        final int eX = in_x2 - in_circleX;
        final int eY = in_y2 - in_circleY;
        final long dX = eX - sX;
        final long dY = eY - sY;
        int x1;
        int x2;
        int y1;
        int y2;
        if (dY == 0L) {
            if (eY < -in_radius || eY > in_radius) {
                return 0;
            }
            x1 = Math_FixedPoint_Sqrt(Math_FixedPoint_Square(in_radius) - Math_FixedPoint_Square(eY));
            x2 = -x1;
            y1 = eY;
            y2 = eY;
        }
        else if (dX == 0L) {
            if (eY < -in_radius || eY > in_radius) {
                return 0;
            }
            x1 = eX;
            x2 = eX;
            y1 = Math_FixedPoint_Sqrt(Math_FixedPoint_Square(in_radius) - Math_FixedPoint_Square(eX));
            y2 = -y1;
        }
        else {
            final long D = sX * (long)eY - eX * (long)sY >> GLLibConfig.math_fixedPointBase;
            final long dR_SQR = dX * dX + dY * dY >> GLLibConfig.math_fixedPointBase;
            final long discriminant = Math_FixedPoint_Square(in_radius) * dR_SQR - D * D >> GLLibConfig.math_fixedPointBase;
            if (discriminant < 0L || dR_SQR == 0L) {
                return 0;
            }
            if (discriminant == 0L) {
                x1 = (x2 = (int)(D * dY / dR_SQR));
                y1 = (y2 = (int)(D * dX / dR_SQR));
            }
            else {
                final long sqrtDisc = Math_FixedPoint_Sqrt(discriminant);
                long tmp1 = D * dY;
                long tmp2 = ((dY < 0L) ? -1 : 1) * dX * sqrtDisc;
                x1 = (int)((tmp1 + tmp2) / dR_SQR);
                x2 = (int)((tmp1 - tmp2) / dR_SQR);
                tmp1 = -D * dX;
                tmp2 = Math.abs(dY) * sqrtDisc;
                y1 = (int)((tmp1 + tmp2) / dR_SQR);
                y2 = (int)((tmp1 - tmp2) / dR_SQR);
            }
        }
        GLLib.s_Math_intersectPoints[0][0] = x1 + in_circleX;
        GLLib.s_Math_intersectPoints[0][1] = y1 + in_circleY;
        GLLib.s_Math_intersectPoints[1][0] = x2 + in_circleX;
        GLLib.s_Math_intersectPoints[1][1] = y2 + in_circleY;
        return (x1 == x2 && y1 == y2) ? 2 : 4;
    }
    
    static int Math_FixedPoint_LineRectangleIntersect(final int in_x1, final int in_y1, final int in_x2, final int in_y2, final int in_rectX, final int in_rectY, final int in_rectW, final int in_rectH) {
        final int leftX = in_rectX;
        final int rightX = in_rectX + in_rectW;
        final int topY = in_rectY;
        final int bottomY = in_rectY + in_rectH;
        int x1;
        int y1;
        int x2;
        int y2;
        if (in_x1 - in_x2 == 0) {
            if (in_x2 < leftX || in_x2 > rightX) {
                return 0;
            }
            x1 = in_x2;
            y1 = topY;
            x2 = in_x2;
            y2 = bottomY;
        }
        else {
            final int m = Math_FixedPoint_Divide(in_y1 - in_y2, in_x1 - in_x2);
            if (m == 0) {
                if (in_y2 < topY || in_y2 > bottomY) {
                    return 0;
                }
                x1 = leftX;
                y1 = in_y2;
                x2 = rightX;
                y2 = in_y2;
            }
            else {
                final int b = -Math_FixedPoint_Multiply(m, in_x2) + in_y2;
                x1 = leftX;
                y1 = Math_FixedPoint_Multiply(m, x1) + b;
                if (y1 < topY || y1 > bottomY) {
                    y1 = ((y1 < topY) ? topY : bottomY);
                    x1 = Math_FixedPoint_Divide(b - y1, -m);
                    if (x1 < leftX || x1 > rightX) {
                        return 0;
                    }
                }
                x2 = rightX;
                y2 = Math_FixedPoint_Multiply(m, x2) + b;
                if (y2 < topY || y2 > bottomY) {
                    y2 = ((y2 < topY) ? topY : bottomY);
                    x2 = Math_FixedPoint_Divide(b - y2, -m);
                    if (x2 < leftX || x2 > rightX) {
                        return 0;
                    }
                }
            }
        }
        GLLib.s_Math_intersectPoints[0][0] = x1;
        GLLib.s_Math_intersectPoints[0][1] = y1;
        GLLib.s_Math_intersectPoints[1][0] = x2;
        GLLib.s_Math_intersectPoints[1][1] = y2;
        return (x1 == x2 && y1 == y2) ? 2 : 4;
    }
    
    static String ConvertFixedPointToString(int value, final int precision) {
        if (precision == 0) {
            return "" + (value >> GLLibConfig.math_fixedPointBase);
        }
        String str = "";
        for (int i = -1; i < precision; ++i) {
            final int tmp = value >> GLLibConfig.math_fixedPointBase;
            str = ((i == -1) ? (tmp + ".") : (str + tmp));
            value -= tmp * GLLib.s_math_F_1;
            value *= 10;
        }
        return str;
    }
    
    static final int Math_Abs(final int a) {
        return Math.abs(a);
    }
    
    static final long Math_Abs(final long a) {
        return Math.abs(a);
    }
    
    static final int Math_Max(final int a, final int b) {
        return Math.max(a, b);
    }
    
    static final long Math_Max(final long a, final long b) {
        return Math.max(a, b);
    }
    
    static final int Math_Min(final int a, final int b) {
        return Math.min(a, b);
    }
    
    static final long Math_Min(final long a, final long b) {
        return Math.min(a, b);
    }
    
    public InputStream GetResourceAsStream(final String s) {
        final InputStream is = "".getClass().getResourceAsStream(s);
        return is;
    }
    
    static void Pack_Open(final String filename) {
        if (filename == null) {
            Assert(false, "Pack_Open.filename is null");
        }
        if (GLLibConfig.pack_dbgDataAccess) {
            Dbg("Pack_Open(" + filename + ")");
        }
        if (GLLib.s_pack_filename != null && filename.compareTo(GLLib.s_pack_filename) == 0) {
            if (GLLibConfig.pack_dbgDataAccess) {
                Dbg("Pack_Open(" + filename + ").file already open");
            }
            return;
        }
        Pack_Close();
        GLLib.s_pack_filename = filename;
        GLLib.s_pack_is = Pack_GetInputStreamFromName(GLLib.s_pack_filename);
        if (GLLib.s_pack_is == null) {
            Assert(false, "Pack_Open.unable to find file");
        }
        GLLib.s_pack_nbData = (short)Pack_Read16();
        if (GLLibConfig.pack_dbgDataAccess) {
            Dbg("   nb of data in pack : " + GLLib.s_pack_nbData);
        }
        GLLib.s_pack_subPack_nbOf = (short)Pack_Read16();
        if (GLLibConfig.pack_dbgDataAccess) {
            Dbg("   nb of subpack for this pack : " + GLLib.s_pack_subPack_nbOf);
        }
        GLLib.s_pack_subPack_fat = new short[GLLib.s_pack_subPack_nbOf];
        for (int i = 0; i < GLLib.s_pack_subPack_nbOf; ++i) {
            GLLib.s_pack_subPack_fat[i] = (short)Pack_Read16();
            if (GLLibConfig.pack_dbgDataAccess) {
                Dbg("   subpack " + i + " start with data : " + GLLib.s_pack_subPack_fat[i]);
            }
        }
        GLLib.s_pack_subPack_curSubPack = 0;
        Pack_GetDataOffset();
    }
    
    private static InputStream Pack_GetInputStreamFromName(final String strName) {
        InputStream pStream;
        if (GLLibConfig.rms_usePackRead && !strName.startsWith("/")) {
            pStream = GetRmsInputStream(strName);
        }
        else if (GLLibConfig.pack_keepLoaded) {
            if (GLLib.s_pack_HashIndex == null) {
                GLLib.s_pack_HashIndex = new Hashtable();
                GLLib.s_pack_HashSize = new Hashtable();
                try {
                    GLLib.s_pack_is = GLLib.s_gllib_instance.GetResourceAsStream("/999");
                    final int nCount = Pack_Read32();
                    GLLib.s_pack_BinaryCache = new byte[nCount][];
                    for (int i = 0; i < nCount; ++i) {
                        final int nStrLength = Pack_Read32();
                        final byte[] pStr = new byte[nStrLength];
                        GLLib.s_pack_is.read(pStr);
                        final String strFileName = new String(pStr);
                        final int nSize = Pack_Read32();
                        GLLib.s_pack_HashIndex.put("/" + strFileName, new Integer(i));
                        GLLib.s_pack_HashSize.put("/" + strFileName, new Integer(nSize));
                    }
                    Pack_Close();
                }
                catch (final Exception e) {
                    Dbg("   Exception while reading file INDEX");
                }
            }
            final int nDataIndex = GLLib.s_pack_HashIndex.get(strName);
            if (GLLib.s_pack_BinaryCache[nDataIndex] == null) {
                final int nSize2 = GLLib.s_pack_HashSize.get(strName);
                GLLib.s_pack_BinaryCache[nDataIndex] = new byte[nSize2];
                try {
                    (GLLib.s_pack_is = GLLib.s_gllib_instance.GetResourceAsStream(strName)).read(GLLib.s_pack_BinaryCache[nDataIndex]);
                    GLLib.s_pack_is.close();
                    GLLib.s_pack_is = null;
                }
                catch (final Exception e2) {
                    Dbg("   Exception while reading file to cache : " + strName);
                }
            }
            if (GLLib.s_pack_BinaryCache[nDataIndex] == null) {
                Assert(false, "   s_pack_BinaryCache[nDataIndex]==null error");
            }
            pStream = new ByteArrayInputStream(GLLib.s_pack_BinaryCache[nDataIndex]);
        }
        else {
            pStream = GLLib.s_gllib_instance.GetResourceAsStream(strName);
        }
        return pStream;
    }
    
    static void Pack_ReleaseBinaryCache(final String filename) {
        if (GLLibConfig.pack_keepLoaded) {
            int nDataIndex = GLLib.s_pack_HashIndex.get(filename);
            if (GLLib.s_pack_BinaryCache[nDataIndex] != null) {
                final short nbSubPack = Mem_GetShort(GLLib.s_pack_BinaryCache[nDataIndex], 2);
                GLLib.s_pack_BinaryCache[nDataIndex] = null;
                for (int i = 1; i < nbSubPack; ++i) {
                    final String strSubPack = filename + "." + i;
                    nDataIndex = GLLib.s_pack_HashIndex.get(strSubPack);
                    GLLib.s_pack_BinaryCache[nDataIndex] = null;
                }
            }
        }
    }
    
    private static void Pack_GetDataOffset() {
        int nbData;
        if (GLLib.s_pack_subPack_curSubPack == GLLib.s_pack_subPack_nbOf - 1) {
            nbData = GLLib.s_pack_nbData - GLLib.s_pack_subPack_fat[GLLib.s_pack_subPack_curSubPack];
        }
        else {
            nbData = GLLib.s_pack_subPack_fat[GLLib.s_pack_subPack_curSubPack + 1] - GLLib.s_pack_subPack_fat[GLLib.s_pack_subPack_curSubPack];
        }
        if (GLLibConfig.pack_dbgDataAccess) {
            Dbg("   nb of data in this subpack : " + nbData);
        }
        GLLib.s_pack_offset = new int[nbData + 1];
        for (int i = 0; i < nbData + 1; ++i) {
            GLLib.s_pack_offset[i] = Pack_Read32();
            if (GLLibConfig.pack_dbgDataAccess) {
                Dbg("   data " + i + " is @ offset : " + GLLib.s_pack_offset[i]);
            }
        }
    }
    
    static void Pack_Close() {
        if (GLLib.s_pack_is != null) {
            try {
                GLLib.s_pack_is.close();
            }
            catch (final Exception ex) {}
            GLLib.s_pack_is = null;
        }
        GLLib.s_pack_curOffset = 0;
        if (GLLibConfig.rms_usePackRead) {
            GLLib.s_rms_buffer = null;
        }
        Gc();
    }
    
    static int Pack_PositionAtData(int idx) {
        if (idx < 0) {
            Assert(false, "Pack_PositionAtData.idx is invalid");
        }
        if (idx >= GLLib.s_pack_nbData) {
            Assert(false, "Pack_PositionAtData.idx is invalid");
        }
        if (GLLibConfig.pack_dbgDataAccess) {
            Dbg("Pack_PositionAtData(" + idx + ")  current sub : " + GLLib.s_pack_subPack_curSubPack);
        }
        int subpack;
        for (subpack = GLLib.s_pack_subPack_nbOf - 1; subpack >= 0 && GLLib.s_pack_subPack_fat[subpack] > idx; --subpack) {}
        if (GLLibConfig.pack_dbgDataAccess) {
            Dbg("   data " + idx + " is in subpack : " + subpack);
        }
        if (GLLib.s_pack_subPack_curSubPack != subpack) {
            if (GLLibConfig.pack_dbgDataAccess) {
                Dbg("   opening subpack : " + subpack);
            }
            GLLib.s_pack_subPack_curSubPack = subpack;
            Pack_Close();
            if (GLLib.s_pack_subPack_curSubPack == 0) {
                final String name = GLLib.s_pack_filename;
                GLLib.s_pack_filename = null;
                Pack_Open(name);
            }
            else {
                GLLib.s_pack_is = Pack_GetInputStreamFromName(GLLib.s_pack_filename + "." + GLLib.s_pack_subPack_curSubPack);
                Pack_GetDataOffset();
            }
        }
        else if (GLLib.s_pack_is == null) {
            if (GLLibConfig.pack_dbgDataAccess) {
                Dbg("   reopening subpack : " + subpack);
            }
            if (GLLib.s_pack_subPack_curSubPack == 0) {
                final String name = GLLib.s_pack_filename;
                GLLib.s_pack_filename = null;
                Pack_Open(name);
            }
            else {
                GLLib.s_pack_is = Pack_GetInputStreamFromName(GLLib.s_pack_filename + "." + GLLib.s_pack_subPack_curSubPack);
            }
        }
        idx -= GLLib.s_pack_subPack_fat[GLLib.s_pack_subPack_curSubPack];
        final int offset = GLLib.s_pack_offset[idx];
        int size = GLLib.s_pack_offset[idx + 1] - GLLib.s_pack_offset[idx];
        if (GLLibConfig.pack_dbgDataAccess) {
            Dbg("   data is at index " + idx + " in this subpack @ offset " + offset + " (" + size + " byte)");
        }
        Pack_Seek(offset);
        GLLib.s_pack_lastDataIsCompress = false;
        if (size > 0) {
            GLLib.s_pack_lastDataReadMimeType = (Pack_Read() & 0xFF);
            if (GLLibConfig.pack_supportLZMADecompression && GLLib.s_pack_lastDataReadMimeType >= 127) {
                GLLib.s_pack_lastDataReadMimeType -= 127;
                GLLib.s_pack_lastDataIsCompress = true;
            }
            --size;
        }
        if (GLLibConfig.pack_dbgDataAccess && GLLib.MIME_type != null) {
            Dbg("   data mime type is " + GLLib.s_pack_lastDataReadMimeType + " (" + GetMIME(GLLib.s_pack_lastDataReadMimeType) + ")");
        }
        return size;
    }
    
    static byte[] Pack_ReadData(final int idx) {
        if (idx < 0) {
            Assert(false, "Pack_ReadData.idx is invalid");
        }
        if (idx >= GLLib.s_pack_nbData) {
            Assert(false, "Pack_ReadData.idx is invalid");
        }
        if (GLLibConfig.pack_dbgDataAccess) {
            Dbg("Pack_ReadData(" + idx + ")");
        }
        final int size = Pack_PositionAtData(idx);
        byte[] data = null;
        if (GLLibConfig.pack_supportLZMADecompression && GLLib.s_pack_lastDataIsCompress) {
            try {
                LZMA_Inflate(GLLib.s_pack_is, size);
                GLLib.s_pack_curOffset += size;
                data = GLLib.m_outStream;
                GLLib.m_outStream = null;
            }
            catch (final Exception e) {
                Assert(false, "LZMA decompression failed : " + e.toString());
            }
        }
        else {
            data = new byte[size];
            Pack_ReadFully(data, 0, data.length);
        }
        if (GLLibConfig.pack_dbgDataAccess) {
            Dbg("     Pack_ReadData(" + idx + ")  DONE");
        }
        return data;
    }
    
    static void Pack_Seek(int addr) {
        if (GLLib.s_pack_curOffset == addr) {
            return;
        }
        if (GLLib.s_pack_curOffset > addr) {
            if (GLLibConfig.pack_dbgDataAccess) {
                Dbg("Pack Close BAD READING ORDER");
            }
            Pack_Close();
            if (GLLib.s_pack_subPack_curSubPack == 0) {
                GLLib.s_pack_is = Pack_GetInputStreamFromName(GLLib.s_pack_filename);
            }
            else {
                GLLib.s_pack_is = Pack_GetInputStreamFromName(GLLib.s_pack_filename + "." + GLLib.s_pack_subPack_curSubPack);
            }
            if (GLLib.s_pack_is == null) {
                Assert(false, "Pack_Seek.internal error");
            }
        }
        else {
            addr -= GLLib.s_pack_curOffset;
        }
        Pack_Skip(addr);
    }
    
    static void Pack_Skip(int nb) {
        if (nb == 0) {
            return;
        }
        if (GLLibConfig.pack_skipbufferSize == 0) {
            GLLib.s_pack_curOffset += nb;
            try {
                while (nb > 0) {
                    nb -= (int)GLLib.s_pack_is.skip(nb);
                }
            }
            catch (final Exception e) {
                Assert(false, "Pack_Skip.IO exception occured");
            }
        }
        else {
            if (GLLib.s_Pack_SkipBuffer == null) {
                GLLib.s_Pack_SkipBuffer = new byte[GLLibConfig.pack_skipbufferSize];
            }
            while (nb > GLLibConfig.pack_skipbufferSize) {
                Pack_ReadFully(GLLib.s_Pack_SkipBuffer, 0, GLLibConfig.pack_skipbufferSize);
                nb -= GLLibConfig.pack_skipbufferSize;
            }
            if (nb > 0) {
                Pack_ReadFully(GLLib.s_Pack_SkipBuffer, 0, nb);
            }
        }
    }
    
    static int Pack_Read() {
        int read = 0;
        try {
            read = GLLib.s_pack_is.read();
        }
        catch (final Exception e) {
            Assert(false, "Pack_Read.IO exception occured");
        }
        if (read < 0) {
            Assert(false, "Pack_Read.EOF");
        }
        ++GLLib.s_pack_curOffset;
        return read;
    }
    
    static int Pack_Read16() {
        return (Pack_Read() & 0xFF) | (Pack_Read() & 0xFF) << 8;
    }
    
    static int Pack_Read32() {
        return (Pack_Read() & 0xFF) | (Pack_Read() & 0xFF) << 8 | ((Pack_Read() & 0xFF) << 16 | (Pack_Read() & 0xFF) << 24);
    }
    
    static int Pack_ReadFully(final byte[] array, final int offset, final int length) {
        if (array == null) {
            Assert(false, "Pack_ReadFully.array is null");
        }
        if (offset < 0) {
            Assert(false, "Pack_ReadFully.offset is negative");
        }
        if (length < 0) {
            Assert(false, "Pack_ReadFully.length is negative");
        }
        if (offset + length > array.length) {
            Assert(false, "Pack_ReadFully.offset+length is bigger than array size");
        }
        int off = offset;
        int len = length;
        int read = 0;
        try {
            while (len > 0) {
                read = GLLib.s_pack_is.read(array, off, len);
                if (read < 0) {
                    Assert(false, "Pack_ReadFully.EOF");
                }
                len -= read;
                off += read;
            }
        }
        catch (final Exception e) {
            Assert(false, "Pack_Read.IO exception occured");
        }
        GLLib.s_pack_curOffset += length;
        return length;
    }
    
    static Object Pack_ReadArray(final int idx) {
        if (idx < 0) {
            Assert(false, "Pack_ReadArray.idx is invalid");
        }
        if (idx >= GLLib.s_pack_nbData) {
            Assert(false, "Pack_ReadArray.idx is invalid");
        }
        if (GLLibConfig.pack_dbgDataAccess) {
            Dbg("Pack_ReadArray(" + idx + ")");
        }
        final int size = Pack_PositionAtData(idx);
        if (GLLibConfig.pack_dbgDataAccess) {
            Dbg("size of data is " + size);
        }
        GLLib.Stream_readOffset = 0;
        Object array;
        if (GLLibConfig.pack_supportLZMADecompression && GLLib.s_pack_lastDataIsCompress) {
            byte[] data = Pack_ReadData(idx);
            ByteArrayInputStream bis = new ByteArrayInputStream(data);
            array = Mem_ReadArray(bis);
            bis = null;
            data = null;
        }
        else {
            array = Mem_ReadArray(GLLib.s_pack_is);
            GLLib.s_pack_curOffset += GLLib.Stream_readOffset;
        }
        return array;
    }
    
    static void Pack_LoadMIME(final String filename) {
        if (filename == null) {
            Assert(false, "Pack_LoadMIME.filename is null");
        }
        if (GLLib.MIME_type == null) {
            final InputStream is = GLLib.s_pack_is;
            GLLib.s_pack_is = Pack_GetInputStreamFromName(filename);
            final int nbOfMime = Pack_Read();
            if (GLLibConfig.pack_dbgDataAccess) {
                Dbg("nb Of MIME type : " + nbOfMime);
            }
            GLLib.MIME_type = new byte[nbOfMime][];
            for (int i = 0; i < nbOfMime; ++i) {
                final int len = Pack_Read();
                Pack_ReadFully(GLLib.MIME_type[i] = new byte[len], 0, len);
            }
            try {
                GLLib.s_pack_is.close();
            }
            catch (final Exception e) {
                Assert(false, "Pack_LoadMIME.IO Error");
            }
            GLLib.s_pack_is = is;
        }
    }
    
    static String GetMIME(final int idx) {
        if (GLLib.MIME_type == null) {
            Assert(false, "GetMIME. MIME type not loaded yet, use Pack_LoadMIME first");
        }
        if (idx >= GLLib.MIME_type.length) {
            return "";
        }
        try {
            return new String(GLLib.MIME_type[idx], "UTF-8");
        }
        catch (final Exception e) {
            return "";
        }
    }
    
    static int GetNBData() {
        return GLLib.s_pack_nbData;
    }
    
    private static int LZMA_RangeDecoderReadByte() {
        if (GLLib.inputIndex == GLLib.m_inSize) {
            GLLib.m_ExtraBytes = 1;
            return 255;
        }
        return GLLib.m_Buffer[GLLib.inputIndex++] & 0xFF;
    }
    
    private static void LZMA_RangeDecoderInit(final byte[] stream, final int bufferSize) {
        GLLib.m_Buffer = stream;
        GLLib.m_inSize = bufferSize;
        GLLib.inputIndex = 0;
        GLLib.m_ExtraBytes = 0;
        GLLib.m_Code = 0L;
        GLLib.m_Range = 4294967295L;
        for (int i = 0; i < 5; ++i) {
            GLLib.m_Code = (GLLib.m_Code << 8 | (long)LZMA_RangeDecoderReadByte());
        }
    }
    
    private static int LZMA_RangeDecoderBitDecode(final int prob) {
        final long bound = (GLLib.m_Range >> 11) * GLLib.m_lzmaInternalData[prob];
        if (GLLib.m_Code < bound) {
            GLLib.m_Range = bound;
            final short[] lzmaInternalData = GLLib.m_lzmaInternalData;
            lzmaInternalData[prob] += (short)(2048 - GLLib.m_lzmaInternalData[prob] >> 5);
            if (GLLib.m_Range < 16777216L) {
                GLLib.m_Code = (GLLib.m_Code << 8 | (long)LZMA_RangeDecoderReadByte());
                GLLib.m_Range <<= 8;
            }
            return 0;
        }
        GLLib.m_Range -= bound;
        GLLib.m_Code -= bound;
        final short[] lzmaInternalData2 = GLLib.m_lzmaInternalData;
        lzmaInternalData2[prob] -= (short)(GLLib.m_lzmaInternalData[prob] >> 5);
        if (GLLib.m_Range < 16777216L) {
            GLLib.m_Code = (GLLib.m_Code << 8 | (long)LZMA_RangeDecoderReadByte());
            GLLib.m_Range <<= 8;
        }
        return 1;
    }
    
    private static int LZMA_LiteralDecodeMatch(final int prob, byte matchByte) {
        int symbol = 1;
        do {
            final int matchBit = matchByte >> 7 & 0x1;
            matchByte <<= 1;
            final int bit = LZMA_RangeDecoderBitDecode(prob + (1 + matchBit << 8) + symbol);
            symbol = (symbol << 1 | bit);
            if (matchBit != bit) {
                while (symbol < 256) {
                    symbol = (symbol << 1 | LZMA_RangeDecoderBitDecode(prob + symbol));
                }
                break;
            }
        } while (symbol < 256);
        return symbol;
    }
    
    private static int LZMA_LiteralDecode(final int probs) {
        int symbol = 1;
        do {
            symbol = (symbol << 1 | LZMA_RangeDecoderBitDecode(probs + symbol));
        } while (symbol < 256);
        return symbol;
    }
    
    private static int LZMA_RangeDecoderBitTreeDecode(final int probs, final int numLevels) {
        int mi = 1;
        for (int i = numLevels; i > 0; --i) {
            mi = (mi << 1) + LZMA_RangeDecoderBitDecode(probs + mi);
        }
        return mi - (1 << numLevels);
    }
    
    private static int LZMA_LenDecode(final int p, final int posState) {
        if (LZMA_RangeDecoderBitDecode(p + 0) == 0) {
            return LZMA_RangeDecoderBitTreeDecode(p + 2 + (posState << 3), 3);
        }
        if (LZMA_RangeDecoderBitDecode(p + 1) == 0) {
            return 8 + LZMA_RangeDecoderBitTreeDecode(p + 130 + (posState << 3), 3);
        }
        return 16 + LZMA_RangeDecoderBitTreeDecode(p + 258, 8);
    }
    
    private static int LZMA_RangeDecoderReverseBitTreeDecode(final int probs, final int numLevels) {
        int mi = 1;
        int symbol = 0;
        for (int i = 0; i < numLevels; ++i) {
            final int bit = LZMA_RangeDecoderBitDecode(probs + mi);
            mi = (mi << 1) + bit;
            symbol |= bit << i;
        }
        return symbol;
    }
    
    private static int LZMA_RangeDecoderDecodeDirectBits(final int numTotalBits) {
        long range = GLLib.m_Range;
        long code = GLLib.m_Code;
        int result = 0;
        for (int i = numTotalBits; i > 0; --i) {
            range >>= 1;
            result <<= 1;
            if (code >= range) {
                code -= range;
                result |= 0x1;
            }
            if (range < 16777216L) {
                range <<= 8;
                code = (code << 8 | (long)LZMA_RangeDecoderReadByte());
            }
        }
        GLLib.m_Range = range;
        GLLib.m_Code = code;
        return result;
    }
    
    private static void LZMA_Decode(final int bufferSize, final int lc, final int lp, final int pb, final byte[] inStream, final int outSize) {
        final int inSize = inStream.length;
        final int numProbs = 1846 + (768 << lc + lp);
        final short[] buffer = GLLib.m_lzmaInternalData;
        int state = 0;
        boolean previousIsMatch = false;
        int previousByte = 0;
        int rep0 = 1;
        int rep2 = 1;
        int rep3 = 1;
        int rep4 = 1;
        int nowPos = 0;
        final int posStateMask = (1 << pb) - 1;
        final int literalPosMask = (1 << lp) - 1;
        int len = 0;
        if (bufferSize < numProbs << 1) {
            return;
        }
        for (int i = 0; i < numProbs; ++i) {
            buffer[i] = 1024;
        }
        LZMA_RangeDecoderInit(inStream, inSize);
        while (nowPos < outSize) {
            final int posState = nowPos & posStateMask;
            if (LZMA_RangeDecoderBitDecode(0 + (state << 4) + posState) == 0) {
                final int probs = 1846 + 768 * (((nowPos & literalPosMask) << lc) + ((previousByte & 0xFF) >> 8 - lc));
                if (state < 4) {
                    state = 0;
                }
                else if (state < 10) {
                    state -= 3;
                }
                else {
                    state -= 6;
                }
                if (previousIsMatch) {
                    final byte matchByte = GLLib.m_outStream[nowPos - rep0];
                    previousByte = (LZMA_LiteralDecodeMatch(probs, matchByte) & 0xFF);
                    previousIsMatch = false;
                }
                else {
                    previousByte = (LZMA_LiteralDecode(probs) & 0xFF);
                }
                GLLib.m_outStream[nowPos++] = (byte)previousByte;
            }
            else {
                previousIsMatch = true;
                if (LZMA_RangeDecoderBitDecode(192 + state) == 1) {
                    if (LZMA_RangeDecoderBitDecode(204 + state) == 0) {
                        if (LZMA_RangeDecoderBitDecode(240 + (state << 4) + posState) == 0) {
                            state = ((state < 7) ? 9 : 11);
                            previousByte = (GLLib.m_outStream[nowPos - rep0] & 0xFF);
                            GLLib.m_outStream[nowPos++] = (byte)previousByte;
                            continue;
                        }
                    }
                    else {
                        int distance;
                        if (LZMA_RangeDecoderBitDecode(216 + state) == 0) {
                            distance = rep2;
                        }
                        else {
                            if (LZMA_RangeDecoderBitDecode(228 + state) == 0) {
                                distance = rep3;
                            }
                            else {
                                distance = rep4;
                                rep4 = rep3;
                            }
                            rep3 = rep2;
                        }
                        rep2 = rep0;
                        rep0 = distance;
                    }
                    len = LZMA_LenDecode(1332, posState);
                    state = ((state < 7) ? 8 : 11);
                }
                else {
                    rep4 = rep3;
                    rep3 = rep2;
                    rep2 = rep0;
                    state = ((state < 7) ? 7 : 10);
                    len = LZMA_LenDecode(818, posState);
                    final int posSlot = LZMA_RangeDecoderBitTreeDecode(432 + (((len < 4) ? len : 3) << 6), 6);
                    if (posSlot >= 4) {
                        final int numDirectBits = (posSlot >> 1) - 1;
                        rep0 = (0x2 | (posSlot & 0x1)) << numDirectBits;
                        if (posSlot < 14) {
                            rep0 += LZMA_RangeDecoderReverseBitTreeDecode(688 + rep0 - posSlot - 1, numDirectBits);
                        }
                        else {
                            rep0 += LZMA_RangeDecoderDecodeDirectBits(numDirectBits - 4) << 4;
                            rep0 += LZMA_RangeDecoderReverseBitTreeDecode(802, 4);
                        }
                    }
                    else {
                        rep0 = posSlot;
                    }
                    ++rep0;
                }
                len += 2;
                do {
                    previousByte = (GLLib.m_outStream[nowPos - rep0] & 0xFF);
                    GLLib.m_outStream[nowPos++] = (byte)previousByte;
                } while (--len > 0 && nowPos < outSize);
            }
        }
    }
    
    private static void LZMA_Inflate(final InputStream is, final int size) throws Exception {
        if (GLLibConfig.pack_supportLZMADecompression) {
            byte[] header = new byte[13];
            byte[] data = new byte[size - 13];
            Stream_ReadFully(is, header, 0, 13);
            Stream_ReadFully(is, data, 0, size - 13);
            int[] properties = new int[5];
            for (int i = 0; i < 5; ++i) {
                properties[i] = (header[i] & 0xFF);
            }
            int outSize = 0;
            for (int j = 0; j < 4; ++j) {
                outSize += (header[j + 5] & 0xFF) << (j << 3);
            }
            int prop0 = properties[0];
            final int pb = prop0 / 45;
            prop0 %= 45;
            final int lp = prop0 / 9;
            final int lc = prop0 % 9;
            final int lzmaInternalSize = 1846 + (768 << lc + lp);
            GLLib.m_outStream = new byte[outSize];
            GLLib.m_lzmaInternalData = new short[lzmaInternalSize];
            LZMA_Decode(lzmaInternalSize * 2, lc, lp, pb, data, outSize);
            GLLib.m_lzmaInternalData = null;
            GLLib.m_Buffer = null;
            properties = null;
            header = null;
            data = null;
            Gc();
        }
    }
    
    public static void LZMA_Inflate(final byte[] compressDat) throws Exception {
        if (GLLibConfig.pack_supportLZMADecompression) {
            byte[] header = new byte[13];
            byte[] data = new byte[compressDat.length - 13];
            System.arraycopy(compressDat, 0, header, 0, 13);
            System.arraycopy(compressDat, 13, data, 0, data.length);
            int[] properties = new int[5];
            for (int i = 0; i < 5; ++i) {
                properties[i] = (header[i] & 0xFF);
            }
            int outSize = 0;
            for (int j = 0; j < 4; ++j) {
                outSize += (header[j + 5] & 0xFF) << (j << 3);
            }
            int prop0 = properties[0];
            final int pb = prop0 / 45;
            prop0 %= 45;
            final int lp = prop0 / 9;
            final int lc = prop0 % 9;
            final int lzmaInternalSize = 1846 + (768 << lc + lp);
            GLLib.m_outStream = new byte[outSize];
            GLLib.m_lzmaInternalData = new short[lzmaInternalSize];
            LZMA_Decode(lzmaInternalSize * 2, lc, lp, pb, data, outSize);
            GLLib.m_lzmaInternalData = null;
            GLLib.m_Buffer = null;
            properties = null;
            header = null;
            data = null;
            Gc();
        }
    }
    
    static final void SetCurrentGraphics(final Graphics graphics) {
        if (graphics == null) {
            GLLib.g = GLLib.s_lastPaintGraphics;
        }
        else {
            GLLib.g = graphics;
        }
    }
    
    static final void SetCurrentGraphics(final Image img) {
        if (img == null) {
            GLLib.g = GLLib.s_lastPaintGraphics;
        }
        else {
            GLLib.g = img.getGraphics();
        }
    }
    
    static final long GetRealTime() {
        return System.currentTimeMillis();
    }
    
    static final long GetFrameTime() {
        return GLLib.s_game_timeWhenFrameStart;
    }
    
    static final int GetScreenWidth() {
        return GLLib.s_screenWidth;
    }
    
    static final int GetScreenHeight() {
        return GLLib.s_screenHeight;
    }
    
    static final void Gc() {
        if (GLLibConfig.useSystemGc) {
            System.gc();
        }
    }
    
    static final void Translate(final int x, final int y) {
        GLLib.g.translate(x, y);
    }
    
    static final int GetTranslateX() {
        return GLLib.g.getTranslateX();
    }
    
    static final int GetTranslateY() {
        return GLLib.g.getTranslateY();
    }
    
    static final int GetColor() {
        return GLLib.g.getColor();
    }
    
    static final int GetRedComponent() {
        return GLLib.g.getRedComponent();
    }
    
    static final int GetGreenComponent() {
        return GLLib.g.getGreenComponent();
    }
    
    static final int GetBlueComponent() {
        return GLLib.g.getBlueComponent();
    }
    
    static final int GetGrayScale() {
        return GLLib.g.getGrayScale();
    }
    
    static final void SetColor(final int RGB) {
        GLLib.g.setColor(RGB);
    }
    
    static final void setColor(final int red, final int green, final int blue) {
        if (red > 255) {
            Assert(false, "setColor. red is bigger than 0xFF");
        }
        if (green > 255) {
            Assert(false, "setColor. green is bigger than 0xFF");
        }
        if (blue > 255) {
            Assert(false, "setColor. blue is bigger than 0xFF");
        }
        GLLib.g.setColor(red << 16 | green << 8 | blue);
    }
    
    static final void SetGrayScale(final int value) {
        if (value > 255) {
            Assert(false, "SetGrayScale. value is bigger than 0xFF");
        }
        try {
            GLLib.g.setGrayScale(value);
        }
        catch (final Exception ex) {}
    }
    
    static final Font GetFont() {
        return GLLib.g.getFont();
    }
    
    static final void SetStrokeStyle(final int style) {
        GLLib.g.setStrokeStyle(style);
    }
    
    static final int GetStrokeStyle() {
        return GLLib.g.getStrokeStyle();
    }
    
    static final void SetFont(final Font font) {
        GLLib.g.setFont(font);
    }
    
    static final int GetClipX() {
        return GLLib.g.getClipX();
    }
    
    static final int GetClipY() {
        return GLLib.g.getClipY();
    }
    
    static final int GetClipWidth() {
        return GLLib.g.getClipWidth();
    }
    
    static final int GetClipHeight() {
        return GLLib.g.getClipHeight();
    }
    
    static final void ClipRect(final int x, final int y, final int width, final int height) {
        GLLib.g.clipRect(x, y, width, height);
    }
    
    static final void SetClip(final int x, final int y, final int width, final int height) {
        GLLib.g.setClip(x, y, width, height);
    }
    
    static final void DrawLine(int x1, int y1, int x2, int y2) {
        if (GLLibConfig.useDrawLineClippingBug && y1 > y2) {
            int tmp = x1;
            x1 = x2;
            x2 = tmp;
            tmp = y1;
            y1 = y2;
            y2 = tmp;
        }
        GLLib.g.drawLine(x1, y1, x2, y2);
    }
    
    static final void FillRect(final int x, final int y, final int width, final int height) {
        if (GLLibConfig.useSafeFillRect) {
            final Image fillRectImage = Image.createImage(width, height);
            final Graphics fillRectGraphics = fillRectImage.getGraphics();
            fillRectGraphics.setColor(GLLib.g.getColor());
            fillRectGraphics.fillRect(0, 0, width, height);
            GLLib.g.drawImage(fillRectImage, x, y, 0);
        }
        else {
            GLLib.g.fillRect(x, y, width, height);
        }
    }
    
    static final void DrawRect(final int x, final int y, final int width, final int height) {
        GLLib.g.drawRect(x, y, width, height);
    }
    
    static final void DrawRoundRect(final int x, final int y, final int width, final int height, final int arcWidth, final int arcHeight) {
        GLLib.g.drawRoundRect(x, y, width, height, arcWidth, arcHeight);
    }
    
    static final void FillRoundRect(final int x, final int y, final int width, final int height, final int arcWidth, final int arcHeight) {
        GLLib.g.fillRoundRect(x, y, width, height, arcWidth, arcHeight);
    }
    
    static final void FillArc(final int x, final int y, final int width, final int height, final int startAngle, final int arcAngle) {
        GLLib.g.fillArc(x, y, width, height, startAngle, arcAngle);
    }
    
    static final void DrawArc(final int x, final int y, final int width, final int height, final int startAngle, final int arcAngle) {
        GLLib.g.drawArc(x, y, width, height, startAngle, arcAngle);
    }
    
    private static final int transformAnchorForText(int anchor) {
        if ((anchor & 0x2) != 0x0) {
            final int n;
            anchor = (n = (anchor & 0xFFFFFFFD));
            final Graphics g = GLLib.g;
            anchor = (n | 0x40);
        }
        return anchor;
    }
    
    static final void DrawString(final String str, final int x, final int y, int anchor) {
        if (str == null) {
            Assert(false, "DrawString.str is null");
        }
        if ((anchor & 0x32) == 0x0) {
            Assert(false, "DrawString.anchor miss vertical positionning");
        }
        if ((anchor & 0xD) == 0x0) {
            Assert(false, "DrawString.anchor miss horizontal positionning");
        }
        anchor = transformAnchorForText(anchor);
        try {
            GLLib.g.drawString(str, x, y, anchor);
        }
        catch (final Exception ex) {}
    }
    
    static final void DrawSubstring(final String str, final int offset, final int len, final int x, final int y, int anchor) {
        if (str == null) {
            Assert(false, "DrawSubstring.str is null");
        }
        if ((anchor & 0x32) == 0x0) {
            Assert(false, "DrawSubstring.anchor miss vertical positionning");
        }
        if ((anchor & 0xD) == 0x0) {
            Assert(false, "DrawSubstring.anchor miss horizontal positionning");
        }
        if (offset >= str.length()) {
            Assert(false, "DrawSubstring.offset is invalid");
        }
        if (offset < 0) {
            Assert(false, "DrawSubstring.offset is negative");
        }
        if (offset + len > str.length()) {
            Assert(false, "DrawSubstring.len is invalid");
        }
        if (len < 0) {
            Assert(false, "DrawSubstring.len is negative");
        }
        anchor = transformAnchorForText(anchor);
        try {
            GLLib.g.drawSubstring(str, offset, len, x, y, anchor);
        }
        catch (final Exception ex) {}
    }
    
    static final void DrawChar(final char character, final int x, final int y, int anchor) {
        if ((anchor & 0x32) == 0x0) {
            Assert(false, "DrawChar.anchor miss vertical positionning");
        }
        if ((anchor & 0xD) == 0x0) {
            Assert(false, "DrawChar.anchor miss horizontal positionning");
        }
        anchor = transformAnchorForText(anchor);
        try {
            GLLib.g.drawChar(character, x, y, anchor);
        }
        catch (final Exception ex) {}
    }
    
    static final void DrawChars(final char[] data, final int offset, final int length, final int x, final int y, int anchor) {
        if (data == null) {
            Assert(false, "DrawChars.data is null");
        }
        if ((anchor & 0x32) == 0x0) {
            Assert(false, "DrawChars.anchor miss vertical positionning");
        }
        if ((anchor & 0xD) == 0x0) {
            Assert(false, "DrawChars.anchor miss horizontal positionning");
        }
        if (offset >= data.length) {
            Assert(false, "DrawChars.offset is invalid");
        }
        if (offset < 0) {
            Assert(false, "DrawChars.offset is negative");
        }
        if (offset + length > data.length) {
            Assert(false, "DrawChars.len is invalid");
        }
        if (length < 0) {
            Assert(false, "DrawChars.len is negative");
        }
        anchor = transformAnchorForText(anchor);
        try {
            GLLib.g.drawChars(data, offset, length, x, y, anchor);
        }
        catch (final Exception ex) {}
    }
    
    static final void DrawImage(final Image img, final int x, final int y, final int anchor) {
        if (img == null) {
            Assert(false, "DrawImage.data is null");
        }
        if ((anchor & 0x32) == 0x0) {
            Assert(false, "DrawImage.anchor miss vertical positionning");
        }
        if ((anchor & 0xD) == 0x0) {
            Assert(false, "DrawImage.anchor miss horizontal positionning");
        }
        try {
            GLLib.g.drawImage(img, x, y, anchor);
        }
        catch (final Exception ex) {}
    }
    
    static final void DrawRegion(final Image src, int x_src, int y_src, int width, int height, final int transform, final int x_dest, final int y_dest, final int anchor) {
        if (src == null) {
            Assert(false, "DrawRegion.src is null");
        }
        if ((anchor & 0x32) == 0x0) {
            Assert(false, "DrawRegion.anchor miss vertical positionning");
        }
        if ((anchor & 0xD) == 0x0) {
            Assert(false, "DrawRegion.anchor miss horizontal positionning");
        }
        if (transform < 0) {
            Assert(false, "DrawRegion.transform is invalid");
        }
        if (transform > 7) {
            Assert(false, "DrawRegion.transform is invalid");
        }
        if (x_src < 0) {
            Assert(false, "DrawRegion.x_src is negative");
        }
        if (y_src < 0) {
            Assert(false, "DrawRegion.y_src is negative");
        }
        if (x_src + width > src.getWidth()) {
            Assert(false, "DrawRegion.x_src+width is bigger than source image");
        }
        if (y_src + height > src.getHeight()) {
            Assert(false, "DrawRegion.x_src+height is bigger than source image");
        }
        if (GLLibConfig.useSafeDrawRegion) {
            if (x_src < 0) {
                width += x_src;
                x_src = 0;
            }
            if (x_src + width >= src.getWidth()) {
                width += src.getWidth() - (x_src + width);
            }
            if (y_src < 0) {
                height += y_src;
                y_src = 0;
            }
            if (y_src + height >= src.getHeight()) {
                height += src.getHeight() - (y_src + height);
            }
            if (height <= 0 || width <= 0) {
                return;
            }
        }
        try {
            if (GLLibConfig.sprite_drawRegionFlippedBug) {
                final Image image = Image.createImage(src, x_src, y_src, width, height, transform);
                GLLib.g.drawImage(image, x_dest, y_dest, anchor);
            }
            else {
                GLLib.g.drawRegion(src, x_src, y_src, width, height, transform, x_dest, y_dest, anchor);
            }
        }
        catch (final IllegalArgumentException iae) {
            Assert(false, "DrawRegion.src cannot be the current graphic context");
        }
        catch (final Exception ex) {}
    }
    
    static final void CopyArea(final int x_src, final int y_src, final int width, final int height, final int x_dest, final int y_dest, final int anchor) {
        try {
            GLLib.g.copyArea(x_src, y_src, width, height, x_dest, y_dest, anchor);
        }
        catch (final IllegalArgumentException iae) {
            Assert(false, "CopyArea.region to be copied exceeds the bounds of the source image");
        }
        catch (final IllegalStateException ise) {
            Assert(false, "CopyArea.gaphic contrext cannot be the display device");
        }
        catch (final Exception ex) {}
    }
    
    static final void FillTriangle(final int x1, final int y1, final int x2, final int y2, final int x3, final int y3) {
        GLLib.g.fillTriangle(x1, y1, x2, y2, x3, y3);
    }
    
    static final void DrawRGB(final int[] rgbData, final int offset, final int scanlength, final int x, final int y, final int width, final int height, final boolean processAlpha) {
        if (rgbData == null) {
            Assert(false, "DrawRGB.rgbData is null");
        }
        if (offset < 0) {
            Assert(false, "DrawRGB. invalid parameter: offset < 0");
        }
        if (width < 0) {
            Assert(false, "DrawRGB. invalid parameter: width < 0");
        }
        if (height < 0) {
            Assert(false, "DrawRGB. invalid parameter: height < 0");
        }
        if (scanlength < 0) {
            Assert(false, "DrawRGB. invalid parameter: scanlength < 0");
        }
        if (offset + width + (height - 1) * scanlength > rgbData.length) {
            Assert(false, "DrawRGB. invalid parameter(s) out of array bounds");
        }
        try {
            if (GLLibConfig.useDrawPartialRGB) {
                drawPartialRGB(GLLib.g, rgbData, scanlength, offset % scanlength, offset / scanlength, x, y, width, height, processAlpha);
            }
            else {
                GLLib.g.drawRGB(rgbData, offset, scanlength, x, y, width, height, processAlpha);
            }
        }
        catch (final Exception ex) {}
    }
    
    public static final void drawPartialRGB(final Graphics g, final int[] rgbData, final int scanlength, final int srcX, final int srcY, final int x, final int y, final int width, final int height, final boolean processAlpha) {
        drawPartialRGB(g, GetScreenWidth(), GetScreenHeight(), rgbData, scanlength, srcX, srcY, x, y, width, height, processAlpha);
    }
    
    public static final void drawPartialRGB(final Graphics g, final int screenWidth, final int screenHeight, final int[] rgbData, final int scanlength, final int srcX, final int srcY, int x, int y, int width, int height, final boolean processAlpha) {
        int offset = srcX + srcY * scanlength;
        if (g == GLLib.s_lastPaintGraphics) {
            if (x >= screenWidth || x + width <= 0 || y >= screenHeight || y + height <= 0) {
                return;
            }
            if (x <= 0) {
                offset -= x;
                width += x;
                x = 0;
            }
            if (x + width >= screenWidth) {
                width = screenWidth - x;
            }
            if (y + height >= screenHeight) {
                height = screenHeight - y;
            }
            if (y <= 0) {
                offset -= y * scanlength;
                height += y;
                y = 0;
            }
        }
        try {
            g.drawRGB(rgbData, offset, scanlength, x, y, width, height, processAlpha);
        }
        catch (final Exception ex) {}
    }
    
    static final int GetDisplayColor(final int color) {
        return GLLib.g.getDisplayColor(color);
    }
    
    static final boolean PlatformRequest(final String url) {
        try {
            return GLLib.s_application.platformRequest(url);
        }
        catch (final Exception e) {
            Dbg("PlatformRequest.Failed with url " + url + " with exception " + e.getMessage());
            return false;
        }
    }
    
    public static void Vibrate(final int duration) {
        if (duration < 0) {
            Assert(false, "Vibrate.duration is negative");
        }
        try {
            if (GLLib.m_nextTimeVibrationAllowed < GLLib.s_game_timeWhenFrameStart) {
                if (GLLibConfig.useFlashLightInsteadOfVibration) {
                    GLLib.s_display.flashBacklight(duration);
                }
                else {
                    GLLib.s_display.vibrate(duration);
                }
                GLLib.m_nextTimeVibrationAllowed = GLLib.s_game_timeWhenFrameStart + 200L;
            }
        }
        catch (final Exception ex) {}
    }
    
    static int Mem_SetByte(final byte[] dst, int dst_off, final byte src) {
        dst[dst_off++] = src;
        return dst_off;
    }
    
    static int Mem_SetShort(final byte[] dst, int dst_off, final short src) {
        dst[dst_off++] = (byte)(src & 0xFF);
        dst[dst_off++] = (byte)(src >>> 8 & 0xFF);
        return dst_off;
    }
    
    static int Mem_SetInt(final byte[] dst, int dst_off, final int src) {
        dst[dst_off++] = (byte)(src & 0xFF);
        dst[dst_off++] = (byte)(src >>> 8 & 0xFF);
        dst[dst_off++] = (byte)(src >>> 16 & 0xFF);
        dst[dst_off++] = (byte)(src >>> 24 & 0xFF);
        return dst_off;
    }
    
    static int Mem_SetLong(final byte[] dst, int dst_off, final long src) {
        dst[dst_off++] = (byte)(src & 0xFFL);
        dst[dst_off++] = (byte)(src >>> 8 & 0xFFL);
        dst[dst_off++] = (byte)(src >>> 16 & 0xFFL);
        dst[dst_off++] = (byte)(src >>> 24 & 0xFFL);
        dst[dst_off++] = (byte)(src >>> 32 & 0xFFL);
        dst[dst_off++] = (byte)(src >>> 40 & 0xFFL);
        dst[dst_off++] = (byte)(src >>> 48 & 0xFFL);
        dst[dst_off++] = (byte)(src >>> 56 & 0xFFL);
        return dst_off;
    }
    
    static byte Mem_GetByte(final byte[] src, final int src_off) {
        return src[src_off];
    }
    
    static short Mem_GetShort(final byte[] src, int src_off) {
        return (short)((src[src_off++] & 0xFF) | (src[src_off++] & 0xFF) << 8);
    }
    
    static int Mem_GetInt(final byte[] src, int src_off) {
        return (src[src_off++] & 0xFF) | (src[src_off++] & 0xFF) << 8 | (src[src_off++] & 0xFF) << 16 | (src[src_off++] & 0xFF) << 24;
    }
    
    static long Mem_GetLong(final byte[] src, int src_off) {
        return (long)(src[src_off++] & 0xFF) | (long)(src[src_off++] & 0xFF) << 8 | (long)(src[src_off++] & 0xFF) << 16 | (long)(src[src_off++] & 0xFF) << 24 | (long)(src[src_off++] & 0xFF) << 32 | (long)(src[src_off++] & 0xFF) << 40 | (long)(src[src_off++] & 0xFF) << 48 | (long)(src[src_off++] & 0xFF) << 56;
    }
    
    static void Mem_ArrayCopy(final Object src, final int src_position, final Object dst, final int dst_position, final int length) throws Exception {
        System.arraycopy(src, src_position, dst, dst_position, length);
    }
    
    static int Mem_SetArray(final byte[] dst, final int dst_off, final byte[] src) throws Exception {
        Mem_ArrayCopy(src, 0, dst, dst_off, src.length);
        return dst_off + src.length;
    }
    
    static int Mem_GetArray(final byte[] src, final int src_off, final byte[] dst) throws Exception {
        Mem_ArrayCopy(src, src_off, dst, 0, dst.length);
        return src_off + dst.length;
    }
    
    static Object Mem_ReadArray(final InputStream is) {
        if (is == null) {
            Assert(false, "Mem_ReadArray.is is null");
        }
        Object array = null;
        try {
            final int ID = Stream_Read(is);
            final int dataPadding = ID >> 4;
            int type = ID & 0x7;
            int nbComponent;
            if ((ID & 0x8) != 0x0) {
                nbComponent = Stream_Read16(is);
            }
            else {
                nbComponent = Stream_Read(is);
            }
            switch (type) {
                case 0: {
                    final byte[] array2 = new byte[nbComponent];
                    for (int i = 0; i < nbComponent; ++i) {
                        array2[i] = (byte)Stream_Read(is);
                    }
                    array = array2;
                    break;
                }
                case 1: {
                    final short[] array3 = new short[nbComponent];
                    if (dataPadding == 0) {
                        for (int i = 0; i < nbComponent; ++i) {
                            array3[i] = (byte)Stream_Read(is);
                        }
                    }
                    else {
                        for (int i = 0; i < nbComponent; ++i) {
                            array3[i] = (short)Stream_Read16(is);
                        }
                    }
                    array = array3;
                    break;
                }
                case 2: {
                    final int[] array4 = new int[nbComponent];
                    if (dataPadding == 0) {
                        for (int i = 0; i < nbComponent; ++i) {
                            array4[i] = (byte)Stream_Read(is);
                        }
                    }
                    else if (dataPadding == 1) {
                        for (int i = 0; i < nbComponent; ++i) {
                            array4[i] = (short)Stream_Read16(is);
                        }
                    }
                    else {
                        for (int i = 0; i < nbComponent; ++i) {
                            array4[i] = Stream_Read32(is);
                        }
                    }
                    array = array4;
                    break;
                }
                default: {
                    type &= 0x3;
                    Object[] genArray = null;
                    switch (type) {
                        case 0: {
                            if (dataPadding == 2) {
                                final byte[][] arrayB = new byte[nbComponent][];
                                genArray = arrayB;
                                break;
                            }
                            final byte[][][] arrayB2 = new byte[nbComponent][][];
                            genArray = arrayB2;
                            break;
                        }
                        case 1: {
                            if (dataPadding == 2) {
                                final short[][] arrayS = new short[nbComponent][];
                                genArray = arrayS;
                                break;
                            }
                            final short[][][] arrayS2 = new short[nbComponent][][];
                            genArray = arrayS2;
                            break;
                        }
                        default: {
                            if (dataPadding == 2) {
                                final int[][] arrayI = new int[nbComponent][];
                                genArray = arrayI;
                                break;
                            }
                            final int[][][] arrayI2 = new int[nbComponent][][];
                            genArray = arrayI2;
                            break;
                        }
                    }
                    for (int j = 0; j < nbComponent; ++j) {
                        genArray[j] = Mem_ReadArray(is);
                    }
                    array = genArray;
                    break;
                }
            }
        }
        catch (final Exception e) {
            Assert(false, "Mem_ReadArray.IO error");
        }
        return array;
    }
    
    static int Stream_Read(final InputStream is) throws Exception {
        final int read = is.read();
        if (read >= 0) {
            ++GLLib.Stream_readOffset;
        }
        return read;
    }
    
    static int Stream_Read16(final InputStream is) throws Exception {
        return (Stream_Read(is) & 0xFF) | (Stream_Read(is) & 0xFF) << 8;
    }
    
    static int Stream_Read32(final InputStream is) throws Exception {
        return (Stream_Read(is) & 0xFF) | (Stream_Read(is) & 0xFF) << 8 | ((Stream_Read(is) & 0xFF) << 16 | (Stream_Read(is) & 0xFF) << 24);
    }
    
    static int Stream_ReadFully(final InputStream is, final byte[] array, final int offset, final int length) {
        if (array == null) {
            Assert(false, "Stream_ReadFully.array is null");
        }
        if (offset < 0) {
            Assert(false, "Stream_ReadFully.offset is negative");
        }
        if (length < 0) {
            Assert(false, "Stream_ReadFully.length is negative");
        }
        if (offset + length > array.length) {
            Assert(false, "Stream_ReadFully.offset+length is bigger than array size");
        }
        int off = offset;
        int len = length;
        int read = 0;
        try {
            while (len > 0) {
                read = is.read(array, off, len);
                if (read < 0) {
                    Assert(false, "Pack_ReadFully.EOF");
                }
                len -= read;
                off += read;
            }
        }
        catch (final Exception e) {
            Assert(false, "Stream_ReadFully.IO exception occured");
        }
        GLLib.Stream_readOffset += length;
        return length;
    }
    
    int Text_GetPhoneDefaultLangage() {
        try {
            String lang = System.getProperty("microedition.locale");
            if (lang == null) {
                return 0;
            }
            lang = lang.toUpperCase();
            if (lang.indexOf(GLLib.StrEN) >= 0) {
                return 0;
            }
            if (lang.indexOf(GLLib.StrDE) >= 0) {
                return 1;
            }
            if (lang.indexOf(GLLib.StrFR) >= 0) {
                return 2;
            }
            if (lang.indexOf(GLLib.StrIT) >= 0) {
                return 3;
            }
            if (lang.indexOf(GLLib.StrES) >= 0) {
                return 4;
            }
            if (lang.indexOf(GLLib.StrBR) >= 0) {
                return 5;
            }
            if (lang.indexOf(GLLib.StrPT) >= 0) {
                return 6;
            }
            if (lang.indexOf("JA") >= 0) {
                return 7;
            }
            if (lang.indexOf(GLLib.StrJP) >= 0) {
                return 7;
            }
            if (lang.indexOf("ZH") >= 0) {
                return 8;
            }
            if (lang.indexOf(GLLib.StrCN) >= 0) {
                return 8;
            }
            if (lang.indexOf("KO") >= 0) {
                return 9;
            }
            if (lang.indexOf("KP") >= 0) {
                return 9;
            }
            if (lang.indexOf(GLLib.StrKR) >= 0) {
                return 9;
            }
            if (lang.indexOf(GLLib.StrRU) >= 0) {
                return 10;
            }
            if (lang.indexOf(GLLib.StrPL) >= 0) {
                return 12;
            }
            if (lang.indexOf(GLLib.StrTR) >= 0) {
                return 11;
            }
            if (lang.indexOf(GLLib.StrCZ) >= 0) {
                return 13;
            }
        }
        catch (final Exception ex) {}
        return 0;
    }
    
    String Text_GetLanguageAsString(final int languageCode) {
        switch (languageCode) {
            case 0: {
                return GLLib.StrEN;
            }
            case 1: {
                return GLLib.StrDE;
            }
            case 2: {
                return GLLib.StrFR;
            }
            case 3: {
                return GLLib.StrIT;
            }
            case 4: {
                return GLLib.StrES;
            }
            case 5: {
                return GLLib.StrBR;
            }
            case 6: {
                return GLLib.StrPT;
            }
            case 7: {
                return GLLib.StrJP;
            }
            case 8: {
                return GLLib.StrCN;
            }
            case 9: {
                return GLLib.StrKR;
            }
            case 10: {
                return GLLib.StrRU;
            }
            case 12: {
                return GLLib.StrPL;
            }
            case 11: {
                return GLLib.StrTR;
            }
            case 13: {
                return GLLib.StrCZ;
            }
            default: {
                return null;
            }
        }
    }
    
    private static int Text_LoadTextFromStream(final InputStream is) {
        try {
            GLLib.text_nbString = Stream_Read32(is);
            GLLib.text_arrayOffset = new int[GLLib.text_nbString + 1];
            for (int i = 1; i < GLLib.text_nbString + 1; ++i) {
                GLLib.text_arrayOffset[i] = Stream_Read32(is);
            }
            Stream_ReadFully(is, GLLib.text_array = new byte[GLLib.text_arrayOffset[GLLib.text_nbString]], 0, GLLib.text_array.length);
        }
        catch (final Exception ex) {}
        return GLLib.text_array.length + (GLLib.text_nbString + 1 << 2);
    }
    
    static void Text_LoadTextFromPack(final String filename, final int index) {
        Text_FreeAll();
        Pack_Open(filename);
        Pack_PositionAtData(index);
        if (GLLibConfig.pack_supportLZMADecompression && GLLib.s_pack_lastDataIsCompress) {
            byte[] data = Pack_ReadData(index);
            ByteArrayInputStream bis = new ByteArrayInputStream(data);
            Text_LoadTextFromStream(bis);
            bis = null;
            data = null;
        }
        else {
            Text_LoadTextFromStream(GLLib.s_pack_is);
        }
        Pack_Close();
        if (GLLibConfig.text_useStringCache) {
            Text_BuildStringCache();
        }
    }
    
    static void Text_LoadTextFromPack(final String filename, final int index1, final int index2) {
        Text_FreeAll();
        Pack_Open(filename);
        Pack_PositionAtData(index1);
        if (GLLibConfig.pack_supportLZMADecompression && GLLib.s_pack_lastDataIsCompress) {
            final ByteArrayInputStream bis = new ByteArrayInputStream(Pack_ReadData(index1));
            Text_LoadTextFromStream(bis);
        }
        else {
            GLLib.s_pack_curOffset += Text_LoadTextFromStream(GLLib.s_pack_is);
        }
        final int nbString1 = GLLib.text_nbString;
        final int[] arrayOffset1 = GLLib.text_arrayOffset;
        final byte[] arrayText1 = GLLib.text_array;
        Text_FreeAll();
        Pack_PositionAtData(index2);
        if (GLLibConfig.pack_supportLZMADecompression && GLLib.s_pack_lastDataIsCompress) {
            final ByteArrayInputStream bis2 = new ByteArrayInputStream(Pack_ReadData(index2));
            Text_LoadTextFromStream(bis2);
        }
        else {
            GLLib.s_pack_curOffset += Text_LoadTextFromStream(GLLib.s_pack_is);
        }
        final int nbString2 = GLLib.text_nbString;
        final int[] arrayOffset2 = GLLib.text_arrayOffset;
        final byte[] arrayText2 = GLLib.text_array;
        for (int i = 1; i < nbString2 + 1; ++i) {
            final int[] array = arrayOffset2;
            final int n = i;
            array[n] += arrayOffset1[nbString1];
        }
        Text_FreeAll();
        Pack_Close();
        GLLib.text_nbString = nbString1 + nbString2;
        System.arraycopy(arrayOffset1, 0, GLLib.text_arrayOffset = new int[GLLib.text_nbString + 1], 0, arrayOffset1.length);
        System.arraycopy(arrayOffset2, 1, GLLib.text_arrayOffset, arrayOffset1.length, arrayOffset2.length - 1);
        System.arraycopy(arrayText1, 0, GLLib.text_array = new byte[GLLib.text_arrayOffset[GLLib.text_nbString]], 0, arrayText1.length);
        System.arraycopy(arrayText2, 0, GLLib.text_array, arrayText1.length, arrayText2.length);
        if (GLLibConfig.text_useStringCache) {
            Text_BuildStringCache();
        }
    }
    
    static final void Text_SetEncoding(final String encoding) {
        GLLib.text_encoding = encoding;
    }
    
    static String Text_FromUTF8(final byte[] src, final int offset, final int len) {
        final char[] buf = new char[len];
        int d = 0;
        int s = offset;
        while (s < offset + len) {
            if ((src[s] & 0x80) == 0x0) {
                buf[d++] = (char)src[s++];
            }
            else if ((src[s] & 0xC0) == 0xC0 && s + 1 < offset + len && (src[s + 1] & 0xC0) == 0x80) {
                buf[d++] = (char)((src[s] & 0x1F) << 6 | (src[s + 1] & 0x3F));
                s += 2;
            }
            else {
                if ((src[s] & 0xE0) != 0xE0 || s + 2 >= offset + len || (src[s + 1] & 0xC0) != 0x80 || (src[s + 2] & 0xC0) != 0x80) {
                    return "";
                }
                buf[d++] = (char)((src[s] & 0xF) << 12 | (src[s + 1] & 0x3F) << 6 | (src[s + 2] & 0x3F));
                s += 3;
            }
        }
        return new String(buf, 0, d);
    }
    
    static String Text_GetString(final int index) {
        if (GLLib.text_encoding == null) {
            Assert(false, "Text_GetString.current text encoding is not set, use Text_SetEncoding()");
        }
        if (GLLibConfig.text_useStringCache && GLLib.text_stringCacheArray != null) {
            return GLLib.text_stringCacheArray[index];
        }
        try {
            final int l = GLLib.text_arrayOffset[index + 1] - GLLib.text_arrayOffset[index];
            if (l == 0) {
                return null;
            }
            if (!GLLibConfig.text_useInternalUTF8Converter) {
                return new String(GLLib.text_array, GLLib.text_arrayOffset[index], l, GLLib.text_encoding);
            }
            if (!GLLib.text_encoding.equals("UTF-8")) {
                return new String(GLLib.text_array, GLLib.text_arrayOffset[index], l, GLLib.text_encoding);
            }
            return Text_FromUTF8(GLLib.text_array, GLLib.text_arrayOffset[index], l);
        }
        catch (final Exception e) {
            Assert(false, "Text_GetString.unable to create string, might try another encoding." + e);
            return null;
        }
    }
    
    static final int Text_GetNbString() {
        return GLLib.text_nbString;
    }
    
    static void Text_BuildStringCache() {
        int size = 0;
        final String[] text = new String[GLLib.text_nbString];
        for (int i = 0; i < GLLib.text_nbString; ++i) {
            text[i] = Text_GetString(i);
            if (text[i] != null) {
                size += text[i].length();
            }
        }
        GLLib.text_stringCacheArray = text;
        GLLib.text_arrayOffset = null;
        GLLib.text_array = null;
        Gc();
        size *= 2;
        if (size > 15360) {
            Warning("you are caching " + Text_GetNbString() + " string, this comsume " + size + " byte of memory, you may consider dividing your text in smaller text package");
        }
    }
    
    static void Text_FreeAll() {
        if (GLLib.text_stringCacheArray != null) {
            for (int i = 0; i < GLLib.text_nbString; ++i) {
                GLLib.text_stringCacheArray[i] = null;
            }
            GLLib.text_stringCacheArray = null;
        }
        GLLib.text_arrayOffset = null;
        GLLib.text_array = null;
        GLLib.text_nbString = 0;
    }
    
    private static void Rms_Close() {
        if (GLLib.s_rs == null) {
            return;
        }
        try {
            GLLib.s_rs.closeRecordStore();
        }
        catch (final RecordStoreException e) {
            Dbg("ERROR! Failed closing RMS: " + e);
        }
        GLLib.s_rs = null;
    }
    
    private static void Rms_Open(final String strName) throws RecordStoreException {
        if (GLLibConfig.rms_useSharing && GLLib.s_rms_vendor != null && GLLib.s_rms_midletName != null) {
            Dbg(" Open recordstore with name : " + strName + ", vendor : " + GLLib.s_rms_vendor + ", suite : " + GLLib.s_rms_midletName);
            GLLib.s_rs = RecordStore.openRecordStore(strName, GLLib.s_rms_vendor, GLLib.s_rms_midletName);
        }
        else {
            Dbg(" Open recordstore : " + strName);
            GLLib.s_rs = RecordStore.openRecordStore(strName, true);
        }
    }
    
    static byte[] Rms_Read(final String strName) {
        byte[] data = null;
        try {
            Rms_Open(strName);
            if (GLLib.s_rs.getNumRecords() > 0) {
                data = GLLib.s_rs.getRecord(1);
            }
        }
        catch (final RecordStoreException e) {
            Dbg("ERROR! Failed reading from RMS: " + e);
            data = null;
        }
        Rms_Close();
        return data;
    }
    
    static void Rms_Write(final String strName, final byte[] data) {
        try {
            Rms_Open(strName);
            if (GLLib.s_rs.getNumRecords() > 0) {
                GLLib.s_rs.setRecord(1, data, 0, data.length);
            }
            else {
                GLLib.s_rs.addRecord(data, 0, data.length);
            }
        }
        catch (final RecordStoreException e) {
            Dbg("ERROR! Failed writing into RMS: " + e);
        }
        Rms_Close();
    }
    
    private static InputStream GetRmsInputStream(final String strName) {
        GLLib.s_rms_buffer = null;
        try {
            GLLib.s_rms_buffer = Rms_Read(strName);
        }
        catch (final Exception e) {
            Dbg("   Exception while reading from rms : " + strName);
        }
        if (GLLib.s_rms_buffer != null) {
            return new ByteArrayInputStream(GLLib.s_rms_buffer);
        }
        return null;
    }
    
    static void InitSharedRms(final String strVendor, final String strMidletName) {
        GLLib.s_rms_vendor = strVendor;
        GLLib.s_rms_midletName = strMidletName;
    }
    
    static void Rms_WriteShared(final String strName, final String strVendor, final String strMidletName, final byte[] data) {
        InitSharedRms(strVendor, strMidletName);
        Rms_Write(strName, data);
        InitSharedRms(null, null);
    }
    
    static byte[] Rms_ReadShared(final String strName, final String strVendor, final String strMidletName) {
        InitSharedRms(strVendor, strMidletName);
        final byte[] data = Rms_Read(strName);
        InitSharedRms(null, null);
        return data;
    }
    
    static void Pack_OpenShared(final String strName, final String strVendor, final String strMidletName) throws Exception {
        InitSharedRms(strVendor, strMidletName);
        Pack_Open(strName);
    }
    
    static void Pack_CloseShared() throws Exception {
        InitSharedRms(null, null);
        Pack_Close();
    }
    
    static void SavePack(final String packName, final String rmsName) {
        final int skipBufferSize = 1024;
        byte[] buffer = new byte[skipBufferSize];
        try {
            InputStream is = GLLib.s_gllib_instance.GetResourceAsStream(packName);
            int size = 0;
            for (int len = is.read(buffer, 0, skipBufferSize); len > 0; len = is.read(buffer, 0, skipBufferSize)) {
                size += len;
            }
            is.close();
            buffer = new byte[size];
            is = GLLib.s_gllib_instance.GetResourceAsStream(packName);
            int off = 0;
            while (size > 0) {
                final int len = is.read(buffer, off, size);
                off += len;
                size -= len;
            }
            is.close();
            Rms_Write(rmsName, buffer);
        }
        catch (final Exception e) {
            Dbg(" SavePack exception for pack : " + packName + " into rms name : " + rmsName);
        }
    }
    
    static void Profiler_Start() {
        if (GLLib.s_profiler_eventNames == null) {
            GLLib.s_profiler_eventNames = new String[200];
            GLLib.s_profiler_eventBegins = new long[200];
            GLLib.s_profiler_eventEnds = new long[200];
            GLLib.s_profiler_eventDepths = new short[200];
            GLLib.s_profiler_eventStack = new short[200];
        }
        GLLib.s_profiler_eventCount = 0;
        GLLib.s_profiler_eventStackIndex = 0;
        GLLib.s_profiler_recording = true;
    }
    
    static void Profiler_End() {
        GLLib.s_profiler_recording = false;
    }
    
    static void Profiler_Draw() {
        SetColor(0);
        FillRect(0, 0, GetScreenWidth(), GLLib.s_profiler_eventCount * GLLib.g.getFont().getHeight());
        SetColor(16777215);
        int i = 0;
        int y = 0;
        while (i < GLLib.s_profiler_eventCount) {
            GLLib.g.drawString(GLLib.s_profiler_eventNames[i], GLLib.s_profiler_eventDepths[i] * 10, y, 0);
            GLLib.g.drawString(Long.toString(GLLib.s_profiler_eventEnds[i] - GLLib.s_profiler_eventBegins[i]), GetScreenWidth() - 2, y, 24);
            y += GLLib.g.getFont().getHeight();
            ++i;
        }
    }
    
    static void Profiler_BeginNamedEvent(final String name) {
        if (GLLib.s_profiler_emulator && System.getProperty("EMU://BeginNamedEvent:" + name) == null) {
            Assert(false, "Failed to call BeginNamedEvent");
        }
        if (GLLib.s_profiler_recording) {
            if (GLLib.s_profiler_eventCount >= 200) {
                Assert(false, "Profiler: Too many events " + GLLib.s_profiler_eventCount);
            }
            GLLib.s_profiler_eventNames[GLLib.s_profiler_eventCount] = name;
            GLLib.s_profiler_eventBegins[GLLib.s_profiler_eventCount] = GetRealTime();
            GLLib.s_profiler_eventDepths[GLLib.s_profiler_eventCount] = (short)GLLib.s_profiler_eventStackIndex;
            GLLib.s_profiler_eventStack[GLLib.s_profiler_eventStackIndex] = (short)GLLib.s_profiler_eventCount;
            ++GLLib.s_profiler_eventCount;
            ++GLLib.s_profiler_eventStackIndex;
        }
    }
    
    static void Profiler_EndNamedEvent() {
        if (GLLib.s_profiler_emulator && System.getProperty("EMU://EndNamedEvent") == null) {
            Assert(false, "Failed to call EndNamedEvent");
        }
        if (GLLib.s_profiler_recording) {
            --GLLib.s_profiler_eventStackIndex;
            if (GLLib.s_profiler_eventStackIndex < 0 || GLLib.s_profiler_eventStackIndex >= 200) {
                Assert(false, "Profiler: Begin/End event match problem");
            }
            GLLib.s_profiler_eventEnds[GLLib.s_profiler_eventStack[GLLib.s_profiler_eventStackIndex]] = GetRealTime();
        }
    }
    
    static {
        GLLib.g = null;
        GLLib.s_lastPaintGraphics = null;
        GLLib.s_screenWidth = 0;
        GLLib.s_screenHeight = 0;
        GLLib.m_FPSLimiter = 1000 / GLLibConfig.FPSLimiter;
        GLLib.s_keyLastKeyPressUntranslatedCode = -9999;
        GLLib.m_last_key_pressed = -9999;
        s_math_F_1 = 1 << GLLibConfig.math_fixedPointBase;
        s_math_F_05 = GLLib.s_math_F_1 >> 1;
        Math_AngleMUL = 1 << GLLibConfig.math_angleFixedPointBase;
        Math_Angle90 = Math_DegreeToFixedPointAngle(90);
        Math_Angle180 = Math_DegreeToFixedPointAngle(180);
        Math_Angle270 = Math_DegreeToFixedPointAngle(270);
        Math_Angle360 = Math_DegreeToFixedPointAngle(360);
        Math_FixedPoint_PI = 1686629713 >> 29 - GLLibConfig.math_fixedPointBase;
        Math_FixedPoint_E = 1459366444 >> 29 - GLLibConfig.math_fixedPointBase;
        ratioRadiansToDegrees = Math_FixedPoint_Divide(180 << GLLibConfig.math_fixedPointBase, GLLib.Math_FixedPoint_PI);
        ratioDegreesToAngleFixedPoint = Math_FixedPoint_Divide(1 << GLLibConfig.math_angleFixedPointBase, 360);
        GLLib.s_Math_intersectPoints = new int[2][2];
        GLLib.Stream_readOffset = 0;
        GLLib.text_encoding = "UTF-8";
        GLLib.StrEN = "EN";
        GLLib.StrDE = "DE";
        GLLib.StrFR = "FR";
        GLLib.StrIT = "IT";
        GLLib.StrES = "ES";
        GLLib.StrBR = "BR";
        GLLib.StrPT = "PT";
        GLLib.StrJP = "JP";
        GLLib.StrCN = "CN";
        GLLib.StrKR = "KR";
        GLLib.StrRU = "RU";
        GLLib.StrTR = "TR";
        GLLib.StrPL = "PL";
        GLLib.StrCZ = "CZ";
        GLLib.s_profiler_emulator = (System.getProperty("EMU://EndNamedEvent") != null);
    }
}
