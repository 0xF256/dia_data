import javax.microedition.io.InputConnection;
import javax.microedition.io.OutputConnection;
import javax.microedition.io.Connection;
import javax.microedition.io.Connector;
import java.io.OutputStream;
import java.io.InputStream;
import javax.microedition.io.StreamConnection;
import java.util.Vector;

// 
// Decompiled by Procyon v0.6.0
// 

public class TCP extends Thread
{
    public boolean m_connected;
    public boolean m_bError;
    public String m_bErrorString;
    private TCPRecv m_receiveThread;
    protected Vector incomingQueue;
    protected Vector outgoingQueue;
    protected byte[] outgoing_data_on_receive_connection;
    protected String url;
    protected StreamConnection connection;
    protected InputStream istream;
    protected OutputStream ostream;
    protected StreamConnection receive_connection;
    protected InputStream receive_istream;
    protected OutputStream receive_ostream;
    
    public TCP(final String url) {
        this.connection = null;
        this.istream = null;
        this.ostream = null;
        this.receive_connection = null;
        this.receive_istream = null;
        this.receive_ostream = null;
        this.m_bError = false;
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            this.m_bErrorString = null;
            if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
                System.out.println("Using dual connection tcp");
            }
            else {
                System.out.println("Using single connection tcp");
            }
        }
        this.incomingQueue = new Vector();
        this.outgoingQueue = new Vector();
        this.url = url;
        if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
            this.outgoing_data_on_receive_connection = null;
        }
    }
    
    public void sendPacket(final byte[] data) {
        synchronized (this.outgoingQueue) {
            this.outgoingQueue.addElement(data);
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("Adding packet to outgoing queue");
            }
        }
    }
    
    public void sendEstablishConnectionPackageOnReceive(final byte[] data) {
        if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
            this.outgoing_data_on_receive_connection = data;
        }
        else {
            this.sendPacket(data);
        }
    }
    
    public byte[] recvPacket() {
        byte[] returndata = null;
        synchronized (this.incomingQueue) {
            if (this.incomingQueue.size() > 0) {
                returndata = this.incomingQueue.firstElement();
                this.incomingQueue.removeElementAt(0);
            }
        }
        return returndata;
    }
    
    public void connect() {
        if (!this.m_connected) {
            try {
                new Thread(this).start();
            }
            catch (final Exception e) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    System.out.println("TCP: connect exception: " + e.toString());
                    e.printStackTrace();
                }
            }
        }
    }
    
    public void disconnect() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            System.out.println("disconnecting tcp ... ");
        }
        this.m_connected = false;
    }
    
    private void cleanup() {
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            System.out.println("cleanup tcp .. ");
        }
        if (this.m_receiveThread != null) {
            this.m_receiveThread.m_running = false;
        }
        try {
            if (this.istream != null) {
                this.istream.close();
            }
        }
        catch (final Exception ex) {}
        try {
            if (this.ostream != null) {
                this.ostream.close();
            }
        }
        catch (final Exception ex2) {}
        try {
            if (this.connection != null) {
                ((Connection)this.connection).close();
            }
        }
        catch (final Exception ex3) {}
        this.istream = null;
        this.ostream = null;
        this.connection = null;
        if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
            try {
                if (this.receive_istream != null) {
                    this.receive_istream.close();
                }
            }
            catch (final Exception ex4) {}
            try {
                if (this.receive_ostream != null) {
                    this.receive_ostream.close();
                }
            }
            catch (final Exception ex5) {}
            try {
                if (this.receive_connection != null) {
                    ((Connection)this.receive_connection).close();
                }
            }
            catch (final Exception ex6) {}
            this.receive_istream = null;
            this.receive_ostream = null;
            this.receive_connection = null;
        }
        synchronized (this.outgoingQueue) {
            while (this.outgoingQueue.size() > 0) {
                this.outgoingQueue.removeElementAt(0);
            }
        }
        synchronized (this.incomingQueue) {
            while (this.incomingQueue.size() > 0) {
                this.incomingQueue.removeElementAt(0);
            }
        }
        try {
            this.m_receiveThread.join();
        }
        catch (final Exception ex7) {}
    }
    
    public void run() {
        this.m_connected = false;
        this.m_bError = false;
        try {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("TCP: Opening connection to " + this.url);
            }
            this.connection = (StreamConnection)Connector.open(this.url);
            if (this.connection == null) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    this.m_bErrorString = "StreamConnection.open to " + this.url;
                }
                this.m_bError = true;
                return;
            }
            if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    System.out.println("TCP: Opening receive connection to " + this.url);
                }
                this.receive_connection = (StreamConnection)Connector.open(this.url);
                if (this.receive_connection == null) {
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        this.m_bErrorString = "StreamConnection.open to " + this.url;
                    }
                    this.m_bError = true;
                    return;
                }
            }
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("TCP: run exception: " + e.toString());
                e.printStackTrace();
            }
            this.m_bError = true;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                this.m_bErrorString = "StreamConnection.open to " + this.url + " exception: " + e;
            }
            return;
        }
        this.ostream = null;
        if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
            this.receive_ostream = null;
        }
        try {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("TCP: Opening output stream");
            }
            this.ostream = ((OutputConnection)this.connection).openOutputStream();
            if (this.ostream == null) {
                this.m_bError = true;
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    this.m_bErrorString = "StreamConnection.openOutputStream to " + this.url;
                }
                return;
            }
            if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
                this.receive_ostream = ((OutputConnection)this.receive_connection).openOutputStream();
                if (this.receive_ostream == null) {
                    this.m_bError = true;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        this.m_bErrorString = "StreamConnection.openOutputStream to " + this.url;
                    }
                    return;
                }
            }
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("TCP: run exception: " + e.toString());
                e.printStackTrace();
            }
            this.m_bError = true;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                this.m_bErrorString = "StreamConnection.openOutputStream to " + this.url + " exception: " + e;
            }
            return;
        }
        this.istream = null;
        if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
            this.receive_istream = null;
        }
        try {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("TCP: Opening input stream");
            }
            this.istream = ((InputConnection)this.connection).openInputStream();
            if (this.istream == null) {
                this.m_bError = true;
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    this.m_bErrorString = "StreamConnection.openInputStream to " + this.url;
                }
                return;
            }
            if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
                this.receive_istream = ((InputConnection)this.receive_connection).openInputStream();
                if (this.receive_istream == null) {
                    this.m_bError = true;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        this.m_bErrorString = "StreamConnection.openInputStream to " + this.url;
                    }
                    return;
                }
            }
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("TCP: run exception: " + e.toString());
                e.printStackTrace();
            }
            this.m_bError = true;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                this.m_bErrorString = "StreamConnection.openInputStream to " + this.url + " exception: " + e;
            }
            return;
        }
        this.m_connected = true;
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            System.out.println("TCP: Connection established, starting recv thread");
        }
        if (GLLibConfig.xplayer_ENABLE_DUAL_TCP) {
            this.m_receiveThread = new TCPRecv(this.receive_istream, this.incomingQueue);
        }
        else {
            this.m_receiveThread = new TCPRecv(this.istream, this.incomingQueue);
        }
        this.m_receiveThread.start();
        final byte[] psize = { 0 };
        while (this.m_connected && this.m_receiveThread.m_running) {
            byte[] packet;
            synchronized (this.outgoingQueue) {
                packet = null;
                if (this.outgoingQueue.size() > 0) {
                    packet = this.outgoingQueue.firstElement();
                    this.outgoingQueue.removeElementAt(0);
                }
            }
            if (packet == null) {
                Thread.yield();
            }
            else {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    System.out.println("TCP: new packet to send");
                }
                psize[0] = (byte)(packet.length & 0xFF);
                try {
                    this.ostream.write(psize);
                    this.ostream.write(packet);
                }
                catch (final Exception e2) {
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        System.out.println("TCP: send exception: " + e2.toString());
                        e2.printStackTrace();
                    }
                    this.m_bError = true;
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        this.m_bErrorString = "Send th: " + ((e2.getMessage() == null) ? e2.toString() : e2.getMessage());
                    }
                    this.m_connected = false;
                }
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    System.out.println("TCP: Sent " + psize[0] + " bytes packet:" + new String(packet));
                }
                if (GLLibConfig.xplayer_ENABLE_DUAL_TCP && this.outgoing_data_on_receive_connection != null) {
                    psize[0] = (byte)(this.outgoing_data_on_receive_connection.length & 0xFF);
                    try {
                        this.receive_ostream.write(psize);
                        this.receive_ostream.write(this.outgoing_data_on_receive_connection);
                    }
                    catch (final Exception e2) {
                        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                            System.out.println("TCP: send exception when sending establish connection on receive: " + e2.toString());
                            e2.printStackTrace();
                        }
                        this.m_bError = true;
                        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                            this.m_bErrorString = "Send th: " + ((e2.getMessage() == null) ? e2.toString() : e2.getMessage());
                        }
                        this.m_connected = false;
                    }
                    this.outgoing_data_on_receive_connection = null;
                }
                Thread.yield();
            }
        }
        this.m_connected = false;
        this.cleanup();
        try {
            this.join();
        }
        catch (final Exception e2) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("TCP: join exception: " + e2.toString());
                e2.printStackTrace();
            }
        }
    }
    
    private class TCPRecv extends Thread
    {
        private InputStream is;
        private Vector v;
        private boolean m_running;
        private byte[] localReceiveBuffer;
        private int len;
        private int receiveBufferOffset;
        private byte[] receiveBufferQueue;
        
        public TCPRecv(final InputStream inputstream, final Vector vector) {
            this.is = inputstream;
            this.v = vector;
            this.localReceiveBuffer = new byte[255];
        }
        
        void recvBytes() {
            this.len = -2;
            try {
                this.len = this.is.read(this.localReceiveBuffer);
            }
            catch (final Exception e) {
                TCP.this.m_bError = true;
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    TCP.this.m_bErrorString = "Recv th: " + ((e.getMessage() == null) ? e.toString() : e.getMessage());
                }
                this.m_running = false;
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    System.out.println("TCP: recv exception: " + e.toString());
                    e.printStackTrace();
                }
            }
            if (this.len <= 0) {
                this.m_running = false;
                return;
            }
            final byte[] retbuf = new byte[this.len + this.receiveBufferQueue.length - this.receiveBufferOffset];
            System.arraycopy(this.receiveBufferQueue, this.receiveBufferOffset, retbuf, 0, this.receiveBufferQueue.length - this.receiveBufferOffset);
            System.arraycopy(this.localReceiveBuffer, 0, retbuf, this.receiveBufferQueue.length - this.receiveBufferOffset, this.len);
            this.receiveBufferOffset = 0;
            this.receiveBufferQueue = retbuf;
            Thread.yield();
        }
        
        int getByte() {
            while (this.m_running && this.receiveBufferQueue.length - this.receiveBufferOffset < 1) {
                this.recvBytes();
            }
            return this.m_running ? this.receiveBufferQueue[this.receiveBufferOffset++] : -1;
        }
        
        byte[] getBytes(final int length) {
            while (this.m_running && this.receiveBufferQueue.length - this.receiveBufferOffset < length) {
                this.recvBytes();
            }
            final byte[] retval = new byte[length];
            System.arraycopy(this.receiveBufferQueue, this.receiveBufferOffset, retval, 0, length);
            this.receiveBufferOffset += length;
            return retval;
        }
        
        public void start() {
            this.m_running = true;
            super.start();
        }
        
        public void run() {
            this.receiveBufferQueue = new byte[0];
            this.receiveBufferOffset = 0;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                System.out.println("TCPRecv: Starting receiver");
            }
            while (this.m_running) {
                int packetlength = this.getByte();
                if (packetlength == -1) {
                    this.m_running = false;
                }
                else {
                    if (packetlength < 0) {
                        packetlength += 256;
                    }
                    final byte[] packet = this.getBytes(packetlength);
                    synchronized (this.v) {
                        this.v.addElement(packet);
                    }
                    if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                        System.out.println("TCPRecv: Received " + packetlength + " bytes packet:" + new String(packet));
                    }
                    Thread.yield();
                }
            }
        }
    }
}
