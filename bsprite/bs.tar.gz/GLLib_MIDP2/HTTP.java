import javax.microedition.io.InputConnection;
import javax.microedition.io.OutputConnection;
import javax.microedition.io.Connection;
import java.io.ByteArrayOutputStream;
import javax.microedition.io.Connector;
import java.io.OutputStream;
import java.io.InputStream;
import javax.microedition.io.HttpConnection;

// 
// Decompiled by Procyon v0.6.0
// 

public final class HTTP implements Runnable
{
    private final int RECEIVEBUFFERSIZE = 16;
    private Thread m_thread;
    private String m_sUrl;
    private String m_sQuery;
    private HttpConnection m_c;
    private InputStream m_i;
    private OutputStream m_o;
    public String m_response;
    public byte[] m_responseByteArray;
    private boolean m_bInProgress;
    private boolean m_bCanceled;
    public boolean m_bError;
    public static String userAgent;
    public static String clientId;
    public static String x_up_subno;
    public static String CarrierDeviceId;
    public static String upsubid;
    public static String x_up_calling_line_id;
    
    public HTTP() {
        this.m_thread = null;
        this.m_c = null;
        this.m_i = null;
        this.m_o = null;
        this.m_bInProgress = false;
        this.m_bCanceled = false;
        this.m_bError = false;
    }
    
    public boolean isInProgress() {
        return this.m_bInProgress;
    }
    
    public boolean isErrorOccurred() {
        return this.m_bError;
    }
    
    public void cancel() {
        this.m_bCanceled = true;
        if (GLLibConfig.xplayer_HTTP_NO_CANCEL) {
            return;
        }
        if (this.m_c != null) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("HTTP: cancel");
            }
            try {
                synchronized (this.m_c) {
                    this.m_i.close();
                }
            }
            catch (final Exception ex) {}
            try {
                synchronized (this.m_c) {
                    ((Connection)this.m_c).close();
                }
            }
            catch (final Exception ex2) {}
            if (GLLibConfig.xplayer_USE_HTTP_POST) {
                try {
                    synchronized (this.m_o) {
                        this.m_o.close();
                    }
                }
                catch (final Exception ex3) {}
                this.m_o = null;
            }
        }
        this.m_i = null;
        this.m_c = null;
        this.m_bInProgress = false;
        this.m_thread = null;
        GLLib.Gc();
    }
    
    public void cleanup() {
        this.cancel();
        this.m_response = null;
        this.m_responseByteArray = null;
    }
    
    public void sendByGet(final String sUrl, final String sQuery) {
        GLLib.Gc();
        if (GLLibConfig.xplayer_ENABLE_DEBUG) {
            GLLib.Dbg("HTTP: sendByGet:url [" + sUrl + "] [" + sQuery + "] ");
        }
        while (this.m_bInProgress) {
            try {
                if (GLLibConfig.xplayer_ENABLE_TIMEOUT && System.currentTimeMillis() - XPlayer.callstarttime > GLLibConfig.xplayer_CONN_TIMEOUT) {
                    this.cancel();
                }
                synchronized (this) {
                    this.wait(50L);
                }
            }
            catch (final Exception e) {}
        }
        this.m_bInProgress = true;
        this.m_bCanceled = false;
        if (GLLibConfig.xplayer_USE_HTTP_POST) {
            this.m_sUrl = sUrl;
            this.m_sQuery = sQuery;
            this.m_sQuery = this.m_sQuery + "&v=" + GLLibConfig.xplayer_XPLAYER_VERSION;
        }
        else {
            this.m_sUrl = sUrl + "?b=" + sQuery;
            this.m_sUrl = this.m_sUrl + "&v=" + GLLibConfig.xplayer_XPLAYER_VERSION;
        }
        if (this.m_thread != null) {
            try {
                this.m_thread.join();
            }
            catch (final Exception ex) {}
        }
        this.m_bError = false;
        (this.m_thread = new Thread(this)).start();
    }
    
    public void run() {
        if (this.m_sUrl == null) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("HTTP: run: URL is null");
            }
            this.cancel();
            this.m_bError = true;
            this.m_bInProgress = false;
            this.m_bCanceled = false;
            return;
        }
        if (GLLibConfig.xplayer_USE_HTTP_POST) {
            if (this.m_sQuery == null) {
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("HTTP: run: Query is null");
                }
                this.cancel();
                this.m_bError = true;
                this.m_bInProgress = false;
                this.m_bCanceled = false;
                return;
            }
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("Using HTTP Post - this phone must have problems with long GET REQUESTS.");
            }
        }
        try {
            this.m_bError = false;
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("HTTP: run:connecting to [" + this.m_sUrl + "]");
            }
            if (this.m_bCanceled) {
                this.m_bInProgress = false;
                return;
            }
            this.m_c = (HttpConnection)Connector.open(this.m_sUrl, 3);
            if (this.m_bCanceled) {
                this.m_bInProgress = false;
                return;
            }
            if (GLLibConfig.xplayer_USE_HTTP_POST) {
                this.m_c.setRequestMethod("POST");
            }
            else {
                this.m_c.setRequestMethod("GET");
            }
            this.m_c.setRequestProperty("Connection", "close");
            if (HTTP.userAgent != null) {
                this.m_c.setRequestProperty("User-Agent", HTTP.userAgent);
            }
            if ((GLLibConfig.xplayer_CARRIER_USSPRINT || GLLibConfig.xplayer_CARRIER_MXTELCEL) && HTTP.clientId != null) {
                this.m_c.setRequestProperty("ClientID", HTTP.clientId);
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("HTTP Warning: clientId=" + HTTP.clientId);
                }
            }
            if (GLLibConfig.xplayer_CARRIER_USVIRGIN && HTTP.x_up_calling_line_id != null) {
                this.m_c.setRequestProperty("x-up-calling-line-id", HTTP.x_up_calling_line_id);
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("HTTP Warning: x-up-calling-line-id=" + HTTP.x_up_calling_line_id);
                }
            }
            if ((GLLibConfig.xplayer_CARRIER_USCINGULAR_BLUE || GLLibConfig.xplayer_CARRIER_USVIRGIN) && HTTP.x_up_subno != null) {
                this.m_c.setRequestProperty("x-up-subno", HTTP.x_up_subno);
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("HTTP Warning: x-up-subno=" + HTTP.x_up_subno);
                }
            }
            if (GLLibConfig.xplayer_CARRIER_USCINGULAR_ORANGE && HTTP.CarrierDeviceId != null) {
                this.m_c.setRequestProperty("CarrierDeviceId", HTTP.CarrierDeviceId);
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("HTTP Warning: CarrierDeviceId=" + HTTP.CarrierDeviceId);
                }
            }
            if (GLLibConfig.xplayer_CARRIER_USNEXTEL && HTTP.upsubid != null) {
                this.m_c.setRequestProperty("UPSUBID", HTTP.upsubid);
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("HTTP Warning: UPSUBID=" + HTTP.upsubid);
                }
            }
            if (GLLibConfig.xplayer_USE_HTTP_POST) {
                this.m_c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                final String sQuery = "b=" + this.m_sQuery;
                this.m_c.setRequestProperty("Content-Length", String.valueOf(sQuery.length()));
                (this.m_o = ((OutputConnection)this.m_c).openOutputStream()).write(sQuery.getBytes(), 0, sQuery.length());
                this.m_o.flush();
            }
            if (this.m_bCanceled) {
                this.m_bInProgress = false;
                return;
            }
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("HTTP: run: receive");
            }
            final int responseCode = this.m_c.getResponseCode();
            final HttpConnection c = this.m_c;
            if (responseCode != 200) {
                this.cancel();
                this.m_bError = true;
                this.m_bInProgress = false;
                this.m_bCanceled = false;
                return;
            }
            if (this.m_bCanceled) {
                this.m_bInProgress = false;
                return;
            }
            synchronized (this.m_c) {
                this.m_i = ((InputConnection)this.m_c).openInputStream();
            }
            final Thread thread = this.m_thread;
            Thread.yield();
            if (this.m_bCanceled) {
                this.m_bInProgress = false;
                return;
            }
            final ByteArrayOutputStream bao = new ByteArrayOutputStream();
            final byte[] abInBuffer = new byte[16];
            int nBytesRead = 0;
            while (nBytesRead != -1) {
                if (this.m_bCanceled) {
                    this.m_bInProgress = false;
                    return;
                }
                if (GLLibConfig.xplayer_USE_BUG_FIX_MESSAGE_SIZE) {
                    for (int i = 0; i < 16; ++i) {
                        abInBuffer[i] = 0;
                    }
                }
                nBytesRead = this.m_i.read(abInBuffer, 0, 16);
                if (this.m_bCanceled) {
                    this.m_bInProgress = false;
                    return;
                }
                if (nBytesRead == -1) {
                    break;
                }
                if (GLLibConfig.xplayer_USE_BUG_FIX_MESSAGE_SIZE) {
                    int i;
                    for (i = 15; i >= 0 && abInBuffer[i] == 0; --i) {}
                    nBytesRead = i + 1;
                }
                if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                    GLLib.Dbg("HTTP: run: read [" + nBytesRead + "] bytes from server");
                }
                bao.write(abInBuffer, 0, nBytesRead);
            }
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("HTTP: run: received [" + bao.toString() + "]");
            }
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("HTTP: run: total bytes read: [" + bao.size() + "]");
            }
            if (this.m_bCanceled) {
                this.m_bInProgress = false;
                return;
            }
            this.m_response = bao.toString();
            this.m_responseByteArray = bao.toByteArray();
        }
        catch (final Exception e) {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("HTTP: run: exception : " + e.toString());
            }
            this.m_bError = true;
            this.m_bInProgress = false;
        }
        finally {
            if (GLLibConfig.xplayer_ENABLE_DEBUG) {
                GLLib.Dbg("HTTP: run: finally");
            }
            this.cancel();
            this.m_thread = null;
            GLLib.Gc();
            this.m_bInProgress = false;
        }
    }
    
    static {
        HTTP.userAgent = null;
        HTTP.clientId = null;
        HTTP.x_up_subno = null;
        HTTP.CarrierDeviceId = null;
        HTTP.upsubid = null;
        HTTP.x_up_calling_line_id = null;
    }
}
