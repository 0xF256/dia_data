////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
// Task commands...
//

private static AURORA_TASK___() {}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Author(s): Ionut Matasaru (ionut.matasaru@gameloft.com)
//
//  main code from POPWW
//
////////////////////////////////////////////////////////////////////////////////////////////////////

	interface TCMD
	{
		final static int CAMERA					= 10;
		final static int CAMERA_MOVE_TO			= (CAMERA + 1); // Camera.MoveTo(x, y, frames);
		final static int CAMERA_FOLLOW			= (CAMERA + 2); // Camera.Follow(spr);

		// The sprite 0 is always Prince.

	//	flags: FLIP_X, FLIP_Y, INVISIBLE, PAUSE, LOOP_OFFSET

		final static int SPRITE					= 20;
		final static int SPRITE_NEW				= (SPRITE +  1); // Sprite[spr].New(parent, spr_id, x, y, z_order);
		final static int SPRITE_DELETE			= (SPRITE +  2); // Sprite[spr].Delete();
		final static int SPRITE_ADD_FLAGS		= (SPRITE +  3); // Sprite[spr].AddFlags(flags);
		final static int SPRITE_REMOVE_FLAGS	= (SPRITE +  4); // Sprite[spr].RemoveFlags(flags);
		final static int SPRITE_SET_MODULE		= (SPRITE +  5); // Sprite[spr].SetModule(module, frame);
		final static int SPRITE_SET_ANIM		= (SPRITE +  6); // Sprite[spr].SetAnim(anim);
		final static int SPRITE_SET_ANIM_EX		= (SPRITE +  7); // Sprite[spr].SetAnimEx(anim, type);
		final static int SPRITE_SET_AFRAME		= (SPRITE +  8); // Sprite[spr].SetAFrame(aframe, atime);
		final static int SPRITE_APPLY_ANIM_OFF	= (SPRITE +  9); // Sprite[spr].ApplyAnimOff();
		final static int SPRITE_SET_POS			= (SPRITE + 10); // Sprite[spr].SetPos(x, y);
		final static int SPRITE_SET_SPEED		= (SPRITE + 11); // Sprite[spr].SetSpeed(vx, vy);
		final static int SPRITE_SET_ACC			= (SPRITE + 12); // Sprite[spr].SetAcc(ax, ay);
		final static int SPRITE_SET_PALETTE		= (SPRITE + 13); // Sprite[spr].SetPalette(pal);

		final static int SYSTEM					= 40;
		final static int WAIT_END_ANIM			= (SYSTEM + 1); // WaitEndAnim(spr);
		final static int WAIT					= (SYSTEM + 2); // Wait(time);
		final static int EVENT					= (SYSTEM + 3); // Event(event, param);
		final static int START_TASK				= (SYSTEM + 4); // StartTask(task);
		final static int END_TASK				= (SYSTEM + 5); // EndTask();
		final static int SET_ANIM_BASE			= (SYSTEM + 6); // SetAnimBase(index, anim_base);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	final static int MAX_ANIM_BASES = 32;

	static byte[] 		_aTasks;

	static boolean		_bTaskActive = false;
	static int			_nTaskTimer;
	static int			_nTask;
	static int			_nTaskOffset;
	static int			_nTaskLength;
	static int			_nCrtPos;
	static int			_nCrtInstr;
	static int			_nTaskWaitTime;

	static int			_cam_pos_x;
	static int			_cam_pos_y;
	static int			_cam_move_to_x;
	static int			_cam_move_to_y;
	static int			_cam_move_to_frames;

	static cObject[]	_aSprInstances;
	static int[]		_aTaskAnimBase;

	static int			_text_marker_posX;
	static int			_text_duration;
	static int			_text_id;

////////////////////////////////////////////////////////////////////////////////////////////////////

	static void StartTask(int task)
	{
		if (DEF.bDbgT) System.out.println("StartTask("+task+")");

		_bTaskActive = true;
		_nTaskTimer = TASK_MAX_TIMER;

		_nTask = 0;
		_nTaskOffset = 1;
		_nTaskLength = (_aTasks[_nTaskOffset]&0xFF) + ((_aTasks[_nTaskOffset+1]&0xFF)<<8);
		while (_nTask < task)
		{
			_nTask++;
			_nTaskOffset += 2 + _nTaskLength;
			_nTaskLength = (_aTasks[_nTaskOffset]&0xFF) + ((_aTasks[_nTaskOffset+1]&0xFF)<<8);
		}
		_nTaskOffset += 2;

		if (DEF.bDbgO) System.out.println("TaskLength: "+_nTaskLength+" bytes");
		_nTaskLength += _nTaskOffset;

		_nCrtPos = _nTaskOffset;
		_nCrtInstr = 0;
		_nTaskWaitTime = 0;

		_Prince._flags |= DEF.FLAG_PAUSE;

		_cam_pos_x = _level._posX & 0xFFFFFF00;
		_cam_pos_y = _level._posY & 0xFFFFFF00;
		_cam_move_to_x = 0;
		_cam_move_to_y = 0;
		_cam_move_to_frames = 0;

		_aSprInstances = new cObject[DEF.MAX_TASK_SPR_INSTANCES];
		_aTaskAnimBase = new int[MAX_ANIM_BASES];

		_nPaintUI = 0xFFFFFFFF;

		// Tasks played when a level starts...
		if (task == 0 &&
			(_nCrtLoadedLevel == LEV.ADVENTURE + 0 ||
			 _nCrtLoadedLevel == LEV.ADVENTURE + 2 ||
			 _nCrtLoadedLevel == LEV.ADVENTURE + 8))
		{
			_nTaskTimer = TASK_TIMER_START;
			UpdateTask();
			_nTaskTimer = TASK_TIMER_START-1;
			UpdateTask();
		}
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	static void StopTask()
	{
		if (!_bTaskActive) return;
		if (DEF.bDbgT) System.out.println("StopTask()");

		_bTaskActive = false;

		_text_id = -1;

	//	if (cObject._oArrow != null)
	//		cObject._oArrow._flags &= ~(DEF.FLAG_HIDDEN|DEF.FLAG_PAUSE);

		_Prince._combo_nr = -1;
		_Prince._flags |= DEF.FLAG_ALWAYS_DRAW;
		_Prince._flags &= ~DEF.FLAG_PAUSE;
		_Prince._flags &= ~DEF.FLAG_HIDDEN;
		_Prince._flags &= ~PRINCE.FLAG_COMBAT;
		_Prince._state = PRINCE.STATE_WAIT;

		if ((_Prince._flags & PRINCE.FLAG_CHAIN) != 0)
			_Prince.SetAnim(PRINCE.ANIM_CHAIN_WAIT);
		else
			_Prince.SetAnim(PRINCE.ANIM_WAIT);

		for (int i = 0; i < _n_enemies; i++)
			_enemies[i]._flags &= ~DEF.FLAG_HIDDEN;

	//	for (int i = 0; i < _n_crows; i++)
	//		_crows[i]._flags &= ~DEF.FLAG_HIDDEN;

		if (_aSprInstances != null && _aSprInstances[0] != null)
		{
			if ((_aSprInstances[0]._flags & DEF.FLAG_FLIP_X) != 0)
				_Prince._flags |= DEF.FLAG_FLIP_X;
			else
				_Prince._flags &= ~DEF.FLAG_FLIP_X;

			_Prince._posX = _aSprInstances[0]._posX;
			_Prince._posY = _aSprInstances[0]._posY - (8<<8);

			int anim = _aSprInstances[0]._nCrtAnim;
			if (anim == PRINCE.ANIM_PULL_BLADES ||
				anim == PRINCE.ANIM_COMBAT_STAND ||
				anim == PRINCE.ANIM_ATTACK_FRAME)
			{
				_Prince._flags |= PRINCE.FLAG_COMBAT;
				_Prince._state = PRINCE.NO_COMBAT1;
				_Prince._sub_state = PRINCE.ANIM_PULL_BLADES;//PRINCE.ANIM_COMBAT_STAND;
				_Prince._data[DI.PRINCE_Next_substate] = -1;
				_Prince._data[DI.PRINCE_Next_state] = -1;
				_Prince._data[DI.PRINCE_Old_stateA] = -1;
				_Prince._data[DI.PRINCE_Old_stateB] = -1;
				_Prince.SetAnim(_Prince._sub_state);
			//	_Prince.AssertOnGround();
			}
		}
		_aSprInstances = null;
		_aTaskAnimBase = null;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	static void UpdateTask()
	{
	//	if (!_bTaskActive) return;

		if (_nTaskTimer == TASK_TIMER_START)
		{
			_Prince._flags &= ~DEF.FLAG_ALWAYS_DRAW;
			_Prince._flags |= DEF.FLAG_HIDDEN;

			for (int i = 0; i < _n_enemies; i++)
				_enemies[i]._flags |= DEF.FLAG_HIDDEN;

			for (int i = 0; i < _n_objects; i++)
			{
				if (_objects[i]._type == DEF.OBJTYPE_CHAIN)
				{
					_objects[i]._data[DI.CHN_Omega] = 0;
					_objects[i]._data[DI.CHN_Theta] = 0;
				}
			}
		}
		if (_nTaskTimer >= TASK_TIMER_START) return;

		// If we are already in the "normal" task state and there's text,
		//   decrease the duration and remove it if needed
		if (_nTaskTimer == 0 && _text_duration > 0)
		{
			_text_duration--;
			if (_text_duration == 0)
			{
				_text_id = -1;
				_nInvalidate |= INVALIDATE_TASK_AREA_BOTTOM;
			}
		}

 		if (((_nCrtPos == _nTaskLength) && (_nTaskWaitTime == 0)) || // task ended ?
 			(((_keys & KEY.SKIP_TASK) != 0) && (_aSprInstances[0] != null))) // skipped by user ?
 		{
 			StopTask();
 			return;
 		}

		if (_cam_move_to_frames > 0)
		{
			_cam_pos_x = ((_cam_move_to_frames - 1) * _cam_pos_x + _cam_move_to_x) / _cam_move_to_frames;
			_cam_pos_y = ((_cam_move_to_frames - 1) * _cam_pos_y + _cam_move_to_y) / _cam_move_to_frames;
			_cam_move_to_frames--;
		}

		for (int i = 0; i < DEF.MAX_TASK_SPR_INSTANCES; i++)
		{
			cObject si = _aSprInstances[i];
			if (si == null) continue;
			if ((si._flags & DEF.FLAG_PAUSE) != 0) continue;
			if ((si._flags & DEF.FLAG_LOOP_OFFSET) != 0)
			{
				if (si.IsAnimEnded())
				{
					si.ApplyAnimOff();
					si._pos_ox = 0;
					si._pos_oy = 0;
				}
			}
			si.UpdateSpriteAnim();
		//	si._posX -= si._pos_ox; si._pos_ox = 0;
		//	si._posY -= si._pos_oy; si._pos_oy = 0;
		//	si.UpdatePos();
		}

		while (true)
		{
			if (_nTaskWaitTime > 0)
			{
				_nTaskWaitTime--;
				break;
			}

			if (_nCrtPos >= _nTaskLength) break;

			int nSavedPos = _nCrtPos;
			byte cmd = _aTasks[_nCrtPos++];
			_nCrtInstr++;

			switch (cmd)
			{
				case TCMD.CAMERA_MOVE_TO:
		        {	// Camera.MoveTo(x, y);
					int x = (_aTasks[_nCrtPos++] & 0xFF);
					x += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
				//o	x = x * DEF.ZOOM_X_DIV / DEF.ZOOM_X;
					int y = (_aTasks[_nCrtPos++] & 0xFF);
					y += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
				//o	y = y * DEF.ZOOM_Y_DIV / DEF.ZOOM_Y;
					int frames = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("Camera.MoveTo("+x+", "+y+", "+frames+");");
					_cam_move_to_x = -(x<<8);
					_cam_move_to_y = -(y<<8);
					if (frames == 0)
					{
						_cam_pos_x = _cam_move_to_x;
						_cam_pos_y = _cam_move_to_y;
					}
					_cam_move_to_frames = frames;
				}	break;
		/*
				case TCMD.CAMERA_FOLLOW:
				{	// Camera.Follow(spr);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("Camera.Follow("+spr+");");
					//TODO
				}	break;
		*/
				case TCMD.SPRITE_NEW:
				{	// Sprite[spr].New(parent, spr_id, x, y, z_order);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					int parent = (_aTasks[_nCrtPos++] & 0xFF);
					int spr_id = (_aTasks[_nCrtPos++] & 0xFF);
					int x = (_aTasks[_nCrtPos++] & 0xFF);
					x += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
				//o	x = x * DEF.ZOOM_X_DIV / DEF.ZOOM_X;
					int y = (_aTasks[_nCrtPos++] & 0xFF);
					y += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
				//o	y = y * DEF.ZOOM_Y_DIV / DEF.ZOOM_Y;
					int z_order = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].New("+parent+", "+spr_id+", "+x+", "+y+", "+z_order+");");
					_aSprInstances[spr] = new cObject(parent, spr_id, x, y, z_order);
					if (spr_id == SPR2.PRINCE)
						_aSprInstances[spr]._flags |= DEF.FLAG_HAS_SHADOW;
				}	break;

				case TCMD.SPRITE_DELETE:
				{	// Sprite[spr].Delete();
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].Delete();");
					_aSprInstances[spr] = null;
				}	break;

				case TCMD.SPRITE_ADD_FLAGS:
				{	// Sprite[spr].AddFlags(flags);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					int flags = (_aTasks[_nCrtPos++] & 0xFF);
					flags += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
					flags += ((_aTasks[_nCrtPos++] & 0xFF) << 16);
					flags += ((_aTasks[_nCrtPos++] & 0xFF) << 24);
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].AddFlags(0x"+Integer.toHexString(flags)+");");
					_aSprInstances[spr]._flags |= flags;
				}	break;

				case TCMD.SPRITE_REMOVE_FLAGS:
				{	// Sprite[spr].RemoveFlags(flags);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					int flags = (_aTasks[_nCrtPos++] & 0xFF);
					flags += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
					flags += ((_aTasks[_nCrtPos++] & 0xFF) << 16);
					flags += ((_aTasks[_nCrtPos++] & 0xFF) << 24);
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].RemoveFlags(0x"+Integer.toHexString(flags)+");");
					_aSprInstances[spr]._flags &= ~flags;
				}	break;

				case TCMD.SPRITE_SET_MODULE:
				{	// Sprite[spr].SetAnim(module, frame);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					int module = (_aTasks[_nCrtPos++] & 0xFF);
					if (module == 0xFF) module = -1;
					int frame = (_aTasks[_nCrtPos++] & 0xFF);
					if (frame == 0xFF) frame = -1;
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].SetModule("+module+", "+frame+");");
					if (module >= 0 || frame >= 0)
					{
						_aSprInstances[spr]._nCrtAnim   = module;
						_aSprInstances[spr]._nCrtAFrame = frame;
						_aSprInstances[spr]._nCrtTime   = -1; // use module or frame
					}
					else
						_aSprInstances[spr]._nCrtTime   = 0; // use anim
				}	break;

				case TCMD.SPRITE_SET_ANIM:
				{	// Sprite[spr].SetAnim(anim);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					int anim = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].SetAnim("+anim+");");
					_aSprInstances[spr].SetAnim(anim);
				}	break;

				case TCMD.SPRITE_SET_ANIM_EX:
				{	// Sprite[spr].SetAnimEx(anim, base_index);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					int anim = (_aTasks[_nCrtPos++] & 0xFF);
					int base_index = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].SetAnimEx("+anim+", "+base_index+");");
					_aSprInstances[spr].SetAnim(anim + _aTaskAnimBase[base_index]);
				}	break;
/*
				case TCMD.SPRITE_SET_AFRAME:
				{	// Sprite[spr].SetAFrame(aframe, atime);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					int aframe = (_aTasks[_nCrtPos++] & 0xFF);
					int time = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].SetAFrame("+aframe+", "+time+");");
					_aSprInstances[spr]._nCrtAFrame = aframe;
					_aSprInstances[spr]._nCrtTime = time;
				}	break;
*/
				case TCMD.SPRITE_APPLY_ANIM_OFF:
				{	// Sprite[spr].ApplyAnimOff(aframe, atime);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].ApplyAnimOff();");
					_aSprInstances[spr].ApplyAnimOff();
				}	break;

				case TCMD.SPRITE_SET_POS:
				{	// Sprite[spr].SetPos(x, y);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					int x = (_aTasks[_nCrtPos++] & 0xFF);
					x += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
				//o	x = x * DEF.ZOOM_X_DIV / DEF.ZOOM_X;
					int y = (_aTasks[_nCrtPos++] & 0xFF);
					y += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
				//o	y = y * DEF.ZOOM_Y_DIV / DEF.ZOOM_Y;
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].SetPos("+x+", "+y+");");
					_aSprInstances[spr]._posX = (x << 8);
					_aSprInstances[spr]._posY = (y << 8);
				}	break;
	/*
				case TCMD.SPRITE_SET_SPEED:
				{	// Sprite[spr].SetSpeed(vx, vy);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					int vx = (_aTasks[_nCrtPos++] & 0xFF);
					vx += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
					int vy = (_aTasks[_nCrtPos++] & 0xFF);
					vy += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].SetSpeed("+vx+", "+vy+");");
				//	_aSprInstances[spr]._nVelX = (vx << 8);
				//	_aSprInstances[spr]._nVelY = (vy << 8);
				}	break;

				case TCMD.SPRITE_SET_ACC:
				{	// Sprite[spr].SetAcc(ax, ay);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					int ax = (_aTasks[_nCrtPos++] & 0xFF);
					ax += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
					int ay = (_aTasks[_nCrtPos++] & 0xFF);
					ay += ((_aTasks[_nCrtPos++] & 0xFF) << 8);
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].SetAcc("+ax+", "+ay+");");
				//	_aSprInstances[spr]._nAccX = (ax << 8);
				//	_aSprInstances[spr]._nAccY = (ay << 8);
				}	break;
	*/
				case TCMD.SPRITE_SET_PALETTE:
				{	// Sprite[spr].SetPalette(pal);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					int pal = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("Sprite["+spr+"].SetPalette("+pal+");");
					_aSprInstances[spr]._sub_state = pal;
				}	break;

				case TCMD.WAIT_END_ANIM:
				{	// WaitEndAnim(spr);
					int spr = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("WaitEndAnim("+spr+");");
					if (!_aSprInstances[spr].IsAnimEnded())
					{
						_nCrtPos = nSavedPos;
						_nCrtInstr--;
						return;
					}
				}	break;

				case TCMD.WAIT:
				{	// Wait(time);
					int time = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("Wait("+time+");");
					_nTaskWaitTime = time;
				}	break;

				case TCMD.EVENT:
				{	// Event(event, param);
					int event = (_aTasks[_nCrtPos++] & 0xFF);
					int param = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("Event("+event+", "+param+");");
					TriggerEvent(event, param);
				}	break;
/*
				case TCMD.START_TASK:
				{	// StartTask(task);
					int task = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("StartTask("+task+");");
					//TODO
				}	break;

				case TCMD.END_TASK:
				{	// EndTask();
					if (DEF.bDbgT) System.out.println("EndTask();");
					_nCrtPos = _nTaskLength;
				}	break;
*/
				case TCMD.SET_ANIM_BASE:
				{	// SetAnimBase(index, anim_base);
					int index = (_aTasks[_nCrtPos++] & 0xFF);
					int anim_base = (_aTasks[_nCrtPos++] & 0xFF);
					if (DEF.bDbgT) System.out.println("SetAnimBase("+index+", "+anim_base+");");
					_aTaskAnimBase[index] = anim_base;
				}	break;

				default:
					if (DEF.bDbgT) System.out.println("ERROR !!! (Instr: "+_nCrtInstr+",  OpCodePos: "+_nCrtPos+"/"+_nTaskLength+")");
					break;
			}

			if (_nCrtPos == _nTaskLength)
			{
				if (DEF.bDbgT) System.out.println("--- END ---");
				return;
			}

		//	if (bLoop && _nCrtPos >= _nCompiledTaskLen)
		//	{
		//		_nCrtPos = 0;
		//		_nCrtInstr = 0;
		//		break;
		//	}

		//	if (bStepByStep) break;
		}
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	static void PaintTaskObjects()
	{
	//	if (!_bTaskActive) return;
		if (_nTaskTimer >= TASK_TIMER_START) return;

		try
		{
			for (int i = DEF.MAX_TASK_SPR_INSTANCES-1; i >= 0; i--)
		//	for (int i = 0; i < DEF.MAX_TASK_SPR_INSTANCES; i++)
			{
				if (_aSprInstances[i] != null)
				 	_aSprInstances[i].Paint(_g);
			}
		}
		catch (Exception e)
		{
			if (DEF.bErr) DBG.CatchException(e, "PaintLevel(4)");
		}
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	final static int TASK_MAX_TIMER   = 19;//20;
	final static int TASK_TIMER_START = 9;

////////////////////////////////////////////////////////////////////////////////////////////////////

	static void PaintTaskInterface()
	{
	//	if (!_bTaskActive) return;

		SetClipSCR(0, 0, DEF.SCR_W, DEF.SCR_H);

		int y1 = DEF.TASK_TOP;
		int y2 = DEF.TASK_BOTTOM;
		if (_nTaskTimer > 0)
		{
			_nTaskTimer -= 2;
			if (_nTaskTimer < 0) _nTaskTimer = 0;
			int y = (_nTaskTimer >= 9) ? (20 - _nTaskTimer) : (_nTaskTimer + 2);

			y *= 8;
			if (_nTaskTimer >= 9)
			{
				y1 = y;
				y2 = y;
			}
			else
			{
				if (y > y1) y1 = y;
				if (y > y2) y2 = y;
			}

			_nInvalidate |= INVALIDATE_TASK_AREA_TOP;
			_nInvalidate |= INVALIDATE_TASK_AREA_BOTTOM;
		}

		if ((_nInvalidate&INVALIDATE_TASK_AREA_TOP) != 0)
		{
			_nInvalidate &= ~INVALIDATE_TASK_AREA_TOP;

			_g.setColor(0);
		//	_g.fillRect(0, DEF.TASK_DY1, DEF.SCR_W, y1);
			_g.fillRect(0, 0, DEF.SCR_W, DEF.TASK_DY1+y1);
			_g.setColor(0xFFCC0000);
			_g.drawLine(0, DEF.TASK_DY1-1+y1, DEF.SCR_W, DEF.TASK_DY1-1+y1);
			_g.setColor(0xFF770000);
			_g.fillRect(0, DEF.TASK_DY1-3+y1, DEF.SCR_W, 2);
		}

		if ((_nInvalidate&INVALIDATE_TASK_AREA_BOTTOM) != 0)
		{
			_nInvalidate &= ~INVALIDATE_TASK_AREA_BOTTOM;

			_g.setColor(0);
		//	_g.fillRect(0, DEF.SCR_H-DEF.TASK_DY2-y2, DEF.SCR_W, y2);
			_g.fillRect(0, DEF.SCR_H-DEF.TASK_DY2-y2, DEF.SCR_W, y2+DEF.TASK_DY2);
			_g.setColor(0xFFCC0000);
			_g.drawLine(0, DEF.SCR_H-DEF.TASK_DY2-y2, DEF.SCR_W, DEF.SCR_H-DEF.TASK_DY2-y2);
			_g.setColor(0xFF770000);
			_g.fillRect(0, DEF.SCR_H-DEF.TASK_DY2+1-y2, DEF.SCR_W, 2);

			if (_text_id != -1)
			{
				_sprFontS.SetCurrentPalette(0);
				if (_text_marker_posX >= 0)
					_sprFontS.DrawString(_g, "^", _text_marker_posX, DEF.SCR_H-DEF.TASK_DY2-DEF.TASK_BOTTOM+3, A_HCENTER_TOP);
				_sprFontM.SetCurrentPalette(2);
				_sprFontM.DrawPage(_g, GetString(3, _text_id), DEF.SCR_W/2, DEF.TASK_TEXT_Y, A_HCENTER_VCENTER);
			}
		}

		if (_aSprInstances != null && _aSprInstances[0] != null)
			DrawKeyHints(_g, MI.VOID, MI.SKIP);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	static void TriggerEvent(int nEvent, int nParam)
	{
		if (DEF.bDbgO) System.out.println("TriggerEvent("+nEvent+", "+nParam+")...");

		if (nEvent == EVENT.TEXT_SET_MARKER)
		{
			// Set text marker x position displayed in cutscene...
			_text_marker_posX = nParam;
			_nInvalidate |= INVALIDATE_TASK_AREA_BOTTOM;
		}
		else if (nEvent == EVENT.TEXT_SET_DURATION)
		{
			// Set text duration displayed in cutscene...
			_text_duration = nParam;
		}
		else if (nEvent == EVENT.TEXT_SET_TEXT)
		{
			// Set text index displayed in cutscene...
			_text_id = nParam;
			_nInvalidate |= INVALIDATE_TASK_AREA_BOTTOM;
		}
		else if (nEvent >= EVENT.OBJECT_MIN &&
				 nEvent <= EVENT.OBJECT_MAX)
		{
			// Send "param" message to objects with id equal with "event"...
			for (int i = 0; i < _n_objects; i++)
			{
				if (_objects[i]._id == nEvent)
					_objects[i].SendMessage(nParam);
			}
			for (int i = 0; i < _n_d2_objs; i++)
			{
				if (_d2_objs[i]._id == nEvent)
					_d2_objs[i].SendMessage(nParam);
			}
		}
		else if (nEvent == EVENT.PRINCE_LOSE_HEALTH)
		{
			// param = health points removed from Prince
			_Prince._nLifePoints -= nParam;
			if (_Prince._nLifePoints < 0)
				_Prince._nLifePoints = 0;
		}
		else if (nEvent == EVENT.PRINCE_GAIN_HEALTH)
		{
			// param = health points added to Prince
			_Prince._nLifePoints += nParam;
			if (_Prince._nLifePoints > PRINCE.MAX_HEALTH_POINTS)
				_Prince._nLifePoints = PRINCE.MAX_HEALTH_POINTS;
		}
		else if (nEvent == EVENT.PRINCE_LOSE_ENERGY)
		{
			// param = energy points removed from Prince
			_Prince._data[DI.PRINCE_Energy] -= nParam;
			if (_Prince._data[DI.PRINCE_Energy] < 0)
				_Prince._data[DI.PRINCE_Energy] = 0;
		}
		else if (nEvent == EVENT.PRINCE_GAIN_ENERGY)
		{
			// param = energy points added to Prince
			_Prince._data[DI.PRINCE_Energy] += nParam;
			if (_Prince._data[DI.PRINCE_Energy] > PRINCE.MAX_ENERGY_POINTS)
				_Prince._data[DI.PRINCE_Energy] = PRINCE.MAX_ENERGY_POINTS;
		}
		else if (nEvent == EVENT.PLAY_SOUND)
		{
			// param = sound index
			if (DEF.bSnd) PlaySound(nParam);
		}
		else if (nEvent == EVENT.START_TASK)
		{
			// param = task index
			StartTask(nParam);
		}
		else if (nEvent == EVENT.CHANGE_LEVEL)
		{
			// param = 0 -> go to next level
			AdventureLevelEnded(nParam);
		}
		else if (nEvent == EVENT.CAMERA_FREEZE)
		{
			// param = 0 -> unfreeze camera, = 1 -> freeze camera
			_cameraFreeze = (nParam == 1);
		}

		// OBSOLETE stuff...
		if (nEvent >= 400 && nEvent <= 450)	StartTask(nEvent - 400);
		if (nEvent == 500)					AdventureLevelEnded(0);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

private static ___AURORA_TASK() {}

// Task commands...
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

	// Anchor...
	final static int	A_LEFT_TOP			= Graphics.LEFT + Graphics.TOP;
	final static int	A_LEFT_VCENTER		= Graphics.LEFT + Graphics.VCENTER;
	final static int	A_LEFT_BOTTOM		= Graphics.LEFT + Graphics.BOTTOM;
	final static int	A_HCENTER_TOP		= Graphics.HCENTER + Graphics.TOP;
	final static int	A_HCENTER_VCENTER	= Graphics.HCENTER + Graphics.VCENTER;
	final static int	A_HCENTER_BOTTOM	= Graphics.HCENTER + Graphics.BOTTOM;
	final static int	A_RIGHT_TOP			= Graphics.RIGHT + Graphics.TOP;
	final static int	A_RIGHT_VCENTER		= Graphics.RIGHT + Graphics.VCENTER;
	final static int	A_RIGHT_BOTTOM		= Graphics.RIGHT + Graphics.BOTTOM;

////////////////////////////////////////////////////////////////////////////////////////////////////

	private static void SetClipSCR(int x, int y, int w, int h)
	{
		if (DEF.bClippingBug)
		{
			_g.setClip(0, 0, DEF.SCR_W, DEF.SCR_H);
			_g.clipRect(x, y, w, h);
		}
		else _g.setClip(x, y, w, h);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

} // class cGame

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
