#include "AEEModGen.h" // Module interface definitions
#include "AEEAppGen.h" // Applet interface definitions
#include "AEEShell.h"  // Shell interface definitions
#include "AEEStdLib.h" // AEE StdLib Services
#include "AEELicense.h"
#include "AEEHeap.h"

//#include "gamedef.h"

//#include "cInstance.h"
//#include "cStage.h"
//#include "cSprite.h"
//#include "cPal.h"
#include "cImg.h"
#include "cGame.h"


cImg::cImg()
{

    this->m_pGame = (cGame *)GETAPPINSTANCE();

	_buffer = this->m_pGame->_dib_buffer->pBmp;
	_npitch = this->m_pGame->_dib_buffer->nPitch;

	_fx = _tr = 0;
	_width = _height = 0;

	_palette = NULL;
	_pixels = NULL;
	allocator_ = null;
	_freePixels = TRUE;

#ifdef USE_COMPRESSED_16_COLORS_IMAGES
	m_bNoCompresData = TRUE;
#endif


	/*
//TODO --- maybe we don't need _buffer and _npicth, because they are used only once a draw :D
#if ((BREW_VER >= 200) || (defined(_AEE_SIMULATOR)))
	_buffer = this->m_pGame->_dib_buffer->pBmp;
	_npitch = this->m_pGame->_dib_buffer->nPitch;
#else
    _buffer = this->m_pGame->_ddb_buffer + PIXEL_OFFSET;
    _npitch = DEF_SCR_W * sizeof(PIXEL_TYPE);
#endif

  */
}


cImg::~cImg()
{
	unload();
}

/*
void cImg::setBuffer(uint8 *buffer, int npitch)
{
	_buffer = buffer;
	_npitch = npitch;
}
*/
void cImg::unload()
{
	if(!allocator_ && _freePixels)
		SAFE_DEL_ARRAY(_pixels);

	//SAFE_DEL(_palette);	
	_palette = NULL;

	_fx = _tr = 0;
	_width = _height = 0;
}

/*
void cImg::draw7TransparentPixelsOnScreenUpwards(Pixel_Type* screen, Pixel_Type* _pal, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels)
{
//	_newLineBegin = (ys * _width) + xs;
//	for (j = _h - 1; j >=0; j-- )
	register int begin;
	register int middle;
	register int end;
	register int _width1;
//	register int max_number_of_colors = (1<<color_occupies_x_bits);
//	register int and_with_bits =  max_number_of_colors - 1;
//	register int max_number_of_information_on_8Bits = 8 -  color_occupies_x_bits;
	register int index;
	register int value;



	register uint8* source;

	for ( ; height >= 0; height --)
	{
		begin	= 0;
		//middle	= 0;
		//end		= 0;
		_width1 = _w;

						middle = _newLineBegin >>2;
						end = _newLineBegin & 0x03;

		source = _pixels + middle;

		if  (end)
							begin = 4 - end;

		if (begin < _width1)
		{
			_width1 -= begin;
							middle = _width1 >> 2;
							end = _width1 & 0x03;

			_width1 = 0;
		}
		else
		{
			begin = _width1;
							_width1 =  4 - begin - end;
			middle = 0;
			end =0;

		}

		if (begin)
		{
			index = *source++;
			if (_width1)
				index >>= _width1;

							begin <<=1;
			while (begin)
			{
								begin -=2;
								value = (index >> begin) & 0x03;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen++;							

			}
		}

		while(middle --)
		{
			index = *source++;

			value = (index >> 6) & 0x03;
			if (value) 
				*screen = (Pixel_Type)_pal[value];

			screen++;							

			value = (index >> 4) & 0x03;
			if (value) 
				*screen = (Pixel_Type)_pal[value];

			screen++;							

			value = (index >> 2) & 0x03;
			if (value) 
				*screen = (Pixel_Type)_pal[value];

			screen++;							

			value = index & 0x03;
			if (value) 
				*screen = (Pixel_Type)_pal[value];

			screen++;							

		}

		if (end)
		{
			index = *source++;
			
			end *=2;
			index >>= 8 - end;
			while (end)
			{
				end -=2;
				value = (index >> end) & 0x03;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen++;							
			//	end -=2;
			}
		}

		screen += _inc1;
		_newLineBegin +=moveSourcexPixels;

	} 
}
*/

#ifdef DRAW_2bits_Colors
void cImg::draw4TransparentPixelsOnScreenUpwards(Pixel_Type* screen, Pixel_Type* _pal, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels)
{
//	_newLineBegin = (ys * _width) + xs;
//	for (j = _h - 1; j >=0; j-- )
	register int begin;
	register int middle;
	register int end;
	register int _width1;
//	register int max_number_of_colors = (1<<color_occupies_x_bits);
//	register int and_with_bits =  max_number_of_colors - 1;
//	register int max_number_of_information_on_8Bits = 8 -  color_occupies_x_bits;
	register int index;
	register int value;



	register uint8* source;

	for ( ; height >= 0; height --)
	{
		begin	= 0;
		//middle	= 0;
		//end		= 0;
		_width1 = _w;

						middle = _newLineBegin >>2;
						end = _newLineBegin & 0x03;

		source = _pixels + middle;

		if  (end)
							begin = 4 - end;

		if (begin < _width1)
		{
			_width1 -= begin;
							middle = _width1 >> 2;
							end = _width1 & 0x03;

			_width1 = 0;
		}
		else
		{
			begin = _width1;
							_width1 =  4 - begin - end;
			middle = 0;
			end =0;

		}

		if (begin)
		{
			index = *source++;
			if (_width1)
				index >>= _width1;

							begin <<=1;
			while (begin)
			{
								begin -=2;
								value = (index >> begin) & 0x03;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen++;							

			}
		}

		while(middle --)
		{
			index = *source++;

			value = (index >> 6) & 0x03;
			if (value) 
				*screen = (Pixel_Type)_pal[value];

			screen++;							

			value = (index >> 4) & 0x03;
			if (value) 
				*screen = (Pixel_Type)_pal[value];

			screen++;							

			value = (index >> 2) & 0x03;
			if (value) 
				*screen = (Pixel_Type)_pal[value];

			screen++;							

			value = index & 0x03;
			if (value) 
				*screen = (Pixel_Type)_pal[value];

			screen++;							

		}

		if (end)
		{
			index = *source++;
			
			end *=2;
			index >>= 8 - end;
			while (end)
			{
				end -=2;
				value = (index >> end) & 0x03;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen++;							
			//	end -=2;
			}
		}

		screen += _inc1;
		_newLineBegin +=moveSourcexPixels;

	} 
}
#endif

#ifdef DRAW_2bits_Colors
/*
void cImg::draw4TransparentPixelsOnScreenDownwards(Pixel_Type* screen, Pixel_Type* _pal, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels)
{
//	_newLineBegin = (ys * _width) + xs;
//	for (j = _h - 1; j >=0; j-- )
	register int begin;
	register int middle;
	register int end;
	register int _width1;
//	register int max_number_of_colors = (1<<color_occupies_x_bits);
//	register int and_with_bits =  max_number_of_colors - 1;
//	register int max_number_of_information_on_8Bits = 8 -  color_occupies_x_bits;
	register int index;
	register int value;


//	register int max_color_on_one_bit = (8 / color_occupies_x_bits);// >> 1;
//	register int and_with_max_color_on_one_bit = (max_color_on_one_bit) - 1;
	
	register uint8* source;

	for ( ; height >= 0; height --)
	{
		begin	= 0;
		//middle	= 0;
		//end		= 0;
		_width1 = _w;

						middle = _newLineBegin >>2;
						end = _newLineBegin & 0x03;

		source = _pixels + middle;

						if  (end)
							begin = 4 - end;

		if (begin < _width1)
		{
			_width1 -= begin;
							middle = _width1 >> 2;
							end = _width1 & 0x03;

			_width1 = 0;
		}
		else
		{
			begin = _width1;
							_width1 =  4 - begin - end;
			middle = 0;
			end =0;

		}

		if (begin)
		{
			index = *source++;
			if (_width1)
				index >>= _width1;

							begin <<=1;
			while (begin)
			{
								begin -=2;
								value = (index >> begin) & 0x03;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen--;							

			}
		}

		while(middle --)
		{
							index = *source++;

							value = (index >> 6) & 0x03;
							if (value) 
								*screen = (Pixel_Type)_pal[value];

							screen--;							

							value = (index >> 4) & 0x03;
							if (value) 
								*screen = (Pixel_Type)_pal[value];

							screen--;							

							value = (index >> 2) & 0x03;
							if (value) 
								*screen = (Pixel_Type)_pal[value];

							screen--;							

							value = index & 0x03;
							if (value) 
								*screen = (Pixel_Type)_pal[value];

							screen--;							

		}

		if (end)
		{
							index = *source++;
							
							end *=2;
			index >>= 8 - end;
			while (end)
			{
								end -=2;
								value = (index >> end) & 0x03;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen--;							
			//	end -=2;
			}
		}

		screen += _inc1;
		_newLineBegin +=moveSourcexPixels;

	} 
}
*/
#endif

#ifdef DRAW_2bits_Colors
/*
void cImg::draw4PixelsOnScreenUpwards(Pixel_Type* screen, Pixel_Type* _pal, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels)
{
	register int begin;
	register int middle;
	register int end;
	register int _width1;
	register int index;

	register uint8* source;

	for ( ; height >= 0; height --)
	{
		begin	= 0;
		//middle	= 0;
		//end		= 0;
		_width1 = _w;

		middle = _newLineBegin >>2;
		end = _newLineBegin & 0x03;

		source = _pixels + middle;

		if  (end)
			begin = 4 - end;

		if (begin < _width1)
		{
			_width1 -= begin;
							middle = _width1 >> 2;
							end = _width1 & 0x03;

			_width1 = 0;
		}
		else
		{
			begin = _width1;
			_width1 =  4 - begin - end;
			middle = 0;
			end =0;

		}

		if (begin)
		{
			index = *source++;
			if (_width1)
				index >>= _width1;

			begin <<=1;
			while (begin)
			{
				begin -=2;
				*screen++ = (Pixel_Type)_pal[(index >> begin) & 0x03];
			}
		}

		while(middle --)
		{
			index = *source++;

			*screen++ = (Pixel_Type)_pal[(index >> 6) & 0x03];
			*screen++ = (Pixel_Type)_pal[(index >> 4) & 0x03];
			*screen++ = (Pixel_Type)_pal[(index >> 2) & 0x03];
			*screen++ = (Pixel_Type)_pal[index & 0x03];
		}

		if (end)
		{
			index = *source++;
			
			end *=2;
			index >>= 8 - end;
			while (end)
			{
				end -=2;
				*screen++ = (Pixel_Type)_pal[(index >> end) & 0x03];
			}
		}

		screen += _inc1;
		_newLineBegin += moveSourcexPixels;

	} 
}
*/
#endif

#ifdef DRAW_2bits_Colors
/*
void cImg::draw4PixelsOnScreenDownwards(Pixel_Type* screen, Pixel_Type* _pal, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels)
{
	register int begin;
	register int middle;
	register int end;
	register int _width1;
	register int index;
	register uint8* source;

	for ( ; height >= 0; height --)
	{
		begin	= 0;
		//middle	= 0;
		//end		= 0;
		_width1 = _w;

		middle = _newLineBegin >>2;
		end = _newLineBegin & 0x03;

		source = _pixels + middle;

		if  (end)
			begin = 4 - end;

		if (begin < _width1)
		{
			_width1 -= begin;
			middle = _width1 >> 2;
			end = _width1 & 0x03;
			_width1 = 0;
		}
		else
		{
			begin = _width1;
			_width1 =  4 - begin - end;
			middle = 0;
			end =0;

		}

		if (begin)
		{
			index = *source++;
			if (_width1)
				index >>= _width1;

			begin <<=1;
			while (begin)
			{
				begin -=2;
				*screen-- = (Pixel_Type)_pal[(index >> begin) & 0x03];
			}
		}

		while(middle --)
		{
			index = *source++;

			*screen-- = (Pixel_Type)_pal[(index >> 6) & 0x03];
			*screen-- = (Pixel_Type)_pal[(index >> 4) & 0x03];
			*screen-- = (Pixel_Type)_pal[(index >> 2) & 0x03];
			*screen-- = (Pixel_Type)_pal[index & 0x03];
		}

		if (end)
		{
			index = *source++;

			end *=2;
			index >>= 8 - end;

			while (end)
			{
				end -=2;
				*screen-- = (Pixel_Type)_pal[(index >> end) & 0x03];
			}


		}

		screen += _inc1;
		_newLineBegin +=moveSourcexPixels;

	} 
}
*/
#endif


/*
void cImg::drawTransparentPixelsOnScreenUpwards(Pixel_Type* screen, Pixel_Type* _pal, int color_occupies_x_bits, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels)
{
//	_newLineBegin = (ys * _width) + xs;
//	for (j = _h - 1; j >=0; j-- )
	register int begin;
	register int middle;
	register int end;
	register int _width1;
	register int max_number_of_colors = (1<<color_occupies_x_bits);
	register int and_with_bits =  max_number_of_colors - 1;
	register int max_number_of_information_on_8Bits = 8 -  color_occupies_x_bits;
	register int index;
	register int value;


	register int max_color_on_one_bit = (8 / color_occupies_x_bits);// >> 1;
	register int and_with_max_color_on_one_bit = (max_color_on_one_bit) - 1;
	
	register uint8* source;

	for ( ; height >= 0; height --)
	{
		begin	= 0;
		//middle	= 0;
		//end		= 0;
		_width1 = _w;

		middle = _newLineBegin / max_color_on_one_bit;
		end = _newLineBegin & and_with_max_color_on_one_bit;

		source = _pixels + middle;

		if  (end)
			begin = max_color_on_one_bit - end;

		if (begin < _width1)
		{
			_width1 -= begin;
			middle = _width1 / max_color_on_one_bit;
			end = _width1 & and_with_max_color_on_one_bit;

			_width1 = 0;
		}
		else
		{
			begin = _width1;
			_width1 =  max_color_on_one_bit - begin - end;
			middle = 0;
			end =0;

		}

		if (begin)
		{
			index = *source++;
			if (_width1)
				index >>= _width1;

			begin *=color_occupies_x_bits;
			while (begin)
			{
				begin -=color_occupies_x_bits;
				value = (index >> begin) & and_with_bits;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen++;							

			}
		}

		while(middle --)
		{
			index = *source++;

			for (begin = max_number_of_information_on_8Bits; begin >= 0; begin -= color_occupies_x_bits)
			{
				value = (index >> begin) & and_with_bits;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen++;							
			}

//			value = (index >> 6) & and_with_bits;
//			if (value) 
//				*screen = (Pixel_Type)_pal[value];
//
//			screen++;							
//
//			value = (index >> 4) & and_with_bits;
//			if (value) 
//				*screen = (Pixel_Type)_pal[value];
//
//			screen++;							
//
//			value = (index >> 2) & and_with_bits;
//			if (value) 
//				*screen = (Pixel_Type)_pal[value];
//
//			screen++;							
//
//			value = index & and_with_bits;
//			if (value) 
//				*screen = (Pixel_Type)_pal[value];
//
//			screen++;							

		}

		if (end)
		{
			index = *source++;
			
			end *=color_occupies_x_bits;
			index >>= 8 - end;
			while (end)
			{
				end -=color_occupies_x_bits;
				value = (index >> end) & and_with_bits;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen++;							
			//	end -=2;
			}
		}

		screen += _inc1;
		_newLineBegin +=moveSourcexPixels;

	} 
}


void cImg::drawTransparentPixelsOnScreenDownwards(Pixel_Type* screen, Pixel_Type* _pal, int color_occupies_x_bits, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels)
{
//	_newLineBegin = (ys * _width) + xs;
//	for (j = _h - 1; j >=0; j-- )
	register int begin;
	register int middle;
	register int end;
	register int _width1;
	register int max_number_of_colors = (1<<color_occupies_x_bits);
	register int and_with_bits =  max_number_of_colors - 1;
	register int max_number_of_information_on_8Bits = 8 -  color_occupies_x_bits;
	register int index;
	register int value;


	register int max_color_on_one_bit = (8 / color_occupies_x_bits);// >> 1;
	register int and_with_max_color_on_one_bit = (max_color_on_one_bit) - 1;
	
	register uint8* source;

	for ( ; height >= 0; height --)
	{
		begin	= 0;
		//middle	= 0;
		//end		= 0;
		_width1 = _w;

		middle = _newLineBegin / max_color_on_one_bit;
		end = _newLineBegin & and_with_max_color_on_one_bit;

		source = _pixels + middle;

		if  (end)
			begin = max_color_on_one_bit - end;

		if (begin < _width1)
		{
			_width1 -= begin;
			middle = _width1 / max_color_on_one_bit;
			end = _width1 & and_with_max_color_on_one_bit;

			_width1 = 0;
		}
		else
		{
			begin = _width1;
			_width1 =  max_color_on_one_bit - begin - end;
			middle = 0;
			end =0;

		}

		if (begin)
		{
			index = *source++;
			if (_width1)
				index >>= _width1;

			begin *=color_occupies_x_bits;
			while (begin)
			{
				begin -=color_occupies_x_bits;
				value = (index >> begin) & and_with_bits;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen--;							

			}
		}

		while(middle --)
		{
			index = *source++;

			for (begin = max_number_of_information_on_8Bits; begin >= 0; begin -= color_occupies_x_bits)
			{
				value = (index >> begin) & and_with_bits;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen--;							
			}

//			value = (index >> 6) & and_with_bits;
//			if (value) 
//				*screen = (Pixel_Type)_pal[value];
//
//			screen++;							
//
//			value = (index >> 4) & and_with_bits;
//			if (value) 
//				*screen = (Pixel_Type)_pal[value];
//
//			screen++;							
//
//			value = (index >> 2) & and_with_bits;
//			if (value) 
//				*screen = (Pixel_Type)_pal[value];
//
//			screen++;							
//
//			value = index & and_with_bits;
//			if (value) 
//				*screen = (Pixel_Type)_pal[value];
//
//			screen++;							

		}

		if (end)
		{
			index = *source++;
			
			end *=color_occupies_x_bits;
			index >>= 8 - end;
			while (end)
			{
				end -=color_occupies_x_bits;
				value = (index >> end) & and_with_bits;
				if (value) 
					*screen = (Pixel_Type)_pal[value];

				screen--;							
			//	end -=2;
			}
		}

		screen += _inc1;
		_newLineBegin +=moveSourcexPixels;

	} 
}



void cImg::drawPixelsOnScreenUpwards(Pixel_Type* screen, Pixel_Type* _pal, int color_occupies_x_bits, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels)
{
//	_newLineBegin = (ys * _width) + xs;
//	for (j = _h - 1; j >=0; j-- )
	register int begin;
	register int middle;
	register int end;
	register int _width1;
	register int max_number_of_colors = (1<<color_occupies_x_bits);
	register int and_with_bits =  max_number_of_colors - 1;
	register int max_number_of_information_on_8Bits = 8 -  color_occupies_x_bits;
	register int index;
//	register int value;


	register int max_color_on_one_bit = (8 / color_occupies_x_bits);// >> 1;
	register int and_with_max_color_on_one_bit = (max_color_on_one_bit) - 1;
	
	register uint8* source;

	for ( ; height >= 0; height --)
	{
		begin	= 0;
		//middle	= 0;
		//end		= 0;
		_width1 = _w;

		middle = _newLineBegin / max_color_on_one_bit;
		end = _newLineBegin & and_with_max_color_on_one_bit;

		source = _pixels + middle;

		if  (end)
			begin = max_color_on_one_bit - end;

		if (begin < _width1)
		{
			_width1 -= begin;
			middle = _width1 / max_color_on_one_bit;
			end = _width1 & and_with_max_color_on_one_bit;

			_width1 = 0;
		}
		else
		{
			begin = _width1;
			_width1 =  max_color_on_one_bit - begin - end;
			middle = 0;
			end =0;

		}

		if (begin)
		{
			index = *source++;
			if (_width1)
				index >>= _width1;

			begin *=color_occupies_x_bits;
			while (begin)
			{
				begin -=color_occupies_x_bits;
//				value = (index >> begin) & and_with_bits;
//				if (value) 
//					*screen = (Pixel_Type)_pal[value];
				*screen++ = (Pixel_Type)_pal[(index >> begin) & and_with_bits];

//				screen++;							

			}
		}

		while(middle --)
		{
			index = *source++;

			for (begin = max_number_of_information_on_8Bits; begin >= 0; begin -= color_occupies_x_bits)
			{
				//value = (index >> begin) & and_with_bits;
				//if (value) 
				//	*screen = (Pixel_Type)_pal[value];
				*screen++ = (Pixel_Type)_pal[(index >> begin) & and_with_bits];

				//screen++;							
			}
		}

		if (end)
		{
			index = *source++;
			
			end *=color_occupies_x_bits;
			index >>= 8 - end;
			while (end)
			{
				end -=color_occupies_x_bits;
				//value = (index >> end) & and_with_bits;
				//if (value) 
				//	*screen = (Pixel_Type)_pal[value];
				*screen++ = (Pixel_Type)_pal[(index >> end) & and_with_bits];
				//screen++;							
			//	end -=2;
			}
		}

		screen += _inc1;
		_newLineBegin +=moveSourcexPixels;

	} 
}


void cImg::drawPixelsOnScreenDownwards(Pixel_Type* screen, Pixel_Type* _pal, int color_occupies_x_bits, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels)
{
//	_newLineBegin = (ys * _width) + xs;
//	for (j = _h - 1; j >=0; j-- )
	register int begin;
	register int middle;
	register int end;
	register int _width1;
	register int max_number_of_colors = (1<<color_occupies_x_bits);
	register int and_with_bits =  max_number_of_colors - 1;
	register int max_number_of_information_on_8Bits = 8 -  color_occupies_x_bits;
	register int index;
//	register int value;


	register int max_color_on_one_bit = (8 / color_occupies_x_bits);// >> 1;
	register int and_with_max_color_on_one_bit = (max_color_on_one_bit) - 1;
	
	register uint8* source;

	for ( ; height >= 0; height --)
	{
		begin	= 0;
		//middle	= 0;
		//end		= 0;
		_width1 = _w;

		middle = _newLineBegin / max_color_on_one_bit;
		end = _newLineBegin & and_with_max_color_on_one_bit;

		source = _pixels + middle;

		if  (end)
			begin = max_color_on_one_bit - end;

		if (begin < _width1)
		{
			_width1 -= begin;
			middle = _width1 / max_color_on_one_bit;
			end = _width1 & and_with_max_color_on_one_bit;

			_width1 = 0;
		}
		else
		{
			begin = _width1;
			_width1 =  max_color_on_one_bit - begin - end;
			middle = 0;
			end =0;

		}

		if (begin)
		{
			index = *source++;
			if (_width1)
				index >>= _width1;

			begin *=color_occupies_x_bits;
			while (begin)
			{
				begin -=color_occupies_x_bits;
				//value = (index >> begin) & and_with_bits;
				//if (value) 
				//*screen = (Pixel_Type)_pal[value];
				*screen-- = (Pixel_Type)_pal[(index >> begin) & and_with_bits];

//				screen--;							

			}
		}

		while(middle --)
		{
			index = *source++;

			for (begin = max_number_of_information_on_8Bits; begin >= 0; begin -= color_occupies_x_bits)
			{
				//value = (index >> begin) & and_with_bits;
				//if (value) 
				//	*screen = (Pixel_Type)_pal[value];
				*screen-- = (Pixel_Type)_pal[(index >> begin) & and_with_bits];
//				screen--;							
			}
		}

		if (end)
		{
			index = *source++;
			
			end *=color_occupies_x_bits;
			index >>= 8 - end;
			while (end)
			{
				end -=color_occupies_x_bits;
				//value = (index >> end) & and_with_bits;
				//if (value) 
				//	*screen = (Pixel_Type)_pal[value];
				*screen-- = (Pixel_Type)_pal[(index >> end) & and_with_bits];
//				screen--;							
			//	end -=2;
			}
		}

		screen += _inc1;
		_newLineBegin +=moveSourcexPixels;

	} 
}
*/

#ifdef TEST_NEW_DRAWING
void cImg::draw(cGraphics* g, int xs, int ys, int _w, int _h, int xd, int yd, uint8 fx )
{
	register int i,j,_width1;

	#ifdef PARANOID
		if (!_pixels || !_palette)
			return;
	#endif

	// clipping part
	register int xcs = g->clip_xs;
	register int ycs = g->clip_ys;
	register int xce = g->clip_xe;
	register int yce = g->clip_ye;

	register int dd = 0;

	{

		if (xs + _w > _width)
			_w = _width - xs;

		if (ys + _h > _height)
			_h = _height - ys;

		if ((xd >= xce) || (xd <= (xcs - _w)))
			return;
		if ((yd >= yce) || (yd <= (ycs - _h)))
			return;

		if ((xd + _w) > xce)
		{
			xce -= (xd + _w);
			_w += xce;
		}
		else
			xce = 0;

		if (xd < xcs)
		{
			dd = xcs - xd;
			xce += dd;
			_w -= dd;
			xs += dd;
			xd = xcs;
		}

		if ((_w <= 0) || (xs >= _width))
			return;

		if ((yd + _h) > yce)
		{
			yce -= (yd + _h);
			_h += yce;
		}
		else
			yce = 0;

		if (yd < ycs)
		{
			dd = ycs - yd;
			yce += dd;
			_h -= dd;
			ys += dd;
			yd = ycs;
		}

		if ((_h <= 0) || (ys >= _height))
			return;
	}

	Palette_Type *_pal = _palette->getCurrentPalette();

	uint8* source = NULL;

	register int _inc2 = g->m_pGraphicsIDIB->nPitch / sizeof(Pixel_Type); // _npitch;
	register int _inc1 = _inc2 - _w;

	Pixel_Type* screen = ((Pixel_Type*)(g->m_pGraphicsIDIB->pBmp));
	Pixel_Type* screen_line = NULL;
	Pixel_Type* screen_end = NULL;

//		screen = (Pixel_Type*)(_buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type)));
	screen += (yd * _inc2) + xd;

	screen_line = screen + _w;
	screen_end = screen + (_h * _inc2);


#ifdef DRAW_2bits_Colors
	if (_nrOfBits_Occupied_by_color == 2)
	{
/*
		if (_tr)
		{
			if (fx & FX_FLIP_H)
			{
				draw4TransparentPixelsOnScreenDownwards(screen + _w, _pal, (ys * _width) + (xs  - xce), _h - 1, _w, _inc1 + (_w << 1), _width);
			}
			else 
				if (fx & FX_FLIP_V)
				{
					draw4TransparentPixelsOnScreenUpwards(screen, _pal, ((ys + _h - 1 - yce) * _width) + xs, _h - 1, _w, _inc1,  -_width);
				}
			else 
				if (fx & FX_FLIP_HV)
				{
					draw4TransparentPixelsOnScreenDownwards(screen + _w, _pal, ((ys + _h - 1 - yce) * _width) + (xs  - xce), _h - 1, _w, _inc1 + (_w << 1), -_width);
				}
			else
*/
			{
				draw4TransparentPixelsOnScreenUpwards(screen, _pal, (ys * _width) + xs, _h - 1, _w, _inc1,  _width);
			}
/*
		}
		else
		{
			if (fx & FX_FLIP_H)
			{
				draw4PixelsOnScreenDownwards(screen + _w, _pal, (ys * _width) + (xs  - xce), _h - 1, _w, _inc1 + (_w << 1), _width);
			}
			else 
				if (fx & FX_FLIP_V)
				{
					draw4PixelsOnScreenUpwards(screen, _pal, ((ys + _h - 1 - yce) * _width) + xs, _h - 1, _w, _inc1,  -_width);
				}
			else 
				if (fx & FX_FLIP_HV)
				{
					draw4PixelsOnScreenDownwards(screen + _w, _pal, ((ys + _h - 1 - yce) * _width) + (xs  - xce), _h - 1, _w, _inc1 + (_w << 1), -_width);
				}
			else
			{
				draw4PixelsOnScreenUpwards(screen, _pal, (ys * _width) + xs, _h - 1, _w, _inc1,  _width);
			}
		}
	}
	else
	{
	
		if (_tr)
		{
			if (fx & FX_FLIP_H)
			{
				drawTransparentPixelsOnScreenDownwards(screen + _w, _pal, _nrOfBits_Occupied_by_color, (ys * _width) + (xs  - xce), _h - 1, _w, _inc1 + (_w << 1), _width);
			}
			else 
				if (fx & FX_FLIP_V)
				{
					drawTransparentPixelsOnScreenUpwards(screen, _pal, _nrOfBits_Occupied_by_color, ((ys + _h - 1 - yce) * _width) + xs, _h - 1, _w, _inc1,  -_width);
				}
			else 
				if (fx & FX_FLIP_HV)
				{
					drawTransparentPixelsOnScreenDownwards(screen + _w, _pal, _nrOfBits_Occupied_by_color, ((ys + _h - 1 - yce) * _width) + (xs  - xce), _h - 1, _w, _inc1 + (_w << 1), -_width);
				}
			else
			{
				drawTransparentPixelsOnScreenUpwards(screen, _pal, _nrOfBits_Occupied_by_color, (ys * _width) + xs, _h - 1, _w, _inc1,  _width);
			}

		}
		else
		{
			if (fx & FX_FLIP_H)
			{
				drawPixelsOnScreenDownwards(screen + _w, _pal, _nrOfBits_Occupied_by_color, (ys * _width) + (xs  - xce), _h - 1, _w, _inc1 + (_w << 1), _width);
			}
			else 
				if (fx & FX_FLIP_V)
				{
					drawPixelsOnScreenUpwards(screen, _pal, _nrOfBits_Occupied_by_color, ((ys + _h - 1 - yce) * _width) + xs, _h - 1, _w, _inc1,  -_width);
				}
			else 
				if (fx & FX_FLIP_HV)
				{
					drawPixelsOnScreenDownwards(screen + _w, _pal, _nrOfBits_Occupied_by_color, ((ys + _h - 1 - yce) * _width) + (xs  - xce), _h - 1, _w, _inc1 + (_w << 1), -_width);
				}
			else
			{
				drawPixelsOnScreenUpwards(screen, _pal, _nrOfBits_Occupied_by_color, (ys * _width) + xs, _h - 1, _w, _inc1,  _width);
			}
		}
*/
	}
	else
#endif
	{

//		_inc2 /= sizeof(Pixel_Type);

		if (_tr)
		{
			register uint8 index = 0;

			if (fx & FX_FLIP_H)
			{
				source = _pixels + (ys * _width) + (xs + _w - 1 - xce);
				_w += _width;
				while(TRUE)
				{
					index = *source--;
					if (index)  
						*screen = (Pixel_Type)_pal[index];
					screen++;
					if (screen >= screen_line)
					{
						source += _w;
						screen += _inc1;
						if(screen >= screen_end)
							break;
						screen_line += _inc2;
					}
				} 

			}
			else if (fx & FX_FLIP_V)
			{
				source = _pixels + ((ys + _h - 1 - yce) * _width) + xs;
				_w += _width;
				while(TRUE)
				{
					index = *source++;
					if (index)  *screen = (Pixel_Type)_pal[index];
					screen++;
					if (screen >= screen_line)
					{
						source -= _w;
						screen += _inc1;
						if(screen >= screen_end)
							break;
						screen_line += _inc2;
					}
				} 
			}
			else if (fx & FX_FLIP_HV)
			{
				source = _pixels + ((ys + _h - 1 - yce) * _width) + (xs + _w - 1 - xce);
				_w -= _width;
				while(TRUE)
				{
					index = *source--;
					if (index)  *screen = (Pixel_Type)_pal[index];
					screen++;
					if (screen >= screen_line)
					{
						source += _w;
						screen += _inc1;
						if(screen >= screen_end)
							break;
						screen_line += _inc2;
					}
				} 
			}
			else
			{
				source = _pixels + (ys * _width) + xs;
/*/
				_w -= _width;
				while(TRUE)
				{
					index = *source++;

					if (index) 
						*screen = (Pixel_Type)_pal[index];

					screen++;
					
					if (screen >= screen_line)
					{
						source -= _w;
						screen += _inc1;
						if(screen >= screen_end)
							break;
						screen_line += _inc2;
					}
				} 
/*/

				_width1 = _width - _w;
				for (j = _h - 1; j >=0; j-- )
				{


					for (i = _w; i >= 8; i -=8)
					{
						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;

						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;

						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;

						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;

						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;

						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;

						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;

						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;
					}


					if (i >=4)
					{
						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;

						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;

						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;

						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;					
						
						i-= 4;
					}

					while (i--)
					{
						index = *source++;

						if (index) 
							*screen = (Pixel_Type)_pal[index];

						screen++;

					}

					screen += _inc1;
					source += _width1;

				} 

//*/
			}
		}
		else
		{
			if (fx & FX_FLIP_H)
			{
				source = _pixels + (ys * _width) + (xs + _w - 1 - xce);
				_w += _width;
				while(TRUE)
				{
					*screen++ = (Pixel_Type)_pal[*source--];
					if (screen >= screen_line)
					{
						source += _w;
						screen += _inc1;
						if(screen >= screen_end)
							break;
						screen_line += _inc2;
					}
				} 
			}
			else if (fx & FX_FLIP_V)
			{
				source = _pixels + ((ys + _h - 1 - yce) * _width) + xs;
				_w += _width;
				while(TRUE)
				{
					*screen++ = (Pixel_Type)_pal[*source++];
					if (screen >= screen_line)
					{
						source -= _w;
						screen += _inc1;
						if(screen >= screen_end)
							break;
						screen_line += _inc2;
					}
				} 
			}
			else if (fx & FX_FLIP_HV)
			{
				source = _pixels + ((ys + _h - 1 - yce) * _width) + (xs + _w - 1 - xce);
				_w -= _width;
				while(TRUE)
				{
					*screen++ = (Pixel_Type)_pal[*source--];
					if (screen >= screen_line)
					{
						source += _w;
						screen += _inc1;
						if(screen >= screen_end)
							break;
						screen_line += _inc2;
					}
				} 
			}
			else
			{
				source = _pixels + (ys * _width) + xs;
/*
				_w -= _width;
				while(TRUE)
				{
					*screen++ = (Pixel_Type)_pal[*source++];
					if (screen >= screen_line)
					{
						source -= _w;
						screen += _inc1;
						if(screen >= screen_end)
							break;
						
						screen_line += _inc2;
					}
				} 
/*/

				_width1 = _width - _w;
				for (j = _h - 1; j >=0; j-- )
				{


					for (i = _w; i >= 8; i -=8)
					{
						*screen++ = (Pixel_Type)_pal[*source++];
						*screen++ = (Pixel_Type)_pal[*source++];
						*screen++ = (Pixel_Type)_pal[*source++];
						*screen++ = (Pixel_Type)_pal[*source++];
						*screen++ = (Pixel_Type)_pal[*source++];
						*screen++ = (Pixel_Type)_pal[*source++];
						*screen++ = (Pixel_Type)_pal[*source++];
						*screen++ = (Pixel_Type)_pal[*source++];
					}


					if (i >=4)
					{
						*screen++ = (Pixel_Type)_pal[*source++];
						*screen++ = (Pixel_Type)_pal[*source++];
						*screen++ = (Pixel_Type)_pal[*source++];
						*screen++ = (Pixel_Type)_pal[*source++];
						
						i-= 4;
					}

					while (i--)
					{
						*screen++ = (Pixel_Type)_pal[*source++];
					}

					screen += _inc1;
					source += _width1;

				} 

//*/
			}
		}
	}
}
#else //TEST_NEW_DRAWING
void cImg::draw(cGraphics* g, int xs, int ys, int _w, int _h, int xd, int yd, uint8 fx )
{
//#error --- aici am ramas... sa fac functiile inline si sa mai optimizez una alta
	_buffer = ((cGraphics*) g)->m_pGraphicsIDIB->pBmp;
	_npitch = ((cGraphics*) g)->m_pGraphicsIDIB->nPitch;


	#ifdef PARANOID
		if (!_pixels || !_palette)
			return;
	#endif

	// clipping part
	register int xcs = g->clip_xs;
	register int ycs = g->clip_ys;
	register int xce = g->clip_xe;
	register int yce = g->clip_ye;

	register int dd = 0;

	{

		if (xs + _w > _width)
			_w = _width - xs;

		if (ys + _h > _height)
			_h = _height - ys;

		if ((xd >= xce) || (xd <= (xcs - _w)))
			return;
		if ((yd >= yce) || (yd <= (ycs - _h)))
			return;

		if ((xd + _w) > xce)
		{
			xce -= (xd + _w);
			_w += xce;
		}
		else
			xce = 0;

		if (xd < xcs)
		{
			dd = xcs - xd;
			xce += dd;
			_w -= dd;
			xs += dd;
			xd = xcs;
		}

		if ((_w <= 0) || (xs >= _width))
			return;

		if ((yd + _h) > yce)
		{
			yce -= (yd + _h);
			_h += yce;
		}
		else
			yce = 0;

		if (yd < ycs)
		{
			dd = ycs - yd;
			yce += dd;
			_h -= dd;
			ys += dd;
			yd = ycs;
		}

		if ((_h <= 0) || (ys >= _height))
			return;
	}

#ifdef USE_COMPRESSED_16_COLORS_IMAGES
	if (m_bNoCompresData)
	{
#endif

	Palette_Type *_pal = _palette->getCurrentPalette();

	uint8* source = NULL;
	{
		register int _inc2 = _npitch;
		register int _inc1 = _inc2 - (_w * sizeof(Pixel_Type));

		Pixel_Type* screen = NULL;
		Pixel_Type* screen_line = NULL;
		Pixel_Type* screen_end = NULL;

		screen = (Pixel_Type*)(_buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type)));
		screen_line = (Pixel_Type*)(((uint8*)screen) + (_w * sizeof(Pixel_Type)));
		screen_end = (Pixel_Type*)(((uint8*)screen) + (_h * _inc2));

		if (_tr)
		{
			uint8 index = 0;

			if (fx & FX_FLIP_H)
			{
				source = _pixels + (ys * _width) + (xs + _w - 1 - xce);
				_w += _width;
				while(TRUE)
				{
					index = *source--;
					if (index)  
						*screen = (Pixel_Type)_pal[index];
					screen++;
					if (screen >= screen_line)
					{
						source += _w;
						screen = (Pixel_Type*)(((uint8*)screen) + _inc1);
						if(screen >= screen_end)
							break;
						screen_line = (Pixel_Type*)(((uint8*)screen_line) + _inc2);
					}
				} 

			}
			else if (fx & FX_FLIP_V)
			{
				source = _pixels + ((ys + _h - 1 - yce) * _width) + xs;
				_w += _width;
				while(TRUE)
				{
					index = *source++;
					if (index)  *screen = (Pixel_Type)_pal[index];
					screen++;
					if (screen >= screen_line)
					{
						source -= _w;
						screen = (Pixel_Type*)(((uint8*)screen) + _inc1);
						if(screen >= screen_end)
							break;
						screen_line = (Pixel_Type*)(((uint8*)screen_line) + _inc2);
					}
				} 
			}
			else if (fx & FX_FLIP_HV)
			{
				source = _pixels + ((ys + _h - 1 - yce) * _width) + (xs + _w - 1 - xce);
				_w -= _width;
				while(TRUE)
				{
					index = *source--;
					if (index)  *screen = (Pixel_Type)_pal[index];
					screen++;
					if (screen >= screen_line)
					{
						source += _w;
						screen = (Pixel_Type*)(((uint8*)screen) + _inc1);
						if(screen >= screen_end)
							break;
						screen_line = (Pixel_Type*)(((uint8*)screen_line) + _inc2);
					}
				} 
			}

			else
			{
				source = _pixels + (ys * _width) + xs;
				_w -= _width;
				while(TRUE)
				{
					index = *source++;

					if (index) 
						*screen = (Pixel_Type)_pal[index];

					screen++;
					
					if (screen >= screen_line)
					{
						source -= _w;
						screen = (Pixel_Type*)(((uint8*)screen) + _inc1);
						if(screen >= screen_end)
							break;
						screen_line = (Pixel_Type*)(((uint8*)screen_line) + _inc2);
					}
				} 
			}
		}
		else
		{
			if (fx & FX_FLIP_H)
			{
				source = _pixels + (ys * _width) + (xs + _w - 1 - xce);
				_w += _width;
				while(TRUE)
				{
					*screen++ = (Pixel_Type)_pal[*source--];
					if (screen >= screen_line)
					{
						source += _w;
						screen = (Pixel_Type*)(((uint8*)screen) + _inc1);
						if(screen >= screen_end)
							break;
						screen_line = (Pixel_Type*)(((uint8*)screen_line) + _inc2);
					}
				} 
			}
			else if (fx & FX_FLIP_V)
			{
				source = _pixels + ((ys + _h - 1 - yce) * _width) + xs;
				_w += _width;
				while(TRUE)
				{
					*screen++ = (Pixel_Type)_pal[*source++];
					if (screen >= screen_line)
					{
						source -= _w;
						screen = (Pixel_Type*)(((uint8*)screen) + _inc1);
						if(screen >= screen_end)
							break;
						screen_line = (Pixel_Type*)(((uint8*)screen_line) + _inc2);
					}
				} 
			}
			else if (fx & FX_FLIP_HV)
			{
				source = _pixels + ((ys + _h - 1 - yce) * _width) + (xs + _w - 1 - xce);
				_w -= _width;
				while(TRUE)
				{
					*screen++ = (Pixel_Type)_pal[*source--];
					if (screen >= screen_line)
					{
						source += _w;
						screen = (Pixel_Type*)(((uint8*)screen) + _inc1);
						if(screen >= screen_end)
							break;
						screen_line = (Pixel_Type*)(((uint8*)screen_line) + _inc2);
					}
				} 
			}
			else
			{
				source = _pixels + (ys * _width) + xs;
				_w -= _width;
				while(TRUE)
				{
					*screen++ = (Pixel_Type)_pal[*source++];
					if (screen >= screen_line)
					{
						source -= _w;
						screen = (Pixel_Type*)(((uint8*)screen) + _inc1);
						if(screen >= screen_end)
							break;
						
						screen_line = (Pixel_Type*)(((uint8*)screen_line) + _inc2);
					}
				} 
			}
		}
	}
#ifdef USE_COMPRESSED_16_COLORS_IMAGES
	}
	else //if(type == TYPE_INDEXED_4BIT) // TYPE_INDEXED_4BIT
	{
//		if (fx & FX_FLIP_H)
//			fx = 0;
		
		//register uint8 *_pixels = (uint8*)_data;

		Palette_Type *_pal = _palette->getCurrentPalette();
		//if(_palette->getCurrentPaletteNumber() == 1)
		//	dd = dd;
		uint8* source = NULL;

		{
			register int _inc2 = _npitch;
			register int xes = xs + _w;

			uint8* screen = NULL;
			uint8* screen_line = NULL;
			uint8* screen_end = NULL;

			if (_tr)
			{
				register uint8 transparency = _tr;
				register uint8 index;
				register uint8 col;

				if (fx & FX_FLIP_H)
				{
					register int _inc1 = _inc2 + (_w * sizeof(Pixel_Type));

//					screen_line = _buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type));
//					screen = screen_line + ((_w - 1)* sizeof(Pixel_Type));
//					screen_end = screen_line + (_h * _inc2);
//ciordache - bug id 106804
					screen_line = _buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type));
					screen = screen_line + ((_w - 1) * sizeof(Pixel_Type));
					screen_end = screen_line + (_h * _inc2);// + sizeof(Pixel_Type);

					uint8 *base_source = _pixels + (ys * img_line);

					xs -= xce;
					xes -= xce;
										
					if (xs & 1)
					{
						source = base_source + (xs >> 1);

						do
						{
							index = (*source) & 0x0F;
							source += img_line;
	
							if (index)
								*((Pixel_Type*)screen) = _pal[index];
							screen += _inc2;

						} while (screen < screen_end);
						
						xs++;
						_inc1 -= sizeof(Pixel_Type);
					}
					
					if (xes & 1)
					{
						source = base_source + (xes >> 1);
						screen_line += sizeof(Pixel_Type);
						screen = screen_line;

						do
						{
							index = (*source) >> 4;
							source += img_line;

							if (index)
								*((Pixel_Type*)screen) = _pal[index];
							screen += _inc2;

						} while (screen < screen_end);

						xes--;
						_inc1 -= sizeof(Pixel_Type);
						//ciordache bug id 106804
						//screen_line += sizeof(Pixel_Type);
					}

					if (xes > xs)
					{
						xes -= xs;						

						source = base_source + (xs >> 1);
						screen = screen_line + ((xes - 1) * sizeof(Pixel_Type));

						xes = ((xes + 1) >> 1) - img_line;

						do
						{
							index = *source++;
							
							col = index >> 4; 

							if (col) *((Pixel_Type*)screen) = _pal[col];
							screen -= sizeof(Pixel_Type);

//							if (col != transparency) *((Pixel_Type*)screen) = _pal[col];
//							screen -= sizeof(Pixel_Type);
							
							col = index & 0x0F; 

							if (col) *((Pixel_Type*)screen) = _pal[col];
							screen -= sizeof(Pixel_Type);

//							if (col != transparency) *((Pixel_Type*)screen) = _pal[col];
//							screen -= sizeof(Pixel_Type);

							if (screen < screen_line)
							{
								source -= xes;
								screen += _inc1;
								screen_line += _inc2;
							}
						} while (screen < screen_end);
					}					
				}
				else if (fx & FX_FLIP_V)
				{
					register int _inc1 = _inc2 + (_w * sizeof(Pixel_Type));

					screen_end = _buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type));
					screen = screen_end + ((_h - 1) * _inc2);
					screen_line = screen + (_w * sizeof(Pixel_Type));

					uint8 *base_source = _pixels + ((ys - yce) * img_line);
										
					if (xs & 1)
					{
						source = base_source + (xs >> 1);

						do
						{
							index = (*source) & 0x0F;
							source += img_line;

							if (index) *((Pixel_Type*)screen) = _pal[index];
							screen -= _inc2;

//							if (index != transparency) *((Pixel_Type*)screen) = _pal[index];
//							screen -= _inc2;

						} while (screen >= screen_end);
						
						xs++;
						_inc1 -= sizeof(Pixel_Type);
					}
					
					if (xes & 1)
					{
						source = base_source + (xes >> 1);
						screen_line -= sizeof(Pixel_Type);
						screen = screen_line;

						do
						{
							index = (*source) >> 4;
							source += img_line;

							if (index) *((Pixel_Type*)screen) = _pal[index];
							screen -= _inc2;

//							if (index != transparency) *((Pixel_Type*)screen) = _pal[index];
//							screen -= _inc2;

						} while (screen >= screen_end);

						xes--;
						_inc1 -= sizeof(Pixel_Type);
					}

					if (xes > xs)
					{
						xes -= xs;						

						source = base_source + (xs >> 1);
						screen = screen_line - (xes * sizeof(Pixel_Type));

						xes = ((xes + 1) >> 1) - img_line;

						do
						{
							index = *source++;
							
							col = index >> 4; 

							if (col) *((Pixel_Type*)screen) = _pal[col];
							screen += sizeof(Pixel_Type);

//							if (col != transparency) *((Pixel_Type*)screen) = _pal[col];
//							screen += sizeof(Pixel_Type);
							
							col = index & 0x0F; 
							if (col) *((Pixel_Type*)screen) = _pal[col];
							screen += sizeof(Pixel_Type);

//							if (col != transparency) *((Pixel_Type*)screen) = _pal[col];
//							screen += sizeof(Pixel_Type);

							if (screen >= screen_line)
							{
								source -= xes;
								screen -= _inc1;
								screen_line -= _inc2;
							}
						} while (screen >= screen_end);
					}
				}
				else if (fx & FX_FLIP_HV)
				{
					register int _inc1 = _inc2 - (_w * sizeof(Pixel_Type));

					screen_end = _buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type));					
					screen_line = screen_end + ((_h - 1) * _inc2);
					screen = screen_line + ((_w - 1) * sizeof(Pixel_Type));

					uint8 *base_source = _pixels + ((ys - yce) * img_line);

					xs -= xce;
					xes -= xce;
										
					if (xs & 1)
					{
						source = base_source + (xs >> 1);

						do
						{
							index = (*source) & 0x0F;
							source += img_line;

							if (index) *((Pixel_Type*)screen) = _pal[index];
							screen -= _inc2;

//							if (index != transparency) *((Pixel_Type*)screen) = _pal[index];
//							screen -= _inc2;

						} while (screen >= screen_end);
						
						xs++;
						_inc1 += sizeof(Pixel_Type);
					}
					
					if (xes & 1)
					{
						source = base_source + (xes >> 1);
						screen_line += sizeof(Pixel_Type);
						screen = screen_line;

						do
						{
							index = (*source) >> 4;
							source += img_line;

							if (index) *((Pixel_Type*)screen) = _pal[index];
							screen -= _inc2;

//							if (index != transparency) *((Pixel_Type*)screen) = _pal[index];
//							screen -= _inc2;

						} while (screen >= screen_end);

						xes--;
						_inc1 += sizeof(Pixel_Type);
					}

					if (xes > xs)
					{
						xes -= xs;						

						source = base_source + (xs >> 1);
						screen = screen_line + ((xes - 1) * sizeof(Pixel_Type));

						xes = ((xes + 1) >> 1) - img_line;

						do
						{
							index = *source++;
							
							col = index >> 4; 

							if (col) *((Pixel_Type*)screen) = _pal[col];
							screen -= sizeof(Pixel_Type);

//							if (col != transparency) *((Pixel_Type*)screen) = _pal[col];
//							screen -= sizeof(Pixel_Type);
							
							col = index & 0x0F; 
							if (col) *((Pixel_Type*)screen) = _pal[col];
							screen -= sizeof(Pixel_Type);
							
//							if (col != transparency) *((Pixel_Type*)screen) = _pal[col];
//							screen -= sizeof(Pixel_Type);

							if (screen < screen_line)
							{
								source -= xes;
								screen -= _inc1;
								screen_line -= _inc2;
							}
						} while (screen >= screen_end);
					}
				}
				else
				{
					register int _inc1 = _inc2 - (_w * sizeof(Pixel_Type));

					screen = _buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type));
					screen_line = screen + (_w * sizeof(Pixel_Type));
					screen_end = screen + (_h * _inc2);

					uint8 *base_source = _pixels + (ys * img_line);
										
					if (xs & 1)
					{
						source = base_source + (xs >> 1);

						do
						{
							index = (*source) & 0x0F;
							source += img_line;

							if (index) *((Pixel_Type*)screen) = _pal[index];
							screen += _inc2;

//							if (index != transparency) *((Pixel_Type*)screen) = _pal[index];
//							screen += _inc2;

						} while (screen < screen_end);
						
						xs++;
						_inc1 += sizeof(Pixel_Type);
					}
					
					if (xes & 1)
					{
						source = base_source + (xes >> 1);
						screen_line -= sizeof(Pixel_Type);
						screen = screen_line;

						do
						{
							index = (*source) >> 4;
							source += img_line;

							if (index) *((Pixel_Type*)screen) = _pal[index];
							screen += _inc2;

//							if (index != transparency) *((Pixel_Type*)screen) = _pal[index];
//							screen += _inc2;

						} while (screen < screen_end);

						xes--;
						_inc1 += sizeof(Pixel_Type);
					}

					if (xes > xs)
					{
						xes -= xs;						

						source = base_source + (xs >> 1);
						screen = screen_line - (xes * sizeof(Pixel_Type));

						xes = ((xes + 1) >> 1) - img_line;

						do
						{
							index = *source++;
							
							col = index >> 4; 

							if (col) *((Pixel_Type*)screen) = _pal[col];
							screen += sizeof(Pixel_Type);

//							if (col != transparency) *((Pixel_Type*)screen) = _pal[col];
//							screen += sizeof(Pixel_Type);
							
							col = index & 0x0F; 

							if (col) *((Pixel_Type*)screen) = _pal[col];
							screen += sizeof(Pixel_Type);

//							if (col != transparency) *((Pixel_Type*)screen) = _pal[col];
//							screen += sizeof(Pixel_Type);

							if (screen >= screen_line)
							{
								source -= xes;
								screen += _inc1;
								screen_line += _inc2;
							}
						} while (screen < screen_end);
					}
				}
			}
			else
			{
				register uint8 index;
				register uint8 col;

				if (fx & FX_FLIP_H)
				{
					register int _inc1 = _inc2 + (_w * sizeof(Pixel_Type));

					screen_line = _buffer + (xd * sizeof(Pixel_Type)) + (yd * _inc2);
					screen = screen_line + ((_w - 1) * sizeof(Pixel_Type));
					screen_end = screen + ((_h - 1) * _inc2) + sizeof(Pixel_Type);

					uint8 *base_source = _pixels + (ys * img_line);

					xs -= xce;
					xes -= xce;
										
					if (xs & 1)
					{
						source = base_source + (xs >> 1);

						do
						{
							index = (*source) & 0x0F;
							source += img_line;

							*((Pixel_Type*)screen) = _pal[index];
							screen += _inc2;

						} while (screen < screen_end);
						
						xs++;
						_inc1 -= sizeof(Pixel_Type);
					}
					
					if (xes & 1)
					{
						source = base_source + (xes >> 1);
						screen_line += sizeof(Pixel_Type);
						screen = screen_line;

						do
						{
							index = (*source) >> 4;
							source += img_line;

							*((Pixel_Type*)screen) = _pal[index];
							screen += _inc2;

						} while (screen < screen_end);

						xes--;
						_inc1 -= sizeof(Pixel_Type);
					}

					if (xes > xs)
					{
						xes -= xs;						

						source = base_source + (xs >> 1);
						screen = screen_line + (xes * sizeof(Pixel_Type));

						xes = ((xes + 1) >> 1) - img_line;

						do
						{
							index = *source++;
							
							col = index >> 4; 
							*((Pixel_Type*)screen) = _pal[col];
							screen -= sizeof(Pixel_Type);
							
							col = index & 0x0F; 
							*((Pixel_Type*)screen) = _pal[col];
							screen -= sizeof(Pixel_Type);

							if (screen < screen_line)
							{
								source -= xes;
								screen += _inc1;
								screen_line += _inc2;
							}
						} while (screen < screen_end);
					}					
				}
				else if (fx & FX_FLIP_V)
				{
					register int _inc1 = _inc2 + (_w * sizeof(Pixel_Type));

					screen_end = _buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type));
					screen = screen_end + ((_h - 1) * _inc2);
					screen_line = screen + (_w * sizeof(Pixel_Type));

					uint8 *base_source = _pixels + ((ys - yce) * img_line);
										
					if (xs & 1)
					{
						source = base_source + (xs >> 1);

						do
						{
							index = (*source) & 0x0F;
							source += img_line;

							*((Pixel_Type*)screen) = _pal[index];
							screen -= _inc2;

						} while (screen >= screen_end);
						
						xs++;
						_inc1 -= sizeof(Pixel_Type);
					}
					
					if (xes & 1)
					{
						source = base_source + (xes >> 1);
						screen_line -= sizeof(Pixel_Type);
						screen = screen_line;

						do
						{
							index = (*source) >> 4;
							source += img_line;

							*((Pixel_Type*)screen) = _pal[index];
							screen -= _inc2;

						} while (screen >= screen_end);

						xes--;
						_inc1 -= sizeof(Pixel_Type);
					}

					if (xes > xs)
					{
						xes -= xs;						

						source = base_source + (xs >> 1);
						screen = screen_line - (xes * sizeof(Pixel_Type));

						xes = ((xes + 1) >> 1) - img_line;

						do
						{
							index = *source++;
							
							col = index >> 4; 
							*((Pixel_Type*)screen) = _pal[col];
							screen += sizeof(Pixel_Type);
							
							col = index & 0x0F; 
							*((Pixel_Type*)screen) = _pal[col];
							screen += sizeof(Pixel_Type);

							if (screen >= screen_line)
							{
								source -= xes;
								screen -= _inc1;
								screen_line -= _inc2;
							}
						} while (screen >= screen_end);
					}
				}
				else if (fx & FX_FLIP_HV)
				{
					register int _inc1 = _inc2 - (_w * sizeof(Pixel_Type));

					screen_end = _buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type));					
					screen_line = screen_end + ((_h - 1) * _inc2);
					screen = screen_line + ((_w - 1) * sizeof(Pixel_Type));

					uint8 *base_source = _pixels + ((ys - yce) * img_line);

					xs -= xce;
					xes -= xce;
										
					if (xs & 1)
					{
						source = base_source + (xs >> 1);

						do
						{
							index = (*source) & 0x0F;
							source += img_line;

							*((Pixel_Type*)screen) = _pal[index];
							screen -= _inc2;

						} while (screen >= screen_end);
						
						xs++;
						_inc1 += sizeof(Pixel_Type);
					}
					
					if (xes & 1)
					{
						source = base_source + (xes >> 1);
						screen_line += sizeof(Pixel_Type);
						screen = screen_line;

						do
						{
							index = (*source) >> 4;
							source += img_line;

							*((Pixel_Type*)screen) = _pal[index];
							screen -= _inc2;

						} while (screen >= screen_end);

						xes--;
						_inc1 += sizeof(Pixel_Type);
					}

					if (xes > xs)
					{
						xes -= xs;						

						source = base_source + (xs >> 1);
						screen = screen_line + (xes * sizeof(Pixel_Type));

						xes = ((xes + 1) >> 1) - img_line;

						do
						{
							index = *source++;
							
							col = index >> 4; 
							*((Pixel_Type*)screen) = _pal[col];
							screen -= sizeof(Pixel_Type);
							
							col = index & 0x0F; 
							*((Pixel_Type*)screen) = _pal[col];
							screen -= sizeof(Pixel_Type);

							if (screen < screen_line)
							{
								source -= xes;
								screen -= _inc1;
								screen_line -= _inc2;
							}
						} while (screen >= screen_end);
					}
				}
				else
				{
					register int _inc1 = _inc2 - (_w * sizeof(Pixel_Type));

					screen = _buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type));
					screen_line = screen + (_w * sizeof(Pixel_Type));
					screen_end = screen + (_h * _inc2);

					uint8 *base_source = _pixels + (ys * img_line);
										
					if (xs & 1)
					{
						source = base_source + (xs >> 1);

						do
						{
							index = (*source) & 0x0F;
							source += img_line;

							*((Pixel_Type*)screen) = _pal[index];
							screen += _inc2;

						} while (screen < screen_end);
						
						xs++;
						_inc1 += sizeof(Pixel_Type);
					}
					
					if (xes & 1)
					{
						source = base_source + (xes >> 1);
						screen_line -= sizeof(Pixel_Type);
						screen = screen_line;

						do
						{
							index = (*source) >> 4;
							source += img_line;

							*((Pixel_Type*)screen) = _pal[index];
							screen += _inc2;

						} while (screen < screen_end);

						xes--;
						_inc1 += sizeof(Pixel_Type);
					}

					if (xes > xs)
					{
						xes -= xs;						

						source = base_source + (xs >> 1);
						screen = screen_line - (xes * sizeof(Pixel_Type));

						xes = ((xes + 1) >> 1) - img_line;

						do
						{
							index = *source++;
							
							col = index >> 4; 
							*((Pixel_Type*)screen) = _pal[col];
							screen += sizeof(Pixel_Type);
							
							col = index & 0x0F; 
							*((Pixel_Type*)screen) = _pal[col];
							screen += sizeof(Pixel_Type);

							if (screen >= screen_line)
							{
								source -= xes;
								screen += _inc1;
								screen_line += _inc2;
							}
						} while (screen < screen_end);
					}
				}
			}
		}
	}
#endif


}

#endif//TEST_NEW_DRAWING





#ifdef USE_ROTATE
void cImg::drawRot( int xs, int ys, int _w, int _h, int xd, int yd, uint8 fx )
{
	typedef uint16 Pixel_Type;

	if (!_pixels || !_palette)
		return;

	// experiment
	// rotate & stuff
	{
		if (fx & (FX_ROT_R90 | FX_ROT_L90))
		{
			if ((fx & (FX_ROT_R90 | FX_FLIP_V)) == (FX_ROT_R90 | FX_FLIP_V))
				fx = (FX_ROT_L90 | FX_FLIP_H);
			else if ((fx & (FX_ROT_L90 | FX_FLIP_V)) == (FX_ROT_L90 | FX_FLIP_V))
				fx = (FX_ROT_R90 | FX_FLIP_H);
			
			// clipping part
			register int xcs = m_pGame->clip_xs;
			register int ycs = m_pGame->clip_ys;
			register int xce = m_pGame->clip_xe;
			register int yce = m_pGame->clip_ye;
			register int dd = 0;

			{
				if ((xd >= xce) || (xd <= (xcs - _h)))
					return;

				if ((yd >= yce) || (yd <= (ycs - _w)))
					return;

				if ((xd + _h) > xce)
				{
					xce -= (xd + _h);
					_h += xce;
				}
				else
					xce = 0;
				if (xd < xcs)
				{
					dd = xcs - xd;
					xce += dd;
					_h -= dd;
					ys += dd;
					xd = xcs;
				}
				//	if ((xs + _w) > _width)
				//	{
				//		_w = _width - xs;
				//	}
				if ((_h <= 0) || (xs >= _width))
					return;

				if ((yd + _w) > yce)
				{
					yce -= (yd + _w);
					_w += yce;
				}
				else
					yce = 0;
				if (yd < ycs)
				{
					dd = ycs - yd;
					yce += dd;
					_w -= dd;
					xs += dd;
					yd = ycs;
				}
				//	if ((ys + _h) > _height)
				//	{
				//		_h = _height - ys;
				//	}
				if ((_w <= 0) || (ys >= _height))
					return;
			}

			Palette_Type *_pal = _palette->getCurrentPalette();
			uint8* source = NULL;

			register int _inc2 = _npitch;
			register int _inc1 = _inc2 - (_h * sizeof(Pixel_Type));

			Pixel_Type* screen = NULL;
			Pixel_Type* screen_line = NULL;
			Pixel_Type* screen_end = NULL;

			screen = (Pixel_Type*)(_buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type)));
			screen_line = (Pixel_Type*)(((uint8*)screen) + (_h * sizeof(Pixel_Type)));
			screen_end = (Pixel_Type*)(((uint8*)screen) + (_w * _inc2));
			
			if (fx & FX_ROT_R90)
			{
				if (fx & FX_FLIP_H)
				{
					source = _pixels + ((ys + _h - 1 - xce) * _width) + xs + _w - 1 - yce;
					_h = (_h * _width) - 1;
				}
				else
				{
					source = _pixels + ((ys + _h - 1 - xce) * _width) + xs;
					_h = (_h * _width) + 1;
				}

				do
				{
					*screen++ = _pal[*source];
					source -= _width;
					if (screen >= screen_line)
					{
						source += _h;
						screen = (Pixel_Type*)(((uint8*)screen) + _inc1);
						screen_line = (Pixel_Type*)(((uint8*)screen_line) + _inc2);
					}
				} while (screen < screen_end);
			}
			else // if (fx & FX_ROT_R90)
			{
				if (fx & FX_FLIP_H)
				{
					source = _pixels + (ys * _width) + xs;
					_h = (_h * _width) - 1;
				}
				else
				{
					source = _pixels + (ys * _width) + xs + _w - 1 - yce;
					_h = (_h * _width) + 1;
				}

				do
				{
					*screen++ = _pal[*source];
					source += _width;
					if (screen >= screen_line)
					{
						source -= _h;
						screen = (Pixel_Type*)(((uint8*)screen) + _inc1);
						screen_line = (Pixel_Type*)(((uint8*)screen_line) + _inc2);
					}
				} while (screen < screen_end);
			}
		}
	}
}
#endif //#ifdef USE_ROTATE

bool cImg::load(uint8* pixels, cPal* pal, int width, int height)
{
	if (!pixels || !pal)
		return FALSE;

	// clean first
	unload();

	_width = width;
	_height = height;

	int size = width * height;

#ifdef USE_4COLORS_DRAWING
	if (_4ColorDrawing)
	{
		size *= _nrOfBits_Occupied_by_color;
		if (size % 8)
		{
			size = (size / 8) + 1;
		}
		else
		{
			size /= 8;
		}
	}
#endif

	_palette = pal;

#ifdef USE_COMPRESSED_16_COLORS_IMAGES
	// test for 16 colors...
	if (pal->_max_colors > 16)
	{
#endif
		// prepare the pixels
		if (allocator_)
		{
			_pixels = allocator_;
			allocator_ += size;
		}
		else
		{
			_pixels = new uint8[size];
		}
		
		if (_pixels == NULL)
			return FALSE;

		MEMCPY(_pixels, pixels, size);

#ifdef USE_COMPRESSED_16_COLORS_IMAGES
	// test for 16 colors...
	}
	else //if(pal->_max_colors <= 16)
	{
		img_line = (_width + 1) >> 1;
		uint32 *temp = new uint32[((img_line * _height) + 3) >> 2];
		uint8 *ptemp = (uint8*)temp;
		uint8 *pdata = (uint8*)pixels;

		int mark = 0, source = 0;
		uint8 val;
		for (int i = 0; i < _height; i++)
		{
			for (int j = (_width >> 1); j > 0; j--)
			{
				val  = ((pdata[source++] & 0x0F) << 4);
				val |= (pdata[source++] & 0x0F);
				ptemp[mark++] = val;
			}
			
			if (_width & 1)
				ptemp[mark++] = ((pdata[source++] & 0x0F) << 4);
		}

		// remove the old one
//		SAFE_DEL_ARRAY(_data);

		// set the new one
		_pixels = (uint8 *) temp;

		m_bNoCompresData = FALSE;

//		DBGPRINTF("4 size = %d", img_line * img_height);
	}
#endif

	/*for(int i = 0; i < size; i++)
	{
		_pixels[i] = pixels[i];
	}*/

	return TRUE;
}

void cImg::usePixels(uint8* pixels, cPal* pal, int width, int height)
{
	#ifdef PARANOID
		if (!pixels || !pal)
			return;
	#endif

 	_width = width;
	_height = height;

	_palette = pal;

	_pixels = pixels;
	_freePixels = FALSE;
}
