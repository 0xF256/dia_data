// ASprite.cpp
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Author(s):	Ionut Matasaru
//
////////////////////////////////////////////////////////////////////////////////////////////////////

#include "ASprite.h"
#include "AEE.h"
#include "AEEStdLib.h"
#include "cGraphics.h"
#include "cImg.h"
#include "cGame.h"

////////////////////////////////////////////////////////////////////////////////////////////////////

ASprite::ASprite()
{
	_nModules			= 0;
	_modules			= NULL;

	_nFrames			= 0;
	_frames_nfm			= NULL;
	_frames_fm_start	= NULL;
	_frames_rc			= NULL;
	_nFModules			= 0;
	_fmodules			= NULL;

	_nAnims				= 0;
	_anims_naf			= NULL;
	_anims_af_start		= NULL;
	_nAFrames			= 0;
	_aframes			= NULL;

	_map				= NULL;
	_nMappings			= 0;
	_cur_map			= -1;

	_palettes			= 0;
	_cur_pal			= 0;
	_pal				= new cPal;

	_modules_data		= NULL;
	_modules_image		= NULL;

	_line_spacing		= 0;

	_index1				= -1;
	_index2				= -1;

	_text_w				= 0;
	_text_h				= 0;

	_use_cache = TRUE;

	allocator_ = NULL;

	multiStep = 0;

    this->m_pGame = (cGame *)GETAPPINSTANCE();
}

////////////////////////////////////////////////////////////////////////////////////////////////////

ASprite::~ASprite()
{
	SAFE_DEL(_pal);

	if (!allocator_)
	{
		SAFE_DEL(_modules); 
		SAFE_DEL(_fmodules); 

		SAFE_DEL_ARRAY(_frames_rc);
		SAFE_DEL(_frames_nfm); 
		SAFE_DEL(_frames_fm_start); 
		SAFE_DEL(_fmodules); 

		SAFE_DEL(_aframes); 
		SAFE_DEL(_anims_naf); 
		SAFE_DEL(_anims_af_start); 

		SAFE_DEL_ARRAY(_modules_data);
		SAFE_DEL_ARRAY(_modules_offsets);
		SAFE_DEL_ARRAY(_modules_image);
	}

	if (_map) {
		for (int i=0; i<MAX_SPRITE_MAPPINGS; i++) {
			SAFE_DEL_ARRAY(_map[i]);
		}
		if (!allocator_)
			SAFE_DEL_ARRAY(_map);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////


bool ASprite::Load(cLib& lib, int /* offset */)
{
	if (!multiStep) {
		Load0(lib);
		if (_nModules > 48) {
			multiStep++;
			l_counter = 0;
			return TRUE;
		}
	}

	switch (multiStep) {
	case 1: Load1(lib); multiStep++; return TRUE;
	case 2: Load2(lib); multiStep++; return TRUE;
	case 3: Load22(lib); multiStep++; return TRUE;
	case 4: Load23(lib); multiStep++; return TRUE;
	case 5: Load24(lib); multiStep++; return TRUE;
	case 6: Load3(lib); multiStep++; return TRUE;
	case 7: Load32(lib); multiStep++; return TRUE;
	case 8: Load33(lib); multiStep++; return TRUE;
	case 9: Load34(lib); multiStep++; return TRUE;
	case 10: Load4(lib); multiStep++; return TRUE;
	case 11: Load5(lib); multiStep++; return TRUE;
	case 12: Load6(lib); multiStep++; return TRUE;
	case 12 + 1: Load7(lib); multiStep++; 
		return FALSE;
	default:
		Load1(lib);
		Load2(lib);
		Load22(lib);
		Load23(lib);
		Load24(lib);
		Load3(lib);
		Load32(lib);
		Load33(lib);
		Load34(lib);
		Load4(lib);
		Load5(lib);
		Load6(lib);
		Load7(lib);
		break;
	}

	return FALSE;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load0(cLib& lib)
{
	int n;
	//		_DBGPRINTF("Sprite.Load(%d bytes, %d)", sizeof(), offset);
	short bs_version = lib.ReadShort();
	//short bs_version = READ_SHORT(file, offset);
	#if (DEF_bDbgS) 
		//System.out.println("bs_version = 0x" + Integer.toHexString(bs_version));
	#endif

	#if (DEF_bErr)
	{
		if (bs_version != BSPRITE_v003)
			//System.out.println("ERROR: Invalid BSprite version !");
	}
	#endif

	//short bs_flags = READ_SHORT(file, offset);
	uint32 bs_flags = (uint32)lib.ReadInt32();

	#if (DEF_bDbgS) 
		//System.out.println("bs_flags = 0x" + Integer.toHexString(bs_flags));
	#endif

	#if (DEF_bErr)
	{
		if ((bs_flags != BS_DEFAULT_MIDP2) && (bs_flags != (BS_DEFAULT_MIDP2|BS_KEEP_PAL)))
			//System.out.println("ERROR: Invalid BSprite flags !");
	}
	#endif
	// Modules...
	//_nModules = READ_SHORT(file, offset);
	_nModules = lib.ReadShort();
	n = _nModules<<1;
	if (_nModules > 0)
	{
		if (!allocator_) 
		{
			SAFE_DEL(_modules);
			_modules = new uint8[n];
		} 
		else 
		{
			_modules = (uint8 *)allocator_;
			allocator_ += ((n + 3) & ~0x3);
		}

		lib.ReadDataUint8(_modules, n);
		//MEMCPY(_modules, &file[offset], n);
		//offset += n;
	}

	(void) bs_version;
	(void) bs_flags;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load1(cLib& lib)
{
	int n;
	
	// FModules...
	_nFModules = lib.ReadShort();
	//_nFModules = READ_SHORT(file, offset);

	n = _nFModules<<2;
	if (_nFModules > 0)
	{
		if (!allocator_) {
			SAFE_DEL_ARRAY(_fmodules);
			_fmodules = new signed char[n];
		} else {
			_fmodules = (signed char *)allocator_;
			allocator_ += ((n + 3) & ~0x3);
		}
		lib.ReadData(_fmodules, n);
		//MEMCPY(_fmodules, &file[offset], n);
		//offset += n;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load2(cLib& lib)
{
	// Frames...
	_nFrames = lib.ReadShort();
	//_nFrames = READ_SHORT(file, offset);
	int i;
	if (_nFrames > 0)
	{
		if (!allocator_) 
		{
			SAFE_DEL_ARRAY(_frames_nfm);
			SAFE_DEL_ARRAY(_frames_fm_start);
			_frames_nfm      = new byte[_nFrames];
			_frames_fm_start = new short[_nFrames];
		} 
		else 
		{
			_frames_nfm = (byte *)allocator_;
			allocator_ += ((_nFrames + 3) & ~0x3);
			_frames_fm_start = (short *)allocator_;
			allocator_ += (((_nFrames << 1) + 1) & ~0x1);
		}
		/*for (i = 0; i < _nFrames / 4; i++)
		{
			_frames_nfm[i]      = lib.ReadByte();
			lib.ReadByte();//BUG:)
			_frames_fm_start[i] = lib.ReadShort();
		}*/

		unsigned char a[4];
		for (i = 0; i < _nFrames / 4; i++)
		{
			lib.ReadDataUint8(a, 4);
			_frames_nfm[i]      = a[0];
			_frames_fm_start[i] = ((a[3]<<8) + a[2]);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load22(cLib& lib)
{
	if (_nFrames > 0)
	{
		/*for (int i = _nFrames / 4; i < _nFrames / 2; i++)
		{
			_frames_nfm[i]      = lib.ReadByte();
			lib.ReadByte();
			_frames_fm_start[i] = lib.ReadShort();
		}*/
		unsigned char a[4];
		for (int i = _nFrames / 4; i < _nFrames / 2; i++)
		{
			lib.ReadDataUint8(a, 4);
			_frames_nfm[i]      = a[0];
			_frames_fm_start[i] = ((a[3]<<8) + a[2]);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load23(cLib& lib)
{
	if (_nFrames > 0)
	{
		/*for (int i = _nFrames / 2; i < 3 * _nFrames / 4; i++)
		{
			_frames_nfm[i]      = lib.ReadByte();
			lib.ReadByte();
			_frames_fm_start[i] = lib.ReadShort();
		}*/
		unsigned char a[4];
		for (int i = _nFrames / 2; i < 3 * _nFrames / 4; i++)
		{
			lib.ReadDataUint8(a, 4);
			_frames_nfm[i]      = a[0];
			_frames_fm_start[i] = ((a[3]<<8) + a[2]);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load24(cLib& lib)
{
	if (_nFrames > 0)
	{
		/*for (int i = 3 * _nFrames / 4; i < _nFrames; i++)
		{
			_frames_nfm[i]      = lib.ReadByte();
			lib.ReadByte();
			_frames_fm_start[i] = lib.ReadShort();
		}*/
		unsigned char a[4];
		for (int i = 3 * _nFrames / 4; i < _nFrames; i++)
		{
			lib.ReadDataUint8(a, 4);
			_frames_nfm[i]      = a[0];
			_frames_fm_start[i] = ((a[3]<<8) + a[2]);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load3(cLib& lib)
{		
	if (_nFrames > 0)
	{
		// Bound rect for each frame...
		int nFrames4 = _nFrames<<2;
		if (!allocator_) 
		{
			SAFE_DEL_ARRAY(_frames_rc);
			_frames_rc = new signed char[nFrames4];
		} 
		else 
		{
			_frames_rc = (signed char *)allocator_;
			allocator_ += ((nFrames4 + 3) & ~0x3);
		}
		//for (int i = 0; i < nFrames4 / 4; i++)
		//	_frames_rc[i] = lib.ReadByte();
		//lib.ReadData(&_frames_rc[0], nFrames4 / 4);
		lib.ReadData(&_frames_rc[0], nFrames4 / 4);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load32(cLib& lib)
{		
	if (_nFrames > 0)
	{
		int nFrames4 = _nFrames<<2;
		//for (int i = nFrames4 / 4; i < nFrames4 / 2; i++)
		//	_frames_rc[i] = lib.ReadByte();
		//lib.ReadData(&_frames_rc[nFrames4 / 4], nFrames4 / 4);
		lib.ReadData(&_frames_rc[nFrames4 / 4], nFrames4 / 4);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load33(cLib& lib)
{		
	if (_nFrames > 0)
	{
		int nFrames4 = _nFrames<<2;
		//for (int i = nFrames4 / 2; i < 3 * nFrames4 / 4; i++)
		//	_frames_rc[i] = lib.ReadByte();
		//lib.ReadData(&_frames_rc[nFrames4 / 2], nFrames4 / 4);
		lib.ReadData(&_frames_rc[nFrames4 / 2], nFrames4 / 4);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load34(cLib& lib)
{		
	if (_nFrames > 0)
	{
		int nFrames4 = _nFrames<<2;
		//for (int i = 3 * nFrames4 / 4; i < nFrames4; i++)
		//	_frames_rc[i] = lib.ReadByte();
		//lib.ReadData(&_frames_rc[3 * nFrames4 / 4], nFrames4 / 4);
		lib.ReadData(&_frames_rc[3 * nFrames4 / 4], nFrames4 / 4);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load4(cLib& lib)
{
	int n;
	
	// AFrames...
	_nAFrames = lib.ReadShort();
	//_nAFrames = READ_SHORT(file, offset);
	if (_nAFrames > 0)
	{
		n = _nAFrames*5;
		if (!allocator_) {
			_aframes = new signed char[n];
		} else {
			_aframes = (signed char *)allocator_;
			allocator_ += ((n + 3) & ~0x3);
		}
		lib.ReadData(_aframes, n);
		//MEMCPY(_aframes, &file[offset], n);
		//offset += n;
	}
	
	// Anims...
	_nAnims = lib.ReadShort();
	//_nAnims = READ_SHORT(file, offset);
	if (_nAnims > 0)
	{
		_anims_naf_length = _nAnims;
		if (!allocator_) {
			_anims_naf      = new byte[_nAnims];
			_anims_af_start = new short[_nAnims];
		} else {
			_anims_naf = (byte *)allocator_;
			allocator_ += ((_nAnims + 3) & ~0x3);
			_anims_af_start = (short *)allocator_;
			allocator_ += (((_nAnims << 1) + 1) & ~0x1);
		}
		for (int i = 0; i < _nAnims; i++)
		{
			_anims_naf[i]      = lib.ReadByte();

			if(_anims_naf[i] != 0)
			{
				_anims_af_start[i] = lib.ReadShort();
			}
		}
	}
	
	if (_nModules <= 0)
	{
		return;
	}

	// Pixel format (must be one of SPRITE_FORMAT_8888, _4444)...
	//short _pixel_format = READ_SHORT(file, offset);
	short _pixel_format = lib.ReadShort();
	
	// Number of palettes...
	//_palettes = (unsigned char)file[offset++];
	_palettes = lib.ReadByte();
	
	// Number of colors...
	//int colors = (unsigned char)file[offset++];
	int colors = lib.ReadByte();
	
	// Palettes...
	//_pal->init(MAX_SPRITE_PALETTES,colors);
	_pal->init(_palettes, colors);//optimization?????
	uint32* pal = (uint32 *)m_pGame->_temp;//new uint32[colors];
	for (int p = 0; p < _palettes; p++)
	{
		switch (_pixel_format)
		{
		case PIXEL_FORMAT_8888:
			{
				for (int c = 0; c < colors; c++)
				{
					uint32 _8888  = ((lib.ReadByte()&0xFF));
					_8888 += ((lib.ReadByte()&0xFF)<< 8);
					_8888 += ((lib.ReadByte()&0xFF)<<16);
					_8888 += ((lib.ReadByte()&0xFF)<<24);
					
					pal[c] = _8888;
					//Stef - we need the pure 0 for evil stuff (faster transp. test)
					#if PIXEL_FORMAT == 0x565
						//if(pal[c] == 0xFF000000)
						if(IBITMAP_RGBToNative(m_pGame->_ddb_buffer,COLOR_ARGB_TO_BGRA(pal[c])) == 0)
							pal[c] = 0xFF0F080F;
					#else
						//if(pal[c] == 0xFF000000)
						if(BGRA2NATIVE(COLOR_ARGB_TO_BGRA(pal[c])) == 0)
							pal[c] = 0xFF1F1F1F;
					#endif
				}
			}
			break;
		case PIXEL_FORMAT_4444:
			{
				for (int c = 0; c < colors; c++)
				{
					// 4444 -> 8888
					uint32 _4444 = (lib.ReadByte()&0xFF) + ((lib.ReadByte()&0xFF)<<8);
					pal[c] = ((_4444 & 0xF000) << 16) | ((_4444 & 0xF000) << 12) |
						((_4444 & 0x0F00) << 12) | ((_4444 & 0x0F00) <<  8) |
						((_4444 & 0x00F0) <<  8) | ((_4444 & 0x00F0) <<  4) |
						((_4444 & 0x000F) <<  4) | ((_4444 & 0x000F)      );
					//Stef - we need the pure 0 for evil stuff (faster transp. test)
					#if PIXEL_FORMAT == 0x565
						//if(pal[c] == 0xFF000000)
						if(IBITMAP_RGBToNative(m_pGame->_ddb_buffer,COLOR_ARGB_TO_BGRA(pal[c])) == 0)
							pal[c] = 0xFF0F080F;
					#else
						//if(pal[c] == 0xFF000000)
						if(BGRA2NATIVE(COLOR_ARGB_TO_BGRA(pal[c])) == 0)
							pal[c] = 0xFF1F1F1F;
					#endif
				}
			}
			break;
		}
		_pal->updatePalette(p, pal);
	}
	//delete pal;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load5(cLib& lib)
{
	// Data format (must be one of ENCODE_FORMAT_I2, _I4, _I16, _I256, _I127RLE)...
	//_data_format = READ_SHORT(file, offset);
	_data_format = lib.ReadShort();
	
	// Graphics data...
	if (_nModules > 0)
	{
		_modules_data_size = 0;
		int m;
		short s;
		if (!allocator_) 
		{
			SAFE_DEL_ARRAY(_modules_offsets);
			_modules_offsets = new uint16[_nModules];
		} else {
			_modules_offsets = (uint16 *)allocator_;
			allocator_ += (((_nModules << 1) + 1) & ~0x1);
		}
		lib.mark();
		for (m = 0; m < _nModules; m++) {
			_modules_offsets[m] = _modules_data_size;
			s = (uint16)lib.ReadShort();
			_modules_data_size += s;
			lib.skip(s);
		}
		lib.restore();


		if (!allocator_) {
			SAFE_DEL_ARRAY(_modules_data);
			_modules_data = new signed char[_modules_data_size];
		} else {
			_modules_data = (signed char *)allocator_;
			allocator_ += ((_modules_data_size + 3) & ~0x3);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load6(cLib& lib)
{
	// Graphics data...
	if (_nModules > 0)
	{
		signed char *dst = _modules_data;
		for (int m = 0; m < _nModules / 2; m++)
		{
			ASSERT(dst - _modules_data == _modules_offsets[m], "_modules_offsets error");
			// Image data for the module...
			uint16 size = (uint16)lib.ReadShort();
			lib.ReadData(dst, size);
			dst += size;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::Load7(cLib& lib)
{
	if (_nModules > 0)
	{
		signed char *dst = _modules_data + _modules_offsets[_nModules / 2];
		for (int m = _nModules / 2; m < _nModules; m++)
		{
			ASSERT(dst - _modules_data == _modules_offsets[m], "_modules_offsets error");
			// Image data for the module...
			uint16 size = (uint16)lib.ReadShort();
			lib.ReadData(dst, size);
			dst += size;
		}
	}

	// module mappings

//	_nMappings = 0;
	_map = NULL;
	_cur_map = -1;
}
	
////////////////////////////////////////////////////////////////////////////////////////////////////
// pal = palette to be initailized
// m1 = first module
// m2 = last module (-1 -> to end)
// pal_copy = mapping to another palette (-1 -> build)

void ASprite::BuildCacheImages(int /* pal */, int m1, int m2, int /* pal_copy */)
{
	if (!_modules)
		return;

	if (m2 == -1)
		m2 = _nModules - 1;
	
	if (_modules_image == NULL)
		_modules_image = new cImg[_nModules];

	{
		////int old_pal = _cur_pal;
		for (int i = m1; i <= m2; i++)
		{
			int m = i << 1;
			int sizeX = _modules[m  ]&0xFF;
			int sizeY = _modules[m+1]&0xFF;
			if (sizeX <= 0 || sizeY <= 0) continue;
			
			signed char* image_data = DecodeImage(i, 0);
			if (image_data == NULL) continue;

			#ifdef USE_4COLORS_DRAWING
				_modules_image[i].set4ColorDrawing(_4ColorDrawing);
			#endif

			#if ((defined(DRAW_2bits_Colors)) || defined (USE_4COLORS_DRAWING))
				_modules_image[i]._nrOfBits_Occupied_by_color = _nrOfBits_Occupied_by_color;
			#endif

			_modules_image[i].load((uint8*)image_data, _pal, sizeX, sizeY);
//			if (_pat)
			//if (_pal->_posTranspColor == 0)
				_modules_image[i].setTransparency(_pal->_posTranspColor);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

cImg* ASprite::BuildModuleImage(cPal* palette, int m, void* Allocator)
{
	cImg* img = new cImg();
	img->setAllocator(Allocator);

	int m1 = m << 1;
	int sizeX = _modules[m1  ]&0xFF;
	int sizeY = _modules[m1+1]&0xFF;
	
	if (sizeX <= 0 || sizeY <= 0) 
	{ 
		SAFE_DEL(img); 
		return NULL; 
	}
	
	signed char* image_data = DecodeImage(m, 0);
	
	if (image_data == NULL)
	{ 
		SAFE_DEL(img); 
		return NULL; 
	}
	
	//RD not doing this anymore cuz it's waste of freakin' good heap.
	//cPal* pPal = new cPal(*_pal);
	//img->load((uint8*)image_data, pPal, sizeX, sizeY);
	#ifdef USE_4COLORS_DRAWING
	img ->_4ColorDrawing = _4ColorDrawing;
	#endif

	#if ((defined(DRAW_2bits_Colors)) || defined (USE_4COLORS_DRAWING))
	img ->_nrOfBits_Occupied_by_color = _nrOfBits_Occupied_by_color;
	#endif
	img->load((uint8*)image_data, palette, sizeX, sizeY);


	return img;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::SetModuleMapping(int map, byte* mmp, int len)
{

	if (!_map) {
		if (!allocator_) {
			_map = new short*[MAX_SPRITE_MAPPINGS];
		} else {
			_map = (short**)allocator_;
			allocator_ += (((MAX_SPRITE_MAPPINGS * sizeof(int *)) + 3) & ~0x3);
		}
		for (int i=0; i<MAX_SPRITE_MAPPINGS; _map[i++]=NULL);
	}

	if (!_map[map])
	{
		int modules = _nModules;
		_map[map] = new short[modules];
		for (int i = 0; i < modules; i++)
			_map[map][i] = i;
	}
	if (!mmp)
		return;
	int off = 0;
	while (off < len)
	{
		int i1 = ((mmp[off] & 0xFF) + ((mmp[off+1] & 0xFF) << 8));
		off += 2;
		int i2 = ((mmp[off] & 0xFF) + ((mmp[off+1] & 0xFF) << 8));
		off += 2;
		_map[map][i1] = i2;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::ApplyModuleMapping(int dst_pal, int src_pal, byte* mmp, int len)
{
	//// TODO: is this still used?  It was buggy.
	int off = 0;
	while (off < len)
	{
		int i1 = ((mmp[off] & 0xFF) + ((mmp[off+1] & 0xFF) << 8));
		off += 2;
		int i2 = ((mmp[off] & 0xFF) + ((mmp[off+1] & 0xFF) << 8));
		off += 2;
		//_modules_image[dst_pal][i1] = _modules_image[src_pal][i2];
		//_modules_image[0].getPalette().setPaletteColor(dst_pal, i1,
		//_modules_image[0].getPalette().getPaletteColor(src_pal, i2));
		_pal->setPaletteColor(dst_pal, i1, _pal->getPaletteColor(src_pal, i2));	// Viorel: TODO???
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

int ASprite::GetAFrameTime(int anim, int aframe)
{
	return _aframes[(_anims_af_start[anim] + aframe) * 5 + 1] & 0xFF;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

int ASprite::GetAFrames(int anim)
{
	return _anims_naf[anim]&0xFF;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

int ASprite::GetFModules(int frame)
{
	return _frames_nfm[frame]&0xFF;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::GetAFrameRect(int rc[4], int anim, int aframe, int posX, int posY, uint32 flags, int hx, int hy)
{
	int off = (_anims_af_start[anim] + aframe) * 5;
	int frame = _aframes[off]&0xFF;
	if (USE_INDEX_EX_AFRAMES)
		frame |= ((_aframes[off+4]&FLAG_INDEX_EX_MASK)<<INDEX_EX_SHIFT);
	if ((flags & FLAG_OFFSET_AF) != 0)
	{
		if ((flags & FLAG_FLIP_X) != 0)	hx += _aframes[off+2];
		else							hx -= _aframes[off+2];
		if ((flags & FLAG_FLIP_Y) != 0)	hy += _aframes[off+3];
		else							hy -= _aframes[off+3];
	}
	GetFrameRect(rc, frame, posX, posY, flags ^ (_aframes[off+4]&0x0F), hx, hy);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::GetFrameRect(int rc[4], int frame, int posX, int posY, uint32 flags, int hx, int hy)
{
	int frame4 = frame<<2;
	int fx = _frames_rc[frame4];
	int fy = _frames_rc[frame4+1];
	int fw = _frames_rc[frame4+2]&0xFF;
	int fh = _frames_rc[frame4+3]&0xFF;
	if ((flags & FLAG_FLIP_X) != 0)	hx += fx + fw;
	else							hx -= fx;
	if ((flags & FLAG_FLIP_Y) != 0)	hy += fy + fh;
	else							hy -= fy;
	rc[0] = posX - (hx<<8);
	rc[1] = posY - (hy<<8);
	rc[2] = rc[0] + (fw<<8);
	rc[3] = rc[1] + (fh<<8);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::GetModuleRect(int rc[4], int module, int posX, int posY, uint32 /* flags */)
{
//	System_out_println("GetModuleRect(rc, "+module+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+")");
	int m = (module<<1);
	rc[0] = posX;
	rc[1] = posY;
	rc[2] = posX + ((_modules[m  ]&0xFF)<<8);
	rc[3] = posY + ((_modules[m+1]&0xFF)<<8);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::PaintAFrame(cGraphics* g, int anim, int aframe, int posX, int posY, uint32 flags, int hx, int hy)
{
//	System_out_println("PaintAFrame(g, "+anim+", "+aframe+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
	int off = (_anims_af_start[anim] + aframe) * 5;
//	int off = (_anims[(anim<<1)+1] + aframe) * 5;
	int frame = _aframes[off]&0xFF;
	if (USE_INDEX_EX_AFRAMES)
		frame |= ((_aframes[off+4]&FLAG_INDEX_EX_MASK)<<INDEX_EX_SHIFT);
	if ((flags & FLAG_OFFSET_AF) != 0)
	{
		if ((flags & FLAG_FLIP_X) != 0)	hx += _aframes[off+2];
		else							hx -= _aframes[off+2];
		if ((flags & FLAG_FLIP_Y) != 0)	hy += _aframes[off+3];
		else							hy -= _aframes[off+3];
	}
//	if ((flags & FLAG_FLIP_X) != 0)	hx += _frames_w[frame]&0xFF;
//	if ((flags & FLAG_FLIP_Y) != 0)	hy += _frames_h[frame]&0xFF;
	PaintFrame(g, frame, posX-hx, posY-hy, flags ^ (_aframes[off+4]&0x0F), hx, hy);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::PaintFrame(cGraphics* g, int frame, int posX, int posY, uint32 flags, int hx, int hy)
{
//	System_out_println("PaintFrame(g, "+frame+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
	int nFModules = _frames_nfm[frame]&0xFF;
//	int nFModules = _frames_nfm[frame];
//	int nFModules = _frames[frame<<1];
	for (int fmodule = 0; fmodule < nFModules; fmodule++)
		PaintFModule(g, frame, fmodule, posX, posY, flags, hx, hy);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::PaintFModule(cGraphics* g, int frame, int fmodule, int posX, int posY, uint32 flags, int hx, int hy)
{
//	System_out_println("PaintFModule(g, "+frame+", "+fmodule+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
	int off = (_frames_fm_start[frame] + fmodule) << 2;
//	int off = (_frames[(frame<<1)+1] + fmodule) << 2;
	int fm_flags = _fmodules[off+3]&0xFF;
	int index = _fmodules[off]&0xFF;
	if (USE_INDEX_EX_FMODULES)
		index |= ((fm_flags&FLAG_INDEX_EX_MASK)<<INDEX_EX_SHIFT);
//	flags |= FLAG_OFFSET_FM; // always use offset FM
//	if ((flags & FLAG_OFFSET_FM) != 0)
	{
		if ((flags & FLAG_FLIP_X) != 0)	posX -= _fmodules[off+1];
		else							posX += _fmodules[off+1];
		if ((flags & FLAG_FLIP_Y) != 0)	posY -= _fmodules[off+2];
		else							posY += _fmodules[off+2];
	}
	if ((fm_flags & FLAG_HYPER_FM) != 0)
	{
	//	if ((flags & FLAG_FLIP_X) != 0)	posX -= _frames[(index<<?)  ]&0xFF; // pF->w
	//	if ((flags & FLAG_FLIP_Y) != 0)	posY -= _frames[(index<<?)+1]&0xFF; // pF->h

		PaintFrame(g, index, posX, posY, flags ^ (fm_flags&0x0F), hx, hy);
	}
	else
	{
		if ((flags & FLAG_FLIP_X) != 0)	posX -= _modules[(index<<1)  ]&0xFF;
		if ((flags & FLAG_FLIP_Y) != 0)	posY -= _modules[(index<<1)+1]&0xFF;

		PaintModule(g, index, posX, posY, flags ^ (fm_flags&0x0F));
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
void ASprite::PaintModule(cGraphics* g, int module, int posX, int posY, uint32 flags)
{
#ifdef DRAW_FONTS_ONLY
	if (this != m_pGame->_sprFontS)
		return ;
#endif

	// Apply current module mapping...
	if (_cur_map >= 0)
	{
	//	ASSERT(_cur_map < _mappings);
	//	ASSERT(_map[_cur_map] != null);
		module = _map[_cur_map][module];
	}

	int m = (module<<1);
	int sizeX = _modules[m  ]&0xFF;
	int sizeY = _modules[m+1]&0xFF;

	if (sizeX <= 0 || sizeY <= 0) 
		return;

    //cGame* m_pGame = (cGame *)GETAPPINSTANCE();		//RD already done in constructor
	
	register int cx = g->clip_xs;
	register int cy = g->clip_ys;
	register int cw = g->clip_w;
	register int ch = g->clip_h;

	// Fast visibility test...
	if ((posX + sizeX < cx ||
		posY + sizeY < cy ||
		posX >= cx + cw ||
		posY >= cy + ch))
	{
	//	System_out_println("outside clip rect");
		return;
	}

	cImg *img = NULL;

/*
#ifdef TEST_NEW_DRAW
	if(_modules_image == 0 || !_modules_image[module].isLoaded())
	{
		img = m_pGame->_tempImg;
		signed char* image_data = DecodeImage1(module, 0);

		#ifdef PARANOID
			if (image_data == NULL) 
			{
				return;
			}
		#endif

		img->usePixels((uint8*)image_data, _pal, sizeX, sizeY);			
//			if (img->_palette->_posTranspColor != 0xFF)
//				img->setTransparency(TRUE);
//			else 
		img->setTransparency(_pal->_posTranspColor);
	}
	else
	{
		img = &_modules_image[module];
	}
#else
	*/
//ciordache: TEST_ONLY
#ifdef USE_4COLORS_DRAWING
	if (this == m_pGame->_sprFontM)
		sizeX = sizeX;
#endif


	if (img == NULL) 
	{
		if(_modules_image == 0 || !_modules_image[module].isLoaded())
		{
			img = m_pGame->_tempImg;
			signed char* image_data = DecodeImage(module, 0);

			#ifdef PARANOID
				if (image_data == NULL) 
				{
					return;
				}
			#endif

	#ifdef USE_4COLORS_DRAWING
	img ->_4ColorDrawing = _4ColorDrawing;
	#endif

	#if ((defined(DRAW_2bits_Colors)) || defined (USE_4COLORS_DRAWING))
	img ->_nrOfBits_Occupied_by_color = _nrOfBits_Occupied_by_color;
	#endif
			img->usePixels((uint8*)image_data, _pal, sizeX, sizeY);			
//			if (img->_palette->_posTranspColor != 0xFF)
//				img->setTransparency(TRUE);
//			else 
			img->setTransparency(_pal->_posTranspColor);
		}
		else
		{
			img = &_modules_image[module];
		}
	}
//#endif

#ifdef USE_4COLORS_DRAWING
	if (this == m_pGame->_sprFontM)
	{
		img->setTransparency(m_pGame->m_bFontIsTransparent);

		switch(m_pGame->m_iChooseFontDrawingType) {
		case 0:
			flags = 0;
			break;

		case 1:
			flags = FLAG_FLIP_X;
			break;

		case 2:
			flags = FLAG_FLIP_Y;
			break;

		case 3:
			flags = FLAG_FLIP_X | FLAG_FLIP_Y;
			break;

		default:
			flags = 0;
		}
	}
#endif

	#ifdef PARANOID
		if (!img) 
		{
			return;
		}
	#endif


	/// Logo lighting effect --- NOT USED FOR NOW
	//if(_blend_effect > 0)
	//{
	//	ApplyBlendEffect(img, posX, posY, sizeX, sizeY);
	//	return;
	//}
	//

	sizeX = img->getWidth();
	sizeY = img->getHeight();
	
	int x = 0;
	int y = 0;

	if (posY < cy)			
	{ 
		y = cy - posY; 
		sizeY -= y; 
		posY = cy; 
	}

	if (posY + sizeY > cy + ch)	
	{ 
		sizeY = cy + ch - posY; 
	}

	// Draw...
	if ((flags & FLAG_FLIP_X) != 0)
	{


		if ((flags & FLAG_FLIP_Y) != 0)
		{
			img->draw(g, x, y, sizeX, sizeY, posX, posY, FX_FLIP_HV);
		}
		else
		{
			img->draw(g, x, y, sizeX, sizeY, posX, posY, FX_FLIP_H);
		}
	}
	else if ((flags & FLAG_FLIP_Y) != 0)
	{
		img->draw(g, x, y, sizeX, sizeY, posX, posY, FX_FLIP_V);
	}
	else
	{
		img->draw(g, x, y, sizeX, sizeY, posX, posY, 0);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef BUILD_CACHE_IMAGES
cImg * ASprite::BuildCacheImage(int module)
{
	int m = (module<<1);
	int sizeX = _modules[m  ]&0xFF;
	int sizeY = _modules[m+1]&0xFF;

	if (sizeX <= 0 || sizeY <= 0) 
		return NULL;

    //cGame* m_pGame = (cGame *)GETAPPINSTANCE();		//RD already done in constructor
	
	cImg *img = NULL;

	if(_modules_image == 0 || !_modules_image[module].isLoaded())
	{
		img = m_pGame->_tempImg;
		signed char* image_data = DecodeImage(module, 0);

		#ifdef PARANOID
			if (image_data == NULL) 
			{
				return;
			}
		#endif
	#ifdef USE_4COLORS_DRAWING
	img ->_4ColorDrawing = _4ColorDrawing;
	#endif

	#if ((defined(DRAW_2bits_Colors)) || defined (USE_4COLORS_DRAWING))
	img ->_nrOfBits_Occupied_by_color = _nrOfBits_Occupied_by_color;
	#endif

		img->usePixels((uint8*)image_data, _pal, sizeX, sizeY);			
//			if (img->_palette->_posTranspColor != 0xFF)
//				img->setTransparency(TRUE);
//			else 
		img->setTransparency(_pal->_posTranspColor);

		
	}
	else
	{
		img = &_modules_image[module];
	}

	return img;
}
#endif //BUILD_CACHE_IMAGES
////////////////////////////////////////////////////////////////////////////////////////////////////
/*
void ASprite::ApplyBlendEffect(cImg* img, int x, int y, int w, int h)
{

	int i,j, index = 0;
	int cx, dx;

	MEMSET(m_pGame->_temp, 0, SIZE_OF_TEMP_BUFFER);
	unsigned short* dest = (unsigned short*)m_pGame->_temp;

	unsigned short* palette = img->getPalette().getCurrentPalette();
	uint8* pixels = img->getPixelsAddress();
	unsigned short tranps = palette[img->getPalette().getPosTranspColor()];


	for (i =0; i<w*h; i++)
	{
		dest[i] = palette[pixels[i]];
	}

	for(i = 0; i < h; i++)
	{
		for(j = 0; j < w; j++)
		{
			if (dest[index] != tranps)
			{
				cx = x + j;
				dx = _blend_x - y - i;
				
				switch(_blend_effect)
				{
					case 1:
						if((dx-2  <= cx && cx < dx) ||
							(dx-7  <= cx && cx < dx-5) ||
							(dx-28 <= cx && cx < dx-14) ||
							(dx-43 <= cx && cx < dx-40) )
						{
							BlendTemp(index, COLOR_WHITE);
						}
						else if((dx-5  <= cx && cx < dx-2) ||
							(dx-40 <= cx && cx < dx-28) )
						{
							BlendTemp(index, COLOR_YELLOW);
						}
						break;
				}
			}
			else
			{
				int xasd=0;
			}
			index++;
		}
	}

	short screen_line = (m_pGame->_dib_buffer->nPitch)/2;
	unsigned short* screen = ((unsigned short*)m_pGame->_dib_buffer->pBmp) + (y*screen_line) + x;
	unsigned short pixel;
	for(i = 0; i < h; i++)
	{
		for(j = 0; j < w; j++)
		{
			pixel = dest[(i*w)+j];
			if (pixel != tranps)
				screen[(i*screen_line) + j]	= pixel;
		}
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::BlendTemp(int index, int blendColor)
{
	unsigned short* dest = (unsigned short*)m_pGame->_temp;
	int r1 = (dest[index] >> 16) & 0xFF;
	int g1 = (dest[index] >> 8 ) & 0xFF;
	int b1 = (dest[index]      ) & 0xFF;
	int r2 = (blendColor >> 16) & 0xFF;
	int g2 = (blendColor >> 8 ) & 0xFF;
	int b2 = (blendColor      ) & 0xFF;
	
	r1 = (r1 + r2) >> 1;
	b1 = (b1 + b2) >> 1;
	g1 = (g1 + g2) >> 1;
	
	dest[index] = (0xFF<<24) + (r1<<16) + (g1<<8) + b1;
}
*/

/*
#ifdef TEST_NEW_DRAW
signed char* ASprite::DecodeImage1(int module, uint32 )
{
	if (!_modules_data)
		return NULL;

	// Choose palette...
	//int[] pal = _pal[_cur_pal];
	//if (pal == null) return null;

	signed char *temp = m_pGame->_temp;

	//MEMSET(temp, 0, SIZE_OF_TEMP_BUFFER);
	int m = (module<<1);
	int sizeX = _modules[m  ] & 0xFF;
	int sizeY = _modules[m+1] & 0xFF;
//	if (sizeX <= 0 || sizeY <= 0) return null;

	if (_data_format == ENCODE_FORMAT_I256)
	{
		return _modules_data + _modules_offsets[module]; 
		//return (_modules_data + (_modules_offsets[module]&0xFFFF));
	}

	signed char* image = _modules_data + _modules_offsets[module];
	//	signed char* image = (_modules_data+ (_modules_offsets[module]&0xFFFF));
	int si = 0;
	int di = 0;
	int ds = sizeX * sizeY;

	// Build displayable...
	//Stef - most used, goes first (i know i'm insane...)
	if (_data_format == ENCODE_FORMAT_I127RLE)
	{
		// RLE compression, max 127 colors...
		while (di < ds)
		{
			int c = image[si++] & 0xFF;
			if (c > 127)
			{
				int c2 = image[si++] & 0xFF;
				c -= 128;
				while (c--)	
					temp[di++] = c2;
			}
			else
				temp[di++] = c;
		}
	}
	else if (_data_format == ENCODE_FORMAT_I16)
	{
		// 2 pixels/byte, max 16 colors...
		while (di < ds)
		{
			signed char c16 = image[si];
			temp[di++] = (c16 >> 4) & 0x0F;
			temp[di++] = (c16     ) & 0x0F;
			si++;
		}
	}
	else if (_data_format == ENCODE_FORMAT_I2)
	{
		// 8 pixels/byte, max 2 colors...
		while (di < ds)
		{
			signed char c2 = image[si];
			temp[di++] = (c2 >> 7) & 0x01;
			temp[di++] = (c2 >> 6) & 0x01;
			temp[di++] = (c2 >> 5) & 0x01;
			temp[di++] = (c2 >> 4) & 0x01;
			temp[di++] = (c2 >> 3) & 0x01;
			temp[di++] = (c2 >> 2) & 0x01;
			temp[di++] = (c2 >> 1) & 0x01;
			temp[di++] = (c2     ) & 0x01;
			si++;
		}
	}
	else if (_data_format == ENCODE_FORMAT_I4)
	{
		// 4 pixels/byte, max 4 colors...
		while (di < ds)
		{
			signed char c4 = image[si];
			temp[di++] = (c4 >> 6) & 0x03;
			temp[di++] = (c4 >> 4) & 0x03;
			temp[di++] = (c4 >> 2) & 0x03;
			temp[di++] = (c4     ) & 0x03;
			si++;
		}
	}

	return temp;
}


#endif //TEST_NEW_DRAW
*/

signed char* ASprite::DecodeImage(int module, uint32 /* flags */)
{
	if (!_modules_data)
		return NULL;

	// Choose palette...
	//int[] pal = _pal[_cur_pal];
	//if (pal == null) return null;

	signed char *temp = m_pGame->_temp;

	//MEMSET(temp, 0, SIZE_OF_TEMP_BUFFER);
	int m = (module<<1);
	int sizeX = _modules[m  ] & 0xFF;
	int sizeY = _modules[m+1] & 0xFF;
//	if (sizeX <= 0 || sizeY <= 0) return null;



	#ifdef USE_4COLORS_DRAWING
		_4ColorDrawing = FALSE;
	#endif
	#if ((defined(DRAW_2bits_Colors)) || defined (USE_4COLORS_DRAWING))
		_nrOfBits_Occupied_by_color = 0;
	#endif

	if (_data_format == ENCODE_FORMAT_I256)
	{
		return _modules_data + _modules_offsets[module]; 
		//return (_modules_data + (_modules_offsets[module]&0xFFFF));
	}

	signed char* image = _modules_data + _modules_offsets[module];
	//	signed char* image = (_modules_data+ (_modules_offsets[module]&0xFFFF));
	int si = 0;
	int di = 0;
	int ds = sizeX * sizeY;



	// Build displayable...
	//Stef - most used, goes first (i know i'm insane...)
	if (_data_format == ENCODE_FORMAT_I127RLE)
	{
		// RLE compression, max 127 colors...
		while (di < ds)
		{
			int c = image[si++] & 0xFF;
			if (c > 127)
			{
				int c2 = image[si++] & 0xFF;
				c -= 128;
				while (c--)	
					temp[di++] = c2;
			}
			else
				temp[di++] = c;
		}
	}
	else if (_data_format == ENCODE_FORMAT_I16)
	{
		#ifdef USE_4COLORS_DRAWING
			_4ColorDrawing = TRUE;
			_nrOfBits_Occupied_by_color = 4;
			return _modules_data + _modules_offsets[module]; 
		#else

		
		// 2 pixels/byte, max 16 colors...
		while (di < ds)
		{
			signed char c16 = image[si];
			temp[di++] = (c16 >> 4) & 0x0F;
			temp[di++] = (c16     ) & 0x0F;
			si++;
		}
		#endif
	}
	else if (_data_format == ENCODE_FORMAT_I2)
	{
		#ifdef USE_4COLORS_DRAWING
			_4ColorDrawing = TRUE;
			_nrOfBits_Occupied_by_color = 1;
			return _modules_data + _modules_offsets[module]; 
		#else
		// 8 pixels/byte, max 2 colors...
		while (di < ds)
		{
			signed char c2 = image[si];
			temp[di++] = (c2 >> 7) & 0x01;
			temp[di++] = (c2 >> 6) & 0x01;
			temp[di++] = (c2 >> 5) & 0x01;
			temp[di++] = (c2 >> 4) & 0x01;
			temp[di++] = (c2 >> 3) & 0x01;
			temp[di++] = (c2 >> 2) & 0x01;
			temp[di++] = (c2 >> 1) & 0x01;
			temp[di++] = (c2     ) & 0x01;
			si++;
		}
		#endif
	}
	else if (_data_format == ENCODE_FORMAT_I4)
	{
		#ifdef DRAW_2bits_Colors
			//_4ColorDrawing = TRUE;
			_nrOfBits_Occupied_by_color = 2;
			return _modules_data + _modules_offsets[module]; 
		#else
			// 4 pixels/byte, max 4 colors...
			while (di < ds)
			{
				signed char c4 = image[si];
				temp[di++] = (c4 >> 6) & 0x03;
				temp[di++] = (c4 >> 4) & 0x03;
				temp[di++] = (c4 >> 2) & 0x03;
				temp[di++] = (c4     ) & 0x03;
				si++;
			}
		#endif
	}

	return temp;
}

void ASprite::ClearAllModulesData()
{
	SAFE_DEL_ARRAY(_modules_data);
	SAFE_DEL_ARRAY(_modules_offsets);
}


////////////////////////////////////////////////////////////////////////////////////////////////////
// Draw String System...
////////////////////////////////////////////////////////////////////////////////////////////////////

	//	_modules[0] -> w  -> width of character ' ' (space)
	//	_modules[1] -> h  -> height of a text line
	//	_fmodules[0*4+1] -> ox -> space between two adiacent chars
	//	_fmodules[0*4+2] -> oy -> base line offset

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::SetSubString(int i1, int i2)
{
	_index1 = i1;
	_index2 = i2;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::UpdateStringSize(const char* s)
{
	_text_w = 0;
	_text_h = (uint8)_modules[1];
	int tw = 0;

	int index1 = ((_index1 >= 0) ? _index1 : 0);
	int index2 = ((_index2 >= 0) ? _index2 : STRLEN(s));

	s += index1;
/*
	for (int i = index1; i < index2; i++)
	{

		int c = (*s++ & 0xff);
		if (c == ' ')
		{
			tw += (_modules[0]&0xFF) + _fmodules[1];
				continue;
		}
		else if (c == '\n')
		{
			if (tw > _text_w) _text_w = tw;
			tw = 0;
			_text_h += _line_spacing + (_modules[1]&0xFF);
				continue;
		}
		else if (c < 32)
		{
				if (c == 0x01) // auto change current palette
				{
					i++; s++;
				//	_cur_pal = s.charAt(i);
					continue;
				}
				else if (c == 0x02) // select fmodule
				{
					i++;
					c = (*s++ & 0xff);
				}
				else continue;
		}
		else
				c = Char2Frame(c);

        if (c >= GetFModules(0))
        {
            c = 0;
        }

        int m = (_fmodules[c<<2]&0xFF)<<1;
        if (m >= (_nModules << 1))
        {
            m = 0;
        }
		tw += (_modules[m]&0xFF) - _fmodules[(c<<2)+1] + _fmodules[1];



	}
/*/
	for (int i = index1; i < index2; i++)
	{
		int c = *s++;

		if (c > 32)
		{
			c = m_pGame->_map_char[c]&0xFF;;
			tw += (_modules[c<<1]&0xFF) - _fmodules[(c<<2)+1] + _fmodules[1];
		}
		else 
			if (c == ' ')
			{
				tw += (_modules[0]&0xFF) + _fmodules[1];
				continue;
			}
		else 
			if (c == '\n')
			{
				if (tw > _text_w) _text_w = tw;
				tw = 0;
				_text_h += _line_spacing + (_modules[1]&0xFF);
				continue;
			}
		else //if (c < 32)
		{
				if (c == 0x01) 
				{
					i++;
					c=*s++;
					continue;
				}
				else if (c == 0x02)
				{
					i++;
					c = *s++;
				}
				else continue;
		}
	}
//*/


	if (tw > _text_w)
		_text_w = tw;

	if (_text_w > 0) 
		_text_w -= _fmodules[1];
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::DrawString(cGraphics* g, const char* s, int x, int y, int anchor)
{
	y -= _fmodules[2];

	if ((anchor & (Graphics_RIGHT | Graphics_HCENTER | Graphics_BOTTOM | Graphics_VCENTER)) != 0)
	{
		UpdateStringSize(s);
		if ((anchor & Graphics_RIGHT) != 0)
			x -= _text_w;
		else if ((anchor & Graphics_HCENTER) != 0) {
			x -= _text_w>>1;
#if DEF_SCR_W & 1
			x--;
#endif
		}
		if ((anchor & Graphics_BOTTOM) != 0)
			y -= _text_h;
		else if ((anchor & Graphics_VCENTER) != 0)
			y -= _text_h>>1;
	}

	int xx = x;
	int yy = y;

	int old_pal = _cur_pal;

	int index1 = ((_index1 >= 0) ? _index1 : 0);
	int index2 = ((_index2 >= 0) ? _index2 : STRLEN(s));

	s += index1;

/*
	bool paint = FALSE;
	for (int i = index1; i < index2; i++)
	{
		paint = FALSE;
		int c = *s++;
		if (c == ' ')
		{
			xx += (_modules[0]&0xFF) + _fmodules[1];
				continue;
		}
		else if (c == '\n')
		{
			xx = x;
			yy += _line_spacing + (_modules[1]&0xFF);
				continue;
		}
		else if (c < 32)
		{
			if (c == 0x01) // auto change current palette
			{
				i++;
				c = *s++;
				if ((c & 0xff) == 0xff) c = 0;	// cannot read 0 because of STRLEN
				SetCurrentPalette(c);
				continue;
			}
			else if (c == 0x02) // select fmodule
			{
				i++;
				c = (*s++ & 0xff);
				if (c == 0xff) c = 0;	// cannot read 0 because of STRLEN
				paint = TRUE;
			}
			else continue;
			
		}
		else // c > 32
		{
			c = Char2Frame(c);
		//	PaintFrame(g, c, xx, yy, 0, 0, 0);
			if (c >= GetFModules(0))
			{
				c = 0;
			}
			paint = TRUE;
		}

		if (paint) {
            int m = (_fmodules[c<<2]&0xFF)<<1;
            if (m >= (_nModules << 1))
            {
                m = 0;
                c = 0;//print space character
            }
            PaintFModule(0, c, xx, yy, 0, 0, 0);
           	xx += (_modules[m]&0xFF) - _fmodules[(c<<2)+1] + _fmodules[1];
		}
	}
/*/
	for (int i = index1; i < index2; i++)
	{
		int c = *s++;

		if (c > 32) 
		{
			c = m_pGame->_map_char[c]&0xFF;;
			if (c >= GetFModules(0))
			{				
				c = 0;
			}			
			PaintFModule(g, 0, c, xx, yy, 0, 0, 0);
			xx += (_modules[c<<1]&0xFF) - _fmodules[(c<<2)+1] + _fmodules[1];
		}
		else 
			if (c == ' ')
			{
				xx += (_modules[0]&0xFF) + _fmodules[1];
				continue;
			}
		else 
			if (c == '\n')
			{
				xx = x;
				yy += _line_spacing + (_modules[1]&0xFF);
				continue;
			}
		else //if (c < 32)
		{
			if (c == 0x01) 
			{
				i++;
				c = *s++;
				SetCurrentPalette(c/*-48*/);
				continue;
			}
			else if (c == 0x02) 
			{
				i++;
				c = *s++;
			}
			else continue;
			
		}
	}

//*/
	////_cur_pal = old_pal;
	SetCurrentPalette(old_pal);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::DrawPage(cGraphics* g, const char* s, int x, int y, int anchor)
{
	// Count lines...
	int lines = 0;
	int len = STRLEN(s);
	int off[100];// = new int[100];	// Viorel: TODO?
	const char *c=s;
	for (int i = 0; i < len; i++)
		if (*c++ == '\n')
			off[lines++] = i;
	off[lines++] = len;

	int th = _line_spacing + (_modules[1]&0xFF);

	if ((anchor & Graphics_BOTTOM) != 0)
		y -= (th * (lines-1));
	else if ((anchor & Graphics_VCENTER) != 0)
		y -= (th * (lines-1)) >> 1;

	// Draw each line...
	for (int j = 0; j < lines; j++)
	{
		_index1 = (j > 0) ? off[j-1]+1 : 0;
		_index2 = off[j];
		DrawString(g, s, x, y + j * th, anchor);
	}
	//delete off;

	// Disable substring...
	_index1 = -1;
	_index2 = -1;	
}



////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::SetCurrentPalette(int pal)
{
 	_cur_pal = pal;
	_pal->setPalette((uint8)pal);
}

void ASprite::SetPaletteColor(int pal, int colorIndex, int newColor)  
{
	_pal->setPaletteColor(pal,colorIndex,newColor);
}
