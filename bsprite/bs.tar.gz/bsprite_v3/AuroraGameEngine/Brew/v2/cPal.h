#ifndef __PAL_H__
#define __PAL_H__

#include "defines.h"

class cGame;

class cPal
{
public:

    cPal(cPal&);
    cPal();
    ~cPal();

	void init(uint8 max_palettes, uint8 max_colors);

	inline Palette_Type* getCurrentPalette() { return (&_palettes[_current * _max_colors]); };
	inline uint8 getCurrentPaletteNumber() { return (_current); };
	inline Palette_Type* getPalette(uint8 p) { return ((p < _max_palettes) ? &_palettes[p * _max_colors] : _palettes); };
	
	inline void setPalette(uint8 p) { if (p < _max_palettes) { _current = p; }; };	
	void updatePalette(uint8 p, uint32* pal);

	void setPaletteColor(uint8 p, uint8 i, uint32 c);
	uint32 getPaletteColor(uint8 p, uint8 i);

	uint8 getNumberOfColors() { return _max_colors; };
	uint8 getNumberOfPalettes() { return _max_palettes; };
	//uint8 getPosTranspColor(){ return _posTranspColor;}

	void GenPalette(int type, int src, int dest );
	bool _posTranspColor;


	uint8 _max_colors;


private:

	cGame *pGame;

	Palette_Type *_palettes;
	
	uint8 _current;

	uint8 _max_palettes;
};

#endif//__PAL_H__
