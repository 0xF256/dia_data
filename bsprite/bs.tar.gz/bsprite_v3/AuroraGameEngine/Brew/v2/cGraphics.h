#ifndef __CGRAPHICS_H__
#define __CGRAPHICS_H__

////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Author(s):	Cristian Iordache
//
//  History:	13.07.2005, created
//
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
// INCLUDES
////////////////////////////////////////////////////////////////////////////////////////////////////
#include "cGame.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
// DEFINES
////////////////////////////////////////////////////////////////////////////////////////////////////
#define Graphics_LEFT		IDF_ALIGN_LEFT
#define Graphics_RIGHT		IDF_ALIGN_RIGHT
#define Graphics_TOP		IDF_ALIGN_TOP
#define Graphics_BOTTOM		IDF_ALIGN_BOTTOM
#define Graphics_HCENTER	IDF_ALIGN_CENTER
#define Graphics_VCENTER	IDF_ALIGN_MIDDLE
#define Graphics_BASELINE   IDF_ALIGN_BOTTOM

////////////////////////////////////////////////////////////////////////////////////////////////////
// Alignment...
#define A_LEFT_TOP			(Graphics_LEFT | Graphics_TOP)
#define A_LEFT_VCENTER		(Graphics_LEFT | Graphics_VCENTER)
#define A_LEFT_BOTTOM		(Graphics_LEFT | Graphics_BOTTOM)
#define A_HCENTER_TOP		(Graphics_HCENTER | Graphics_TOP)
#define A_HCENTER_VCENTER	(Graphics_HCENTER | Graphics_VCENTER)
#define A_HCENTER_BOTTOM	(Graphics_HCENTER | Graphics_BOTTOM)
#define A_RIGHT_TOP			(Graphics_RIGHT | Graphics_TOP)
#define A_RIGHT_VCENTER		(Graphics_RIGHT | Graphics_VCENTER)
#define A_RIGHT_BOTTOM		(Graphics_RIGHT | Graphics_BOTTOM)

////////////////////////////////////////////////////////////////////////////////////////////////////
// classes
////////////////////////////////////////////////////////////////////////////////////////////////////
class cGame;

class cGraphics
{
////////////////////////////////////////////////////////////////////////////////////////////////////
// VARIABLES
////////////////////////////////////////////////////////////////////////////////////////////////////
	public:
		cGame*		m_pGame;

		IDIB *		m_pGraphicsIDIB;
		IBitmap*	m_pGraphicsIBitmap;
		
		int			m_iBufferWidth;
		int			m_iBufferHeight;

		uint8*		m_piGraphicsbuffer;
		int			m_iGraphicsnpitch;

		// provided by SetClip
		int			clip_xs;
		int			clip_ys; 
		int			clip_xe;
		int			clip_ye;
		int			clip_w;
		int			clip_h;

		// --- current color used
		uint32		m_CurrentColor;

		// --- should i release the associated buffer?
		bool		m_bReleaseBuffer;

////////////////////////////////////////////////////////////////////////////////////////////////////
// Methods
////////////////////////////////////////////////////////////////////////////////////////////////////
	public:
		// --- cGraphics constructor 
		cGraphics();

		// --- cGraphics destructor
		~cGraphics();

		// --- creates the new Buffer
		int createNewBackBuffer(int width, int height);

		// --- sets the new buffer 
		void setBuffer(IDIB* new_dib_buffer, IBitmap* new_ddb_buffer, int new_width, int new_height);

		// --- releases the Buffer
		void releaseBuffer(); 
	
		// ---
		void setClip(int x, int y, int w, int h);
		
		// --- sets the color to be used by draw rect, ....
		void setColor(int color);

		// --- drawPoint
		void drawPoint(int x, int y);

		// --- drawLine
		void drawLine(int x0, int y0, int x1, int y1);//, uint32 color);

		// --- drawLine
		void drawRect(int x, int y, int w, int h, int color, int colorFill, uint32 flag);

		// --- 
		void fillRect( int x, int y, int w, int h);

		// ---
		void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle);

#if  (DEF_bUseCDB || DEF_bUseTerrainBB)
		// ---
		void drawBackBufferImage(cGraphics* backBuffer, int xs, int ys, int width, int height, int xd, int yd);

#endif//(DEF_bUseCDB || DEF_bUseTerrainBB)

		// ---
		bool drawImage(cImg* img, int xd, int yd, int anchor);



		// ---
		void drawRegion(cImg* image, int x_src, int y_src, int width, int height, int transform,
									 int x_dest, int y_dest,
									 int anchor);

};//class cGraphics

#endif //__CGRAPHICS_H__

