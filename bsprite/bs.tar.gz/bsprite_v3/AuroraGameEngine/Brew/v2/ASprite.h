// ASprite.h
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Author(s):	Ionut Matasaru
//
//  History:	28.09.2003, created
//
//	Desc:		* use ".bsprite" files
//					(BSPRITE_v003, exported by AuroraGT v0.4.1 - SpriteEditor v0.5.2 or later)
//				* BSprite flags: BS_DEFAULT_MIDP2
//				* pixel formats supported:
//					8888	- A8 R8 G8 B8
//					4444	- A4 R4 G4 B4
//				* data formats supported:
//					I2		- 8 pixels/byte encoding (max 2 colors)
//					I4		- 4 pixels/byte encoding (max 4 colors)
//					I16		- 2 pixels/byte encoding (max 16 colors)
//					I127RLE	- RLE compression (max 127 colors)
//					I256	- 1 pixel/byte encoding (max 256 colors)
//
////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _AURORA_SPRITE_H_
#define _AURORA_SPRITE_H_

////////////////////////////////////////////////////////////////////////////////////////////////////

	// Index extension usage:
	//		FALSE -> max.  256 modules|frames
	//		TRUE  -> max. 4096 modules|frames
	#define USE_INDEX_EX_FMODULES TRUE
	#define USE_INDEX_EX_AFRAMES  TRUE

	//////////////////////////////////////////////////

	#define MAX_SPRITE_PALETTES		16
	#define MAX_SPRITE_MAPPINGS		8

	#define BSPRITE_v003			((short)0x03DF)	// supported version

	//////////////////////////////////////////////////
	// BSprite flags

	#define BS_MODULES				(1 << 0)
	#define BS_MODULES_XY			(1 << 1)
	#define BS_MMAPPINGS			(1 << 2)
	#define BS_FRAMES				(1 << 8)
	#define BS_FMAPPINGS			(1 << 9)
	#define BS_FM_OFF_SHORT     	(1 << 10)    // export fm offsets as shorts
	#define BS_ANIMS				(1 << 16)
	#define BS_AMAPPINGS			(1 << 17)
	#define BS_AF_OFF_SHORT     	(1 << 18)    // export af offsets as shorts
    #define BS_NAF_1_BYTE       	(1 << 19)    // export naf as byte
	#define BS_MODULE_IMAGES		(1 << 24)
	#define BS_PNG_CRC				(1 << 25)
	#define BS_KEEP_PAL         	(1 << 26)    // keep original palette (do not optimize colors)
	#define BS_TRANSP_FIRST			(1 << 27)
	#define BS_TRANSP_LAST			(1 << 28)

	#define BS_DEFAULT_DOJA			(BS_MODULES | BS_FRAMES | BS_ANIMS)
	#define BS_DEFAULT_MIDP2		(BS_MODULES | BS_FRAMES | BS_ANIMS | BS_MODULE_IMAGES)
	#define BS_DEFAULT_NOKIA		BS_DEFAULT_MIDP2
	#define BS_DEFAULT_MIDP1		(BS_MODULES | BS_MODULES_XY | BS_FRAMES | BS_ANIMS)
	#define BS_DEFAULT_MIDP1b		(BS_MODULES | BS_FRAMES | BS_ANIMS | BS_MODULE_IMAGES | BS_PNG_CRC)

	#define BS_KK_FLAGS				(BS_DEFAULT_MIDP2 | BS_NAF_1_BYTE)

	//////////////////////////////////////////////////

	#define PIXEL_FORMAT_8888		((short)0x8888)
	#define PIXEL_FORMAT_4444		((short)0x4444)

	//////////////////////////////////////////////////

	#define ENCODE_FORMAT_I2		0x0200
	#define ENCODE_FORMAT_I4		0x0400
//	#define ENCODE_FORMAT_I8		0x0800
	#define ENCODE_FORMAT_I16		0x1600
//	#define ENCODE_FORMAT_I32		0x3200
//	#define ENCODE_FORMAT_I64		0x6400
//	#define ENCODE_FORMAT_I128		0x2801
	#define ENCODE_FORMAT_I256		0x5602
//	#define ENCODE_FORMAT_I127_		0x2701
	#define ENCODE_FORMAT_I127RLE	0x27F1
//	#define ENCODE_FORMAT_I256RLE	0x56F2

	//////////////////////////////////////////////////
	// Frames/Anims flags...

	#define FLAG_FLIP_X				0x01
	#define FLAG_FLIP_Y				0x02
	#define FLAG_ROT_90				0x04

	#define FLAG_HYPER_FM			0x10 // Hyper FModule, used by FModules

	#define FLAG_USER0				0x10 // user flag 0
	#define FLAG_USER1				0x20 // user flag 1

	#define FLAG_INDEX_EX_MASK		0xC0 // 11000000, bits 6, 7
	#define INDEX_MASK				0x03FF // max 1024 values
	#define INDEX_EX_MASK			0x0300
	#define INDEX_EX_SHIFT			2

	//////////////////////////////////////////////////
	// flags passed as params...

	#define FLAG_OFFSET_FM			0x10
	#define FLAG_OFFSET_AF			0x20

////////////////////////////////////////////////////////////////////////////////////////////////////

#include "cImg.h"

class cImg;
class cPal;
class cGame;
class cLib;
class cGraphics;

////////////////////////////////////////////////////////////////////////////////////////////////////

class ASprite
{
public:
	ASprite();
	~ASprite();

	bool Load(cLib& lib, int offset);
	void Load0(cLib& lib);
	void Load1(cLib& lib);
	void Load2(cLib& lib);
	void Load22(cLib& lib);
	void Load23(cLib& lib);
	void Load24(cLib& lib);
	void Load3(cLib& lib);
	void Load32(cLib& lib);
	void Load33(cLib& lib);
	void Load34(cLib& lib);
	void Load4(cLib& lib);
	void Load5(cLib& lib);
	void Load6(cLib& lib);
	void Load7(cLib& lib);

	void BuildCacheImages(int pal = 0, int m1 = 0, int m2 = -1, int pal_copy = -1);
	cImg* BuildModuleImage(cPal* palette, int m, void* Allocator = 0);

	int GetAFrameTime(int anim, int aframe);
	int GetAFrames(int anim);
	int GetFModules(int frame);

	void GetAFrameRect(int* rc, int anim, int aframe, int posX, int posY, uint32 flags, int hx, int hy);
	void GetFrameRect(int* rc, int frame, int posX, int posY, uint32 flags, int hx, int hy);
	void GetModuleRect(int* rc, int module, int posX, int posY, uint32 flags);

	void PaintAFrame(cGraphics* g, int anim, int aframe, int posX, int posY, uint32 flags, int hx, int hy);
	void PaintFrame(cGraphics* g, int frame, int posX, int posY, uint32 flags, int hx, int hy);
	void PaintFModule(cGraphics* g, int frame, int fmodule, int posX, int posY, uint32 flags, int hx, int hy);
	void PaintModule(cGraphics* g, int module, int posX, int posY, uint32 flags);

#ifndef BUILD_CACHE_IMAGES
	cImg * BuildCacheImage(int module);
#endif //BUILD_CACHE_IMAGES

	void ApplyBlendEffect(cImg* img, int posX, int posY, int w, int h);
	void BlendTemp(int index, int blendColor);

	signed char* DecodeImage(int module, uint32 flags);

	//////////////////////////////////////////////////
	// Palettes and colors...

	void SetCurrentPalette(int pal);
	int GetCurrentPalette()	{ return _cur_pal; }

	void SetColor(int index, int color);
	void SetColor(int index, int a, int r, int g, int b);
	void SetPaletteColor(int pal, int colorIndex, int newColor);

	void ClearAllModulesData();
	
	void SetCurrentMMapping(int map)	{ _cur_map = map; }
	int GetCurrentMMapping()			{ return _cur_map; }

	//////////////////////////////////////////////////

	void SetModuleMapping(int map, byte* mmp, int len);
	void ApplyModuleMapping(int dst_pal, int src_pal, byte* mmp, int len);

	//////////////////////////////////////////////////

	// Space between two lines of text...
	int  GetLineSpacing()				{ return _line_spacing; }
	void SetLineSpacing(int spacing)	{ _line_spacing = spacing; }
	void SetLineSpacingToDefault()		{ _line_spacing = ((_modules[1]&0xFF) >> 1); }
	int  GetTextHeight()				{ return (_modules[1]&0xFF); }
	int  GetLineHeight()				{ return (_modules[1]&0xFF) + _line_spacing; }

	void SetSubString(int i1, int i2);
	void UpdateStringSize(const char* s);
	void DrawString(cGraphics* g, const char* s, int x, int y, int anchor);
	void DrawPage(cGraphics* g, const char* s, int x, int y, int anchor);

	//////////////////////////////////////////////////


	void setAllocator(void *buffer) { allocator_ = (byte *)buffer; }
	void *getAllocator() const { return allocator_; }

// Atributtes...
private:

	//////////////////////////////////////////////////

	// Modules...
	int			_nModules;			// number of modules
	unsigned char*		_modules;			// 2 chars for each Module
	//	u8			_x;					// [0] : x [BS_MODULES_XY]
	//	u8			_y;					// [1] : y [BS_MODULES_XY]
	//	u8			_w;					// 0/[2] : width
	//	u8			_h;					// 1/[3] : height

	//////////////////////////////////////////////////

	// Frames...
	int			_nFrames;			// number of frames
	byte*		_frames_nfm;		// number of FModules (max 256 FModules/Frame)
//	short*		_frames_nfm;		// number of FModules (max 32768 FModules/Frame)
	short*		_frames_fm_start;	// index of first FModule
	signed char* _frames_rc;		// frame bound rect (x y width height)
	//	s8			x;					// 0 : x position
	//	s8			y;					// 1 : y position
	//	u8			w;					// 2 : width
	//	u8			h;					// 3 : height

	// FModules...
	int			_nFModules;			// number of frame modules
	signed char*		_fmodules;			// 4 chars for each FModule
//	char[]		_fmodules_module;		// 0 : module index
//	char[]		_fmodules_ox;			// 1 : ox
//	char[]		_fmodules_oy;			// 2 : oy
//	char[]		_fmodules_flags;		// 3 : flags

	//////////////////////////////////////////////////

	// Anims...
	int			_nAnims;			// number of animations
	byte		_anims_naf_length;
	byte*		_anims_naf;			// number of AFrames (max 256 AFrames/Anim)
//	short*		_anims_naf;			// number of AFrames (max 32768 AFrames/Anim)
	short*		_anims_af_start;	// index of first AFrame

	// AFrames...
	int			_nAFrames;			// number of animation frames
	signed char* _aframes;			// 5 chars for each AFrame
//	char[]		_aframes_frame;			// 0 : frame index
//	char[]		_aframes_time;			// 1 : time
//	char[]		_aframes_ox;			// 2 : ox
//	char[]		_aframes_oy;			// 3 : oy
//	char[]		_aframes_flags;			// 4 : flags

	//////////////////////////////////////////////////

	// Module mappings...
	int			_nMappings;			// number of mapings
	short**		_map; 				// all mappings
	int			_cur_map;			// current mapping

	// Palettes...
//	short 		_pixel_format;		// always converted to 8888
	cPal*		_pal; 				// all palettes
	int			_palettes;			// number of palettes
	int			_cur_pal;			// current palette
	//bool		_alpha;				// has transparency ?

	// Graphics data (for each module)...
	uint16 			_data_format;
	signed char*	_modules_data;		// image data (encoded)
	uint16			_modules_data_size;
	uint16*			_modules_offsets;
//	int**			_modules_data2;		// cash image data (decoded)
	cImg*			_modules_image;		// cache image for each module 
//	Image[]			_modules_image_fx;	// cache image for each module (flipped horiz.)

	//////////////////////////////////////////////////
	// Draw String

	//	_modules[0] -> w  -> width of character ' ' (space)
	//	_modules[1] -> h  -> height of a text line
	//	_fmodules[0*4+1] -> ox -> space between two adiacent chars
	//	_fmodules[0*4+2] -> oy -> base line offset

	// Used to gather dimensions of a string...
	// (call UpdateStringSize() to update these values)
	int _text_w;
	int _text_h;

	int _line_spacing;	// space between two lines of text

	int _index1;
	int _index2;

	//////////////////////////////////////////////////

	bool _use_cache;

	byte *allocator_;

	cGame *m_pGame;

	signed char multiStep;
	signed short l_counter;

#ifdef USE_4COLORS_DRAWING
	bool	_4ColorDrawing;
#endif

#if ((defined(DRAW_2bits_Colors)) || defined (USE_4COLORS_DRAWING))
	int		_nrOfBits_Occupied_by_color;
#endif

}; // class ASprite

#endif // _AURORA_SPRITE_H_

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
