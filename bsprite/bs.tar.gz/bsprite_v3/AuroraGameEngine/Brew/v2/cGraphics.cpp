////////////////////////////////////////////////////////////////////////////////////////////////////
// INCLUDES
////////////////////////////////////////////////////////////////////////////////////////////////////
#include "cGame.h"
#include "cGraphics.h"

//---------------------------------------------------------------------
//cGraphics constructor  
//---------------------------------------------------------------------
cGraphics::cGraphics()
{
	m_pGame = (cGame *)GETAPPINSTANCE();
	m_iBufferWidth	= 0;
	m_iBufferHeight = 0;

	m_CurrentColor	= 0;

	m_bReleaseBuffer = TRUE;
}


//---------------------------------------------------------------------
//cGraphics destructor 
//---------------------------------------------------------------------
cGraphics::~cGraphics()
{	
	if (m_bReleaseBuffer)
		releaseBuffer();
}

//---------------------------------------------------------------------
//createNewBackBuffer 
//---------------------------------------------------------------------
int cGraphics::createNewBackBuffer(int width, int height)
{
	// --- create backbuffer
	if (IBITMAP_CreateCompatibleBitmap((IBitmap*) m_pGame->_ddb_buffer, (IBitmap**)&(m_pGraphicsIBitmap), (uint16) width, (uint16)height) != SUCCESS)
	{
		m_pGame->setGameState(GAMESTATE_STATE_OUT_OF_MEMORY);
		return ENOMEMORY;
	}

	IBITMAP_QueryInterface(m_pGraphicsIBitmap, BACKBUFFER_CORE_OFFSET, (void**)& (m_pGraphicsIDIB));

	m_iBufferWidth = width;
	m_iBufferHeight = height;

	m_piGraphicsbuffer = m_pGraphicsIDIB->pBmp;
	m_iGraphicsnpitch = m_pGraphicsIDIB->nPitch;

	return SUCCESS;
}


//---------------------------------------------------------------------
//setBuffer: 
//---------------------------------------------------------------------
void cGraphics::setBuffer(IDIB* new_dib_buffer, IBitmap* new_ddb_buffer, int new_width, int new_height)
{
	m_pGraphicsIDIB		= new_dib_buffer;
	m_pGraphicsIBitmap	= new_ddb_buffer;
	
	m_iBufferWidth		= new_width;
	m_iBufferHeight		= new_height;

	m_piGraphicsbuffer	= m_pGraphicsIDIB->pBmp;
	m_iGraphicsnpitch	= m_iBufferWidth * NATIVE_PIXEL_SIZE;// m_pGraphicsIDIB->nPitch;

	m_bReleaseBuffer	= FALSE;
}


//---------------------------------------------------------------------
//releaseBuffer 
//---------------------------------------------------------------------
void cGraphics::releaseBuffer()
{
	SAFE_DEL(m_pGraphicsIDIB)
	if(m_pGraphicsIBitmap){
		SYSFREE(m_pGraphicsIBitmap);
		m_pGraphicsIBitmap = NULL;
	}

}

//---------------------------------------------------------------------
//setClip:
//---------------------------------------------------------------------
void cGraphics::setClip(int x, int y, int w, int h)
{
#ifdef USE_BLACK_INTERFACE
	if( !m_bReleaseBuffer)
	{
		if( y < 0)
			y = 0;

		if( (y + h) >= DEF_SCR_H)
			h = DEF_SCR_H - y;
	}
#endif
	if ((x >= m_iBufferWidth) || (y >= m_iBufferHeight))
	{
		clip_w = 0;
		clip_h = 0;
		clip_xs = 0;
		clip_ys = 0;
		clip_xe = 0;
		clip_ye = 0;
#ifdef USE_BLACK_INTERFACE
	if( !m_bReleaseBuffer)
		IDISPLAY_SetClipRect(m_pGame->m_pIDisplay, NULL);
#endif
		return;
	}

	if (x < 0)
		x = 0;
	
	if (y < 0)
		y = 0;

	if ((x + w) > m_iBufferWidth)
		w = m_iBufferWidth - x;

	if ((y + h) > m_iBufferHeight)
		h = m_iBufferHeight - y;

	if ((w <= 0) || (h <= 0))
	{
		clip_w = 0;
		clip_h = 0;
		clip_xs = 0;
		clip_ys = 0;
		clip_xe = 0;
		clip_ye = 0;
#ifdef USE_BLACK_INTERFACE
	if( !m_bReleaseBuffer)
		IDISPLAY_SetClipRect(m_pGame->m_pIDisplay, NULL);
#endif		
		return;
	}

#ifdef USE_BLACK_INTERFACE
	AEERect r;

	r.dx = clip_w = w;
	r.dy = clip_h = h;
    r.x = clip_xs = x;
    r.y = clip_ys = y;
    clip_xe = x + w;
    clip_ye = y + h;
	////_DBGPRINTF("setClip(%d, %d, %d, %d)", x, y, w, h);
	if( !m_bReleaseBuffer)
		IDISPLAY_SetClipRect(m_pGame->m_pIDisplay, &r);
#else
	clip_w = w;
	clip_h = h;
    clip_xs = x;
    clip_ys = y;
    clip_xe = x + w;
    clip_ye = y + h;
#endif
}


//---------------------------------------------------------------------
//setColor: sets the color to be used by draw rect, ....
//---------------------------------------------------------------------
void cGraphics::setColor(int color)
{
	m_CurrentColor = color;
}



//---------------------------------------------------------------------
//drawPoint:
//---------------------------------------------------------------------
void cGraphics::drawPoint(int x, int y)
{
	typedef uint16 Pixel_Type; 

	if ((x < clip_xs) || (x > clip_xe))
		return;

	if ((y < clip_ys) || (y > clip_ye))
		return;

	NativeColor nativeColor = IBITMAP_RGBToNative(m_pGraphicsIBitmap, COLOR_ARGB_TO_BGRA(m_CurrentColor));
	*(Pixel_Type *)(m_piGraphicsbuffer + y * m_iGraphicsnpitch + x * NATIVE_PIXEL_SIZE) = (Pixel_Type)nativeColor;

}


//---------------------------------------------------------------------
//drawLine:
//---------------------------------------------------------------------
void cGraphics::drawLine(int x0, int y0, int x1, int y1)//, uint32 color)
{

	// IULIAN
	// Bresenham's line algorithm to draw a line in the _ddb_buffer
	// algorithm copied from site:
	// http://en.wikipedia.org/wiki/Bresenham%27s_line_algorithm_C_code
	// NOT OPTIMIZED ... too much !!!

	NativeColor nativeColor = IBITMAP_RGBToNative(m_pGraphicsIBitmap, COLOR_ARGB_TO_BGRA(m_CurrentColor));
	//NativeColor *screen = (NativeColor *)(_ddb_buffer+PIXEL_OFFSET);
//	#if BREW_VER >=200
		uint8 *screen = m_piGraphicsbuffer;//(uint8*)_dib_buffer->pBmp;
//	#else
//		uint8 *screen = (uint8*)(_ddb_buffer+PIXEL_OFFSET);
//	#endif
	

	typedef uint16 Pixel_Type1;

	int i;
	int steep = 1;
	int sx, sy;  /* step positive or negative (1 or -1) */
	int dx, dy;  /* delta (difference in X and Y between points) */
	int dx2,dy2;    /* IULIAN *** suggested optimizations */
	int e;

	/*
	* inline swap. On some architectures, the XOR trick may be faster ( IULIAN *** using it :D )
	*/
	// IULIAN *** don't worry it works !!!
	#define SWAP(a,b) (a) = (a)^(b),(b) = (a)^(b),(a) = (a)^(b)

	/*
	* optimize for vertical and horizontal lines here
	*/
	dx = x1 - x0;
   if( dx > 0 )
   {
       sx = 1;
   }
   else
   {
        dx = -dx;
        sx = -1;
   }
   
   dy = (y1 - y0);
   if( dy > 0 )
   {
        sy = 1;
   }
   else
   {
       dy = -dy;
       sy = -1;
   }
   
   if (dy > dx) {
           steep = 0;
           SWAP(x0, y0);
           SWAP(dx, dy);
           SWAP(sx, sy);
   }
   else if (dx == 0 && dy == 0)
   {
	/*		if( x0 >= 0 && x0 < m_iBufferHeight &&
				y0 >= clip_xs && y0 < clip_xe &&
				y0 >= 0 && y0 < m_iBufferWidth &&
				x0 >= clip_ys && x0 < clip_ye )
			*(Pixel_Type1 *)(screen + x0 * m_iGraphicsnpitch + y0 * NATIVE_PIXEL_SIZE) = (Pixel_Type1)nativeColor;
	   */
	   /*
		dx++;
		dy++;
		*/
	   drawPoint(x0, y0);
	   return;
   }

   dx2 = dx<<1;
   dy2 = dy<<1;

   e = dy2 - dx;
   for (i = 0; i < dx; i++)
   {
		if (steep)
		{
			//plot(x0,y0,color);
			if( x0 >= 0 && x0 < m_iBufferWidth && x0 >= clip_xs && x0 < clip_xe &&
				y0 >= 0 && y0 < m_iBufferHeight && y0 >= clip_ys && y0 < clip_ye )
				*(Pixel_Type1 *)(screen + y0 * m_iGraphicsnpitch + x0 * NATIVE_PIXEL_SIZE) = (Pixel_Type1)nativeColor;
			//((Pixel_Type1*)screen)[x0+y0*GAME_CANVAS_WIDTH] = (Pixel_Type1)nativeColor;
		}
		else
		{
			//plot(y0,x0,color);
			if( x0 >= 0 && x0 < m_iBufferHeight &&
				y0 >= clip_xs && y0 < clip_xe &&
				y0 >= 0 && y0 < m_iBufferWidth &&
				x0 >= clip_ys && x0 < clip_ye )
			*(Pixel_Type1 *)(screen + x0 * m_iGraphicsnpitch + y0 * NATIVE_PIXEL_SIZE) = (Pixel_Type1)nativeColor;
//			((Pixel_Type1*)screen)[y0+x0*GAME_CANVAS_WIDTH] = (Pixel_Type1)nativeColor;
		}
/*
		while (e >= 0)
		{
			y0 += sy;
			e -= dx2;
		}
*/
		while (TRUE)
		{
			if (e < 0)
				break;
			y0 += sy;
			e -= dx2;
		}

		x0 += sx;
		e += dy2;
   }
#undef SWAP
}



//---------------------------------------------------------------------
//drawRect
//---------------------------------------------------------------------
void cGraphics::drawRect(int x, int y, int w, int h, int color, int colorFill, uint32 flag)
{
#if ((BREW_VER >= 200) &&(DRAWRECT_ONLY_ON_DISPLAY))
	AEERect rc;
	
	rc.x = x;
	rc.y = y;
	rc.dx = w;
	rc.dy = h;

	uint8 b = (color & 0xFF);
	uint8 g = ((color >> 8) & 0xFF);
	uint8 r = ((color >> 16) & 0xFF);

	uint8 b1 = (colorFill & 0xFF);
	uint8 g1 = ((colorFill >> 8) & 0xFF);
	uint8 r1 = ((colorFill >> 16) & 0xFF);

	IDISPLAY_DrawRect(m_pGame->m_pIDisplay, &rc, MAKE_RGB(r, g, b), MAKE_RGB(r1, g1, b1), flag);
#else
	drawLine(x, y, x + w - 1, y);
	drawLine(x + w - 1, y, x + w - 1, y + h);
	drawLine(x + w - 1, y + h - 1, x, y + h - 1);
	drawLine(x, y + h - 1, x, y);
#endif
}

//---------------------------------------------------------------------
//fillRect
//---------------------------------------------------------------------
void cGraphics::fillRect( int x, int y, int w, int h )
{
	AEERect r;

	// # 59137
	if (x < clip_xs) {
		w -= (clip_xs - x);
		x = clip_xs;
	}
	if (y < clip_ys) {
		h -= (clip_ys - y);
		y = clip_ys;
	}
	if (x + w > clip_xe) w = clip_xe - x;
	if (y + h > clip_ye) h = clip_ye - y;
	if (w <= 0 || h <= 0)
		return;

	r.x = x;
	r.y = y;
	r.dx = w;
	r.dy = h;

	// set in the BREW format
	uint32 color = COLOR_ARGB_TO_BGRA(m_CurrentColor);

//    if (_buffer)
#if BREW_VER >= 200
		IBITMAP_FillRect(m_pGraphicsIBitmap, &r, IBITMAP_RGBToNative(m_pGraphicsIBitmap, color), AEE_RO_COPY);
#else
#	ifdef ON_EMULATOR
		if (!_bRealloc) {
			byte pixel = (byte)IBITMAP_RGBToNative(_ddb_buffer, color);
			int inc = _dib_buffer->nPitch;
			byte *dst = ((byte *)_dib_buffer->pBmp) + (GAME_CANVAS_HEIGHT - y - h) * inc + x;
			for (int i = 0; i < h; i++) {
				for (int j = 0; j < w; j++) {
					*dst++ = pixel;
				}
				if (w < inc)
					dst += (inc-w);
			}
		} else {
#	endif
			short pixel = (short)IBITMAP_RGBToNative(_ddb_buffer, color);
			int inc = (_dib_buffer->nPitch >> 1);
			short *dst = ((short *)_dib_buffer->pBmp) + (y * inc) + x;
			for (int i = 0; i < h; i++) {
				for (int j = 0; j < w; j++) {
					*dst++ = pixel;
				}
				if (w < inc)
					dst += (inc-w);
			}
#	ifdef ON_EMULATOR
		}
#	endif
#endif
//	else
//		IDISPLAY_FillRect(m_pIDisplay, &r, color);
}


//---------------------------------------------------------------------
//drawArc
//---------------------------------------------------------------------
void cGraphics::drawArc(int x, int y, int width, int height, int startAngle, int arcAngle)
{
#ifdef TODO
	AEEArc pArc;
	pArc.cx = x /** X_SCALE*/;
	pArc.cy = y /** Y_SCALE*/;
	pArc.r = width /** X_SCALE*/;
	pArc.startAngle = startAngle;
	pArc.arcAngle = arcAngle;
	IGRAPHICS_DrawArc(m_pGame->m_pIGraphics, &pArc);
#endif
}


//---------------------------------------------------------------------
//drawBackBuffer
//---------------------------------------------------------------------
//void cGraphics::drawRegion(cImg* img, int x_src, int y_src, int width, int height, int transform,
//										int x_dest, int y_dest,
//										int anchor)
#if (DEF_bUseCDB || DEF_bUseTerrainBB)

void cGraphics::drawBackBufferImage(cGraphics* backBuffer, int xs, int ys, int _w, int _h, int xd, int yd)
{
#ifdef DRAW_FONTS_ONLY
	return;
#endif

	typedef uint16 Pixel_Type;

//	register int i,j;
	
	int _width  = backBuffer->m_iBufferWidth;
	int _height = backBuffer->m_iBufferHeight;
	
	int xcs = clip_xs;
	int ycs = clip_ys;
	int xce = clip_xe;
	int yce = clip_ye;


	int dd = 0;

	if (xs + _w > _width)
		_w = _width - xs;

	if (ys + _h > _height)
		_h = _height - ys;

	if ((xd >= xce) || (xd <= (xcs - _w)))
		return;
	if ((yd >= yce) || (yd <= (ycs - _h)))
		return;

	if ((xd + _w) > xce)
	{
		xce -= (xd + _w);
		_w += xce;
	}
	else
		xce = 0;

	if (xd < xcs)
	{
		dd = xcs - xd;
		xce += dd;
		_w -= dd;
		xs += dd;
		xd = xcs;
	}

	if ((_w <= 0) || (xs >= _width))
		return;

	if ((yd + _h) > yce)
	{
		yce -= (yd + _h);
		_h += yce;
	}
	else
		yce = 0;

	if (yd < ycs)
	{
		dd = ycs - yd;
		yce += dd;
		_h -= dd;
		ys += dd;
		yd = ycs;
	}

	if ((_h <= 0) || (ys >= _height))
		return;
///*
	Pixel_Type* source = NULL;

	int _inc2 = m_iGraphicsnpitch/2;

	Pixel_Type* screen = (Pixel_Type*)m_piGraphicsbuffer;
//	Pixel_Type* screen_line = NULL;
	Pixel_Type* screen_end = NULL;

	screen += (yd * _inc2) + xd;

	source =(Pixel_Type*) backBuffer->m_piGraphicsbuffer;
	source +=((ys * _width) + xs);
	//_w -= _width;

#ifdef USE_MEMCPY
	screen_end = screen + (_h * _inc2);
	_w *= 2;

	while(TRUE)
	{
		MEMCPY(screen, source, _w);

		screen += _inc2;
		source+= _width;

		if(screen >= screen_end)
			break;
	} 


#else

	screen_end = screen + (_h * _inc2);

	while(TRUE)
	{
		for(int i = _w - 1; i; i--)
		{
			screen[i] = source[i];
		}

		screen[0] = source[0];

		screen += _inc2;
		source+= _width;

		if(screen >= screen_end)
			break;
	} 
//
//	register uint32* source1 = NULL;
//	register uint32* screen1 = NULL;
//
//	_inc2 -= _w;
//	_width -= _w;
//
//	for (j = _h - 1; j >=0; j-- )
//	{
//		source1 = (uint32*) source;
//		screen1 = (uint32*) screen;
//
//
//		for(i = _w; i >= 32; i-=32)
//		{
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//		}
//
//		if(i >= 16)
//		{
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			i-=16;
//		}
//
//		if (i >= 8)
//		{
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//			i -=8;
//		}
//
//
//		if (i >=4)
//		{
//			*screen1++ = *source1++;
//			*screen1++ = *source1++;
//
//			i-= 4;
//		}
//
//		source = (Pixel_Type*) source1;
//		screen = (Pixel_Type*) screen1;
//		while (i--)
//		{
//			*screen++ = *source++;
//		}
//
//		screen += _inc2;
//		source += _width;
//
//	} 
#endif
/*/


#if	((defined(_AEE_SIMULATOR))||(!(BREW_VER < 200)))
{
	IBITMAP_BltIn(m_pGraphicsIBitmap, xd, yd, m_iBufferWidth, m_iBufferHeight, backBuffer->m_pGraphicsIBitmap, 0, 0, AEE_RO_COPY);
}
#else
	#error not implemented
	int inc = (nPitch >> 1);
	short *src = ((short *)(_ddb_buffer_BK + PIXEL_OFFSET))+ ((y - yCurrent)* inc) + x;
	short *dst = ((short *)(_ddb_buffer + PIXEL_OFFSET))+ ((y - yCurrent) * inc) + x;
	for (int i = 0; i < _h; i++) 
	{
		for (int j = 0; j < _w; j++)
			*dst++ = *src++;
		if (_w < inc){
			dst += (inc-_w);
			src += (inc-_w);
		}
	}
#endif





//*/
}
#endif//(DEF_bUseCDB || DEF_bUseTerrainBB)


bool cGraphics::drawImage(cImg* img, int xd, int yd, int anchor)
{
	if (img == NULL)
		return FALSE;


	if ((anchor & (Graphics_RIGHT | Graphics_HCENTER | Graphics_BOTTOM | Graphics_VCENTER)) != 0)
	{
		if ((anchor & Graphics_RIGHT) != 0)
			xd -= img->getWidth();
		else if ((anchor & Graphics_HCENTER) != 0) {
			xd -= img->getWidth()>>1;
#if DEF_SCR_W & 1
			x--;
#endif
		}

		if ((anchor & Graphics_BOTTOM) != 0)
			yd -= img->getHeight();
		else if ((anchor & Graphics_VCENTER) != 0)
			yd -= img->getHeight()>>1;
	}

#ifndef DRAW_FONTS_ONLY
	// --- draw string
	img->draw(this, 0, 0, img->getWidth(), img->getHeight(), xd, yd, 0);
#endif
	return TRUE;
}



void cGraphics::drawRegion(cImg* img, int x_src, int y_src, int width, int height, int transform,
										int x_dest, int y_dest,
										int anchor)
{
	// --- drawRegion
#ifndef DRAW_FONTS_ONLY
	img->draw(this, x_src, y_src, width, height, x_dest, y_dest, transform);
#endif
}
