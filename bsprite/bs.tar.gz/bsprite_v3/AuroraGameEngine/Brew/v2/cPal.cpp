#include "AEEModGen.h" // Module interface definitions
#include "AEEAppGen.h" // Applet interface definitions
#include "AEEShell.h"  // Shell interface definitions
#include "AEEStdLib.h" // AEE StdLib Services
#include "AEELicense.h"
#include "AEEHeap.h"

///#include "gamedef.h"
//#include "cInstance.h"
//#include "cStage.h"
#include "cGame.h"
//#include "cPal.h"

cPal::cPal(cPal& rPal)
{
    this->pGame = (cGame *)GETAPPINSTANCE();
	init(rPal._max_palettes, rPal._max_colors);
	_current = rPal._current;
	for(int p = 0; p < _max_palettes; p++)
		for(int c = 0; c < _max_colors; c++)
			setPaletteColor(p,c,rPal.getPaletteColor(p,c));
}

cPal::cPal()
{
    this->pGame = (cGame *)GETAPPINSTANCE();

	_max_colors = 0;
	_max_palettes = 0;
	_current = 0;

	_palettes = NULL;
}

void cPal::init(uint8 max_palettes, uint8 max_colors)
{
	this->pGame = (cGame *)GETAPPINSTANCE();

	SAFE_DEL_ARRAY(_palettes);

	_max_colors = max_colors;
	_max_palettes = max_palettes;

	_current = 0;
	// # platform transparency bugfix
	_posTranspColor = FALSE;//0;

	_palettes = new Palette_Type[_max_palettes * _max_colors];
}

cPal::~cPal()
{
	int x = 0;
	
	SAFE_DEL_ARRAY(_palettes);

	_max_colors = 0;
	_max_palettes = 0;
	_current = 0;
}

void cPal::updatePalette(uint8 p, uint32* pal)
{
	if (!pal || (p >= _max_palettes))
		return;

	// fill in the colors
	for (int j = 0; j < _max_colors; j++)
		setPaletteColor(p, j, pal[j]);
}

void cPal::setPaletteColor(uint8 p, uint8 i, uint32 color)
{
	if ((p >= _max_palettes) || (i >= _max_colors))
		return;
//	short palTransp = ;
	_palettes[p * _max_colors + i] = (Palette_Type)IBITMAP_RGBToNative(pGame->_ddb_buffer, COLOR_ARGB_TO_BGRA(color));
	if((short)_palettes[p * _max_colors] == pGame->_transparent_native_color)
		_posTranspColor = TRUE;
}

uint32 cPal::getPaletteColor(uint8 p, uint8 i)
{
	if ((p >= _max_palettes) || (i >= _max_colors))
		return 0;
	
	uint32 color = IBITMAP_NativeToRGB(pGame->_ddb_buffer, _palettes[p * _max_colors + i]);

	return COLOR_BGRA_TO_ARGB(color);
}


////////////////////////////////////////////////////////////////////////////////////////////////////
// Palette generation based on other palette...

// -1 - original colors
//  0 - invisible (the sprite will be hidden)
//  1 - red-yellow
//  2 - blue-cyan
//  3 - green
//  4 - grey

void cPal::GenPalette(int type, int src, int dest)
{
	if (type <  0) return ;	// original
	if (type == 0) return ; // invisible DannyD: TODO... check here - was return null

	uint32* new_pal = new uint32[_max_colors];
	int i = 0;
	switch (type)
	{
		case 1: // red - yellow
			for (i = 0; i < _max_colors; i++)
				new_pal[i] = (getPaletteColor(src,i) | 0x00FF3300) & 0xFFFFFF00;
			break;

		case 2: // blue - cyan
			for (i = 0; i < _max_colors; i++)
				new_pal[i] = (getPaletteColor(src,i) | 0x000033FF) & 0xFF00FFFF;
			break;

		case 3: // green
			for (i = 0; i < _max_colors; i++)
				new_pal[i] = (getPaletteColor(src,i) | 0x00000000) & 0xFF00FF00;
			break;

		case 4: // grey
			for (i = 0; i < _max_colors; i++)
			{
				int a = (getPaletteColor(src,i) & 0xFF000000);
				int r = (getPaletteColor(src,i) & 0x00FF0000) >> 16;
				int g = (getPaletteColor(src,i) & 0x0000FF00) >> 8;
				int b = (getPaletteColor(src,i) & 0x000000FF);
				int l = ((r + b + g) / 3) & 0x000000FF;
				new_pal[i] = ((l << 16) | (l << 8) | l | a);
			}
			break;
	}
	updatePalette(dest, new_pal);
	delete new_pal;
}
