#ifndef __IMG_H__
#define __IMG_H__

//#define USE_ROTATE
//#include "cPal.h"

#define FX_NORMAL				(0x00)
#define FX_FLIP_H               (0x01)
#define FX_FLIP_V               (0x02)
#define FX_FLIP_HV              (0x04)

#ifdef USE_ROTATE
	#define FX_ROT_R90              (0x08)
	#define FX_ROT_L90              (0x10)
#endif



#include "AEE.h"   //	AEEFile Services
#include "AEEAppGen.h" // AEEApplet declaration
#include "AEEGraphics.h"
#include "AEEFile.h"   //	AEEFile Services
#include "defines.h"
//#include "cGraphics.h"
class cImg;
class cGraphics;

class cGame;
class cPal;


#if (NATIVE_PIXEL_SIZE == 2)
	typedef uint16 Pixel_Type;
#elif (NATIVE_PIXEL_SIZE == 4)
	typedef uint32 Pixel_Type;
#else
	#error --- define ENABLE_DRAW_16 or ENABLE_DRAW_32 or a new typedef for PixelType
#endif

class cImg
{
public:

    cImg();
    ~cImg();

//	void setBuffer(uint8 *buffer, int npitch);

	bool load(uint8* pixels, cPal* pal, int width, int height);
	void usePixels(uint8* pixels, cPal* pal, int width, int height);
	void unload();
	
	//void cImg::draw8(int xs, int ys, int _w, int _h, int xd, int yd, uint8 fx);
	void draw(cGraphics* g, int xs, int ys, int _w, int _h, int xd, int yd, uint8 fx );

#ifdef USE_ROTATE
	void drawRot( int xs, int ys, int _w, int _h, int xd, int yd, uint8 fx );
#endif

	int getWidth() { return _width; };
	int getHeight() { return _height; };
	uint8* getPixelsAddress() { return _pixels; };

	inline void setTransparency(bool has_transparency) { _tr = has_transparency; };
	bool isLoaded(){return (_pixels != 0);}

	cPal& getPalette() {return *_palette; }

private:

	cGame *m_pGame;
	uint8 *_buffer;
	bool _freePixels;
	int _npitch;

	uint8 _fx;
	int _tr;

	int _width;
	int _height;
	

    uint8 *_pixels;

	byte *allocator_;

#ifdef USE_COMPRESSED_16_COLORS_IMAGES
	bool	m_bNoCompresData;
	int		img_line;
#endif



public:
	cPal *_palette;

	void setAllocator(void *buffer) { allocator_ = (byte *)buffer; }
	void *getAllocator() const { return allocator_; }

#ifdef DRAW_2bits_Colors
	void draw4TransparentPixelsOnScreenUpwards(Pixel_Type* screen, Pixel_Type* _pal, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels);
	//void draw4PixelsOnScreenUpwards(Pixel_Type* screen, Pixel_Type* _pal, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels);

	//void draw4TransparentPixelsOnScreenDownwards(Pixel_Type* screen, Pixel_Type* _pal, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels);
	//void draw4PixelsOnScreenDownwards(Pixel_Type* screen, Pixel_Type* _pal, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels);
#endif
/*

	void drawTransparentPixelsOnScreenUpwards(Pixel_Type* screen, Pixel_Type* _pal, int color_occupies_x_bits, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels);
	void drawPixelsOnScreenUpwards(Pixel_Type* screen, Pixel_Type* _pal, int color_occupies_x_bits, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels);

	void drawTransparentPixelsOnScreenDownwards(Pixel_Type* screen, Pixel_Type* _pal, int color_occupies_x_bits, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels);
	void drawPixelsOnScreenDownwards(Pixel_Type* screen, Pixel_Type* _pal, int color_occupies_x_bits, int _newLineBegin, int height, int _w, int _inc1, int moveSourcexPixels);
*/

	int	 _nrOfBits_Occupied_by_color;


#ifdef USE_4COLORS_DRAWING
	bool	_4ColorDrawing;
	inline void set4ColorDrawing(bool bool_4ColorDrawing) { _4ColorDrawing = bool_4ColorDrawing; };

#endif

};

#endif //__IMG_H__
