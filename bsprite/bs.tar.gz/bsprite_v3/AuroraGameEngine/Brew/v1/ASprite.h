// ASprite.h
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Author(s): Ionut Matasaru (ionut.matasaru@gameloft.com)
//
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  History:	28.09.2003, created
//				16.09.2005, updated
//
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Desc:		* use ".bsprite" files (BSPRITE_v003, exported by AuroraGT v0.5.0 - SpriteEditor v0.6.0 or later)
//				* BSprite flags: BS_DEFAULT_MIDP2 | BS_FM_OFF_SHORT
//				* pixel formats supported:
//					8888	- A8 R8 G8 B8
//					4444	- A4 R4 G4 B4
//				* data formats supported:
//					I2		- 8 pixels/byte encoding (max 2 colors)
//					I4		- 4 pixels/byte encoding (max 4 colors)
//					I16		- 2 pixels/byte encoding (max 16 colors)
//					I127RLE	- RLE compression (max 127 colors)
//					I256	- 1 pixel/byte encoding (max 256 colors)
//
////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _AURORA_SPRITE_H_
#define _AURORA_SPRITE_H_

////////////////////////////////////////////////////////////////////////////////////////////////////

	#define USE_MODULE_MAPPINGS		true	// use Module Mappings ?

	#define USE_HYPER_FM			true	// use Hyper Frame Modules ?

	#define USE_INDEX_EX_FMODULES	true	// true|false -> max. 1024|256 modules refs. from a FModule
	#define USE_INDEX_EX_AFRAMES	true	// true|false -> max. 1024|256 frames refs. from an Anim

	//////////////////////////////////////////////////

	#define MAX_SPRITE_PALETTES		16
	#define MAX_SPRITE_MAPPINGS		16

	#define BSPRITE_v003			0x03DF // supported version

	//////////////////////////////////////////////////
	// BSprite flags

	#define BS_MODULES				(1 << 0)
	#define BS_MODULES_XY			(1 << 1)
	#define BS_MMAPPINGS			(1 << 2)
	#define BS_FRAMES				(1 << 8)
	#define BS_FMAPPINGS			(1 << 9)
	#define BS_FM_OFF_SHORT     	(1 << 10)    // export fm offsets as shorts
	#define BS_ANIMS				(1 << 16)
	#define BS_AMAPPINGS			(1 << 17)
	#define BS_AF_OFF_SHORT     	(1 << 18)    // export af offsets as shorts
	#define BS_NAF_1_BYTE       	(1 << 19)    // export naf as byte
	#define BS_MODULE_IMAGES		(1 << 24)
	#define BS_PNG_CRC				(1 << 25)
	#define BS_KEEP_PAL         	(1 << 26)    // keep original palette (do not optimize colors)
	#define BS_TRANSP_FIRST			(1 << 27)
	#define BS_TRANSP_LAST			(1 << 28)

	#define BS_DEFAULT_DOJA			(BS_MODULES | BS_FRAMES | BS_ANIMS)
	#define BS_DEFAULT_MIDP2		(BS_MODULES | BS_FRAMES | BS_ANIMS | BS_MODULE_IMAGES)
	#define BS_DEFAULT_NOKIA		BS_DEFAULT_MIDP2
	#define BS_DEFAULT_MIDP1		(BS_MODULES | BS_MODULES_XY | BS_FRAMES | BS_ANIMS)
	#define BS_DEFAULT_MIDP1b		(BS_MODULES | BS_FRAMES | BS_ANIMS | BS_MODULE_IMAGES | BS_PNG_CRC)

	#define BS_KK_FLAGS				(BS_DEFAULT_MIDP2 | BS_NAF_1_BYTE)

	//////////////////////////////////////////////////

	#define PIXEL_FORMAT_8888		0x8888
	#define PIXEL_FORMAT_4444		0x4444

	//////////////////////////////////////////////////

	#define ENCODE_FORMAT_I2		0x0200
	#define ENCODE_FORMAT_I4		0x0400
//	#define ENCODE_FORMAT_I8		0x0800
	#define ENCODE_FORMAT_I16		0x1600
//	#define ENCODE_FORMAT_I16MP		0x16??
//	#define ENCODE_FORMAT_I32		0x3200
//	#define ENCODE_FORMAT_I64		0x6400
//	#define ENCODE_FORMAT_I128		0x2801
	#define ENCODE_FORMAT_I256		0x5602
//	#define ENCODE_FORMAT_I127_		0x2701
	#define ENCODE_FORMAT_I127RLE	0x27F1
//	#define ENCODE_FORMAT_I256RLE	0x56F2

	//////////////////////////////////////////////////
	// Frames/Anims flags...

	#define FLAG_FLIP_X				0x01
	#define FLAG_FLIP_Y				0x02
	#define FLAG_ROT_90				0x04

	#define FLAG_USER0				0x10 // user flag 0
	#define FLAG_USER1				0x20 // user flag 1

	#define FLAG_HYPER_FM			0x10 // Hyper FModule, used by FModules

	// Index extension...
	#define FLAG_INDEX_EX_MASK		0xC0 // 11000000, bits 6, 7
	#define INDEX_MASK				0x03FF // max 1024 values
	#define INDEX_EX_MASK			0x0300
	#define INDEX_EX_SHIFT			2

	//////////////////////////////////////////////////
	// flags passed as params...

	#define FLAG_OFFSET_FM			0x10
	#define FLAG_OFFSET_AF			0x20

////////////////////////////////////////////////////////////////////////////////////////////////////

class LZMAFile;
class Image;
class gxGraphics;

////////////////////////////////////////////////////////////////////////////////////////////////////

class ASprite
{
public:
	ASprite();
	~ASprite();

	// Loads a sprite from a file
	int LoadSprite(LZMAFile* pFile);

	int BuildCacheImages(int pal = 0, int m1 = 0, int m2 = -1, int pal_copy = -1);

	int GetAFrameTime(int anim, int aframe) { return _aframes[(_anims_af_start[anim] + aframe) * 5 + 1] & 0xFF;	}
	int GetAFrames(int anim)				{ return _anims_naf[anim] & 0xFF; }
	int GetFModules(int frame)				{ return _frames_nfm[frame] & 0xFF; }

	void GetAFrameRect(int* rc, int anim, int aframe, int posX, int posY, u32 flags, int hx, int hy);
	void GetFrameRect(int* rc, int frame, int posX, int posY, u32 flags, int hx, int hy);
	void GetModuleRect(int* rc, int module, int posX, int posY, u32 flags);

	void PaintAFrame(int anim, int aframe, int posX, int posY, u32 flags, int hx, int hy);
	void PaintFrame(int frame, int posX, int posY, u32 flags = 0, int hx = 0, int hy = 0);
	void PaintFModule(int frame, int fmodule, int posX, int posY, u32 flags = 0, int hx = 0, int hy = 0);
	void PaintModule(int module, int posX, int posY, u32 flags);

	u16* DecodeModuleImage (u16* target, int module);
	u8*  DecodeModuleImage8(u8*  target, int module);

	//////////////////////////////////////////////////
	// Palettes and colors...

	void SetPalette(int pal) { _pCrtPalette = pPalettes[pal]; }

	void SetColor(int index, int color)							{ _pCrtPalette[index] = COLOR32TO16ARGB(color); }
	void SetPaletteColor(int pal, int color_index, int color)	{ pPalettes[pal][color_index] = COLOR32TO16ARGB(color); }
	void SetFontColor(int color, int outline)
	{
		_pCrtPalette[0] = COLOR32TO16ARGB(outline);
		_pCrtPalette[1] = COLOR32TO16ARGB(color);
	}

	//////////////////////////////////////////////////

	// Space between two lines of text...
	int  GetLineSpacing()				{ return _line_spacing; }
	void SetLineSpacing(int spacing)	{ _line_spacing = spacing; }
	void SetDefaultLineSpacing()		{ _line_spacing = ((_modules[1]&0xFF))>>2; }
	int  GetTextHeight()				{ return (_modules[1]&0xFF); }
	int  GetLineHeight()				{ return (_modules[1]&0xFF) + _line_spacing; }

	void SetSubString(int i1, int i2) { _index1 = i1; _index2 = i2; }	// (-1, -1) to disable
	void GetStringSize(const char* str, int* pW, int* pH);
	void DrawString(const char* str, int x, int y, int anchor);
	void DrawPage(const char* str, int x, int y, int anchor);

	//////////////////////////////////////////////////

	// Sets the target device...
	void SetRasterDevice(gxGraphics* newDevice)	 { pDevice = newDevice; }

private:
	int LoadSprite_0(LZMAFile* pFile);	// Modules
	int LoadSprite_1(LZMAFile* pFile);	// Frames
	int LoadSprite_2(LZMAFile* pFile);	// Anims
	int LoadSprite_3(LZMAFile* pFile);	// Palettes
	int LoadSprite_4(LZMAFile* pFile);	// Images

	//Decodes all module gfx data and creates images
	int BuildModuleImages();

	//Returns the string size in w and h.
	void StringSize(const char* str, int& w, int& h);


	inline int FModuleOX(int fm)
	{
		u8* ptr = _fmodules + fm * 6 + 1;
		return (s16)((*ptr) | (*(ptr + 1) << 8));
	}
	inline int FModuleOY(int fm)
	{
		u8* ptr = _fmodules + fm * 6 + 3;
		return (s16)((*ptr) | (*(ptr + 1) << 8));
	}

// Atributtes...
private:

	//////////////////////////////////////////////////

	// Modules...
	int			_nModules;			// number of modules
	u8*			_modules;			// 2/[4] bytes for each Module
	//	u8			_x;					// [0] : x [BS_MODULES_XY]
	//	u8			_y;					// [1] : y [BS_MODULES_XY]
	//	u8			_w;					// 0/[2] : width
	//	u8			_h;					// 1/[3] : height

	//////////////////////////////////////////////////

	// Frames...
	int			_nFrames;			// number of frames
	u8*			_frames_nfm;		// number of FModules (max 256 FModules/Frame)
//	u16*		_frames_nfm;		// number of FModules (max 65536 FModules/Frame)
	u16*		_frames_fm_start;	// index of first FModule
	s8*			_frames_rc;			// frame bound rect, 4 bytes
	//	s8			x;					// 0 : x position
	//	s8			y;					// 1 : y position
	//	u8			w;					// 2 : width
	//	u8			h;					// 3 : height

	// FModules...
	int			_nFModules;			// number of frame modules
	u8*			_fmodules;			// 6 bytes for each FModule
	//	u8			_module;			// 0 : module index
	//	s16			_ox;				// 1, 2 : ox
	//	s16			_oy;				// 3, 4 : oy
	//	u8			_flags;				// 5 : flags

	//////////////////////////////////////////////////

	// Anims...
	int			_nAnims;			// number of animations
	u8*			_anims_naf;			// number of AFrames (max 256 AFrames/Anim)
//	u16*		_anims_naf;			// number of AFrames (max 65536 AFrames/Anim)
	u16*		_anims_af_start;	// index of first AFrame

	// AFrames...
	int			_nAFrames;			// number of animation frames
	u8*			_aframes;			// 5 bytes for each AFrame
	//	u8			_frame;				// 0 : frame index
	//	u8			_time;				// 1 : time
	//	s8			_ox;				// 2 : ox
	//	s8			_oy;				// 3 : oy
	//	u8			_flags;				// 4 : flags

	//////////////////////////////////////////////////

	// Module mappings...
//	int			_nMMappings;			// number of module mappings
//	int**		_pMMappings; 			// all module mappings
//	int			_nCrtMMaping;			// current module mapping

	// Palettes...
//	u16			_pixel_format;		// always converted to PIXEL_FORMAT_0565
	int			_nPalettes;			// number of palettes
	int			_nColors;			// number of colors in each palette
	u16**		_pPalettes;			// palettes
	u16*		_pCrtPalette;		// current palette
//	boolean		_alpha;				// has transparency ?
//	int			_flags;				// transparency, etc.

	// Graphics data (for each module)...
	u16			_data_format;		// data format
	u8**		_pModulesData;		// encoded image data for each module
	u16*		_pModulesDataSize;	// size of each module's image data
	Image**		_pModulesImages;	// cache image for each module / with each palette

	//////////////////////////////////////////////////
	// Draw String

	//	_modules[0] -> w  -> width of the space character (' ')
	//	_modules[1] -> h  -> height of a text line
	//	_fmodules[0*4+1] -> ox -> space between two adiacent chars
	//	_fmodules[0*4+2] -> oy -> base line offset

	int _line_spacing;	// space between two lines of text

	int _index1;
	int _index2;

	//////////////////////////////////////////////////

	gxGraphics*	pDevice;	// device on which the sprites are rendered

}; // class ASprite

#endif // _AURORA_SPRITE_H_

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
