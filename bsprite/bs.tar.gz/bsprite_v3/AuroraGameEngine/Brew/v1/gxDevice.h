// gxDevice.h
////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __GX_DEVICE_H__
#define __GX_DEVICE_H__

////////////////////////////////////////////////////////////////////////////////////////////////////
// Options...

// Target device...
//	#define TARGET_NGAGE			// Nokia NGage
	#define TARGET_LGE_VX8000		// LGE VX8000
//	#define TARGET_SAMSUNG_A890		// Samsung A890
//	#define TARGET_AUDIOVOX_8940	// Audiovox 8940

// Operating Systems avaiable:
//	#define OS_SYMBIAN
//	#define OS_BREW
//	#define OS_WIN32
#if defined(AEE_SIMULATOR)
	#define OS_BREW
#endif

// Pixel Formats avaiable:
//	#define PF_RGB444
//	#define PF_RGB565

//#define CACHE_FILES		//Define this to load files into memory when opening them

////////////////////////////////////////////////////////////////////////////////////////////////////

#if defined(TARGET_NGAGE)

//	#define OS_SYMBIAN
	#define PF_RGB444
	#define GX_SCREEN_W		176
	#define GX_SCREEN_H		208

#elif defined(TARGET_LGE_VX8000) | defined(TARGET_SAMSUNG_A890) | defined(TARGET_AUDIOVOX_8940)

	#define TARGET_VCAST
//	#define OS_BREW
	#define PF_RGB565
	#define GX_SCREEN_W		176
	#define GX_SCREEN_H		203

#endif

////////////////////////////////////////////////////////////////////////////////////////////////////

#if defined(_WINDOWS) || defined(WIN32)

	#define GX_DEBUG
//	#define GX_CHECK_MATH
//	#define CHECK_MEMORY_LEAKS

	#pragma warning(disable:4786)
	#pragma warning(disable:4503)
	#pragma warning(disable:4311)
	#pragma warning(disable:4312)

#endif

////////////////////////////////////////////////////////////////////////////////////////////////////
//RedStorm's Reminder: usage: #pragma REMINDER("type your message")
//Will show up at compile time and will allow go-to-line with double-click.

#ifdef _DEBUG
  #define REMINDER_STR(x)	#x
  #define REMINDER_STR2(x)	REMINDER_STR(x)
  #define REMINDER(msg)		message(__FILE__ "(" REMINDER_STR2(__LINE__) ") : " msg)
  #define HARDCODED(v)		message(__FILE__ "(" REMINDER_STR2(__LINE__) ") : warning: '"#v"' : value is hardcoded")
#else
  #define REMINDER_STR(x)
  #define REMINDER_STR2(x)
  #define REMINDER(msg)
  #define HARDCODED(v)
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////

#if defined(OS_BREW)
	#include "AEEModGen.h"	// Module interface definitions
	#include "AEEAppGen.h"	// Applet interface definitions
	#include "AEEShell.h"	// Shell interface definitions
	#include "AEEStdLib.h"	// Std Functions
	#include "AEEFile.h"	// File interface definitions
	#include "AEEGraphics.h"	// Graphics definitions
	#include "AEEHeap.h"		// Heap management definitions
	#include "AEEMEdia.h"
	#include "AEEMediaFormats.h"
	#include "AEEMediaUtil.h"
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////
// Limits...

#define MAX_INT			0x7FFFFFFF
#define MAX_UINT		0xFFFFFFFF
#define MAX_SHORT		0x7FFF
#define MAX_USHORT		0xFFFF

////////////////////////////////////////////////////////////////////////////////////////////////////

typedef unsigned char	u8;
typedef signed char		s8;
typedef unsigned short	u16;
typedef signed short	s16;
typedef unsigned int	u32;
typedef signed int		s32;

////////////////////////////////////////////////////////////////////////////////////////////////////
#if !defined(OS_SYMBIAN)

typedef unsigned char	TUint8;
typedef signed char		TInt8;
typedef unsigned short	TUint16;
typedef signed short	TInt16;
typedef unsigned int	TUint32;
typedef signed int		TInt32;
typedef unsigned int	TUint;
typedef signed int		TInt;

#endif
////////////////////////////////////////////////////////////////////////////////////////////////////

#if defined(OS_WIN32)

	// WIN32 APP ***********************************************************************************

	#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
	#include <windows.h>
	#include <math.h>
	#include <assert.h>
	#include <stdlib.h>
	#include <malloc.h>
	#include <memory.h>
	#include <tchar.h>
	#include <stdio.h>
	#include <string.h>
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <fcntl.h>
	#include <io.h>

	#define GX_ASSERT_GAPI(arg1, __ga)		assert(arg1)
	#define GX_ASSERT_BREW(arg1)			assert(arg1)
	#define GX_ASSERT(arg1)					assert(arg1)
	#define GX_WARNING						printf

	#define DBGPRINTF						printf
	#define PRINTF							printf
	#define SPRINTF							sprintf

	#define GX_MALLOC(size)					malloc(size)
//	#define GX_MALLOC(size)					NEW u8[size]
	#define GX_FREE(ptr)					free(ptr)
//	#define GX_FREE(ptr)					DELETE_ARRAY(ptr)
	#define GX_REALLOC(ptr, size)			realloc(ptr, size)

	#define GX_MEMCPY(dest, src, size)		memcpy(dest, src, size)
	#define GX_MEMSET(dest, data, size)		memset(dest, data, size)

	#define GX_STRLEN(string)				lstrlen(string)
	#define GX_STRCPY(dest, src)			strcpy(dest, src)
	#define GX_STRNCPY(dest, src, n)		strncpy(dest, src, n)
	#define GX_STRCMP(dest, src)			strcmp(dest, src)
	#define GX_STRCAT(dest, src)			strcat(dest, src)
	#define GX_STRDUP(src)					strdup(src)

	//Floating point operators
	#define GX_FADD(f1, f2)					(f1 + f2)
	#define GX_FSUB(f1, f2)					(f1 - f2)
	#define	GX_FMUL(f1, f2)					(f1 * f2)
	#define GX_FDIV(f1, f2)					(f1 / f2)
	#define GX_FSQRT(f1)					sqrt(f1)
	
//	inline u32	GX_FILEREAD(void* ptr, u32 size, u32 id)	{ return (u32)fread(ptr, 1, size, (FILE*)id); } // return 0 if read not fully done
//	inline u32	GX_FILEOPEN(char* name)						{ return (u32)fopen(name, "rb"); } // return 0 if not opened
//	inline void	GX_FILECLOSE(u32 id)						{ fclose((FILE*)id); }

	void debug_out(const char* fmt, ...);
	#define DEBUG_OUT	debug_out
//	#define DEBUG_OUT

#elif defined(OS_SYMBIAN)

	// SYMBIAN EMULATOR OR REAL DEVICE *************************************************************

	#include <assert.h>
	#include <stdlib.h>
	#include <string.h>

	#define GX_ASSERT						assert
	#define GX_WARNING						printf

	#define PRINTF							printf
	#define SPRINTF							sprintf

	#define GX_MEMCPY						memcpy
	#define GX_MEMSET						memset

	#define GX_STRLEN						strlen
	#define GX_STRCPY						strcpy
	#define GX_STRNCPY						strncpy
	#define GX_STRCMP						strcmp

//	void debug_out(const char* fmt, ...);
//	#define DEBUG_OUT	debug_out
	#define DEBUG_OUT

#elif defined(OS_BREW)

	#ifdef WIN32

	// BREW DLL UNDER WINDOWS EMULATOR *************************************************************

	#define GX_ASSERT_GAPI(arg1, __ga)		{ if (!(arg1)) { DBGPRINTF("!A:" #arg1, __LINE__); __ga->quit(1); } }
	#define GX_ASSERT_BREW(arg1)			{ if (!(arg1)) { DBGPRINTF("!A:" #arg1, __LINE__); pMe->_quit=1; } }
	#define GX_ASSERT(arg1)					{ if (!(arg1)) { DBGPRINTF("!A:" #arg1, __LINE__); } }
	#define GX_WARNING						DBGPRINTF

	#define GX_MALLOC(size)					MALLOC(size)
	#define GX_FREE(ptr)					FREE(ptr)
	#define GX_REALLOC(ptr, size)			REALLOC(ptr, size)

	#define GX_MEMCPY(dest, src, size)		MEMCPY(dest, src, size)
	#define GX_MEMSET(dest, data, size)		MEMSET(dest, data, size)

	#define GX_STRLEN(string)				STRLEN(string)
	#define GX_STRCPY(dest, src)			STRCPY(dest, src)
	#define GX_STRNCPY(dest, src, n)		STRNCPY(dest, src, n)
	#define GX_STRCMP(dest, src)			STRCMP(dest, src)
	#define GX_STRCAT(dest, src)			STRCAT(dest, src)
	#define GX_STRDUP(src)					STRDUP(src)

	//Floating point operators
	#define GX_FADD(f1, f2)					(float)FADD(f1, f2)
	#define GX_FSUB(f1, f2)					(float)FSUB(f1, f2)
	#define	GX_FMUL(f1, f2)					(float)FMUL(f1, f2)
	#define GX_FDIV(f1, f2)					(float)FDIV(f1, f2)
	#define GX_FSQRT(f1)					(float)FSQRT(f1)

//	inline u32	GX_FILEREAD(void* /*ptr*/, u32 /*size*/, u32 /*id*/)	{ GX_ASSERT(0); return 0; }
//	inline u32	GX_FILEOPEN(char* /*name*/)								{ GX_ASSERT(0); return 0; }
//	inline void	GX_FILECLOSE(u32 /*id*/)								{ GX_ASSERT(0); }

	void debug_out(const char* fmt, ...);
	#define DEBUG_OUT	debug_out
//	#define DEBUG_OUT	DBGPRINTF
//	#define DEBUG_OUT

	#else

	// BREW ON REAL DEVICE *************************************************************************

	#define GX_ASSERT_GAPI(arg1, __ga)		{}
	#define GX_ASSERT_BREW(arg1)			{}
	#define GX_ASSERT(arg1)					{}
	#define GX_WARNING						

//	#define GX_ASSERT_GAPI(arg1, __ga)		if (!(arg1)) { DBGPRINTF("!A:" #arg1, __LINE__); __ga->quit(1); }
//	#define GX_ASSERT_BREW(arg1)			if (!(arg1)) { DBGPRINTF("!A:" #arg1, __LINE__); pMe->_quit=1; }
//	#define GX_ASSERT(arg1)					if (!(arg1)) { DBGPRINTF("!A:" #arg1, __LINE__); }

	#define GX_MALLOC(size)					MALLOC(size)
	#define GX_FREE(ptr)					FREE(ptr)
	#define GX_REALLOC(ptr, size)			REALLOC(ptr, size)

	#define GX_MEMCPY(dest, src, size)		MEMCPY(dest, src, size)
	#define GX_MEMSET(dest, data, size)		MEMSET(dest, data, size)

	#define GX_STRLEN(string)				STRLEN(string)
	#define GX_STRCPY(dest, src)			STRCPY(dest, src)
	#define GX_STRNCPY(dest, src, n)		STRCPY(dest, src, n)
	#define GX_STRCMP(dest, src)			STRCMP(dest, src)
	#define GX_STRCAT(dest, src)			STRCAT(dest, src)
	#define GX_STRDUP(src)					STRDUP(src)

	//Floating point operators
	#define GX_FADD(f1, f2)					(float)FADD(f1, f2)
	#define GX_FSUB(f1, f2)					(float)FSUB(f1, f2)
	#define	GX_FMUL(f1, f2)					(float)FMUL(f1, f2)
	#define GX_FDIV(f1, f2)					(float)FDIV(f1, f2)
	#define GX_FSQRT(f1)					(float)FSQRT(f1)

//	inline u32	GX_FILEREAD(void* /*ptr*/, u32 /*size*/, u32 /*id*/)	{ GX_ASSERT(0); return 0; }
//	inline u32	GX_FILEOPEN(char* /*name*/)								{ GX_ASSERT(0); return 0; }
//	inline void	GX_FILECLOSE(u32 /*id*/)								{ GX_ASSERT(0); }

	void debug_out(const char* fmt, ...);
//	#define DEBUG_OUT	debug_out
//	#define DEBUG_OUT	DBGPRINTF
	#define DEBUG_OUT

	#endif

#endif

////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef PF_RGB444

	#define COLOR_MASK_R		0x0F00	// 0000111100000000
	#define COLOR_MASK_G		0x00F0	// 0000000011110000
	#define COLOR_MASK_B		0x000F	// 0000000000001111

	#define COLOR_BITS_R		4
	#define COLOR_BITS_G		4
	#define COLOR_BITS_B		4

	// 1 (444)
	#define COLOR_ONE_SHIFT_R	8	// <<
	#define COLOR_ONE_SHIFT_G	4	// <<
	#define COLOR_ONE_SHIFT_B	0	// <<

	// max (444)
	#define COLOR_SHIFT_R		12	// <<
	#define COLOR_SHIFT_G		8	// <<
	#define COLOR_SHIFT_B		4	// <<

	#define R8(col)				(((col) & COLOR_MASK_R) >> (COLOR_SHIFT_R - 8))
	#define G8(col)				(((col) & COLOR_MASK_G)                       )
	#define B8(col)				(((col) & COLOR_MASK_B) << (8 - COLOR_SHIFT_B))

	#define R_FROM_R8(col)		(((col) << (COLOR_SHIFT_R - 8)) & COLOR_MASK_R)
	#define G_FROM_G8(col)		(((col))                        & COLOR_MASK_G)
	#define B_FROM_B8(col)		(((col) >> (8 - COLOR_SHIFT_B)) & COLOR_MASK_B)

	#define COLOR32TO16ARGB(color) ((unsigned short)(((color & 0x00F00000) >> 12) |	\
													 ((color & 0x0000F000) >> 8) |	\
													 ((color & 0x000000F0) >> 4)))

	#define COLOR_BLACK16		0x0001

#endif

////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef PF_RGB565

	#define COLOR_MASK_R		0xF800	// 1111100000000000
	#define COLOR_MASK_G		0x07E0	// 0000011111100000
	#define COLOR_MASK_B		0x001F	// 0000000000011111

	#define COLOR_BITS_R		5
	#define COLOR_BITS_G		6
	#define COLOR_BITS_B		5

	// 1 (565)
	#define COLOR_ONE_SHIFT_R	11	// <<
	#define COLOR_ONE_SHIFT_G	5	// <<
	#define COLOR_ONE_SHIFT_B	0	// <<

	// max (565)
	#define COLOR_SHIFT_R		16	// <<
	#define COLOR_SHIFT_G		11	// <<
	#define COLOR_SHIFT_B		5	// <<

	#define R8(col)				(((col) & COLOR_MASK_R) >> (COLOR_SHIFT_R - 8))
	#define G8(col)				(((col) & COLOR_MASK_G) >> (COLOR_SHIFT_G - 8))
	#define B8(col)				(((col) & COLOR_MASK_B) << (8 - COLOR_SHIFT_B))

	#define R_FROM_R8(col)		(((col) << (COLOR_SHIFT_R - 8)) & COLOR_MASK_R)
	#define G_FROM_G8(col)		(((col) << (COLOR_SHIFT_G - 8)) & COLOR_MASK_G)
	#define B_FROM_B8(col)		(((col) >> (8 - COLOR_SHIFT_B)) & COLOR_MASK_B)

	#define COLOR32TO16ARGB(color) ((unsigned short)(((color & 0x00F80000) >> 8) |	\
													 ((color & 0x0000FC00) >> 5) |	\
													 ((color & 0x000000F8) >> 3)))

	#define COLOR_BLACK16		0x0020

#endif

////////////////////////////////////////////////////////////////////////////////////////////////////

#define R(col)				((col) & COLOR_MASK_R)
#define CLAMP_R(col)		{ if (col > COLOR_MASK_R) col = COLOR_MASK_R; }

#define G(col)				((col) & COLOR_MASK_G)
#define CLAMP_G(col)		{ if (col > COLOR_MASK_G) col = COLOR_MASK_G; }

#define B(col)				((col) & COLOR_MASK_B)
#define CLAMP_B(col)		{ if (col > COLOR_MASK_B) col = COLOR_MASK_B; }

#define TRANSPARENT_LONG	0
#define IS_OPAQUE(x)		(x)	// returns true if x is an opaque color

////////////////////////////////////////////////////////////////////////////////////////////////////

#if !defined(OS_BREW)
#define MIN(x,y)		((x)<(y)?(x):(y))
#define MAX(x,y)		((x)>(y)?(x):(y))
#define ABS(x)			((x)<0?-(x):(x))
#endif

#define SGN(x)			(((x)>0)?1:-1)
#define SQR(x)			((x)*(x))

////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef GX_CHECK_MATH

	#include <limits.h>

	inline void _Check_Int_Limit(double x)
	{
		GX_ASSERT(x <= double(INT_MAX) && x >= double(INT_MIN));
	}

	inline void _Check_Short_Limit(double x)
	{
		GX_ASSERT(x <= double(SHRT_MAX) && x >= double(SHRT_MIN));
	}

	inline void _Check_Precision(double fResult, int nResult, double fTolerancePercentage)
	{
		double fError = GX_FSUB(fResult, nResult);
		if (fError < 0) fError = -fError;
		double fTolerance = GX_FDIV(GX_FMUL(fTolerancePercentage, fResult), 100);
		if (fTolerance < 0) fTolerance = -fTolerance;
		GX_ASSERT(int(fError) <= int(fTolerance)); // always tolerate decimal error
	}

	inline void _Check_Add(double x, double y) { _Check_Int_Limit(GX_FADD(x, y)); }
	inline void _Check_Mul(double x, double y) { _Check_Int_Limit(GX_FMUL(x, y)); }

	#define CHECK_LIMIT(x)			_Check_Int_Limit(x);
	#define CHECK_SHORT_LIMIT(x)	_Check_Short_Limit(x);
    #define CHK_PRECISION(f,n,t)	_Check_Precision(f,n,t);
	#define CHK_ADD(x, y)			_Check_Add(double(x), double(y))
	#define CHK_MUL(x, y)			_Check_Mul(double(x), double(y))

#else

	#define CHECK_SHORT_LIMIT(x)
	#define CHECK_LIMIT(x)
    #define CHK_PRECISION(fResult, nResult, fTolerancePercentage)
	#define CHK_ADD(x, y)
	#define	CHK_MUL(x, y)

#endif // GX_CHECK_MATH

#define CHK_ADD3(x1,x2,x3)					{ CHK_ADD(x1,x2); CHK_ADD((x1)+(x2),x3); }
#define CHK_MUL2_ADD3(x1,x2,y1,y2,z1,z2)	{ CHK_MUL(x1,x2); CHK_MUL(y1,y2); CHK_MUL(z1,z2); CHK_ADD3((x1)*(x2),(y1)*(y2),(z1)*(z2)); }

////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef __WINS__
	// disable dynamic cast
	template<class C, class T> C wins_dynamic_cast(T in_Par) { return *((C*)&(in_Par)); }
	#define dynamic_cast wins_dynamic_cast
#endif

#ifndef NEW
#define NEW				new
#endif

#ifndef DELETE
#define DELETE			delete
#endif

#ifndef DELETE_ARRAY
#define DELETE_ARRAY	delete[]
#endif

#ifndef NULL
#define	NULL	0L
#endif

#define SAFE_DEL(p)					{ if (p) { delete (p); p = NULL; } }
#define SAFE_DEL_ARRAY(p)			{ if (p) { delete[] (p); p = NULL; } }
#define SAFE_DEL_ARRAY_OBJ(p, n)	{ if (p) { for (int i = 0; i < n; i++) SAFE_DEL((p)[i]); delete[] (p); p = NULL; } }
#define SAFE_DEL_ARRAY_ARRAY(p, n)	{ if (p) { for (int i = 0; i < n; i++) SAFE_DEL_ARRAY((p)[i]); delete[] (p); p = NULL; } }

#define SAFE_NEW_RET(p,t,s)			{ p = new t[s]; if ((p) == NULL) { return FALSE; } }
#define SAFE_NEW_CLEAN(p,t,s)		{ p = new t[s]; if ((p) != NULL) MEMSET((u8*)(p), 0, (s)*(sizeof(t))); }
#define SAFE_NEW_CLEAN_RET(p,t,s)	{ p = new t[s]; if ((p) == NULL) { return FALSE; } MEMSET((u8*)(p), 0, (s)*(sizeof(t))); }

#ifndef GX_DEBUG
	#ifdef GX_ASSERT
	#undef GX_ASSERT
	#endif
	#define GX_ASSERT(a)
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////

#endif // __GX_DEVICE_H__

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
