// Image.h
////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _IMAGE_H
#define _IMAGE_H

////////////////////////////////////////////////////////////////////////////////////////////////////

class gxGraphics;

////////////////////////////////////////////////////////////////////////////////////////////////////

//Image draw flags
#define FX_NORMAL				(0x00)
#define FX_FLIP_H               (0x01)
#define FX_FLIP_V               (0x02)
#define FX_FLIP_HV              (FX_FLIP_H|FX_FLIP_V)

////////////////////////////////////////////////////////////////////////////////////////////////////

class Image
{
public:
	Image();
	~Image();

	//Initializes an image's resources
	void init(u8* data, int w, int h);

	//Sets an active palette
	void setPalette(u16* pal);

	//Sets the raster device
	void setRasterDevice(gxGraphics* newDevice)
	{	
		pDevice	= newDevice;
		nPitch = pDevice->GetWidth() << 1;
	}

	//Sets the render function to be used
	void setOpacity(unsigned char flag);

	//Renders the image
	inline void	draw(int xs, int ys, int w, int h, int xd, int yd, u8 fx)
	{
		(this->*rfun)(xs, ys, w, h, xd, yd, fx);
	}

private:
	//Render functions
	void (Image::*rfun)(int xs, int ys, int w, int h, int xd, int yd, u8 fx);	//Pointer to image's rendering function

	//Draws (w, h) of the image on screen, at (xs, ys).
	void drawFull(int xs, int ys, int w, int h, int xd, int yd, u8 fx);
	void drawAlpha_25(int xs, int ys, int w, int h, int xd, int yd, u8 fx);
	void drawAlpha_50(int xs, int ys, int w, int h, int xd, int yd, u8 fx);
	void drawAlpha_75(int xs, int ys, int w, int h, int xd, int yd, u8 fx);

private:
	gxGraphics*			pDevice;
	u8*					pixels;
	int					nPitch;
	int					width;
	int					height;
	u16*				palette;
	cGame*				pGame;
};

////////////////////////////////////////////////////////////////////////////////////////////////////

#endif

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
