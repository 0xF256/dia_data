// gxGraphics.cpp
////////////////////////////////////////////////////////////////////////////////////////////////////

#include "gxGraphics.h"

////////////////////////////////////////////////////////////////////////////////////////////////////

gxGraphics::gxGraphics()
{
	data			= NULL;
	size_w			= 0;
	size_h			= 0;

	clip_xs			= 0;
	clip_ys			= 0;
	clip_xe			= 0;
	clip_ye			= 0;
	clip_w			= 0;
	clip_h			= 0;

	_currentColor	= 0x00000000;
	_currentColor16	= 0x0000;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

gxGraphics::~gxGraphics()
{
//	if (bLocalBuffer)
//		SAFE_DEL_ARRAY(data);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void gxGraphics::SetDataBuffer(void* pData, int width, int height)
{
	data	= pData;
	size_w	= width;
	size_h	= height;

	setClip(0, 0, width, height);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void gxGraphics::setColor(int color)
{
	_currentColor = (u32)color;
	_currentColor16 = COLOR32TO16ARGB(color);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void gxGraphics::setClip(int x, int y, int w, int h)
{
	if (x < 0)			{ w += x; x = 0; }
	if (y < 0)			{ h += y; y = 0; }
	if (x + w > size_w)	w = size_w - x;
	if (y + h > size_h)	h = size_h - y;

	if ((w <= 0) || (h <= 0))
	{
		clip_w = 0;
		clip_h = 0;
		clip_xs = 0;
		clip_ys = 0;
		clip_xe = 0;
		clip_ye = 0;
	//	IDISPLAY_SetClipRect(m_pIDisplay, NULL);
		return;
	}

	clip_w = w;
	clip_h = h;
    clip_xs = x;
    clip_ys = y;
    clip_xe = x + w;
    clip_ye = y + h;
/*
	AEERect r;
    r.x = x;
    r.y = y;
	r.dx = w;
	r.dy = h;
	IDISPLAY_SetClipRect(m_pIDisplay, &r);
*/
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void gxGraphics::fillRect(int x, int y, int w, int h)
{
	register int xcs = clip_xs;
	register int ycs = clip_ys;
	register int xce = clip_xe;
	register int yce = clip_ye;

	if ((x >= xce) || (x <= (xcs - w))) return;
	if ((y >= yce) || (y <= (ycs - h))) return;

	if ((x + w) > xce)
		w = xce - x;

	if (x < xcs)
	{
		w -= xcs - x;
		x = xcs;
	}

	if (w <= 0)
		return;

	if ((y + h) > yce)
		h = yce - y;

	if (y < ycs)
	{
		h -= ycs - y;
		y = ycs;
	}

	if (h <= 0)
		return;

	u16 _col = COLOR32TO16ARGB(_currentColor);
	u16* dst = (u16*)data + y * size_w + x;

	int off_w = size_w - w;

	while (h--)
	{
		int ww = w;
		while (ww--)
			*dst++ = _col;
		dst += off_w;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void gxGraphics::fillRectAlpha(int x, int y, int w, int h)
{
	register int xcs = clip_xs;
	register int ycs = clip_ys;
	register int xce = clip_xe;
	register int yce = clip_ye;

	if ((x >= xce) || (x <= (xcs - w))) return;
	if ((y >= yce) || (y <= (ycs - h))) return;

	if ((x + w) > xce)
		w = xce - x;

	if (x < xcs)
	{
		w -= xcs - x;
		x = xcs;
	}

	if (w <= 0)
		return;

	if ((y + h) > yce)
		h = yce - y;

	if (y < ycs)
	{
		h -= ycs - y;
		y = ycs;
	}

	if (h <= 0)
		return;

	u16* dst = (u16*)data + y * size_w + x;
	int off_w = size_w - w;

	int inv_alpha = ((_currentColor & 0xFF000000) >> 24);
	int alpha = 0xFF - inv_alpha;
	int sr = ((_currentColor & 0x00FF0000) >> 16) * inv_alpha;
	int sg = ((_currentColor & 0x0000FF00) >>  8) * inv_alpha;
	int sb = ((_currentColor & 0x000000FF)      ) * inv_alpha;

	while (h--)
	{
		int ww = w;
		while (ww--)
		{
			u32 s_color = *dst;
			*dst++ = (u16)(	R_FROM_R8((R8(s_color) * alpha + sr) >> 8) |
							G_FROM_G8((G8(s_color) * alpha + sg) >> 8) |
							B_FROM_B8((B8(s_color) * alpha + sb) >> 8));
		}
		dst += off_w;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void gxGraphics::drawLine(int xs, int ys, int xe, int ye)
{
//	int	dX = xe - xs;
//	int	dY = ye - ys;

	// Clip line to ensure we are in the frame-buffer memory...
	if (!clipLine(xs, ys, xe, ye))
		return;

	int dx = xe - xs;
	int dy = ye - ys;

	if (!dx && !dy)
		return;	// not a line

	int xinc = 1;
	int yinc = 1;
	int width = GX_SCREEN_W;

	if (dx < 0)	{ xinc = -1; dx = -dx; }
	if (dy < 0)	{ yinc = -1; dy = -dy; width = -width; }

	u16* buffer = ((u16*)data) + ys * GX_SCREEN_W + xs;

	if (dy < dx)
	{
		// X major

		int x = xs;
		int y = ys;
		int d = 0;

		int c = dx << 1;
		int m = dy << 1;

		while (x != xe)
		{
			*buffer++ = _currentColor16;

			if (xinc < 0)
				buffer -= 2;

			x += xinc;
			d += m;

			if (d > dx)
			{
				y += yinc;
				d -= c;
				buffer -= width;
			}
		}
	}
	else
	{
		// Y major

		int x = xs;
		int y = ys;
		int d = 0;

		int c = dy << 1;
		int m = dx << 1;

		while (y != ye)
		{
			*buffer = _currentColor16;
			buffer -= width;

			y += yinc;
			d += m;

			if (d > dy)
			{
				x += xinc;
				d -= c;
				buffer += xinc;
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Clips a line's start and end points so that it lies in the screen

bool gxGraphics::clipLine(int & xs, int & ys, int & xe, int & ye)
{
	int X1 = clip_xs;
	int Y1 = clip_ys;
	int X2 = clip_xe - 1;
	int Y2 = clip_ye;

	//Test the particular case when ye == ys or xe == xs
	int cs = ((xs < X1) << 3) | ((xs > X2) << 2) | ((ys < Y1) << 1) | (ys > Y2);
	int ce = ((xe < X1) << 3) | ((xe > X2) << 2) | ((ye < Y1) << 1) | (ye > Y2);

	if (cs & ce)
		return false; //Line is not on screen

	//Tests made to prevent division by zero
	if (xe == xs)
	{
		if		(ys < Y1)	ys = Y1;
		else if	(ys > Y2)	ys = Y2;
		if		(ye < Y1)	ye = Y1;
		else if	(ye > Y2)	ye = Y2;
		return true;
	}

	if (ye == ys)
	{
		if		(xs < X1)	xs = X1;
		else if	(xs > X2)	xs = X2;
		if		(xe < X1)	xe = X1;
		else if	(xe > X2)	xe = X2;
		return true;
	}

	//Calculate the slope of the line
	int m   = ((ye - ys) << 16) / (xe - xs);
	int m_1 = ((xe - xs) << 16) / (ye - ys);

	while (cs | ce)
	{
		cs = ((xs < X1) << 3) | ((xs > X2) << 2) | ((ys < Y1) << 1) | (ys > Y2);
		ce = ((xe < X1) << 3) | ((xe > X2) << 2) | ((ye < Y1) << 1) | (ye > Y2);

		if (cs & ce)
			return false;	//Line is not on the screen

		if (cs)
		{
			if (cs & 8)
			{	
				ys += (((X1 - xs)*m) >> 16);
				xs = X1;	
			}
			else if (cs & 4)
			{
				ys += (((X2 - xs)*m) >> 16);
				xs = X2; 
			}
			else if (cs & 2)
			{
				xs += (((Y1 - ys)*m_1) >> 16);
				ys = Y1;
			}
			else if (cs & 1)
			{	
				xs += (((Y2 - ys)*m_1) >> 16);
				ys = Y2;
			}
		}

		//See if line is on the screen
		cs = ((xs < X1) << 3) | ((xs > X2) << 2) | ((ys < Y1) << 1) | (ys > Y2);
		if (cs & ce)
			return false;	

		if (ce)
		{
			if (ce & 8)
			{
				ye += (((X1 - xe) * m) >> 16);
				xe = X1; 
			}
			else if (ce & 4)
			{
				ye += (((X2 - xe) * m) >> 16);
				xe = X2; 
			}
			else if (ce & 2)
			{
				xe += (((Y1 - ye) * m_1) >> 16);
				ye = Y1; 
			}
			else if (ce & 1)
			{
				xe += (((Y2 - ye) * m_1) >> 16);
				ye = Y2;
			}
		}

		if (xe == xs)
		{
			if		(ys < Y1)	ys = Y1;
			else if	(ys > Y2)	ys = Y2;
			if		(ye < Y1)	ye = Y1;
			else if	(ye > Y2)	ye = Y2;
			return true;
		}

		if (ye == ys)
		{
			if		(xs < X1)	xs = X1;
			else if	(xs > X2)	xs = X2;
			if		(xe < X1)	xe = X1;
			else if	(xe > X2)	xe = X2;
			return true;
		}
	}

	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void gxGraphics::fillMenuRect(int x, int y, int w, int h)
{
	int pitch = size_w;
	u16* p = ((u16*)data) + pitch * y;

	if (x < 0) { w += x; x = 0; }
	if (w <= 0) return;

	int off_x = pitch - w;
	int iy = h-1;
	while (iy--)
	{
		int ix = w;
		while (ix--)
		{
			u32 a = 0xFF - (ix * 0x88) / w;
			u32 s_color = *p;
			*p++ = (u16)(R_FROM_R8((R8(s_color) * a) >> 8) |
				G_FROM_G8((G8(s_color) * a) >> 8) |
				B_FROM_B8((B8(s_color) * a) >> 8));
		}
		p += off_x;
	}

	// Last line...
	{
		int ix = w;
		while (ix--)
		{
			u32 a = 0xFF - (ix * 0xFF) / w;
			u32 s_color = *p;
			*p++ = (u16)(R_FROM_R8((R8(s_color) * a) >> 8) |
				G_FROM_G8((G8(s_color) * a) >> 8) |
				B_FROM_B8((B8(s_color) * a) >> 8));
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
