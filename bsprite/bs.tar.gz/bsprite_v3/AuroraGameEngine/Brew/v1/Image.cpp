// Image.cpp
////////////////////////////////////////////////////////////////////////////////////////////////////

#include "Image.h"
#include "LZMAFile.h"
#include "Game.h"

////////////////////////////////////////////////////////////////////////////////////////////////////

//Image implementation
Image::Image()
{
	rfun	= &Image::drawFull;
	pDevice	= NULL;
	pixels	= NULL;
	nPitch	= GX_SCREEN_W * 2;// pGame->_dib_buffer->nPitch;
	width	= 0;
	height	= 0;
	palette	= NULL;
	pGame	= cGame::getGame();
}

Image::~Image()
{
	SAFE_DEL_ARRAY(pixels);
}

//Initializes an image's resources
void Image::init(u8 * data, int w, int h)
{
	pixels	= data;
	width	= w;
	height	= h;
}

//Sets an active palette
void Image::setPalette(u16* pal)
{
	palette = pal;
}

//Sets the render function to be used
void Image::setOpacity(unsigned char flag)
{
#define OPACITY_MASK	0x0C
#define OPACITY_25		0x04
#define OPACITY_50		0x08
#define OPACITY_75		0x0C

	flag &= OPACITY_MASK;

		 if (flag == OPACITY_25)	rfun = &Image::drawAlpha_25;
	else if (flag == OPACITY_50)	rfun = &Image::drawAlpha_50;
	else if (flag == OPACITY_75)	rfun = &Image::drawAlpha_75;
	else							rfun = &Image::drawFull;

#undef OPACITY_75
#undef OPACITY_50
#undef OPACITY_25
#undef OPACITY_MASK
}

//Draws (w, h) of the image on screen, at (xs, ys).
void Image::drawFull(int xs, int ys, int w, int h, int xd, int yd, u8 fx)
{
	typedef unsigned short Pixel_Type;

	if (!pixels || !palette)
		return;

	//Clipping part
	register int xcs = pDevice->GetClipXS();
	register int ycs = pDevice->GetClipYS();
	register int xce = pDevice->GetClipXE();
	register int yce = pDevice->GetClipYE();
	register int dd = 0;
	u8* buffer = (u8*)pDevice->GetData();

	{
		if ((xd >= xce) || (xd <= (xcs - w)))
			return;
		if ((yd >= yce) || (yd <= (ycs - h)))
			return;

		if ((xd + w) > xce)
		{
			xce	-= (xd + w);
			w	+= xce;
		}
		else
			xce = 0;

		if (xd < xcs)
		{
			dd	= xcs - xd;
			xce	+= dd;
			w	-= dd;
			xs	+= dd;
			xd	= xcs;
		}

		if ((w <= 0) || (xs >= width))
			return;

		if ((yd + h) > yce)
		{
			yce	-= (yd + h);
			h	+= yce;
		}
		else
			yce = 0;

		if (yd < ycs)
		{
			dd	= ycs - yd;
			yce	+= dd;
			h	-= dd;
			ys	+= dd;
			yd	= ycs;
		}

		if ((h <= 0) || (ys >= height))
			return;
	}


	u8* source = NULL;
	register u16 ctr;

	{
		register int	_inc2	= nPitch;
		register int	_inc1	= _inc2 - (w * sizeof(Pixel_Type));

		Pixel_Type	*	screen		= NULL;
		Pixel_Type	*	screen_line	= NULL;
		Pixel_Type	*	screen_end	= NULL;

		screen		= (Pixel_Type*)(buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type)));
		screen_line	= (Pixel_Type*)(((u8*)screen) + (w * sizeof(Pixel_Type)));
		screen_end	= (Pixel_Type*)(((u8*)screen) + (h * _inc2));

		u8 index;

		if ((fx & FX_FLIP_HV) == FX_FLIP_HV)
		{
			source	= pixels + ((ys + h - 1 - yce) * width) + (xs + w - 1 - xce);
			w		-= width;

			do
			{
				index	= *source--;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					*screen	= (Pixel_Type)ctr;
				screen++;
				if (screen >= screen_line)
				{
					source		+= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else if (fx & FX_FLIP_H)
		{
			source	= pixels + (ys * width) + (xs + w - 1 - xce);
			w		+= width;

			do
			{
				index	= *source--;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					*screen	= (Pixel_Type)ctr;
				screen++;
				if (screen >= screen_line)
				{
					source		+= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else if (fx & FX_FLIP_V)
		{
			source	= pixels + ((ys + h - 1 - yce) * width) + xs;
			w		+= width;

			do
			{
				index	= *source++;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					*screen	= (Pixel_Type)ctr;
				screen++;
				if (screen >= screen_line)
				{
					source		-= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else
		{
			source	= pixels + (ys * width) + xs;
			w		-= width;

			do
			{
				index	= *source++;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					*screen	= (Pixel_Type)ctr;
				screen++;
				if (screen >= screen_line)
				{
					source		-= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
	}
}

inline void writePixelAlpha_25(unsigned short *& screen, unsigned short color)
{
	register int	r	= (R(color) +	3 * R(*screen))	>> 2;
	register int	g	= (G(color) +	3 * G(*screen))	>> 2;
	register int	b	= (B(color) +	3 * B(*screen))	>> 2;

	*screen	= (u16)(R(r) | G(g) | B(b));
}

inline void writePixelAlpha_50(unsigned short *& screen, unsigned short color)
{
	register int	r	= (R(color) +	R(*screen))	>> 1;
	register int	g	= (G(color) +	G(*screen))	>> 1;
	register int	b	= (B(color) +	B(*screen))	>> 1;

	*screen	= (u16)(R(r) | G(g) | B(b));
}

inline void writePixelAlpha_75(unsigned short *& screen, unsigned short color)
{
	register int	r	= (3 * R(color) +	R(*screen))	>> 2;
	register int	g	= (3 * G(color) +	G(*screen))	>> 2;
	register int	b	= (3 * B(color) +	B(*screen))	>> 2;

	*screen	= (u16)(R(r) | G(g) | B(b));
}


//Draws an image with alpha, opacity 25%.
void Image::drawAlpha_25(int xs, int ys, int w, int h, int xd, int yd, u8 fx)
{
	typedef unsigned short Pixel_Type;

	if (!pixels || !palette)
		return;

	//Clipping part
	register int xcs = pDevice->GetClipXS();
	register int ycs = pDevice->GetClipYS();
	register int xce = pDevice->GetClipXE();
	register int yce = pDevice->GetClipYE();
	register int dd = 0;
	u8* buffer = (u8*)pDevice->GetData();

	{
		if ((xd >= xce) || (xd <= (xcs - w)))
			return;
		if ((yd >= yce) || (yd <= (ycs - h)))
			return;

		if ((xd + w) > xce)
		{
			xce	-= (xd + w);
			w	+= xce;
		}
		else
			xce = 0;

		if (xd < xcs)
		{
			dd	= xcs - xd;
			xce	+= dd;
			w	-= dd;
			xs	+= dd;
			xd	= xcs;
		}

		if ((w <= 0) || (xs >= width))
			return;

		if ((yd + h) > yce)
		{
			yce	-= (yd + h);
			h	+= yce;
		}
		else
			yce = 0;

		if (yd < ycs)
		{
			dd	= ycs - yd;
			yce	+= dd;
			h	-= dd;
			ys	+= dd;
			yd	= ycs;
		}

		if ((h <= 0) || (ys >= height))
			return;
	}


	unsigned char			*	source	= NULL;
	register unsigned short		ctr;

	{
		register int	_inc2	= nPitch;
		register int	_inc1	= _inc2 - (w * sizeof(Pixel_Type));

		Pixel_Type	*	screen		= NULL;
		Pixel_Type	*	screen_line	= NULL;
		Pixel_Type	*	screen_end	= NULL;

		screen		= (Pixel_Type*)(buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type)));
		screen_line	= (Pixel_Type*)(((u8*)screen) + (w * sizeof(Pixel_Type)));
		screen_end	= (Pixel_Type*)(((u8*)screen) + (h * _inc2));

		u8 index;

		if ((fx & FX_FLIP_HV) == FX_FLIP_HV)
		{
			source	= pixels + ((ys + h - 1 - yce) * width) + (xs + w - 1 - xce);
			w		-= width;

			do
			{
				index	= *source--;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_25(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		+= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else if (fx & FX_FLIP_H)
		{
			source	= pixels + (ys * width) + (xs + w - 1 - xce);
			w		+= width;

			do
			{
				index	= *source--;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_25(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		+= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else if (fx & FX_FLIP_V)
		{
			source	= pixels + ((ys + h - 1 - yce) * width) + xs;
			w		+= width;

			do
			{
				index	= *source++;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_25(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		-= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else
		{
			source	= pixels + (ys * width) + xs;
			w		-= width;

			do
			{
				index	= *source++;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_25(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		-= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
	}
}

//Draws an image with alpha, opacity 50%.
void Image::drawAlpha_50(int xs, int ys, int w, int h, int xd, int yd, u8 fx)
{
	typedef unsigned short Pixel_Type;

	if (!pixels || !palette)
		return;

	//Clipping part
	register int xcs = pDevice->GetClipXS();
	register int ycs = pDevice->GetClipYS();
	register int xce = pDevice->GetClipXE();
	register int yce = pDevice->GetClipYE();
	register int dd = 0;
	u8* buffer = (u8*)pDevice->GetData();

	{
		if ((xd >= xce) || (xd <= (xcs - w)))
			return;
		if ((yd >= yce) || (yd <= (ycs - h)))
			return;

		if ((xd + w) > xce)
		{
			xce	-= (xd + w);
			w	+= xce;
		}
		else
			xce = 0;

		if (xd < xcs)
		{
			dd	= xcs - xd;
			xce	+= dd;
			w	-= dd;
			xs	+= dd;
			xd	= xcs;
		}

		if ((w <= 0) || (xs >= width))
			return;

		if ((yd + h) > yce)
		{
			yce	-= (yd + h);
			h	+= yce;
		}
		else
			yce = 0;

		if (yd < ycs)
		{
			dd	= ycs - yd;
			yce	+= dd;
			h	-= dd;
			ys	+= dd;
			yd	= ycs;
		}

		if ((h <= 0) || (ys >= height))
			return;
	}


	unsigned char			*	source	= NULL;
	register unsigned short		ctr;

	{
		register int	_inc2	= nPitch;
		register int	_inc1	= _inc2 - (w * sizeof(Pixel_Type));

		Pixel_Type	*	screen		= NULL;
		Pixel_Type	*	screen_line	= NULL;
		Pixel_Type	*	screen_end	= NULL;

		screen		= (Pixel_Type*)(buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type)));
		screen_line	= (Pixel_Type*)(((u8*)screen) + (w * sizeof(Pixel_Type)));
		screen_end	= (Pixel_Type*)(((u8*)screen) + (h * _inc2));

		u8 index;

		if ((fx & FX_FLIP_HV) == FX_FLIP_HV)
		{
			source	= pixels + ((ys + h - 1 - yce) * width) + (xs + w - 1 - xce);
			w		-= width;

			do
			{
				index	= *source--;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_50(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		+= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else if (fx & FX_FLIP_H)
		{
			source	= pixels + (ys * width) + (xs + w - 1 - xce);
			w		+= width;

			do
			{
				index	= *source--;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_50(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		+= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else if (fx & FX_FLIP_V)
		{
			source	= pixels + ((ys + h - 1 - yce) * width) + xs;
			w		+= width;

			do
			{
				index	= *source++;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_50(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		-= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else
		{
			source	= pixels + (ys * width) + xs;
			w		-= width;

			do
			{
				index	= *source++;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_50(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		-= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
	}
}

//Draws an image with alpha, opacity 75%.
void Image::drawAlpha_75(int xs, int ys, int w, int h, int xd, int yd, u8 fx)
{
	typedef unsigned short Pixel_Type;

	if (!pixels || !palette)
		return;

	//Clipping part
	register int xcs = pDevice->GetClipXS();
	register int ycs = pDevice->GetClipYS();
	register int xce = pDevice->GetClipXE();
	register int yce = pDevice->GetClipYE();
	register int dd = 0;
	u8* buffer = (u8*)pDevice->GetData();

	{
		if ((xd >= xce) || (xd <= (xcs - w)))
			return;
		if ((yd >= yce) || (yd <= (ycs - h)))
			return;

		if ((xd + w) > xce)
		{
			xce	-= (xd + w);
			w	+= xce;
		}
		else
			xce = 0;

		if (xd < xcs)
		{
			dd	= xcs - xd;
			xce	+= dd;
			w	-= dd;
			xs	+= dd;
			xd	= xcs;
		}

		if ((w <= 0) || (xs >= width))
			return;

		if ((yd + h) > yce)
		{
			yce	-= (yd + h);
			h	+= yce;
		}
		else
			yce = 0;

		if (yd < ycs)
		{
			dd	= ycs - yd;
			yce	+= dd;
			h	-= dd;
			ys	+= dd;
			yd	= ycs;
		}

		if ((h <= 0) || (ys >= height))
			return;
	}


	unsigned char			*	source	= NULL;
	register unsigned short		ctr;

	{
		register int	_inc2	= nPitch;
		register int	_inc1	= _inc2 - (w * sizeof(Pixel_Type));

		Pixel_Type	*	screen		= NULL;
		Pixel_Type	*	screen_line	= NULL;
		Pixel_Type	*	screen_end	= NULL;

		screen		= (Pixel_Type*)(buffer + (yd * _inc2) + (xd * sizeof(Pixel_Type)));
		screen_line	= (Pixel_Type*)(((u8*)screen) + (w * sizeof(Pixel_Type)));
		screen_end	= (Pixel_Type*)(((u8*)screen) + (h * _inc2));

		u8 index;

		if ((fx & FX_FLIP_HV) == FX_FLIP_HV)
		{
			source	= pixels + ((ys + h - 1 - yce) * width) + (xs + w - 1 - xce);
			w		-= width;

			do
			{
				index	= *source--;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_75(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		+= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else if (fx & FX_FLIP_H)
		{
			source	= pixels + (ys * width) + (xs + w - 1 - xce);
			w		+= width;

			do
			{
				index	= *source--;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_75(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		+= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else if (fx & FX_FLIP_V)
		{
			source	= pixels + ((ys + h - 1 - yce) * width) + xs;
			w		+= width;

			do
			{
				index	= *source++;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_75(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		-= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
		else
		{
			source	= pixels + (ys * width) + xs;
			w		-= width;

			do
			{
				index	= *source++;
				ctr		= palette[index];
				if (IS_OPAQUE(ctr))
					writePixelAlpha_75(screen, ctr);
				screen++;
				if (screen >= screen_line)
				{
					source		-= w;
					screen		= (Pixel_Type*)(((u8*)screen) + _inc1);
					screen_line	= (Pixel_Type*)(((u8*)screen_line) + _inc2);
				}
			}while (screen < screen_end);
		}
	}
}

