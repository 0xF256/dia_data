// gxGraphics.h
////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _GX_GRAPHICS_H_
#define _GX_GRAPHICS_H_

////////////////////////////////////////////////////////////////////////////////////////////////////

#include "GX_Device.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
// implements a 2D graphics (raster device)

class gxGraphics
{
public:
	gxGraphics();
	~gxGraphics();

	void SetDataBuffer(void* pData, int width, int height);

	void* GetData()		{ return data; }
	int GetWidth()		{ return size_w; }
	int GetHeight()		{ return size_h; }

	int GetClipXS()		{ return clip_xs; }
	int GetClipYS()		{ return clip_ys; }
	int GetClipXE()		{ return clip_xe; }
	int GetClipYE()		{ return clip_ye; }
	int GetClipW()		{ return clip_w; }
	int GetClipH()		{ return clip_h; }

	int GetColor()		{ return _currentColor; }

	void setClip(int x, int y, int w, int h);
	void setColor(int color);
	void fillRect(int x, int y, int w, int h);
	void fillRectAlpha(int x, int y, int w, int h);
	void fillMenuRect(int x, int y, int w, int h);
	void drawLine(int xStart, int yStart, int xEnd, int yEnd);

private:
	bool clipLine(int & xs, int & ys, int & xe, int & ye);

private:
	void*	data;				// data buffer
	int		size_w, size_h;		// size of the device

	int		clip_xs, clip_ys;	// upper left clip point
	int		clip_xe, clip_ye;	// lower right clip point
	int		clip_w, clip_h;		// clip rect width and height

	u32		_currentColor;
	u16		_currentColor16;
};

////////////////////////////////////////////////////////////////////////////////////////////////////

#endif // _GX_GRAPHICS_H_

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
