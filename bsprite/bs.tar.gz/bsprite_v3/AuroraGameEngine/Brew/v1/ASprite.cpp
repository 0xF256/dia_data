// ASprite.cpp
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Author(s): Ionut Matasaru (ionut.matasaru@gameloft.com)
//
////////////////////////////////////////////////////////////////////////////////////////////////////

#include "ASprite.h"
#include "font_table.h"
#include "gxDevice.h"
#include "gxafx.h"
#include "LZMAFile.h"
#include "Image.h"

////////////////////////////////////////////////////////////////////////////////////////////////////

ASprite::ASprite()
{
	nModules			= 0;
	_modules			= NULL;

	nFrames				= 0;
	_frames_nfm			= NULL;
	_frames_fm_start	= NULL;
	_frames_rc			= NULL;
	nFModules			= 0;
	_fmodules			= NULL;

	nAnims				= 0;
	_anims_naf			= NULL;
	_anims_af_start		= NULL;
	nAFrames			= 0;
	_aframes			= NULL;

//	_nMMappings			= 0;
//	_pMMappings			= NULL;
//	_nCrtMMaping		= 0;

	nPalettes			= 0;
	nColors				= 0;
	pPalettes			= NULL;
	_pCrtPalette		= NULL;

	_data_format		= 0;
	_pModulesData		= NULL;
	_pModulesDataSize	= NULL;
	_pModulesImages		= NULL;

	_line_spacing		= 0;

	_index1				= -1;
	_index2				= -1;

	//Initialize buffer to screen
	pDevice = &(cGame::getGame()->_g);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

ASprite::~ASprite()
{
	SAFE_DEL_ARRAY(_modules);

	SAFE_DEL_ARRAY(_frames_nfm);
	SAFE_DEL_ARRAY(_frames_fm_start);
	SAFE_DEL_ARRAY(_frames_rc);

	SAFE_DEL_ARRAY(_fmodules);

	SAFE_DEL_ARRAY(_anims_naf);
	SAFE_DEL_ARRAY(_anims_af_start);

	SAFE_DEL_ARRAY(_aframes);

//	SAFE_DEL_ARRAY_ARRAY(_pMMappings, _nMMappings);

	SAFE_DEL_ARRAY_ARRAY(pPalettes, nPalettes);

	SAFE_DEL_ARRAY_ARRAY(_pModulesData, nModules);
	SAFE_DEL_ARRAY(_pModulesDataSize);
	SAFE_DEL_ARRAY_OBJ(_pModulesImages, nModules);

//	pDevice = NULL;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//Loads a sprite from a file

int ASprite::LoadSprite(LZMAFile* pFile)
{
	int	ret;

	if ((ret = loadSprite_0(pFile)) < 0)	return ret;	// Modules
	if ((ret = loadSprite_1(pFile)) < 0)	return ret;	// Frames
	if ((ret = loadSprite_2(pFile)) < 0)	return ret;	// Anims
	if ((ret = loadSprite_3(pFile)) < 0)	return ret;	// Palettes
	if ((ret = loadSprite_4(pFile)) < 0)	return ret;	// Images

	//No error
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Modules...

int ASprite::LoadSprite_0(LZMAFile* pFile)
{
	pFile->readShort();	// version
	pFile->readInt();	// flags

	//Modules...
	nModules = pFile->readShort();
	if (nModules)
	{
		int size = nModules << 1;
		_modules = NEW u8[size];
		if (!nModules) return -1;
		pFile->read(_modules, size);
	}

	//No error
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Frames...

int ASprite::LoadSprite_1(LZMAFile* pFile)
{
	//Frame Modules...
	nFModules = pFile->readShort();
	if (nFModules > 0)
	{
		int size = nFModules * 6;
		_fmodules = NEW u8[size];
		if (!_fmodules) return -2;
		pFile->read(_fmodules, size);
	}

	//Frames...
	nFrames = pFile->readShort();
	if (nFrames > 0)
	{
		_frames_nfm = NEW u8[nFrames];
		if (!_frames_nfm) return -3;

		_frames_fm_start = NEW u16[nFrames];
		if (!_frames_fm_start) return -4;

		//Read data for each frame
		for (int i = 0; i < nFrames; i++)
		{
			_frames_nfm[i] = (u8)(pFile->readShort()); // 16->8 !!!
			_frames_fm_start[i]= pFile->readShort();
		}

		// Bound rect for each frame...
		int size = nFrames << 2;
		_frames_rc = NEW s8[size];
		if (!_frames_rc) return -5;
		pFile->read(_frames_rc, size);
	}

	//No error
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Anims...

int ASprite::LoadSprite_2(LZMAFile * pFile)
{
	//Animation frames
	nAFrames = pFile->readShort();
	if (nAFrames)
	{
		int size = nAFrames * 5;
		_aframes = NEW u8[size];
		if (!_aframes) return -6;
		pFile->read(_aframes, size);
	}

	//Animations
	nAnims = pFile->readShort();
	if (nAnims)
	{
		_anims_naf = NEW u8[nAnims];
		if (!_anims_naf) return -7;
		_anims_af_start = NEW u16[nAnims];
		if (!_anims_af_start) return -8;

		//Read each anim data
		for (int i = 0; i < nAnims; i++)
		{
			_anims_naf[i] = (u8)(pFile->readShort()); // 16->8 !!!
			_anims_af_start[i] = pFile->readShort();
		}
	}

	//No error
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Palettes...

int ASprite::LoadSprite_3(LZMAFile* pFile)
{
	// Pixel format (must be one of SPRITE_FORMAT_8888, _4444)...
	int _pixel_format = pFile->readShort() & 0xFFFF;
//	SPRITE_DBG_OUT("_pixel_format = 0x%04X" + _pixel_format);

	// Number of palettes...
	nPalettes = (u8)pFile->readChar();
//	SPRITE_DBG_OUT("_palettes = %d", nPalettes);

	// Number of colors...
	nColors = (u8)pFile->readChar();
//	SPRITE_DBG_OUT("_colors = %d", nColors);

	//Alloc the palettes
	pPalettes = NEW u16*[nPalettes]; // [MAX_SPRITE_PALETTES];
	if (!pPalettes) return -9;
	GX_MEMSET(pPalettes, 0, sizeof(u16*) * nPalettes); // * MAX_SPRITE_PALETTES);

	//Read the palettes
	for (int p = 0; p < nPalettes; p++)
	{
		//Alloc this palette
		pPalettes[p] = NEW u16[nColors];
		if (!pPalettes[p]) return -10;

		//Convert from bsprite pixel format
		for (int c = 0; c < nColors; c++)
		{
			u32 rawColor = 0;

			switch (_pixel_format)
			{
				case PIXEL_FORMAT_8888:
					rawColor  =   pFile->readChar() & 0xFF;
					rawColor += ((pFile->readChar() & 0xFF) << 8);
					rawColor += ((pFile->readChar() & 0xFF) << 16);
					rawColor += ((pFile->readChar() & 0xFF) << 24);
					break;
		
				case PIXEL_FORMAT_4444:
					rawColor  =   pFile->readChar() & 0xFF;
					rawColor += ((pFile->readChar() & 0xFF) << 8);
					rawColor  = ((rawColor & 0xF000) << 16) | ((rawColor & 0xF000) << 12) |
								((rawColor & 0x0F00) << 12) | ((rawColor & 0x0F00) <<  8) |
								((rawColor & 0x00F0) <<  8) | ((rawColor & 0x00F0) <<  4) |
								((rawColor & 0x000F) <<  4) | ((rawColor & 0x000F)      );
					break;
			}

			//Convert the color to native format
			if (/*(rawColor == 0xFFFF00FF) || */((rawColor & 0xFF000000) == 0))
				pPalettes[p][c] = 0;
			else
			{
				pPalettes[p][c] = COLOR32TO16ARGB(rawColor);
				if (pPalettes[p][c] == 0)
					pPalettes[p][c] = COLOR_BLACK16;
			}
		}
	}

	//Set current palette
	SetPalette(0);

	//No error
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Images...

int ASprite::LoadSprite_4(LZMAFile* pFile)
{
	// Data format (must be one of ENCODE_FORMAT_I2, _I4, _I16, _I256, _I127RLE)...
	_data_format = pFile->readShort(); 
//	SPRITE_DBG_OUT("_data_format = 0x%04X" + _data_format);

	if (nModules <= 0) return 0;

	_pModulesData = NEW u8*[nModules];
	if (!_pModulesData) return -11;
	GX_MEMSET(_pModulesData, NULL, sizeof(u8*) * nModules);

	_pModulesDataSize = NEW u16[nModules];
	if (!_pModulesDataSize) return -12;

	// Encoded image data for each module...
	for (int m = 0; m < nModules; m++)
	{
		//Read module size
		_pModulesDataSize[m] = (u16)pFile->readShort();
		if (!_pModulesDataSize[m]) continue;
		//Alloc module data
		_pModulesData[m] = NEW u8[_pModulesDataSize[m]];
		if (!_pModulesData[m]) return -13;
		//Read module
		pFile->read(_pModulesData[m], _pModulesDataSize[m]);
	}

	//No error
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// pal = palette to be initailized
// m1 = first module
// m2 = last module (-1 -> to end)
// pal_copy = mapping to another palette (-1 -> build)

int ASprite::BuildCacheImages(int pal, int m1, int m2, int pal_copy)
{
	if (_modules == NULL) return 0;

	if (m2 == -1)
		m2 = nModules - 1;

	if ((_pModulesImages == NULL) && (nModules > 0))
	{
		_pModulesImages = NEW Image*[nModules];
		if (!_pModulesImages) return -14;
		GX_MEMSET(_pModulesImages, NULL, sizeof(Image*) * nModules);
	}

//	if (_pModulesImages[pal] == null)
//		_pModulesImages[pal] = NEW Image[_modules.length>>1];

//	if (pal_copy >= 0)
//	{
//		for (int i = m1; i <= m2; i++)
//			_pModulesImages[pal][i] = _pModulesImages[pal_copy][i];
//	}
//	else
//	{
//		int old_pal = _cur_pal;
//		_cur_pal = pal;

		for (int i = m1; i <= m2; i++)
		{
			if (_pModulesDataSize[i] == 0) continue;

			int m = i << 1;
			int sizeX = _modules[m  ];
			int sizeY = _modules[m+1];
			if (sizeX <= 0 || sizeY <= 0) continue;

			//Alloc module image
			_pModulesImages[i] = NEW Image();
			if (!_pModulesImages[i]) return -15;

			//Initialize the decompressed image.
			_pModulesImages[i]->init(DecodeModuleImage8(NULL, i), sizeX, sizeY);

			//Delete encoded buffer.
			SAFE_DEL_ARRAY(_pModulesData[i]);
		}

//		_cur_pal = old_pal;
//	}

	//No error
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/*
void ASprite::SetModuleMapping(int map, byte[] mmp)
{
//	ASSERT(map >= 0 && map < _mappings);
	if (_map[map] == null)
	{
		int modules = _modules.length>>1;
		_map[map] = NEW int[modules];
		for (int i = 0; i < modules; i++)
			_map[map][i] = i;
	}
	if (mmp == null) return;
	int off = 0;
	while (off < mmp.length)
	{
		int i1 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
		int i2 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
		_map[map][i1] = i2;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::ApplyModuleMapping(int dst_pal, int src_pal, byte[] mmp)
{
	int off = 0;
	while (off < mmp.length)
	{
		int i1 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
		int i2 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
		_modules_image[dst_pal][i1] = _modules_image[src_pal][i2];
	}
	System.gc();
}
*/
////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::GetAFrameRect(int* rc, int anim, int aframe, int posX, int posY, u32 flags, int hx, int hy)
{
//	SPRITE_DBG_OUT("GetAFrameRect(rc, "+anim+", "+aframe+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
	int off = (_anims_af_start[anim] + aframe) * 5;
	int frame = _aframes[off] & 0xFF;
#ifdef USE_INDEX_EX_AFRAMES
	frame |= ((_aframes[off+4] & FLAG_INDEX_EX_MASK) << INDEX_EX_SHIFT);
#endif
	if (flags & FLAG_OFFSET_AF)
	{
		if (flags & FLAG_FLIP_X)	hx += _aframes[off+2];
		else						hx -= _aframes[off+2];
		if (flags & FLAG_FLIP_Y)	hy += _aframes[off+3];
		else						hy -= _aframes[off+3];
	}
//	if (flags & FLAG_FLIP_X)	hx += _frames_w[frame] & 0xFF;
//	if (flags & FLAG_FLIP_Y)	hy += _frames_h[frame] & 0xFF;
	GetFrameRect(rc, frame, posX, posY, flags ^ (_aframes[off+4] & 0x0F), hx, hy);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::GetFrameRect(int* rc, int frame, int posX, int posY, u32 flags, int hx, int hy)
{
//	SPRITE_DBG_OUT("GetFrameRect(rc, "+frame+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
	int frame4 = frame<<2;
	int fx = _frames_rc[frame4++];
	int fy = _frames_rc[frame4++];
	int fw = _frames_rc[frame4++] & 0xFF;
	int fh = _frames_rc[frame4++] & 0xFF;
	if (flags & FLAG_FLIP_X)	hx += fx + fw;
	else						hx -= fx;
	if (flags & FLAG_FLIP_Y)	hy += fy + fh;
	else						hy -= fy;
	rc[0] = posX - (hx<<8);
	rc[1] = posY - (hy<<8);
	rc[2] = rc[0] + (fw<<8);
	rc[3] = rc[1] + (fh<<8);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::GetModuleRect(int* rc, int module, int posX, int posY, u32 flags)
{
//	SPRITE_DBG_OUT("GetModuleRect(rc, "+module+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+")");
	int m = (module<<1);
	rc[0] = posX;
	rc[1] = posY;
	rc[2] = posX + ((_modules[m  ] & 0xFF) << 8);
	rc[3] = posY + ((_modules[m+1] & 0xFF) << 8);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::PaintAFrame(int anim, int aframe, int posX, int posY, u32 flags, int hx, int hy)
{
//	SPRITE_DBG_OUT("PaintAFrame(g, "+anim+", "+aframe+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
	int off = (_anims_af_start[anim] + aframe) * 5;
	int frame = _aframes[off] & 0xFF;
#ifdef USE_INDEX_EX_AFRAMES
	frame |= ((_aframes[off+4] & FLAG_INDEX_EX_MASK) << INDEX_EX_SHIFT);
#endif

//	if (flags & FLAG_OFFSET_AF)
	{
		int ox = ((s8*)_aframes)[off+2];
		int oy = ((s8*)_aframes)[off+3];
		if (flags & FLAG_FLIP_X)	hx += ox;
		else						hx -= ox;
		if (flags & FLAG_FLIP_Y)	hy += oy;
		else						hy -= oy;
	}
//	if (flags & FLAG_FLIP_X)	hx += _frames_w[frame] & 0xFF;
//	if (flags & FLAG_FLIP_Y)	hy += _frames_h[frame] & 0xFF;
	PaintFrame(frame, posX-hx, posY-hy, flags ^ (_aframes[off+4] & 0x0F), hx, hy);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::PaintFrame(int frame, int posX, int posY, u32 flags, int hx, int hy)
{
//	SPRITE_DBG_OUT("PaintFrame(g, "+frame+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
	if (!_frames_nfm) return;
	int nFModules = _frames_nfm[frame] & 0xFF;	// number of frame modules for this frame
	for (int fmodule = 0; fmodule < nFModules; fmodule++)
		PaintFModule(frame, fmodule, posX, posY, flags, hx, hy);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//Paints a frame module

void ASprite::PaintFModule(int frame, int fmodule, int posX, int posY, u32 flags, int hx, int hy)
{
//	SPRITE_DBG_OUT("PaintFModule(g, "+frame+", "+fmodule+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
	int off = (_frames_fm_start[frame] + fmodule) * 6;	// offset in the _fmodules array
	int fm_flags = _fmodules[off+5] & 0xFF;
	int index = _fmodules[off] & 0xFF;	// module index
#ifdef USE_INDEX_EX_FMODULES
	index |= ((fm_flags & FLAG_INDEX_EX_MASK) << INDEX_EX_SHIFT);
#endif

//	if (flags & FLAG_OFFSET_FM)
	{
		int ox = (s16)((_fmodules[off + 1] & 0xFF) | ((_fmodules[off + 2] & 0xFF) << 8));
		int oy = (s16)((_fmodules[off + 3] & 0xFF) | ((_fmodules[off + 4] & 0xFF) << 8));
		if (flags & FLAG_FLIP_X)	posX -= ox;
		else						posX += ox;
		if (flags & FLAG_FLIP_Y)	posY -= oy;
		else						posY += oy;
	}

	if ((fm_flags & FLAG_HYPER_FM) != 0)
	{
	//	if (flags & FLAG_FLIP_X)	posX -= _frames[(index<<?)  ] & 0xFF; // pF->w
	//	if (flags & FLAG_FLIP_Y)	posY -= _frames[(index<<?)+1] & 0xFF; // pF->h

		PaintFrame(index, posX, posY, flags ^ (fm_flags & 0x0F), hx, hy);
	}
	else
	{
		if (flags & FLAG_FLIP_X)	posX -= _modules[(index << 1)    ] & 0xFF;
		if (flags & FLAG_FLIP_Y)	posY -= _modules[(index << 1) + 1] & 0xFF;

		PaintModule(index, posX, posY, flags ^ (fm_flags & 0x0F));
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//Paints a module

void ASprite::PaintModule(int module, int posX, int posY, u32 flags)
{
//	SPRITE_DBG_OUT("PaintModule(g, "+module+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+")");
//	SPRITE_DBG_OUT("PaintModule(module = "+module+", _cur_pal = "+_cur_pal+")...");

/*	// Apply current module mapping...
	if (_cur_map >= 0)
	{
	//	if (DEF.bASSERT) DBG.ASSERT(_cur_map < _mappings);
	//	if (DEF.bASSERT) DBG.ASSERT(_map[_cur_map] != null);
		module = _map[_cur_map][module];
	//	System.out.println("module -> "+module);
	}
*/
	int	m = module << 1;
	int	sizeX = _modules[m  ] & 0xFF;
	int sizeY = _modules[m+1] & 0xFF;
	if (sizeX <= 0 || sizeY <= 0) return;

	register int cx = pDevice->GetClipXS();
	register int cy = pDevice->GetClipYS();
	register int cw = pDevice->GetClipW();
	register int ch = pDevice->GetClipH();

	//See if module is outside the clip rect
	if (posX + sizeX < cx || posY + sizeY < cy || posX >= cx + cw || posY >= cy + ch)
		return;

	//Get the module image
	Image* img = _pModulesImages[module];
	img->setPalette(_pCrtPalette);
	img->setRasterDevice(pDevice);

	int	x = 0;
	int	y = 0;

	//Do clipping on y
	if (posY < cy)
	{
		y = cy - posY;
		sizeY -= y;
		posY = cy;
	}
	if (posY + sizeY > cy + ch)
		sizeY = cy + ch - posY;

	img->setOpacity((unsigned char)flags);
	img->draw(x, y, sizeX, sizeY, posX, posY, flags);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

u16* ASprite::DecodeModuleImage(u16* target, int module)
{
//	SPRITE_DBG_OUT("DecodeImage("+module+", 0x"+Integer.toHexString(flags)+")...");

	// Choose palette...
	u16* pal = _pCrtPalette;
	if (pal == NULL) return NULL;

	int m = module << 1;
	int sizeX = _modules[m  ];
	int sizeY = _modules[m+1];
//	if (sizeX <= 0 || sizeY <= 0) return null;

	u16* img_data = target;
	if (img_data == NULL) img_data = NEW u16[sizeX * sizeY + 7];
	if (img_data == NULL) return NULL;

	// Decode...
	if (_data_format == ENCODE_FORMAT_I2)
	{
		// 8 pixels/byte, max 2 colors...
		u8* image = _pModulesData[module];
		int size = _pModulesDataSize[module];
		int si = 0;
		int di = 0;
		while (si < size)
		{
			img_data[di++] = pal[(image[si] >> 7) & 0x01];
			img_data[di++] = pal[(image[si] >> 6) & 0x01];
			img_data[di++] = pal[(image[si] >> 5) & 0x01];
			img_data[di++] = pal[(image[si] >> 4) & 0x01];
			img_data[di++] = pal[(image[si] >> 3) & 0x01];
			img_data[di++] = pal[(image[si] >> 2) & 0x01];
			img_data[di++] = pal[(image[si] >> 1) & 0x01];
			img_data[di++] = pal[(image[si]     ) & 0x01];
			si++;
		}
	}
	else if (_data_format == ENCODE_FORMAT_I4)
	{
		// 4 pixels/byte, max 4 colors...
		u8* image = _pModulesData[module];
		int size = _pModulesDataSize[module];
		int si = 0;
		int di = 0;
		while (si < size)
		{
			img_data[di++] = pal[(image[si] >> 6) & 0x03];
			img_data[di++] = pal[(image[si] >> 4) & 0x03];
			img_data[di++] = pal[(image[si] >> 2) & 0x03];
			img_data[di++] = pal[(image[si]     ) & 0x03];
			si++;
		}
	}
	else if (_data_format == ENCODE_FORMAT_I16)
	{
		// 2 pixels/byte, max 16 colors...
		u8* image = _pModulesData[module];
		int size = _pModulesDataSize[module];
		int si = 0;
		int di = 0;
		while (si < size)
		{
			img_data[di++] = pal[(image[si] >> 4) & 0x0F];
			img_data[di++] = pal[(image[si]     ) & 0x0F];
			si++;
		}
	}
	else if (_data_format == ENCODE_FORMAT_I256)
	{
		// 1 pixel/byte, max 256 colors...
		u8* image = _pModulesData[module];
		int size = _pModulesDataSize[module];
		int si = 0;
		int di = 0;
		while (si < size)
			img_data[di++] = pal[image[si++]];
	}
	else if (_data_format == ENCODE_FORMAT_I127RLE)
	{
		// RLE compression, max 127 colors...
		u8* image = _pModulesData[module];
		int size = _pModulesDataSize[module];
		int si = 0;
		int di = 0;
		while (si < size)
		{
			int c = image[si++];
		//	System.out.println("--- c = " + c);
			if (c > 127)
			{
				int c2 = image[si++];
			//	System.out.println("--- c2 = " + c2);
				int clr = pal[c2];
				c -= 128;
				while (c-- > 0)
					img_data[di++] = clr;
			}
			else
				img_data[di++] = pal[c];
		}
	}

//	SPRITE_DBG_OUT("...DecodeImage("+module+", 0x"+Integer.toHexString(flags)+")");
	return img_data;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

u8* ASprite::DecodeModuleImage8(u8* target, int module)
{
//	SPRITE_DBG_OUT("DecodeImage("+module+", 0x"+Integer.toHexString(flags)+")...");

	int m = module << 1;
	int sizeX = _modules[m  ];
	int sizeY = _modules[m+1];
//	if (sizeX <= 0 || sizeY <= 0) return null;

	u8* img_data = target;
	if (img_data == NULL) img_data = NEW u8[sizeX * sizeY + 7];
	if (img_data == NULL) return NULL;

	if (_data_format == ENCODE_FORMAT_I2)
	{
		// 8 pixels/byte, max 2 colors...
		u8* image = _pModulesData[module];
		int size = _pModulesDataSize[module];
		int si = 0;
		int di = 0;
		while (si < size)
		{
			img_data[di++] = (image[si] >> 7) & 0x01;
			img_data[di++] = (image[si] >> 6) & 0x01;
			img_data[di++] = (image[si] >> 5) & 0x01;
			img_data[di++] = (image[si] >> 4) & 0x01;
			img_data[di++] = (image[si] >> 3) & 0x01;
			img_data[di++] = (image[si] >> 2) & 0x01;
			img_data[di++] = (image[si] >> 1) & 0x01;
			img_data[di++] = (image[si]     ) & 0x01;
			si++;
		}
	}
	else if (_data_format == ENCODE_FORMAT_I4)
	{
		// 4 pixels/byte, max 4 colors...
		u8* image = _pModulesData[module];
		int size = _pModulesDataSize[module];
		int si = 0;
		int di = 0;
		while (si < size)
		{
			img_data[di++] = (image[si] >> 6) & 0x03;
			img_data[di++] = (image[si] >> 4) & 0x03;
			img_data[di++] = (image[si] >> 2) & 0x03;
			img_data[di++] = (image[si]     ) & 0x03;
			si++;
		}
	}
	else if (_data_format == ENCODE_FORMAT_I16)
	{
		// 2 pixels/byte, max 16 colors...
		u8* image = _pModulesData[module];
		int size = _pModulesDataSize[module];
		int si = 0;
		int di = 0;
		while (si < size)
		{
			img_data[di++] = (image[si] >> 4) & 0x0F;
			img_data[di++] = (image[si]     ) & 0x0F;
			si++;
		}
	}
	else if (_data_format == ENCODE_FORMAT_I256)
	{
		// 1 pixel/byte, max 256 colors...
		GX_MEMCPY(img_data, _pModulesData[module], _pModulesDataSize[module]);
	}
	else if (_data_format == ENCODE_FORMAT_I127RLE)
	{
		// RLE compression, max 127 colors...
		u8* image = _pModulesData[module];
		int size = _pModulesDataSize[module];
		int si = 0;
		int di = 0;
		while (si < size)
		{
			int c = image[si++];
		//	System.out.println("--- c = " + c);
			if (c > 127)
			{
				u8 c2 = image[si++];
				c -= 128;
				while (c-- > 0)
					img_data[di++] = c2;
			}
			else
				img_data[di++] = (u8)c;
		}
	}

//	SPRITE_DBG_OUT("...DecodeImage("+module+", 0x"+Integer.toHexString(flags)+")");
	return img_data;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//Returns the string size in w and h.

void ASprite::GetStringSize(const char* str, int* pW, int* pH)
{
	int w = 0;
	int h = _modules[1] & 0xFF;
	int tw = 0;

	int index1 = ((_index1 >= 0) ? _index1 : 0);
	int index2 = ((_index2 >= 0) ? _index2 : GX_STRLEN(str));

	str += index1;
	for (int i = index1; i < index2; i++)
	{
		int c = *str++ & 0xFF;
		if (c > 32)
		{
			c = _map_char[c];
		}

		else if (c == ' ')
		{
			tw	+= (_modules[0] & 0xFF) + FModuleOX(0);
			continue;
		}
		else if (c == '\n')
		{
			if (tw > w) w = tw;
			tw = 0;
			h += _line_spacing + (_modules[1] & 0xFF);
			continue;
		}
		else // if (c < 32)
		{
			if (c == 1) // auto change current palette
			{
				i++;
				str++;
				continue;
			}
			else if (c == 2) // select fmodule
			{
				i++;
				c = *str++ & 0xFF;
			}
			else continue;
		}

		//The font has only one frame, containing all modules.
		if (c >= getFModules(0))
		{
		//	SPRITE_DBG_OUT("Character not available: c = %d", c);
			c = 0;
		}

		//Get character module.
		int m = (_fmodules[c * 6] & 0xFF) << 1;
		if (m >= (nModules << 1))
		{
		//	SPRITE_DBG_OUT("Character module not available: c = %d, m = %d", c, m>>1);
			m = 0;
			c = 0;
		}

		//Add character witdh to the text width
		tw	+= (_modules[m] & 0xFF) - FModuleOX(c) + FModuleOX(0);
	}

	if (tw > w) w = tw;
	if (w > 0)	w -= FModuleOX(0);

	*pW = w;
	*pH = h;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//Draws a string on the screen

void ASprite::DrawString(const char* str, int x, int y, int anchor)
{
	y -= FModuleOY(0);

	if (anchor & (RIGHT | HCENTER | BOTTOM | VCENTER))
	{
		int	w, h;
		GetStringSize(str, &w, &h);
			 if (anchor & RIGHT)	x -= w;
		else if (anchor & HCENTER)	x -= w >> 1;
			 if (anchor & BOTTOM)	y -= h;
		else if (anchor & VCENTER)	y -= h >> 1;
	}

	int xx = x;
	int yy = y;

	u16* pOldPal = _pCrtPalette;

	int index1 = ((_index1 >= 0) ? _index1 : 0);
	int index2 = ((_index2 >= 0) ? _index2 : GX_STRLEN(str));

	str += index1;
	for (int i = index1; i < index2; i++)
	{
		int c = *str++ & 0xFF;
		if (c > 32)
		{
			c = _map_char[c];
		}
		else if (c == ' ')
		{
			xx	+= (_modules[0] & 0xFF) + FModuleOX(0);
			continue;
		}
		else if (c == '\n')
		{
			xx = x;
			yy += _line_spacing + (_modules[1] & 0xFF);
			continue;
		}
		else // if (c < 32)
		{
			if (c == 1) // auto change current palette
			{
				i++;
				SetPalette(*str++ & 0xFF);
				continue;
			}
			else if (c == 2) // select fmodule
			{
				i++;
				c = *str++ & 0xFF;
			}
			else continue;
		}
		
		if (c >= getFModules(0))
		{
		//	SPRITE_DBG_OUT("Character not available: c = %d", c);
			c = 0;
		}

		int m = (_fmodules[c * 6] & 0xFF) << 1;

		if (m >= (nModules << 1))
		{
		//	SPRITE_DBG_OUT("Character module not available: c = %d, m = %d", c, m>>1);
			m = 0;
			c = 0;
		}

		PaintFModule(0, c, xx, yy, 0, 0, 0);
		xx += (_modules[m] & 0xFF) - FModuleOX(c) + FModuleOX(0);
	}

	_pCrtPalette = pOldPal;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void ASprite::DrawPage(const char* str, int x, int y, int anchor)
{
	// Count lines...
	int lines = 0;
	int len = GX_STRLEN(str);
	int* off = NEW int[100];
	char* s = (char*)str;
	for (int i = 0; i < len; i++)
		if (*(s++) == '\n')
			off[lines++] = i;
	off[lines++] = len;

	int th = _line_spacing + (_modules[1] & 0xFF);

		 if (anchor & BOTTOM)	y -= (th * (lines-1));
	else if (anchor & VCENTER)	y -= (th * (lines-1)) >> 1;

	// Draw each line...
	for (int j = 0; j < lines; j++)
	{
		_index1 = (j > 0) ? off[j-1]+1 : 0;
		_index2 = off[j];
		DrawString(str, x, y + j * th, anchor);
	}

	SAFE_DEL_ARRAY(off);

	// Disable substring...
	_index1 = -1;
	_index2 = -1;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
