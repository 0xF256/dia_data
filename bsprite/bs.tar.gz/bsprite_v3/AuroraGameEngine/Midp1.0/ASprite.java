// ASprite.java - Aurora Sprite - MIDP 1.0 version
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Author(s): Ionut Matasaru (ionut.matasaru@gameloft.com)
//
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Implementation for sprites exported by AuroraGT editor.
//  Contains methods to handle displaying of strings.
//
//  History:
//		28.09.2003, created
//		20.09.2005, updated
//
//  Features:
//		* use ".bsprite" files (BSPRITE_v003, exported by AuroraGT v0.5.3 - SpriteEditor v0.6.3 or later)
//		* BSprite flags: BS_DEFAULT_MIDP1
//
//  Note:
//		If you want to use the Draw String System, first init the "_map_char" for each font sprite.
//		It should contain a 256 byte array with the mapping between ASCII codes and FModules.
//		You could use FontTable.exe to generate it.
//
////////////////////////////////////////////////////////////////////////////////////////////////////

import javax.microedition.lcdui.*;
//import javax.microedition.lcdui.game.Sprite; // just for MIDP2 transformations

////////////////////////////////////////////////////////////////////////////////////////////////////

class ASprite
{
	//////////////////////////////////////////////////
	// Set these switches to best suite your game!
	// Unused code will be removed by the obfuscator!

	final static boolean USE_MODULE_MAPPINGS		= !true; // use Module Mappings ?

	final static boolean USE_HYPER_FM				= !true; // use Hyper Frame Modules ?

	final static boolean USE_INDEX_EX_FMODULES		= !true; // true|false -> max. 1024|256 modules refs. from a FModule
	final static boolean USE_INDEX_EX_AFRAMES		= !true; // true|false -> max. 1024|256 frames refs. from an Anim

	final static boolean USE_PRECOMPUTED_FRAME_RECT = !true;

	final static boolean ALWAYS_BS_NFM_1_BYTE		= false; // all sprites are exported with BS_NFM_1_BYTE
	final static boolean ALWAYS_BS_SKIP_FRAME_RC	= false; // all sprites are exported with BS_SKIP_FRAME_RC
	final static boolean ALWAYS_BS_NAF_1_BYTE		= false; // all sprites are exported with BS_NAF_1_BYTE

	final static int MAX_SPRITE_PALETTES			= 16;
	final static int MAX_MODULE_MAPPINGS			= 16;

	//////////////////////////////////////////////////

	final static short BSPRITE_v003	= (short)0x03DF; // supported version

	//////////////////////////////////////////////////
	// BSprite flags

	final static int BS_MODULES			= (1 << 0);
	final static int BS_MODULES_XY		= (1 << 1);
	final static int BS_MODULES_IMG		= (1 << 2);
	final static int BS_FRAMES			= (1 << 8);
	final static int BS_FM_OFF_SHORT	= (1 << 10);    // export fm offsets as shorts
	final static int BS_NFM_1_BYTE		= (1 << 11);    // export nfm as byte
	final static int BS_SKIP_FRAME_RC	= (1 << 12);    // do not export frame rect
	final static int BS_ANIMS			= (1 << 16);
	final static int BS_AF_OFF_SHORT	= (1 << 18);    // export af offsets as shorts
	final static int BS_NAF_1_BYTE		= (1 << 19);    // export naf as byte
	final static int BS_MODULE_IMAGES	= (1 << 24);
	final static int BS_PNG_CRC			= (1 << 25);
	final static int BS_KEEP_PAL		= (1 << 26);
	final static int BS_TRANSP_FIRST	= (1 << 27);
	final static int BS_TRANSP_LAST		= (1 << 28);

	final static int BS_DEFAULT_DOJA	= (BS_MODULES | BS_FRAMES | BS_ANIMS);
	final static int BS_DEFAULT_MIDP2	= (BS_MODULES | BS_FRAMES | BS_ANIMS | BS_MODULE_IMAGES);
	final static int BS_DEFAULT_NOKIA	= BS_DEFAULT_MIDP2;
	final static int BS_DEFAULT_MIDP1	= (BS_MODULES | BS_MODULES_XY | BS_FRAMES | BS_ANIMS);
	final static int BS_DEFAULT_MIDP1b	= (BS_MODULES | BS_FRAMES | BS_ANIMS | BS_MODULE_IMAGES | BS_PNG_CRC);

	//////////////////////////////////////////////////

	final static short PIXEL_FORMAT_8888		= (short)0x8888;
	final static short PIXEL_FORMAT_4444		= (short)0x4444;
	final static short PIXEL_FORMAT_1555		= (short)0x5515;
	final static short PIXEL_FORMAT_0565		= (short)0x6505;

	//////////////////////////////////////////////////

	final static short ENCODE_FORMAT_I2			= 0x0200;
	final static short ENCODE_FORMAT_I4			= 0x0400;
//	final static short ENCODE_FORMAT_I8			= 0x0800;
	final static short ENCODE_FORMAT_I16		= 0x1600;
//	final static short ENCODE_FORMAT_I16MP		= 0x16??;
//	final static short ENCODE_FORMAT_I32		= 0x3200;
//	final static short ENCODE_FORMAT_I64		= 0x6400;
//	final static short ENCODE_FORMAT_I128		= 0x2801;
	final static short ENCODE_FORMAT_I256		= 0x5602;
//	final static short ENCODE_FORMAT_I127_		= 0x2701;
	final static short ENCODE_FORMAT_I64RLE		= 0x64F0;
	final static short ENCODE_FORMAT_I127RLE	= 0x27F1;
	final static short ENCODE_FORMAT_I256RLE	= 0x56F2;

	//////////////////////////////////////////////////
	// Frames/Anims flags...

	final static byte FLAG_FLIP_X	= 0x01;
	final static byte FLAG_FLIP_Y	= 0x02;
	final static byte FLAG_ROT_90	= 0x04;

	final static byte FLAG_USER0	= 0x10; // user flag 0
	final static byte FLAG_USER1	= 0x20; // user flag 1

	final static byte FLAG_HYPER_FM	= 0x10; // Hyper FModule, used by FModules

	// Index extension...
	final static int FLAG_INDEX_EX_MASK = 0xC0; // 11000000, bits 6, 7
	final static int INDEX_MASK			= 0x03FF; // max 1024 values
	final static int INDEX_EX_MASK		= 0x0300;
	final static int INDEX_EX_SHIFT 	= 2;

	//////////////////////////////////////////////////
	// flags passed as params...

	final static byte FLAG_OFFSET_FM = 0x10;
	final static byte FLAG_OFFSET_AF = 0x20;

	//////////////////////////////////////////////////

	// Modules...
	int			_nModules;			// number of modules
	byte[]		_modules_x;			// x  for each module [BS_MODULES_XY]
	byte[]		_modules_y;			// y  for each module [BS_MODULES_XY]
	byte[]		_modules_w;			// width for each module
	byte[]		_modules_h;			// height for each module

	// Frames...
	byte[]		_frames_nfm;		// number of FModules (max 256 FModules/Frame)
//	short[]		_frames_nfm;		// number of FModules (max 65536 FModules/Frame)
	short[]		_frames_fm_start;	// index of the first FModule
	byte[]		_frames_rc;			// frame bound rect (x y width height)
	// FModules...
	byte[]		_fmodules;			// 4 bytes for each FModule
//	byte[]		_fmodules_module;		// 0 : module index
//	byte[]		_fmodules_ox;			// 1 : ox
//	byte[]		_fmodules_oy;			// 2 : oy
//	byte[]		_fmodules_flags;		// 3 : flags

	// Anims...
	byte[]		_anims_naf;			// number of AFrames (max 256 AFrames/Anim)
//	short[]		_anims_naf;			// number of AFrames (max 65536 AFrames/Anim)
	short[]		_anims_af_start;	// index of the first AFrame
	// AFrames...
	byte[]		_aframes;			// 5 bytes for each AFrame
//	byte[]		_aframes_frame;			// 0 : frame index
//	byte[]		_aframes_time;			// 1 : time
//	byte[]		_aframes_ox;			// 2 : ox
//	byte[]		_aframes_oy;			// 3 : oy
//	byte[]		_aframes_flags;			// 4 : flags

	// Module mappings...
	int[][]		_map; 				// all mappings
//	int			_mappings;			// number of mapings
	private int	_cur_map;			// current mapping

	// Palettes...
//	short 		_pixel_format;		// always converted to 8888
//	int[][]		_pal; 				// all palettes
//	int			_palettes;			// number of palettes
	private int	_crt_pal;			// current palette
//	boolean		_alpha;				// has transparency ?
//	int			_flags;				// transparency, etc.

	// Graphics data (for each module)...
	Image[]		_main_image;		// an image with all modules, for each palette
//	short 		_data_format;
//	byte[]		_modules_data;		// encoded image data for all modules
//	short[]		_modules_data_off;	// offset for the image data of each module
//	int[][]		_modules_data2;		// cashe image data (decoded)
//	Image[][]	_modules_image;		// cache image for each module / with each palette
//	Image[]		_modules_image_fx;	// cache image for each module (flipped horizontally)

////////////////////////////////////////////////////////////////////////////////////////////////////

	ASprite()
	{
	//	_map = null;
	//	_mappings = 0;
	//	_cur_map = -1;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void Load(byte[] file, int offset, Image sprImage)
	{
try
{
		if (DEF.bDbgS) System.out.println("ASprite.Load("+file.length+" bytes, "+offset+")...");

		System.gc();

		short bs_version = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
		if (DEF.bDbgS) System.out.println("bs_version = 0x" + Integer.toHexString(bs_version));
		if (DEF.bErr)
		{
			if (bs_version != BSPRITE_v003)
				System.out.println("ERROR: Invalid BSprite version !");
		}

		int bs_flags =  ((file[offset++]&0xFF)    ) +
						((file[offset++]&0xFF)<< 8) +
						((file[offset++]&0xFF)<<16) +
						((file[offset++]&0xFF)<<24);
		if (DEF.bDbgS) System.out.println("bs_flags = 0x" + Integer.toHexString(bs_flags));
		if (DEF.bErr)
		{
			if (bs_flags != BS_DEFAULT_MIDP1)
				System.out.println("ERROR: Invalid BSprite flags !");
		}

		//////////////////////////////

		// Modules...
		_nModules = (file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8);
		if (DEF.bDbgS) System.out.println("nModules = " + _nModules);
		if (_nModules > 0)
		{
		//	_modules = new byte[nModules<<1]; // only w and h
		//	System.arraycopy(file, offset, _modules, 0, _modules.length);
		//	offset += _modules.length;

		//	if ((bs_flags & BS_MODULES_XY) != 0)
		//	{
				_modules_x  = new byte[_nModules];
				_modules_y  = new byte[_nModules];
		//	}
			_modules_w  = new byte[_nModules];
			_modules_h  = new byte[_nModules];
			for (int i = 0; i < _nModules; i++)
			{
			//	if ((bs_flags & BS_MODULES_XY) != 0)
			//	{
					_modules_x[i] = file[offset++];
					_modules_y[i] = file[offset++];
			//	}
				_modules_w[i] = file[offset++];
				_modules_h[i] = file[offset++];
			}
		}

		//////////////////////////////

		// FModules...
		int nFModules = (file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8);
		if (DEF.bDbgS) System.out.println("nFModules = " + nFModules);
		if (nFModules > 0)
		{
			_fmodules = new byte[nFModules<<2];
			System.arraycopy(file, offset, _fmodules, 0, _fmodules.length);
			offset += _fmodules.length;
		}

		// Frames...
		int nFrames = (file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8);
		if (DEF.bDbgS) System.out.println("nFrames = " + nFrames);
		if (nFrames > 0)
		{
			_frames_nfm      = new  byte[nFrames];
		//	_frames_nfm      = new short[nFrames];
			_frames_fm_start = new short[nFrames];
			for (int i = 0; i < nFrames; i++)
			{
				_frames_nfm[i]      = file[offset++]; if (!ALWAYS_BS_NFM_1_BYTE) offset++;
			//	_frames_nfm[i]      = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
				_frames_fm_start[i] = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
			}

			if (!ALWAYS_BS_SKIP_FRAME_RC)
			{
				if (USE_PRECOMPUTED_FRAME_RECT)
				{
					// Bound rect for each frame...
					int nFrames4 = nFrames<<2;
					_frames_rc = new byte[nFrames4];
					for (int i = 0; i < nFrames4; i++)
						_frames_rc[i] = file[offset++];
				}
				else
					offset += (nFrames<<2);
			}
			else
			{
				if (USE_PRECOMPUTED_FRAME_RECT)
				{
					// TODO: precompute frame rc
				}
			}
		}

		//////////////////////////////

		// AFrames...
		int nAFrames = (file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8);
		if (DEF.bDbgS) System.out.println("nAFrames = " + nAFrames);
		if (nAFrames > 0)
		{
			_aframes = new byte[nAFrames*5];
			System.arraycopy(file, offset, _aframes, 0, _aframes.length);
			offset += _aframes.length;
		}

		// Anims...
		int nAnims = (file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8);
		if (DEF.bDbgS) System.out.println("nAnims = " + nAnims);
		if (nAnims > 0)
		{
			_anims_naf      = new  byte[nAnims];
		//	_anims_naf      = new short[nAnims];
			_anims_af_start = new short[nAnims];
			for (int i = 0; i < nAnims; i++)
			{
				_anims_naf[i]      = file[offset++]; if (!ALWAYS_BS_NAF_1_BYTE) offset++;
			//	_anims_naf[i]      = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
				_anims_af_start[i] = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
			}
		}

		//////////////////////////////

		if (_nModules <= 0)
		{
			if (DEF.bErr) System.out.println("WARNING: sprite with num modules = "+_nModules);
			System.gc();
			return;
		}

		//////////////////////////////

		// The image contains all modules...
		_main_image = new Image[MAX_SPRITE_PALETTES];
		_main_image[0] = sprImage;

		//////////////////////////////
		// module mappings

		if (USE_MODULE_MAPPINGS)
		{
			_map = new int[MAX_MODULE_MAPPINGS][];
		//	_mappings = 0;
			_cur_map = -1;
		}

		//////////////////////////////

		if (DEF.bDbgS) System.out.println("--- ok");
		System.gc();
}
catch (Exception e)
{
	if (DEF.bErr) DBG.CatchException(e, "ASprite.Load()");
}
	}


////////////////////////////////////////////////////////////////////////////////////////////////////

/*
	public String toString()
	{
		String str = new String();

		if (DEF.bDbgM)
		{
			// Memory usage...
			int nModulesMem = 0;
			for (int i = 0; i < _nModules; i++)
				nModulesMem += (_modules_w[i]&0xFF) * (_modules_h[i]&0xFF);
			str = "encoded/decoded: " + _modules_data.length + "/" + ((DEF.bEmu ? 3 : 2) * nModulesMem);
		}

		return str;
	}
*/
////////////////////////////////////////////////////////////////////////////////////////////////////
// Module Mapping...

private void MODULE_MAPPING___() {}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void SetModuleMapping(int map, byte[] mmp)
	{
	//	if (DEF.bASSERT) DBG.ASSERT(map >= 0 && map < _mappings, "map >= 0 && map < _mappings");
		if (_map[map] == null)
		{
			_map[map] = new int[_nModules];
			for (int i = 0; i < _nModules; i++)
				_map[map][i] = i;
		}
		if (mmp == null) return;
		int off = 0;
		while (off < mmp.length)
		{
			int i1 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
			int i2 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
			_map[map][i1] = i2;
		}
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void ApplyModuleMapping(int dst_pal, int src_pal, byte[] mmp)
	{
		int off = 0;
		while (off < mmp.length)
		{
			int i1 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
			int i2 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
			_modules_image[dst_pal][i1] = _modules_image[src_pal][i2];
		}
		System.gc();
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void SetCurrentMMapping(int map)	{ _cur_map = map; }
	int GetCurrentMMapping()			{ return _cur_map; }

////////////////////////////////////////////////////////////////////////////////////////////////////

private void ___MODULE_MAPPING() {}

// ... Module Mapping
////////////////////////////////////////////////////////////////////////////////////////////////////

	int GetAFrameTime(int anim, int aframe)
	{
	//	int af = (_anims_af_start[anim] + aframe);
	//	return _aframes[((af<<2) + af + 1)] & 0xFF;
		return _aframes[(_anims_af_start[anim] + aframe) * 5 + 1] & 0xFF;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	int GetAFrames(int anim)
	{
		return _anims_naf[anim]&0xFF;
	//	return _anims_naf[anim]&0xFFFF;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	int GetFModules(int frame)
	{
		return _frames_nfm[frame]&0xFF;
	//	return _frames_nfm[frame]&0xFFFF;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

    int GetModuleWidth(int module)
    {
        return _modules_w[module]&0xFF;
    }

    int GetModuleHeight(int module)
    {
        return _modules_h[module]&0xFF;
    }

////////////////////////////////////////////////////////////////////////////////////////////////////

    int GetFrameWidth(int frame)
    {
        return _frames_rc[frame*4 + 2]&0xFF;
    }

    int GetFrameHeight(int frame)
    {
        return _frames_rc[frame*4 + 3]&0xFF;
    }

////////////////////////////////////////////////////////////////////////////////////////////////////

    int GetFrameModuleX(int frame, int fmodule)
    {
        int off = (_frames_fm_start[frame] + fmodule) << 2;
        return _fmodules[off+1];
    }

    int GetFrameModuleY(int frame, int fmodule)
    {
        int off = (_frames_fm_start[frame] + fmodule) << 2;
        return _fmodules[off+2];
    }

    int GetFrameModuleWidth(int frame, int fmodule)
    {
        int off = (_frames_fm_start[frame] + fmodule) << 2;
        int index = _fmodules[off]&0xFF;
        return _modules_w[index]&0xFF;
    }

    int GetFrameModuleHeight(int frame, int fmodule)
    {
        int off = (_frames_fm_start[frame] + fmodule) << 2;
        int index = _fmodules[off]&0xFF;
        return _modules_h[index]&0xFF;
    }

////////////////////////////////////////////////////////////////////////////////////////////////////

    int GetAnimFrame(int anim, int aframe)
    {
        int off = (_anims_af_start[anim] + aframe) * 5;
        return _aframes[off]&0xFF;
    }

////////////////////////////////////////////////////////////////////////////////////////////////////

	void GetAFrameRect(int[] rc, int anim, int aframe, int posX, int posY, int flags, int hx, int hy)
	{
	//	System.out.println("GetAFrameRect(rc, "+anim+", "+aframe+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
		int off = (_anims_af_start[anim] + aframe) * 5;
		int frame = _aframes[off]&0xFF;
		if (USE_INDEX_EX_AFRAMES)
			frame |= ((_aframes[off+4]&FLAG_INDEX_EX_MASK)<<INDEX_EX_SHIFT);
		if ((flags & FLAG_OFFSET_AF) != 0)
		{
			if ((flags & FLAG_FLIP_X) != 0)	hx += _aframes[off+2];
			else							hx -= _aframes[off+2];
			if ((flags & FLAG_FLIP_Y) != 0)	hy += _aframes[off+3];
			else							hy -= _aframes[off+3];
		}
	//	if ((flags & FLAG_FLIP_X) != 0)	hx += _frames_w[frame]&0xFF;
	//	if ((flags & FLAG_FLIP_Y) != 0)	hy += _frames_h[frame]&0xFF;
		GetFrameRect(rc, frame, posX, posY, flags ^ (_aframes[off+4]&0x0F), hx, hy);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void GetFrameRect(int[] rc, int frame, int posX, int posY, int flags, int hx, int hy)
	{
	//	System.out.println("GetFrameRect(rc, "+frame+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");

		if (USE_PRECOMPUTED_FRAME_RECT)
		{
			int frame4 = frame<<2;
			int fx = _frames_rc[frame4++];
			int fy = _frames_rc[frame4++];
			int fw = _frames_rc[frame4++]&0xFF;
			int fh = _frames_rc[frame4++]&0xFF;

			if ((flags & FLAG_FLIP_X) != 0)	hx += fx + fw;
			else							hx -= fx;
			if ((flags & FLAG_FLIP_Y) != 0)	hy += fy + fh;
			else							hy -= fy;

			rc[0] = posX - (hx << DEF.FIXED_PRECISION);
			rc[1] = posY - (hy << DEF.FIXED_PRECISION);
			rc[2] = rc[0] + (fw << DEF.FIXED_PRECISION);
			rc[3] = rc[1] + (fh << DEF.FIXED_PRECISION);
		}
		else
		{
// old
//			int fx = (255 << DEF.FIXED_PRECISION);
//			int fy = (255 << DEF.FIXED_PRECISION);
// new
			int fx = 0;
			int fy = 0;
			int fw = 0;
			int fh = 0;

			int nFModules = _frames_nfm[frame]&0xFF;
		//	int nFModules = _frames_nfm[frame]&0xFFFF;
			for (int fmodule = 0; fmodule < nFModules; fmodule++)
			{
				GetFModuleRect(rc, frame, fmodule, posX, posY, flags, hx, hy);
// old
//				if (rc[0] < fx)			fx = rc[0];
//				if (rc[1] < fy)			fy = rc[1];
//				if (rc[2] > fx + fw)	fw = rc[2] - fx;
//				if (rc[3] > fy + fh)	fh = rc[3] - fy;
// new
				if (rc[0] < fx)
				{
					fw = (fx+fw) - rc[0];
					fx = rc[0];
				}

				if (rc[1] < fy)
				{
					fh = (fy+fh) - rc[1];
					fy = rc[1];
				}

				if (rc[2] > fx + fw)
				{
					fw = rc[2] - fx;
				}

				if (rc[3] > fy + fh)
				{
					fh = rc[3] - fy;
				}
			}

			hx <<= DEF.FIXED_PRECISION;
			hy <<= DEF.FIXED_PRECISION;

			if ((flags & FLAG_FLIP_X) != 0)	hx += fx + fw;
			else							hx -= fx;
			if ((flags & FLAG_FLIP_Y) != 0)	hy += fy + fh;
			else							hy -= fy;

			rc[0] = posX - hx;
			rc[1] = posY - hy;
			rc[2] = rc[0] + fw;
			rc[3] = rc[1] + fh;
		}
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void GetFModuleRect(int[] rc, int frame, int fmodule, int posX, int posY, int flags, int hx, int hy)
	{
		rc[0] = GetFrameModuleX(frame, fmodule) << DEF.FIXED_PRECISION;
		rc[1] = GetFrameModuleY(frame, fmodule) << DEF.FIXED_PRECISION;
		rc[2] = rc[0] + (GetFrameModuleWidth(frame, fmodule) << DEF.FIXED_PRECISION);
		rc[3] = rc[1] + (GetFrameModuleHeight(frame, fmodule) << DEF.FIXED_PRECISION);

	//	System.out.println("GetFModuleRect(rc, "+frame+", "+fmodule+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void GetModuleRect(int[] rc, int module, int posX, int posY, int flags)
	{
	//	System.out.println("GetModuleRect(rc, "+module+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+")");
		rc[0] = posX;
		rc[1] = posY;
		rc[2] = posX + ((_modules_w[module]&0xFF) << DEF.FIXED_PRECISION);
		rc[3] = posY + ((_modules_h[module]&0xFF) << DEF.FIXED_PRECISION);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void PaintAFrame(Graphics g, int anim, int aframe, int posX, int posY, int flags, int hx, int hy)
	{
	//	System.out.println("PaintAFrame(g, "+anim+", "+aframe+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
		int off = (_anims_af_start[anim] + aframe) * 5;
		int frame = _aframes[off]&0xFF;
		if (USE_INDEX_EX_AFRAMES)
			frame |= ((_aframes[off+4]&FLAG_INDEX_EX_MASK)<<INDEX_EX_SHIFT);
	//	if ((flags & FLAG_OFFSET_AF) != 0)
		{
			if ((flags & FLAG_FLIP_X) != 0)	hx += _aframes[off+2];
			else							hx -= _aframes[off+2];
			if ((flags & FLAG_FLIP_Y) != 0)	hy += _aframes[off+3];
			else							hy -= _aframes[off+3];
		}
	//	if ((flags & FLAG_FLIP_X) != 0)	hx += _frames_w[frame]&0xFF;
	//	if ((flags & FLAG_FLIP_Y) != 0)	hy += _frames_h[frame]&0xFF;
		PaintFrame(g, frame, posX-hx, posY-hy, flags ^ (_aframes[off+4]&0x0F), hx, hy);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void PaintFrame(Graphics g, int frame, int posX, int posY, int flags, int hx, int hy)
	{
	//	System.out.println("PaintFrame(g, "+frame+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
		int nFModules = _frames_nfm[frame]&0xFF;
	//	int nFModules = _frames_nfm[frame]&0xFFFF;
		for (int fmodule = 0; fmodule < nFModules; fmodule++)
			PaintFModule(g, frame, fmodule, posX, posY, flags, hx, hy);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void PaintFModule(Graphics g, int frame, int fmodule, int posX, int posY, int flags, int hx, int hy)
	{
	//	System.out.println("PaintFModule(g, "+frame+", "+fmodule+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
		int off = (_frames_fm_start[frame] + fmodule) << 2;
	//	int off = (_frames[(frame<<1)+1] + fmodule) << 2;

		int fm_flags = _fmodules[off+3]&0xFF;
		int index = _fmodules[off]&0xFF;
		if (USE_INDEX_EX_FMODULES)
			index |= ((fm_flags&FLAG_INDEX_EX_MASK)<<INDEX_EX_SHIFT);

	//	if ((flags & FLAG_OFFSET_FM) != 0)
		{
			if ((flags & FLAG_FLIP_X) != 0)	posX -= _fmodules[off+1];
			else							posX += _fmodules[off+1];
			if ((flags & FLAG_FLIP_Y) != 0)	posY -= _fmodules[off+2];
			else							posY += _fmodules[off+2];
		}

		if (USE_HYPER_FM && ((fm_flags & FLAG_HYPER_FM) != 0))
		{
		//	if ((flags & FLAG_FLIP_X) != 0)	posX -= _frames[(index<<?)  ]&0xFF; // pF->w
		//	if ((flags & FLAG_FLIP_Y) != 0)	posY -= _frames[(index<<?)+1]&0xFF; // pF->h

			PaintFrame(g, index, posX, posY, flags ^ (fm_flags&0x0F), hx, hy);
		}
		else
		{
			if ((flags & FLAG_FLIP_X) != 0)	posX -= _modules_w[index]&0xFF;
			if ((flags & FLAG_FLIP_Y) != 0)	posY -= _modules_h[index]&0xFF;

			PaintModule(g, index, posX, posY, flags ^ (fm_flags&0x0F));
		}
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void PaintModule(Graphics g, int module, int posX, int posY, int flags)
	{
	//	System.out.println("PaintModule(g, "+module+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+")");
	//	System.out.println("PaintModule(module = "+module+", _crt_pal = "+_crt_pal+")...");

		if (USE_MODULE_MAPPINGS)
		{
			// Apply current module mapping...
			if (_cur_map >= 0)
			{
			//	if (DEF.bASSERT) DBG.ASSERT(_cur_map < _mappings, "_cur_map < _mappings");
			//	if (DEF.bASSERT) DBG.ASSERT(_map[_cur_map] != null, "_map[_cur_map] != null");
				module = _map[_cur_map][module];
			//	System.out.println("module -> "+module);
			}
		}

	//	if (DEF.bASSERT) DBG.ASSERT(module >= 0, "module >= 0");
	//	if (DEF.bASSERT) DBG.ASSERT(module < _nModules, "module < _nModules");
		int sizeX = _modules_w[module]&0xFF;
		int sizeY = _modules_h[module]&0xFF;
		if (sizeX <= 0 || sizeY <= 0) return;
		
		int cx = g.getClipX();
		int cy = g.getClipY();
		int cw = g.getClipWidth();
		int ch = g.getClipHeight();

		int new_cx = posX;
		int new_cy = posY;
		int new_endcx = posX + sizeX;
		int new_endcy = posY + sizeY;

		// Fast visibility test...
		if (posX + sizeX < cx ||
			posY + sizeY < cy ||
			posX >= cx + cw ||
			posY >= cy + ch)
		{
			return;
		}

		if (posX < cx)
			new_cx = cx;
		if (posY < cy)
			new_cy = cy;
			
		if (new_endcx > cx+cw)
			new_endcx = cx+cw;
		if (new_endcy > cy+ch)
			new_endcy = cy+ch;

		g.setClip(new_cx, new_cy, new_endcx - new_cx, new_endcy - new_cy);
		
		g.drawImage(_main_image[_crt_pal], posX - (_modules_x[m]&0xFF), posY - (_modules_y[m]&0xFF), Graphics.TOP | Graphics.LEFT);
		g.setClip(cx, cy, cw, ch);

	//	System.out.println("...PaintModule(_crt_pal = "+_crt_pal+")");
	//	System.out.println("...PaintModule(g, "+module+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+")");
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void SetCurrentPalette(int pal)		{ _crt_pal = pal; }
	int GetCurrentPalette()				{ return _crt_pal; }

////////////////////////////////////////////////////////////////////////////////////////////////////
// Draw String System...

private void DRAW_STRINGS_SYSTEM___() {}

////////////////////////////////////////////////////////////////////////////////////////////////////

	//	_modules_w[0] -> w  -> width of the space character (' ')
	//	_modules_h[0] -> h  -> height of a text line
	//	_fmodules[0*4+1] -> ox -> space between two adiacent chars
	//	_fmodules[0*4+2] -> oy -> base line offset

	// Used to gather dimensions of a string...
	// (call UpdateStringSize() to update these values)
	static int _text_w;
	static int _text_h;

	// Maps an ASCII char to a sprite FModule...
	byte[] _map_char;// = new byte[256]; NEEDS TO BE LOADED FROM RESOURCES !!!

////////////////////////////////////////////////////////////////////////////////////////////////////
// Space between two lines of text...

	private int _line_spacing = 0;

	int  GetLineSpacing()				{ return _line_spacing; }
	void SetLineSpacing(int spacing)	{ _line_spacing = spacing; }
	void SetLineSpacingToDefault()		{ _line_spacing = ((_modules_h[0]&0xFF) >> 1); }

////////////////////////////////////////////////////////////////////////////////////////////////////

	static int _index1 = -1;
	static int _index2 = -1;

	static void SetSubString(int i1, int i2)
	{
		_index1 = i1;
		_index2 = i2;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void UpdateStringSize(String s)
	{
	//	if (DEF.bASSERT) DBG.ASSERT(_map_char != null, "_map_char != null");

		_text_w = 0;
		_text_h = (_modules_h[0]&0xFF);
		int tw = 0;

		int index1 = ((_index1 >= 0) ? _index1 : 0);
		int index2 = ((_index2 >= 0) ? _index2 : s.length());

		for (int i = index1; i < index2; i++)
		{
			int c = s.charAt(i);
			if (c > 32)
			{
				if (DEF.bErr)
				{
					if (c > 255)
					{
						System.out.println("Unknown char: " + c);
						c = 0;
					}
					if (_map_char == null)
					{
						System.out.println("ERROR: _map_char is null !!!");
						break;
					}
				}
				c = _map_char[c]&0xFF;
			}
			else if (c == ' ')
			{
				tw += (_modules_w[0]&0xFF) + _fmodules[1];
				continue;
			}
			else if (c == '\n')
			{
				if (tw > _text_w) _text_w = tw;
				tw = 0;
				_text_h += _line_spacing + (_modules_h[0]&0xFF);
				continue;
			}
			else // if (c < 32)
			{
				if (c == '\u0001') // auto change current palette
				{
					i++;
				//	_crt_pal = s.charAt(i);
					continue;
				}
				else if (c == '\u0002') // select fmodule
				{
					i++;
					c = s.charAt(i);
				}
				else continue;
			}

			if (DEF.bErr)
			{
				if (c >= GetFModules(0))
				{
					System.out.println("Character not available: c = "+c);
					c = 0;
				}
			}

			int m = (_fmodules[c<<2]&0xFF);

			if (DEF.bErr)
			{
				if (m >= _nModules)
				{
					System.out.println("Character module not available: c = "+c+"  m = "+m);
					m = 0;
					c = 0;
				}
			}

			tw += (_modules_w[m]&0xFF) - _fmodules[(c<<2)+1] + _fmodules[1];
		}
		if (tw > _text_w) _text_w = tw;
		if (_text_w > 0) _text_w -= _fmodules[1];
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void DrawString(Graphics g, String s, int x, int y, int anchor)
	{
	//	if (DEF.bASSERT) DBG.ASSERT(_map_char != null, "_map_char != null");

		y -= _fmodules[2];

		if ((anchor & (Graphics.RIGHT | Graphics.HCENTER | Graphics.BOTTOM | Graphics.VCENTER)) != 0)
		{
			UpdateStringSize(s);
				 if ((anchor & Graphics.RIGHT)   != 0)	x -= _text_w;
			else if ((anchor & Graphics.HCENTER) != 0)	x -= _text_w>>1;
				 if ((anchor & Graphics.BOTTOM)  != 0)	y -= _text_h;
			else if ((anchor & Graphics.VCENTER) != 0)	y -= _text_h>>1;
		}

		int xx = x;
		int yy = y;

		int old_pal = _crt_pal;

		int index1 = ((_index1 >= 0) ? _index1 : 0);
		int index2 = ((_index2 >= 0) ? _index2 : s.length());

		for (int i = index1; i < index2; i++)
		{
			int c = s.charAt(i);
			if (c > 32)
			{
				if (DEF.bErr)
				{
					if (c > 255)
					{
						System.out.println("Unknown char: " + c);
						c = 0;
					}
					if (_map_char == null)
					{
						System.out.println("ERROR: _map_char is null !!!");
						break;
					}
				}
				c = _map_char[c]&0xFF;
			}
			else if (c == ' ')
			{
				xx += (_modules_w[0]&0xFF) + _fmodules[1];
				continue;
			}
			else if (c == '\n')
			{
				xx = x;
				yy += _line_spacing + (_modules_h[0]&0xFF);
				continue;
			}
			else // if (c < 32)
			{
				if (c == '\u0001') // auto change current palette
				{
					i++;
					_crt_pal = s.charAt(i);
					continue;
				}
				else if (c == '\u0002') // select fmodule
				{
					i++;
					c = s.charAt(i);
				}
				else continue;
			}

			if (DEF.bErr)
			{
				if (c >= GetFModules(0))
				{
					System.out.println("Character not available: c = "+c);
					c = 0;
				}
			}

			int m = (_fmodules[c<<2]&0xFF);

			if (DEF.bErr)
			{
				if (m >= _nModules)
				{
					System.out.println("Character module not available: c = "+c+"  m = "+m);
					m = 0;
					c = 0;
				}
			}

			PaintFModule(g, 0, c, xx, yy, 0, 0, 0);
			xx += (_modules_w[m]&0xFF) - _fmodules[(c<<2)+1] + _fmodules[1];
		}

		_crt_pal = old_pal;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void DrawPage(Graphics g, String s, int x, int y, int anchor)
	{
		// Count lines...
		int lines = 0;
		int len = s.length();
		int[] off = new int[100];
		for (int i = 0; i < len; i++)
			if (s.charAt(i) == '\n')
				off[lines++] = i;
		off[lines++] = len;

		int th = _line_spacing + (_modules_h[0]&0xFF);

			 if ((anchor & Graphics.BOTTOM)  != 0)	y -= (th * (lines-1));
		else if ((anchor & Graphics.VCENTER) != 0)	y -= (th * (lines-1)) >> 1;

		// Draw each line...
		for (int j = 0; j < lines; j++)
		{
			_index1 = (j > 0) ? off[j-1]+1 : 0;
			_index2 = off[j];
			DrawString(g, s, x, y + j * th, anchor);
		}

		// Disable substring...
		_index1 = -1;
		_index2 = -1;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

private void ___DRAW_STRINGS_SYSTEM() {}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Sprite lib...
/*
	static ASprite[] _sprites;

////////////////////////////////////////////////////////////////////////////////////////////////////

	static ASprite Lib_GetSprite(int index)
	{
		if (index < 0 || index >= _sprites.length)
			return null;
		return _sprites[index];
	}
*/
////////////////////////////////////////////////////////////////////////////////////////////////////

} // class ASprite

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
