////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

package kk;

////////////////////////////////////////////////////////////////////////////////////////////////////

import javax.microedition.lcdui.*;

/*#DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700#*///<editor-fold>
import javax.microedition.lcdui.game.*;
/*$DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700$*///</editor-fold>

/*#Nokia6230i,Series60MIDP1,Series60MIDP2#*///<editor-fold>
//--import com.nokia.mid.ui.*;
/*$Nokia6230i,Series60MIDP1,Series60MIDP2$*///</editor-fold>


import kk.config.*;
import kk.game.*;
import kk.objects.*;
import kk.sprites.*;

import kk._debug.*;


////////////////////////////////////////////////////////////////////////////////////////////////////

final class cSprite implements BSPRITE, LZMA
{
        final static int MAX_SPRITE_PALETTES            = 8;
        final static int MAX_SPRITE_MAPPINGS            = 8;
        
        final static int MAX_STATIC_BUFFER_SIZE         = 3 * 1024;
        
	//////////////////////////////////////////////////

/*#DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700#*///<editor-fold>
        static int           temp[]     = new int[MAX_STATIC_BUFFER_SIZE]; // temp memory
        final static int     ALPHA_MASK = 0xFF000000;
/*$DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700$*///</editor-fold>
        
/*#Series60MIDP1,Series60MIDP2#*///<editor-fold>
//--        static short           temp[]     = new short[MAX_STATIC_BUFFER_SIZE]; // temp memory
//--        final static short     ALPHA_MASK = (short)0xF000;
/*$Series60MIDP1,Series60MIDP2$*///</editor-fold>
        
        
        static boolean _temp_alpha;          // has image decoded in temp transparency ?
        
        //////////////////////////////////////////////////

        // Modules...
        byte[]          _modules;       // 2/4 bytes for each Module
                                        // 0 : x [BS_MODULES_XY] - [pixels]
                                        // 1 : y [BS_MODULES_XY] - [pixels]
                                        // 0/2 : width   - [pixels]
                                        // 1/3 : height  - [pixels]

        // Frames...
        byte[]		_frames_nfm;        // number of FModules (max 256 FModules/Frame)
        short[]		_frames_fm_start;   // index of first FModule
        byte[]		_frames_rc;         // frame bound rect (x y width height)
        
	// FModules...
	byte[]		_fmodules;          // 4 bytes for each FModule
                                            // 0 : module index
                                            // 1 : ox - [pixels]
                                            // 2 : oy - [pixels]
                                            // 3 : flags

	// Anims...
        byte[]          _anims_naf;             // number of AFrames (max 256 AFrames/Anim)
        short[]         _anims_af_start;        // index of first AFrame
        
        // AFrames...
        byte[]          _aframes;           // 5 bytes for each AFrame
                                            // 0 : frame index
                                            // 1 : time
                                            // 2 : ox - [game pixels]
                                            // 3 : oy - [game pixels]
                                            // 4 : flags

        // Module mappings...
        int[][]         _map;               // all mappings
        private int     _cur_map;           // current mapping
        
        // Used for IRLEVAR
        int             _ivar_color_mask;

        // Palettes...
/*#DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700#*///<editor-fold>
        int[][]         _pal;               // all palettes
/*$DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700$*///</editor-fold>
/*#Series60MIDP1,Series60MIDP2#*///<editor-fold>
//--        short[][]       _pal;               // all palettes        
/*$Series60MIDP1,Series60MIDP2$*///</editor-fold>

        int             _palettes;          // number of palettes
        int             _cur_pal;           // current palette
        
        // Graphics data (for each module)...
        short           _data_format;
        
        byte[]          _modules_data;          // encoded image data for all modules
        short[]         _modules_data_off;      // offset for the image data of each module
        
        Image[][]       _modules_image;         // cache image for each module / with each palette
        short[][]       _modules_data_unpacked; // decoded image data for all modules

////////////////////////////////////////////////////////////////////////////////////////////////////

        cSprite(){}

////////////////////////////////////////////////////////////////////////////////////////////////////

        void Load(byte[] file, int offset)
        {
                try
                {
                        DBG.PRINT(DBG.LOAD_SPRITE, "cSprite.Load(%d bytes, %d)...", file.length, offset);

                        System.gc();

                        short bs_version = cGame.Mem_GetShort(file, offset); offset += 2;
                        
                        DBG.PRINT(DBG.LOAD_SPRITE, "bs_version = 0x%h", bs_version);
                        DBG.ASSERT((bs_version == BSPRITE_v003), "ERROR: Invalid BSprite version !");

                        int bs_flags =  cGame.Mem_GetInt(file, offset); offset += 4;
                        
                        DBG.PRINT(DBG.LOAD_SPRITE, "bs_flags = 0x%h", bs_flags);
                        DBG.ASSERT((bs_flags == BS_KK_FLAGS), "ERROR: Invalid BSprite flags !");

                        //////////////////////////////

                        // Modules...
                        short nModules = cGame.Mem_GetShort(file, offset); offset += 2;
                        DBG.PRINT(DBG.LOAD_SPRITE, "nModules = %d", nModules);
                        if (nModules > 0)
                        {
                                _modules = new byte[nModules << 1]; // only w and h
                                System.arraycopy(file, offset, _modules, 0, _modules.length);
                                offset += _modules.length;
                        }

                        //////////////////////////////

                        // FModules...
                        short nFModules = cGame.Mem_GetShort(file, offset); offset += 2;
                        DBG.PRINT(DBG.LOAD_SPRITE, "nFModules = %d", nFModules);
                        
                        if (nFModules > 0)
                        {
                                _fmodules = new byte[nFModules<<2];
                                System.arraycopy(file, offset, _fmodules, 0, _fmodules.length);
                                offset += _fmodules.length;
                        }

                        // Frames...
                        short nFrames = cGame.Mem_GetShort(file, offset); offset += 2;
                        DBG.PRINT(DBG.LOAD_SPRITE, "nFrames = %d", nFrames);
                        
                        if (nFrames > 0)
                        {
                                _frames_nfm      = new  byte[nFrames];
                        //	_frames_nfm      = new short[nFrames];
                                _frames_fm_start = new short[nFrames];
                                for (int i = 0; i < nFrames; i++)
                                {
                                        _frames_nfm[i]      = file[offset++]; offset++;
                                //	_frames_nfm[i]      = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
                                        _frames_fm_start[i] = cGame.Mem_GetShort(file, offset); offset += 2;
                                }

                                // Bound rect for each frame...
                                int nFrames4 = nFrames<<2;
                                _frames_rc = new byte[nFrames4];
                                for (int i = 0; i < nFrames4; i++)
                                        _frames_rc[i] = file[offset++];
                        }

                        //////////////////////////////

                        // AFrames...
                        short nAFrames = cGame.Mem_GetShort(file, offset); offset += 2;
                        DBG.PRINT(DBG.LOAD_SPRITE, "nAFrames = %d", nAFrames);
                        
                        if (nAFrames > 0)
                        {
                                _aframes = new byte[nAFrames*5];
                                System.arraycopy(file, offset, _aframes, 0, _aframes.length);
                                offset += _aframes.length;
                        }

                        // Anims...
                        short nAnims = cGame.Mem_GetShort(file, offset); offset += 2;
                        DBG.PRINT(DBG.LOAD_SPRITE, "nAnims = %d", nAnims);
                        
                        if (nAnims > 0)
                        {
                                _anims_naf      = new  byte[nAnims];
                                _anims_af_start = new short[nAnims];
                                for (int i = 0; i < nAnims; i++)
                                {
                                        _anims_naf[i] = file[offset++];
                                        
                                        if(_anims_naf[i] != 0)
                                        {
                                               _anims_af_start[i] = cGame.Mem_GetShort(file, offset); offset += 2;
                                        }
                                }
                        }

                        //////////////////////////////

                        if (nModules <= 0)
                        {
                                DBG.PRINT(DBG.LOAD_SPRITE, "WARNING: sprite with num modules = %d", nModules);
                                System.gc();
                                return;
                        }

                        //////////////////////////////

                        // Pixel format (must be one of SPRITE_FORMAT_8888, _4444)...
                        short _pixel_format = cGame.Mem_GetShort(file, offset); offset += 2;
                        DBG.PRINT(DBG.LOAD_SPRITE, "_pixel_format = 0x%h", _pixel_format);

                        // Number of palettes...
                        _palettes = file[offset++] & 0xFF;
                        DBG.PRINT(DBG.LOAD_SPRITE, "_palettes = %d", _palettes);

                        // Number of colors...
                        int colors = file[offset++] & 0xFF;
                        DBG.PRINT(DBG.LOAD_SPRITE, "colors = %d", colors);

                        // Palettes...
/*#DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700#*///<editor-fold>
                        _pal = new int[MAX_SPRITE_PALETTES][];
                        for (int p = 0; p < _palettes; p++)
                        {
                                _pal[p] = new int[colors];
                                switch (_pixel_format)
                                {
                                        // _8888 -> _8888
                                        case PIXEL_FORMAT_8888:
                                                for (int c = 0; c < colors; c++)
                                                {
                                                        _pal[p][c] = cGame.Mem_GetInt(file, offset); offset += 4;
                                                }
                                                break;

                                        // _4444 -> _8888
                                        case PIXEL_FORMAT_4444:
                                                for (int c = 0; c < colors; c++)
                                                {
                                                        // 4444 -> 8888
                                                        int _4444 = cGame.Mem_GetShort(file, offset); offset += 2;
                                                        _pal[p][c] = ((_4444 & 0xF000) << 16) | ((_4444 & 0xF000) << 12) |
                                                                     ((_4444 & 0x0F00) << 12) | ((_4444 & 0x0F00) <<  8) |
                                                                     ((_4444 & 0x00F0) <<  8) | ((_4444 & 0x00F0) <<  4) |
                                                                     ((_4444 & 0x000F) <<  4) | ((_4444 & 0x000F)      );
                                                }
                                                break;
                                }
                        }
/*$DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700$*///</editor-fold>
                        
/*#Series60MIDP1,Series60MIDP2#*///<editor-fold>
//--                        _pal = new short[MAX_SPRITE_PALETTES][];
//--                        for (int p = 0; p < _palettes; p++)
//--                        {
//--                                _pal[p] = new short[colors];
//--                                switch (_pixel_format)
//--                                {
//--                                        // _8888 -> _4444
//--                                        case PIXEL_FORMAT_8888:
//--                                                for (int c = 0; c < colors; c++)
//--                                                {
//--                                                        int _4444  = ((file[offset++]&0xF0)>>4);
//--                                                            _4444 |= ((file[offset++]&0xF0)   );
//--                                                            _4444 |= ((file[offset++]&0xF0)<<4);
//--                                                            _4444 |= ((file[offset++]&0xF0)<<8);
//--                                                        _pal[p][c] = (short)(_4444 & 0xFFFF);
//--                                                }
//--                                                break;
//--
//--                                        // _4444 -> _4444
//--                                        case PIXEL_FORMAT_4444:
//--                                                for (int c = 0; c < colors; c++)
//--                                                {
//--                                                        // 4444 -> 8888
//--                                                        _pal[p][c] = cGame.Mem_GetShort(file, offset); offset += 2;
//--                                                }
//--                                                break;
//--                                }
//--                        }
/*$Series60MIDP1,Series60MIDP2$*///</editor-fold>

                        //////////////////////////////

                        // Data format (must be one of ENCODE_FORMAT_I2, _I4, _I16, _I256, _I127RLE)...
                        _data_format = cGame.Mem_GetShort(file, offset); offset += 2;
                        DBG.PRINT(DBG.LOAD_SPRITE, "_data_format = 0x%h", _data_format);
                        
                        if(_data_format == ENCODE_FORMAT_I127VAR)
                        {
                                colors--;
                                _ivar_color_mask = 1;
                                while(colors != 0)
                                {
                                    colors           >>= 1;
                                    _ivar_color_mask <<= 1;
                                }
                                _ivar_color_mask--;
                        }

                        // Graphics data...
                        if (nModules > 0)
                        {
                                _modules_data_off = new short[nModules];
                                int len = 0;
                                int off = offset;
                                for (int m = 0; m < nModules; m++)
                                {
                                        // Image data for the module...
                                        short size = cGame.Mem_GetShort(file, off); off += 2;
                                        _modules_data_off[m] = (short)len;
                                        off += size;
                                        len += size;
                                }

                                _modules_data = new byte[len];
                                for (int m = 0; m < nModules; m++)
                                {
                                        // Image data for the module...
                                        short size = cGame.Mem_GetShort(file, offset); offset += 2;
                                        DBG.PRINT(DBG.LOAD_SPRITE, "frame[%d] size = %d",m , size);
                                        
                                        System.arraycopy(file, offset, _modules_data, _modules_data_off[m]&0xFFFF, size);
                                        offset += size;
                                }
                        }

                        //////////////////////////////
                        // module mappings

                        _map     = new int[MAX_SPRITE_MAPPINGS][];
                        _cur_map = -1;

                        //////////////////////////////

                        DBG.COMP_MAX_TEMP_SIZE(_modules, nModules);
                        
                        DBG.PRINT(DBG.LOAD_SPRITE, "...cSprite.Load()");
                        System.gc();
                }
                catch (Exception e)
                {
                        DBG.CATCH_EXCEPTION(e, "cSprite.Load()");
                }
        }


////////////////////////////////////////////////////////////////////////////////////////////////////

/*#DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700#*///<editor-fold>
        Image BuildCacheImage(int module)
        {
                int m = module << 1;
                int sizeX = _modules[m++]&0xFF;
                int sizeY = _modules[m  ]&0xFF;
                if (sizeX <= 0 || sizeY <= 0) return null;

                if(!DecodeImage(module, 0))
                        return null;

                PROFILER.SPRITE_BUILD_UPDATE(sizeX * sizeY);

                return Image.createRGBImage(temp, sizeX, sizeY, _temp_alpha);
        }
/*$DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700$*///</editor-fold>
        
/*#Series60MIDP2#*///<editor-fold>
//--        static int temp_tile[] = new int[256];
//--        static int pal_tile[]  = new int[128];
//--        
//--        Image  BuildCacheImage(int module)
//--        {
//--                boolean temp_alpha = false;
//--                
//--                int m = module << 1;
//--                int sizeX = _modules[m++] & 0xFF;
//--                int sizeY = _modules[m  ] & 0xFF;
//--                if (sizeX <= 0 || sizeY <= 0) return null;
//--                
//--                byte[] image = _modules_data;
//--                int si = _modules_data_off[module] & 0xFFFF;
//--                int di = 0;
//--                int ds = sizeX * sizeY;
//--                int c, c2, clr;
//--                
//--                int[] img_data = temp_tile;
//--                int[] pal      = pal_tile;
//--                
//--                for (c = 0; c < _pal[_cur_pal].length; c++)
//--                {
//--                        // 4444 -> 8888
//--                        int _4444 = _pal[_cur_pal][c];
//--                        pal[c] = ((_4444 & 0xF000) << 16) | ((_4444 & 0xF000) << 12) |
//--                                     ((_4444 & 0x0F00) << 12) | ((_4444 & 0x0F00) <<  8) |
//--                                     ((_4444 & 0x00F0) <<  8) | ((_4444 & 0x00F0) <<  4) |
//--                                     ((_4444 & 0x000F) <<  4) | ((_4444 & 0x000F)      );
//--                }
//--                
//--                while (di < ds)
//--                {
//--                        c  = image[si++] & 0xFF;
//--                        if (c > 127)
//--                        {
//--                                c2 = image[si++] & 0xFF;
//--                                clr = pal[c2];
//--
//--                                c -= 128;
//--                                while (c-- > 0)
//--                                {
//--                                        img_data[di++] = clr;
//--                                }
//--                        }
//--                        else
//--                        {
//--                                clr            = pal[c];
//--                                img_data[di++] = clr;
//--                        }
//--
//--                        if ((clr & 0xFF000000) != 0xFF000000)
//--                                temp_alpha = true;
//--                }
//--
//--                return Image.createRGBImage(temp_tile, sizeX, sizeY, temp_alpha);
//--        }
/*$Series60MIDP2$*///</editor-fold>
        
/*#Series60MIDP1#*///<editor-fold>
//--        Image BuildCacheImage(int module)
//--        {
//--                int m = module << 1;
//--                int sizeX = _modules[m++]&0xFF;
//--                int sizeY = _modules[m  ]&0xFF;
//--                int size = sizeX * sizeY;
//--                if (size == 0) return null;
//--                
//--                short[] image_data = temp;
//--
//--                if(!DecodeImage(module, 0))
//--                        return null;
//--
//--                // workaround for a bug on 6600 phones
//--                if(PHONE.bCreateImageBug)
//--                {
//--                        if (((sizeX & 1) != 0) || ((sizeY & 1) != 0))
//--                       {
//--                                int sx  = sizeX + (sizeX & 1);
//--                                int sy  = sizeY + (sizeY & 1);
//--                                
//--                                short[] local_buffer = new short[sx * sy];
//--                                
//--                                for (int y = 0; y < sizeY; y++)
//--                                {
//--                                        for (int x = 0; x < sizeX; x++)
//--                                        {
//--                                                local_buffer[x + y * sx] = image_data[x + y * sizeX];
//--                                        }
//--                                }
//--                                
//--                                if ((sizeX & 1) != 0)
//--                                {
//--                                        for (int y = 0; y < sy; y++)
//--                                        {
//--                                                local_buffer[sizeX + y * sx] = 0;
//--                                        }
//--                                }
//--                                
//--                                if ((sizeY & 1) != 0)
//--                                {
//--                                        for (int x = 0; x < sx; x++)
//--                                        {
//--                                                local_buffer[x + (sy-1)*sx] = 0;
//--                                        }
//--                                }
//--                                
//--                                sizeX      = sx;
//--                                sizeY      = sy;
//--                                image_data = local_buffer;
//--                        }
//--                }
//--
//--                PROFILER.SPRITE_BUILD_UPDATE(size);
//--                
//--                Image img         = DirectUtils.createImage(sizeX, sizeY, 0xFF000000);
//--                DirectGraphics dg = DirectUtils.getDirectGraphics(img.getGraphics());
//--                
//--                dg.drawPixels(image_data, true, 0, sizeX, 0, 0, sizeX, sizeY, 0, DirectGraphics.TYPE_USHORT_4444_ARGB);
//--
//--                image_data = null;
//--                System.gc();
//--                
//--                return img;
//--        }
/*$Series60MIDP1$*///</editor-fold>
        
////////////////////////////////////////////////////////////////////////////////////////////////////

/*#Series60MIDP1#*///<editor-fold>
//--        short[] BuildCacheTile(int module)
//--        {
//--                int m = module << 1;
//--                int sizeX = _modules[m++]&0xFF;
//--                int sizeY = _modules[m  ]&0xFF;
//--                int size = sizeX * sizeY;
//--                if (size == 0) return null;
//--
//--                if(!DecodeImage(module, 0))
//--                        return null;
//--        
//--                PROFILER.SPRITE_BUILD_UPDATE(size);
//--        
//--                short[] img = new short[size];
//--                System.arraycopy(temp, 0, img, 0, size);
//--        
//--                return img;
//--        }
/*$Series60MIDP1$*///</editor-fold>

////////////////////////////////////////////////////////////////////////////////////////////////////
// pal = palette to be initailized
// m1 = first module
// m2 = last module (-1 -> to end)
// pal_copy = mapping to another palette (-1 -> build)

	void BuildCacheImages(int pal, int m1, int m2, int pal_copy)
	{
                int old_pal;

                if (_modules == null) return;

                if (m2 == -1)
                        m2 = (_modules.length>>1) - 1;

                if (_modules_image == null)
                        _modules_image = new Image[_palettes][];

                if (_modules_image[pal] == null)
                        _modules_image[pal] = new Image[_modules.length>>1];

                if (pal_copy >= 0)
                {
                        for (int i = m1; i <= m2; i++)
                                _modules_image[pal][i] = _modules_image[pal_copy][i];
                }
                else
                {
                        old_pal  = _cur_pal;
                        _cur_pal = pal;

                        System.gc();
                        PROFILER.SPRITE_BUILD_RESET(m2 - m1 + 1);

                        for (int i = m1; i <= m2; i++)
                        {
                                _modules_image[pal][i] = BuildCacheImage(i);
                        }

                        System.gc();
                        PROFILER.SPRITE_BUILD_PRINT();

                        _cur_pal = old_pal;
                }
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void SetModuleMapping(int map, byte[] mmp)
	{
		if (_map[map] == null)
		{
			int modules = _modules.length>>1;
			_map[map] = new int[modules];
			for (int i = 0; i < modules; i++)
				_map[map][i] = i;
		}
		if (mmp == null) return;
                
		int off = 0;
		while (off < mmp.length)
		{
			int i1 = cGame.Mem_GetShort(mmp, off); off += 2; 
			int i2 = cGame.Mem_GetShort(mmp, off); off += 2; 
			_map[map][i1] = i2;
		}
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void ApplyModuleMapping(int dst_pal, int src_pal, byte[] mmp)
	{
		int off = 0;
		while (off < mmp.length)
		{
			int i1 = cGame.Mem_GetShort(mmp, off); off += 2; 
			int i2 = cGame.Mem_GetShort(mmp, off); off += 2; 
			_modules_image[dst_pal][i1] = _modules_image[src_pal][i2];
		}
		System.gc();
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	int GetAFrameTime(int anim, int aframe)
	{
		return _aframes[(_anims_af_start[anim] + aframe) * 5 + 1] & 0xFF;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	int GetAFrames(int anim)
	{
		return _anims_naf[anim] & 0xFF;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	int GetFModules(int frame)
	{
		return _frames_nfm[frame] & 0xFF;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

        void GetAFrameRect(int[] rc, int anim, int aframe, int posX, int posY, int flags, int hx, int hy)
        {
                int off   = (_anims_af_start[anim] + aframe) * 5;
                int frame = _aframes[off] & 0xFF;

                if (USE_INDEX_EX_AFRAMES)
                {
                        frame |= ((_aframes[off + 4] & FLAG_INDEX_EX_MASK) << INDEX_EX_SHIFT);
                }

                if ((flags & FLAG_OFFSET_AF) != 0)
                {
                        if ((flags & FLAG_FLIP_X) != 0)	hx += _aframes[off + 2] * GAME.ZOOM_X / GAME.ZOOM_X_DIV;
                        else                            hx -= _aframes[off + 2] * GAME.ZOOM_X / GAME.ZOOM_X_DIV;
                        if ((flags & FLAG_FLIP_Y) != 0)	hy += _aframes[off + 3] * GAME.ZOOM_Y / GAME.ZOOM_Y_DIV;
                        else                            hy -= _aframes[off + 3] * GAME.ZOOM_Y / GAME.ZOOM_Y_DIV;
                }

                GetFrameRect(rc, frame, posX, posY, flags ^ (_aframes[off + 4] & 0x0F), hx, hy);
        }

////////////////////////////////////////////////////////////////////////////////////////////////////

        void GetFrameRect(int[] rc, int frame, int posX, int posY, int flags, int hx, int hy)
        {
                int frame4 = (frame << 2);
                int fx = _frames_rc[frame4++];
                int fy = _frames_rc[frame4++];
                int fw = _frames_rc[frame4++] & 0xFF;
                int fh = _frames_rc[frame4++] & 0xFF;

                if ((flags & FLAG_FLIP_X) != 0) hx += fx + fw;
                else                            hx -= fx;
                if ((flags & FLAG_FLIP_Y) != 0) hy += fy + fh;
                else                            hy -= fy;
                
                rc[0] = posX  - (hx << 8);
                rc[1] = posY  - (hy << 8);
                rc[2] = rc[0] + (fw << 8);
                rc[3] = rc[1] + (fh << 8);
        }

////////////////////////////////////////////////////////////////////////////////////////////////////

        void GetModuleRect(int[] rc, int module, int posX, int posY, int flags)
        {
                int m = (module << 1);
                rc[0] = posX;
                rc[1] = posY;
                rc[2] = posX + ((_modules[m + 0] & 0xFF) << 8);
                rc[3] = posY + ((_modules[m + 1] & 0xFF) << 8);
        }

////////////////////////////////////////////////////////////////////////////////////////////////////

        void PaintAFrame(Graphics g, int anim, int aframe, int posX, int posY, int flags, int hx, int hy)
        {
                int off   = (_anims_af_start[anim] + aframe) * 5;
                int frame = _aframes[off] & 0xFF;
                
                if (USE_INDEX_EX_AFRAMES)
                {
                        frame |= ((_aframes[off + 4] & FLAG_INDEX_EX_MASK) << INDEX_EX_SHIFT);
                }
                
                if ((flags & FLAG_OFFSET_AF) != 0)
                {
                        if ((flags & FLAG_FLIP_X) != 0) hx += _aframes[off + 2] * GAME.ZOOM_X / GAME.ZOOM_X_DIV;
                        else                            hx -= _aframes[off + 2] * GAME.ZOOM_X / GAME.ZOOM_X_DIV;
                        if ((flags & FLAG_FLIP_Y) != 0) hy += _aframes[off + 3] * GAME.ZOOM_Y / GAME.ZOOM_Y_DIV;
                        else                            hy -= _aframes[off + 3] * GAME.ZOOM_Y / GAME.ZOOM_Y_DIV;
                }
                
                PaintFrame(g, frame, posX - hx, posY - hy, flags ^ (_aframes[off + 4] & 0x0F), hx, hy);
        }

////////////////////////////////////////////////////////////////////////////////////////////////////

        void PaintFrame(Graphics g, int frame, int posX, int posY, int flags, int hx, int hy)
        {
                int nFModules = (_frames_nfm[frame] & 0xFF);

                for (int fmodule = 0; fmodule < nFModules; fmodule++)
                {
                        PaintFModule(g, frame, fmodule, posX, posY, flags, hx, hy);
                }
        }

////////////////////////////////////////////////////////////////////////////////////////////////////

        void PaintFModule(Graphics g, int frame, int fmodule, int posX, int posY, int flags, int hx, int hy)
        {
                int off = (_frames_fm_start[frame] + fmodule) << 2;

                int fm_flags = _fmodules[off + 3] & 0xFF;
                int index    = _fmodules[off + 0] & 0xFF;

                if (USE_INDEX_EX_FMODULES)
                {
                        index |= ((fm_flags & FLAG_INDEX_EX_MASK) << INDEX_EX_SHIFT);
                }

        //	if ((flags & FLAG_OFFSET_FM) != 0)
                {
                        if ((flags & FLAG_FLIP_X) != 0)	posX -= _fmodules[off + 1];
                        else                            posX += _fmodules[off + 1];
                        if ((flags & FLAG_FLIP_Y) != 0)	posY -= _fmodules[off + 2];
                        else                            posY += _fmodules[off + 2];
                }

                if ((fm_flags & FLAG_HYPER_FM) != 0)
                {
                        PaintFrame(g, index, posX, posY, flags ^ (fm_flags & 0x0F), hx, hy);
                }
                else
                {
                        if ((flags & FLAG_FLIP_X) != 0) posX -= _modules[(index << 1) + 0] & 0xFF;
                        if ((flags & FLAG_FLIP_Y) != 0) posY -= _modules[(index << 1) + 1] & 0xFF;

                        PaintModule(g, index, posX, posY, flags ^ (fm_flags&0x0F));
                }
        }

////////////////////////////////////////////////////////////////////////////////////////////////////

        void PaintModule(Graphics g, int module, int posX, int posY, int flags)
        {
                // Apply current module mapping...
                if (_cur_map >= 0)
                {
                        module = _map[_cur_map][module];
                }

                int m = (module << 1);
                int sizeX = _modules[m + 0] & 0xFF;
                int sizeY = _modules[m + 1] & 0xFF;
                if (sizeX <= 0 || sizeY <= 0) return;

                Image img = null;

                // Try to use cached images...
                if ((_modules_image != null) &&
                    (_cur_pal < _modules_image.length) &&
                    (_modules_image[_cur_pal] != null))
                        img = _modules_image[_cur_pal][module];


/*#DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700#*///<editor-fold>
                int trans = Sprite.TRANS_NONE;
                if ((flags & FLAG_FLIP_X) != 0)
                {
                        if ((flags & FLAG_FLIP_Y) != 0)
                        {
                                trans = Sprite.TRANS_ROT180;
                        }
                        else
                        {
                                trans = Sprite.TRANS_MIRROR;
                        }
                }
                else if ((flags & FLAG_FLIP_Y) != 0)
                {
                        trans = Sprite.TRANS_MIRROR_ROT180;
                }
/*$DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700$*///</editor-fold>
                
/*#Series60MIDP1,Series60MIDP2#*///<editor-fold>
//--                int trans = 0;
//--                if ((flags & FLAG_FLIP_X) != 0)
//--                {
//--                        if ((flags & FLAG_FLIP_Y) != 0)
//--                        {
//--                                trans = DirectGraphics.ROTATE_180;
//--                        }
//--                        else
//--                        {
//--                                trans = DirectGraphics.FLIP_HORIZONTAL;
//--                        }
//--                }
//--                else if ((flags & FLAG_FLIP_Y) != 0)
//--                {
//--                        trans = DirectGraphics.FLIP_VERTICAL;
//--                }
/*$Series60MIDP1,Series60MIDP2$*///</editor-fold>

                
                // Build RGB image...
                if (img == null)
                {
                        if(!DecodeImage(module, flags))
                        {
                                DBG.PRINT(-1, "DecodeImage() FAILED !");
                                return;
                        }

/*#DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700#*///<editor-fold>
                        g.drawRGB(temp, 0, sizeX, posX, posY, sizeX, sizeY, _temp_alpha);
/*$DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700$*///</editor-fold>

/*#Series60MIDP1,Series60MIDP2#*///<editor-fold>
//--                        DirectGraphics dg = DirectUtils.getDirectGraphics(g);
//--                        dg.drawPixels(temp, _temp_alpha, 0, sizeX, posX, posY, sizeX, sizeY, trans, DirectGraphics.TYPE_USHORT_4444_ARGB);
/*$Series60MIDP1,Series60MIDP2$*///</editor-fold>
                        return;
                }

                sizeX = img.getWidth();
                sizeY = img.getHeight();
                
/*#!Series60MIDP1,Series60MIDP2#*///<editor-fold>
                g.drawRegion(img, 0, 0, sizeX, sizeY, trans, posX, posY, 0);
/*$!Series60MIDP1,Series60MIDP2$*///</editor-fold>
/*#Series60MIDP1,Series60MIDP2#*///<editor-fold>
//--                g.drawImage(img, posX, posY, A.LEFT_TOP);
/*$Series60MIDP1,Series60MIDP2$*///</editor-fold>                
        }

////////////////////////////////////////////////////////////////////////////////////////////////////

        boolean DecodeImage(int module, int flags)
	{
                if (_modules_data == null || _modules_data_off == null) return false;

                int m = (module << 1);
                int sizeX = _modules[m + 0] & 0xFF;
                int sizeY = _modules[m + 1] & 0xFF;
        //      if (sizeX <= 0 || sizeY <= 0) return null;

/*#DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700#*///<editor-fold>
                int[] img_data = temp;
                int[] pal      = _pal[_cur_pal];
                int   clr;
/*$DefaultConfiguration,MotorolaMPX220,MotorolaV300,MotorolaC975,Motorolai860,Nokia6230i,SamsungD500,SamsungE720,SamsungZ130,SonyEricssonK700$*///</editor-fold>

/*#Series60MIDP1,Series60MIDP2#*///<editor-fold>
//--                short[] img_data = temp;
//--                short[] pal      = _pal[_cur_pal];
//--                short   clr;
/*$Series60MIDP1,Series60MIDP2$*///</editor-fold>
                
                if (pal == null) return false;
                
                _temp_alpha = false;

                byte[] image = _modules_data;
                int si = _modules_data_off[module] & 0xFFFF;
                int di = 0;
                int ds = sizeX * sizeY;
                int c, c2;
                
                // Build displayable...
                switch (_data_format)
                {
                    /*
                        case ENCODE_FORMAT_I2:
                                // 8 pixels/byte, max 2 colors...
                                while (di < ds)
                                {
                                        img_data[di++] = pal[(image[si] >> 7) & 0x01];
                                        img_data[di++] = pal[(image[si] >> 6) & 0x01];
                                        img_data[di++] = pal[(image[si] >> 5) & 0x01];
                                        img_data[di++] = pal[(image[si] >> 4) & 0x01];
                                        img_data[di++] = pal[(image[si] >> 3) & 0x01];
                                        img_data[di++] = pal[(image[si] >> 2) & 0x01];
                                        img_data[di++] = pal[(image[si] >> 1) & 0x01];
                                        img_data[di++] = pal[(image[si]     ) & 0x01];
                                        si++;
                                }
                                break;

                        case ENCODE_FORMAT_I4:
                                // 4 pixels/byte, max 4 colors...
                                while (di < ds)
                                {
                                        img_data[di++] = pal[(image[si] >> 6) & 0x03];
                                        img_data[di++] = pal[(image[si] >> 4) & 0x03];
                                        img_data[di++] = pal[(image[si] >> 2) & 0x03];
                                        img_data[di++] = pal[(image[si]     ) & 0x03];
                                        si++;
                                }
                                break;
                        */
                        case ENCODE_FORMAT_I16:
                                // 2 pixels/byte, max 16 colors...
                                while (di < ds)
                                {
                                        img_data[di++] = pal[(image[si] >> 4) & 0x0F];
                                        img_data[di++] = pal[(image[si]     ) & 0x0F];
                                        si++;
                                }
                                break;
                        
                        case ENCODE_FORMAT_I256:
                                // 1 pixel/byte, max 256 colors...
                                while (di < ds)
                                        img_data[di++] = pal[image[si++] & 0xFF];
                                break;

                        case ENCODE_FORMAT_I127RLE:
                                // RLE compression, max 127 colors...
                                while (di < ds)
                                {
                                        c  = image[si++] & 0xFF;
                                        if (c > 127)
                                        {
                                                c2 = image[si++] & 0xFF;
                                                clr = pal[c2];

                                                c -= 128;
                                                while (c-- > 0)
                                                {
                                                        img_data[di++] = clr;
                                                }
                                        }
                                        else
                                        {
                                                clr            = pal[c];
                                                img_data[di++] = clr;
                                        }
                                        
                                        if ((clr & ALPHA_MASK) != ALPHA_MASK)
                                                _temp_alpha = true;
                                }
                                break;
                                
                        case ENCODE_FORMAT_I127VAR:
                                // RLE VAR compression, max 127 colors...
                                int color_bits = 0;
                                
                                while((_ivar_color_mask & (1 << color_bits)) != 0) 
                                {
                                        color_bits++;
                                }
                                
                                while (di < ds)
                                {
                                        c     = image[si++] & 0xFF;
                                        c2    = c & _ivar_color_mask;
                                        clr   = pal[c2];
                                        c   >>= color_bits;

                                        while (c-- >= 0)
                                        {
                                                img_data[di++] = clr;
                                        }
                                        
                                        if ((clr & ALPHA_MASK) != ALPHA_MASK)
                                                _temp_alpha = true;
                                }
                                break;
                }

                int i, j, t, t2, j2;
/*#!Series60MIDP1,Series60MIDP2#*///<editor-fold>
                if ((flags & FLAG_FLIP_X) != 0)
                {
                        t2 = sizeX * sizeY;
                        t  = sizeX >> 1;
                        for(i = 0; i < t2; i += sizeX)
                        {

                                for(j = 0, j2 = sizeX-1; j < t; j++, j2--)
                                {
                                        clr = img_data[i + j];
                                        img_data[i + j] = img_data[i + j2];
                                        img_data[i + j2] = clr;
                                }
                        }
                }
                if ((flags & FLAG_FLIP_Y) != 0)
                {
                        for(i = 0, t = 0, t2 = sizeX*(sizeY-1); i < (sizeY>>1); i++, t += sizeX, t2 -= sizeX)
                        {

                                for(j = 0; j < sizeX; j++)
                                {
                                        clr = img_data[t + j];
                                        img_data[t + j] = img_data[t2 + j];
                                        img_data[t2 + j] = clr;
                                }
                        }
                }
/*$!Series60MIDP1,Series60MIDP2$*///</editor-fold>

                // check for alpha
                if (_data_format != ENCODE_FORMAT_I127RLE && _data_format != ENCODE_FORMAT_I127VAR)
                {
                        ds = sizeX * sizeY;
                        for (di = 0; di < ds; di++)
                        {
                                if ((img_data[di] & ALPHA_MASK) != ALPHA_MASK)
                                {
                                        _temp_alpha = true;
                                        break;
                                }
                        }
                }
                
                return true;
        }

////////////////////////////////////////////////////////////////////////////////////////////////////

        void SetCurrentMMapping(int map)     { _cur_map = map;  }
        int  GetCurrentMMapping()            { return _cur_map; }

////////////////////////////////////////////////////////////////////////////////////////////////////

        void SetCurrentPalette(int pal)      { _cur_pal = pal;  }
        int  GetCurrentPalette()             { return _cur_pal; }

        //void SetPaletteColor(int pal, int colorIndex, int newColor)  {_pal[pal][colorIndex] = newColor;}
        
////////////////////////////////////////////////////////////////////////////////////////////////////

        
        
////////////////////////////////////////////////////////////////////////////////////////////////////
// Draw String System...
////////////////////////////////////////////////////////////////////////////////////////////////////

	//	_modules[0] -> w  -> width of the space character (' ')
	//	_modules[1] -> h  -> height of a text line
	//	_fmodules[0*4+1] -> ox -> space between two adiacent chars
	//	_fmodules[0*4+2] -> oy -> base line offset

	// Used to gather dimensions of a string...
	// (call UpdateStringSize() to update these values)
	static int _text_w;
	static int _text_h;

////////////////////////////////////////////////////////////////////////////////////////////////////
// Space between two lines of text...

        private int _line_spacing;// = 0;

        int  GetLineSpacing()                   { return _line_spacing; }
        void SetLineSpacing(int spacing)        { _line_spacing = spacing; }
        void SetLineSpacingToDefault()          { _line_spacing = ((_modules[1] & 0xFF) >> 1); }

////////////////////////////////////////////////////////////////////////////////////////////////////

	static int _index1 = -1;
	static int _index2 = -1;

	void SetSubString(int i1, int i2)
	{
		_index1 = i1;
		_index2 = i2;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void UpdateStringSize(String s)
	{
		_text_w = 0;
		_text_h = (_modules[1] & 0xFF);
		int tw = 0;

		int index1 = ((_index1 >= 0) ? _index1 : 0);
		int index2 = ((_index2 >= 0) ? _index2 : s.length());

		for (int i = index1; i < index2; i++)
		{
			int c = s.charAt(i);
			if (c == ' ')
			{
				tw += (_modules[0]&0xFF) + _fmodules[1];
				continue;
			}
			else if (c == '\n')
			{
				if (tw > _text_w) _text_w = tw;
				tw = 0;
				_text_h += _line_spacing + (_modules[1]&0xFF);
				continue;
			}
			else if (c < 32)
			{
				if (c == '\u0001') // auto change current palette
				{
					i++;
				//	_cur_pal = s.charAt(i);
					continue;
				}
				else if (c == '\u0002') // select fmodule
				{
					i++;
					c = s.charAt(i);
				}
				else continue;
			}
			else
				c = Char2Frame(c);

			if (c >= GetFModules(0))
			{
				DBG.PRINT(-1, "Character not available: c = %d", (int)c);
				c = 0;
			}

			int m = (_fmodules[c<<2]&0xFF)<<1;

			if (m >= _modules.length)
			{
				DBG.PRINT(-1, "Character module not available: c = %d,  m = %d", (int)c, (m>>1));
				m = 0;
				c = 0;
			}

			tw += (_modules[m]&0xFF) - _fmodules[(c<<2)+1] + _fmodules[1];
		}
		if (tw > _text_w) _text_w = tw;
		if (_text_w > 0) _text_w -= _fmodules[1];
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

        void DrawString(Graphics g, String s, int x, int y, int anchor)
        {
                y -= _fmodules[2];
                
                if ((anchor & (A.RIGHT | A.HCENTER | A.BOTTOM | A.VCENTER)) != 0)
                {
                        UpdateStringSize(s);
                             if ((anchor & A.RIGHT)   != 0)     x -= _text_w;
                        else if ((anchor & A.HCENTER) != 0)     x -= _text_w >> 1;
                             if ((anchor & A.BOTTOM)  != 0)     y -= _text_h;
                        else if ((anchor & A.VCENTER) != 0)     y -= _text_h >> 1;
                }

                int xx = x;
                int yy = y;

                int old_pal = _cur_pal;

                int index1 = ((_index1 >= 0) ? _index1 : 0);
                int index2 = ((_index2 >= 0) ? _index2 : s.length());

                for (int i = index1; i < index2; i++)
                {
                        int c = s.charAt(i);
                        if (c == ' ')
                        {
                                xx += (_modules[0]&0xFF) + _fmodules[1];
                                continue;
                        }
                        else if (c == '\n')
                        {
                                xx = x;
                                yy += _line_spacing + (_modules[1]&0xFF);
                                continue;
                        }
                        else if (c < 32)
                        {
                                if (c == '\u0001') // auto change current palette
                                {
                                        i++;
                                        _cur_pal = s.charAt(i);
                                        continue;
                                }
                                else if (c == '\u0002') // select fmodule
                                {
                                        i++;
                                        c = s.charAt(i);
                                }
                                else continue;
                        }
                        else // c > 32
                        {
                                c = Char2Frame(c);
                        }

                        if (c >= GetFModules(0))
                        {
                                DBG.PRINT(-1, "Character not available: c = %d", (int)c);
                                c = 0;
                        }

                        int m = (_fmodules[c<<2]&0xFF)<<1;

                        if (m >= _modules.length)
                        {
                                DBG.PRINT(-1, "Character module not available: c = %d,  m = %d", (int)c, (m>>1));
                                m = 0;
                                c = 0;
                        }

                        PaintFModule(g, 0, c, xx, yy, 0, 0, 0);
                        xx += (_modules[m]&0xFF) - _fmodules[(c<<2)+1] + _fmodules[1];
                }

                _cur_pal = old_pal;
        }

////////////////////////////////////////////////////////////////////////////////////////////////////
// maps an ASCII char to a sprite FModule

        static byte[] _map_char;

        private static int Char2Frame(int c)
        {
                DBG.ASSERT(c < _map_char.length, "Unknown char");
                
                return _map_char[c] & 0xFF;
        }

////////////////////////////////////////////////////////////////////////////////////////////////////

        static int[] _off = new int[20];
        void DrawPage(Graphics g, String s, int x, int y, int anchor)
        {
                // Count lines...
                int lines = 0;
                int len = s.length();
                for (int i = 0; i < len; i++)
                        if (s.charAt(i) == '\n')
                                _off[lines++] = i;
                _off[lines++] = len;

                int th = _line_spacing + (_modules[1]&0xFF);

                     if ((anchor & Graphics.BOTTOM)  != 0)	y -= (th * (lines-1));
                else if ((anchor & Graphics.VCENTER) != 0)	y -= (th * (lines-1)) >> 1;

                // Draw each line...
                for (int j = 0; j < lines; j++)
                {
                        _index1 = (j > 0) ? _off[j-1]+1 : 0;
                        _index2 = _off[j];
                        DrawString(g, s, x, y + j * th, anchor);
                }

                // Disable substring...
                _index1 = -1;
                _index2 = -1;
        }


////////////////////////////////////////////////////////////////////////////////////////////////////
        
        
        static int GetGradientColor(int color1, int color2, int index, int max)
        {
                if (index < 0)     index = 0;
                if (index > max)   index = max;
                
                int r1 = (color1 >> 16) & 0xFF;
                int g1 = (color1 >> 8 ) & 0xFF;
                int b1 = (color1      ) & 0xFF;
                int r2 = (color2 >> 16) & 0xFF;
                int g2 = (color2 >> 8 ) & 0xFF;
                int b2 = (color2      ) & 0xFF;

                r1 = r1 + (r2 - r1) * index / max;
                b1 = b1 + (b2 - b1) * index / max;
                g1 = g1 + (g2 - g1) * index / max;

                return (0xFF<<24) + (r1<<16) + (g1<<8) + b1;
        }

////////////////////////////////////////////////////////////////////////////////////////////////////
        
        
        
        
        
        
        
        
        
        
        
        
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////         LZMA DECOMPRESSION        ///////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

        static short[] _lzmaInternalBuffer; //= new short[LZMAInternalData_MAX_SIZE];

        public static byte[] _inBuffer;
        public static byte[] _outBuffer; //= new byte[LZMAOutputData_MAX_SIZE];
        static int   _inBufferIndex;

        static long _lzmaCode;
        static long _lzmaRange;

////////////////////////////////////////////////////////////////////////////////////////////////////
        
        static long LZMA_RangeDecoderDecodeDirectBits(int numTotalBits) 
        {
                long result = 0;

                for (int i = numTotalBits; i > 0; i--) 
                {
                        _lzmaRange >>= 1;
                        result <<= 1;

                        if (_lzmaCode >= _lzmaRange) 
                        {
                            _lzmaCode -= _lzmaRange;
                            result |= 1;
                        }

                        if (_lzmaRange < kTopValue) 
                        {
                            _lzmaRange <<= 8;
                            _lzmaCode = (_lzmaCode << 8) |
                                        (_inBuffer[_inBufferIndex++] & 0xFF);
                        }
                }

                return result & (long) 0xFFFFFFFF;
        }

////////////////////////////////////////////////////////////////////////////////////////////////////
        
        static int LZMA_RangeDecoderBitDecode(int index) 
        {
                int prob = _lzmaInternalBuffer[index] & 0xFFFF;

                long bound = (_lzmaRange >> kNumBitModelTotalBits) * prob;
                int rez = 0;

                if (_lzmaCode < bound) 
                {
                        _lzmaRange = bound;
                        prob += (kBitModelTotal - prob) >> kNumMoveBits;
                }
                else
                {
                        _lzmaRange -= bound;
                        _lzmaCode -= bound;

                        prob -= prob >> kNumMoveBits;

                        rez = 1;
                }

                if (_lzmaRange < kTopValue) 
                {
                        _lzmaCode = (_lzmaCode << 8) | (_inBuffer[_inBufferIndex++] & 0xFF);
                        _lzmaRange <<= 8;
                }

                _lzmaInternalBuffer[index] = (short) prob;
                return rez;
        }

////////////////////////////////////////////////////////////////////////////////////////////////////
        
        static int LZMA_RangeDecoderBitTreeDecode(int index, int numLevels) 
        {
                int mi = 1;
                int i;

                for (i = numLevels; i > 0; i--) 
                {
                        mi = (mi + mi) + LZMA_RangeDecoderBitDecode(index + mi);
                }

                return mi - (1 << numLevels);
        }

////////////////////////////////////////////////////////////////////////////////////////////////////
        
        static int LZMA_RangeDecoderReverseBitTreeDecode(int index, int numLevels) 
        {
                int mi = 1;
                int i;
                int symbol = 0;

                for (i = 0; i < numLevels; i++) 
                {
                        int bit = LZMA_RangeDecoderBitDecode(index + mi);
                        mi = mi + mi + bit;
                        symbol |= (bit << i);
                }

                return symbol;
        }

////////////////////////////////////////////////////////////////////////////////////////////////////
        
        static int LZMA_LenDecode(int index, int posState) 
        {
                if (LZMA_RangeDecoderBitDecode(index + LenChoice) == 0) 
                {
                        return LZMA_RangeDecoderBitTreeDecode(index + LenLow + (posState << kLenNumLowBits), kLenNumLowBits);
                }

                if (LZMA_RangeDecoderBitDecode(index + LenChoice2) == 0) 
                {
                    return kLenNumLowSymbols + LZMA_RangeDecoderBitTreeDecode(index + LenMid + (posState << kLenNumMidBits), kLenNumMidBits);
                }

                return kLenNumLowSymbols + kLenNumMidSymbols + LZMA_RangeDecoderBitTreeDecode(index + LenHigh, kLenNumHighBits);
        }

////////////////////////////////////////////////////////////////////////////////////////////////////
// 0..4  - properties
// 5..8  - out size
// 9..12 - zero

        static byte[] LZMA_Decompress(byte[] inStream)
        {
                int outSize = 0;
                int i;
                int prop0;
                int lc, lp, pb;
                
                byte[] outStream = null;
                
                if(inStream == null) return null;

                _inBuffer = inStream;
                
                for (i = 0; i < 4; i++) 
                {
                        outSize += (int) (_inBuffer[i + INDEX_OUT_SIZE] & 0xFF) << (i * 8);
                }

                prop0 = _inBuffer[INDEX_PROPERTIES] & 0xFF;

                for (pb = 0; prop0 >= (9 * 5); pb++, prop0 -= (9 * 5));
                for (lp = 0; prop0 >= 9; lp++, prop0 -= 9);
                lc = prop0;

                if(_lzmaInternalBuffer == null)
                {
                        _lzmaInternalBuffer = new short[LZMAInternalData_MAX_SIZE];
                }
                if(outStream == null)
                {
                        outStream = new byte[outSize];
                }
                //outStream = _outBuffer;

                int numProbs = Literal + ((int) LZMA_LIT_SIZE << (lc + lp));

                int  state = 0;
                int  previousIsMatch = 0;
                byte previousByte    = 0;
                int  rep0 = 1, rep1 = 1, rep2 = 1, rep3 = 1;
                int  nowPos = 0;
                int  posStateMask   = (1 << pb) - 1;
                int  literalPosMask = (1 << lp) - 1;
                int  len = 0;

                //_lzmaInternalBuffer = new short[LZMAInternalData_MAX_SIZE];

                for (i = 0; i < numProbs; i++) 
                {
                        _lzmaInternalBuffer[i] = (short) (kBitModelTotal >> 1);
                }

                _inBufferIndex = LZMA_HEADER_SIZE;

                _lzmaCode = 0;
                _lzmaRange = 0x0FFFFFFFFL;

                for (i = 0; i < 5; i++) 
                {
                        _lzmaCode = (_lzmaCode << 8) | (_inBuffer[_inBufferIndex++] & 0xFF);
                }

                while (nowPos < outSize) 
                {
                        int posState = (int) (nowPos & posStateMask);

                        if (LZMA_RangeDecoderBitDecode(IsMatch + (state << kNumPosBitsMax) + posState) == 0) 
                        {
                                int index = Literal + (LZMA_LIT_SIZE * ((((nowPos) & literalPosMask) << lc) + ((previousByte & 0xFF) >> (8 - lc))));

                                if (state < 4) 
                                {
                                        state = 0;
                                } 
                                else if (state < 10) 
                                {
                                        state -= 3;
                                }
                                else
                                {
                                        state -= 6;
                                }

                                if (previousIsMatch != 0) 
                                {
                                        i = 1;
                                        previousIsMatch = outStream[nowPos - rep0] & 0xFF;

                                        do 
                                        {
                                                int bit;
                                                int matchBit = (previousIsMatch >> 7) & 1;
                                                previousIsMatch <<= 1;

                                                bit = LZMA_RangeDecoderBitDecode(index + ((1 + matchBit) << 8) + i);
                                                i = (i << 1) | bit;

                                                if (matchBit != bit) 
                                                {
                                                        while (i < 0x100) 
                                                        {
                                                                i = (i + i) | LZMA_RangeDecoderBitDecode(index + i);
                                                        }
                                                        break;
                                                }
                                        } while (i < 0x100);

                                        previousByte = (byte) i;

                                        previousIsMatch = 0;
                                } 
                                else 
                                {
                                        //previousByte = LzmaLiteralDecode(index);
                                        i = 1;

                                        do 
                                        {
                                                i = (i + i) | LZMA_RangeDecoderBitDecode(index + i);
                                        } while (i < 0x100);

                                        previousByte = (byte) i;
                                }

                                outStream[nowPos++] = previousByte;
                        } 
                        else 
                        {
                                previousIsMatch = 1;
                                if (LZMA_RangeDecoderBitDecode(IsRep + state) == 1) 
                                {
                                        if (LZMA_RangeDecoderBitDecode(IsRepG0 + state) == 0) 
                                        {
                                                if (LZMA_RangeDecoderBitDecode(IsRep0Long + (state << kNumPosBitsMax) + posState) == 0) 
                                                {
                                                        state = state < 7 ? 9 : 11;

                                                        previousByte = outStream[nowPos - rep0];

                                                        outStream[nowPos++] = previousByte;
                                                        continue;
                                                }
                                        }
                                        else
                                        {
                                                int distance;
                                                if (LZMA_RangeDecoderBitDecode(IsRepG1 + state) == 0) 
                                                {
                                                        distance = rep1;
                                                }
                                                else
                                                {
                                                        if (LZMA_RangeDecoderBitDecode(IsRepG2 + state) == 0)
                                                        {
                                                                distance = rep2;
                                                        }
                                                        else
                                                        {
                                                                distance = rep3;
                                                                rep3 = rep2;
                                                        }
                                                        rep2 = rep1;
                                                }
                                                rep1 = rep0;
                                                rep0 = distance;
                                        }
                                        len = LZMA_LenDecode(RepLenCoder, posState);
                                        state = state < 7 ? 8 : 11;
                                } 
                                else 
                                {
                                        int posSlot;
                                        rep3  = rep2;
                                        rep2  = rep1;
                                        rep1  = rep0;
                                        state = state < 7 ? 7 : 10;
                                        
                                        len     = LZMA_LenDecode(LenCoder, posState);
                                        posSlot = LZMA_RangeDecoderBitTreeDecode(PosSlot +
                                                ((len < kNumLenToPosStates ? len : kNumLenToPosStates - 1) << kNumPosSlotBits), kNumPosSlotBits);
                                        
                                        if (posSlot >= 4) 
                                        {
                                                int numDirectBits = ((posSlot >> 1) - 1);
                                                rep0 = ((2 | ((int) posSlot & 1)) << numDirectBits);
                                                if (posSlot < kEndPosModelIndex) 
                                                {
                                                        rep0 += LZMA_RangeDecoderReverseBitTreeDecode(SpecPos + rep0 - posSlot - 1, numDirectBits);
                                                }
                                                else 
                                                {
                                                        rep0 += LZMA_RangeDecoderDecodeDirectBits(numDirectBits - 4) << kNumAlignBits;
                                                        rep0 += LZMA_RangeDecoderReverseBitTreeDecode(Align, kNumAlignBits);
                                                }
                                        }
                                        else
                                        {
                                                rep0 = posSlot;
                                        }
                                        rep0++;
                                }
                                if (rep0 == 0)
                                {
                                        // it's for stream version
                                        len = -1;
                                        break;
                                }

                                len += 2;
                                do
                                {
                                        previousByte = outStream[nowPos - rep0];

                                        outStream[nowPos++] = previousByte;
                                        len--;
                                } while (len > 0 && nowPos < outSize);
                        }
                }
                //_lzmaInternalBuffer = null;
                //_inBuffer = null;
                //System.gc();

                return outStream;
        }

////////////////////////////////////////////////////////////////////////////////////////////////////

}; // class cSprite

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
