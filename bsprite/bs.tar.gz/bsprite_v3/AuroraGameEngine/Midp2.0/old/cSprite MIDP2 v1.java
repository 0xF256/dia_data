// cSprite.java - sprite implementation - MIDP 2.0 version
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Author(s):	Ionut Matasaru
//
//  History:	28.09.2003, created
//				03.10.2003, I16, I127
//				12.11.2003, I2, I4, I256
//				24.11.2003, Draw String System
//				22.12.2003, MIDP 2.0 version
//				23.04.2004, I256 bug fixed (&0xFF)
//				12.05.2004, modular version, 8888 pixel format
//				15.06.2004, improved (flip X, flip Y, flip XY)
//			    24.06.2004, 4 bits extension for FModules -> module index => 4+8=12 bits => max. 4096 modules
//                          4 bits extension for AFrames  -> frame index  => 4+8=12 bits => max. 4096 frames
//				06.07.2004, Nokia API version
//				23.08.2004, BSprite v3
//				10.09.2004, HyperFrames/HyperFModules, module mappings
//
//	Desc:		* use ".bsprite" files (BSPRITE_v003, exported by AuroraGT v0.3.1 - SpriteEditor v0.4.2 or later)
//				* BSprite flags: BS_DEFAULT_MIDP2
//				* pixel formats supported:
//					8888	- A8 R8 G8 B8
//					4444	- A4 R4 G4 B4
//				* data formats supported:
//					I2		- 8 pixels/byte encoding (max 2 colors)
//					I4		- 4 pixels/byte encoding (max 4 colors)
//					I16		- 2 pixels/byte encoding (max 16 colors)
//					I127RLE	- RLE compression (max 127 colors)
//					I256	- 1 pixel/byte encoding (max 256 colors)
//
////////////////////////////////////////////////////////////////////////////////////////////////////

import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.Sprite; // just for transformations
//import com.nokia.mid.ui.*;

////////////////////////////////////////////////////////////////////////////////////////////////////

final class cSprite
{
	static int temp[] = new int[3*1024]; // temp memory

	//////////////////////////////////////////////////

	final static int MAX_SPRITE_PALETTES = 16;
	final static int MAX_SPRITE_MAPPINGS = 16;

	final static short BSPRITE_v003	= (short)0x03DF; // supported version

	//////////////////////////////////////////////////
	// BSprite flags

	final static int BS_MODULES			= (1 << 0);
	final static int BS_MODULES_XY		= (1 << 1);
//	final static int BS_MMAPPINGS		= (1 << 2);
	final static int BS_FRAMES			= (1 << 8);
//	final static int BS_FMAPPINGS		= (1 << 9);
	final static int BS_FM_OFF_SHORT	= (1 << 10);	// fm offsets as shorts
	final static int BS_ANIMS			= (1 << 16);
//	final static int BS_AMAPPINGS		= (1 << 17);
	final static int BS_AF_OFF_SHORT	= (1 << 18);	// af offsets as shorts
	final static int BS_MODULE_IMAGES	= (1 << 24);
	final static int BS_PNG_CRC			= (1 << 25);

	final static int BS_DEFAULT_DOJA	= (BS_MODULES | BS_FRAMES | BS_ANIMS);
	final static int BS_DEFAULT_MIDP2	= (BS_MODULES | BS_FRAMES | BS_ANIMS | BS_MODULE_IMAGES);
	final static int BS_DEFAULT_NOKIA	= BS_DEFAULT_MIDP2;
	final static int BS_DEFAULT_MIDP1	= (BS_MODULES | BS_MODULES_XY | BS_FRAMES | BS_ANIMS);
	final static int BS_DEFAULT_MIDP1b	= (BS_MODULES | BS_FRAMES | BS_ANIMS | BS_MODULE_IMAGES | BS_PNG_CRC);

	//////////////////////////////////////////////////

	final static short PIXEL_FORMAT_8888		= (short)0x8888;
	final static short PIXEL_FORMAT_4444		= (short)0x4444;

	//////////////////////////////////////////////////

	final static short ENCODE_FORMAT_I2			= 0x0200;
	final static short ENCODE_FORMAT_I4			= 0x0400;
//	final static short ENCODE_FORMAT_I8			= 0x0800;
	final static short ENCODE_FORMAT_I16		= 0x1600;
//	final static short ENCODE_FORMAT_I32		= 0x3200;
//	final static short ENCODE_FORMAT_I64		= 0x6400;
//	final static short ENCODE_FORMAT_I128		= 0x2801;
	final static short ENCODE_FORMAT_I256		= 0x5602;
//	final static short ENCODE_FORMAT_I127_		= 0x2701;
	final static short ENCODE_FORMAT_I127RLE	= 0x27F1;
//	final static short ENCODE_FORMAT_I256RLE	= 0x56F2;

	//////////////////////////////////////////////////
	// Frames/Anims flags...

	final static byte FLAG_FLIP_X	= 0x01;
	final static byte FLAG_FLIP_Y	= 0x02;

	final static byte FLAG_ROT_0	= 0x00;
	final static byte FLAG_ROT_90	= 0x04;
	final static byte FLAG_ROT_180	= 0x08;
	final static byte FLAG_ROT_270	= 0x0C;

	final static byte FLAG_USER0	= 0x10; // user flag 0
	final static byte FLAG_USER1	= 0x20; // user flag 1

	final static byte FLAG_HYPER_FM	= 0x10; // Hyper FModule, used by FModules

	final static int FLAG_INDEX_EX_MASK = 0xC0; // 11000000, bits 6, 7
	final static int INDEX_MASK			= 0x03FF; // max 1024 values
	final static int INDEX_EX_MASK		= 0x0300;
	final static int INDEX_EX_SHIFT 	= 2;

	// Index extension...
	final static boolean USE_INDEX_EX_FMODULES = true; // true|false -> max. 1024|256 modules refs. from a FModule
	final static boolean USE_INDEX_EX_AFRAMES  = true; // true|false -> max. 1024|256 frames refs. from an Anim

	//////////////////////////////////////////////////
	// flags passed as params...

	final static byte FLAG_OFFSET_FM = 0x10;
	final static byte FLAG_OFFSET_AF = 0x20;

	//////////////////////////////////////////////////

	// Modules...
	byte[]		_modules;			// 2 bytes for each Module
//	byte[]		_modules_x;				// 0 : x [BS_MODULES_XY]
//	byte[]		_modules_y;				// 1 : y [BS_MODULES_XY]
//	byte[]		_modules_w;				// 0/2 : width
//	byte[]		_modules_h;				// 1/3 : height

	// Frames...
//	short[]		_frames;
	byte[]		_frames_nfm;		// number of FModules (max 256 FModules/Frame)
//	short[]		_frames_nfm;		// number of FModules (max 32768 FModules/Frame)
	short[]		_frames_fm_start;	// index of first FModule
	byte[]		_frames_rc;			// frame bound rect (x y width height)
	// FModules...
	byte[]		_fmodules;			// 4 bytes for each FModule
//	byte[]		_fmodules_module;		// 0 : module index
//	byte[]		_fmodules_ox;			// 1 : ox
//	byte[]		_fmodules_oy;			// 2 : oy
//	byte[]		_fmodules_flags;		// 3 : flags

	// Anims...
//	short[]		_anims;
	byte[]		_anims_naf;			// number of AFrames (max 256 AFrames/Anim)
//	short[]		_anims_naf;			// number of AFrames (max 32768 AFrames/Anim)
	short[]		_anims_af_start;	// index of first AFrame
	// AFrames...
	byte[]		_aframes;			// 5 bytes for each AFrame
//	byte[]		_aframes_frame;			// 0 : frame index
//	byte[]		_aframes_time;			// 1 : time
//	byte[]		_aframes_ox;			// 2 : ox
//	byte[]		_aframes_oy;			// 3 : oy
//	byte[]		_aframes_flags;			// 4 : flags

	// Module mappings...
	int[][]		_map; 				// all mappings
//	int			_mappings;			// number of mapings
	private int	_cur_map;			// current mapping

	// Palettes...
//	short 		_pixel_format;		// always converted to 8888
	int[][]		_pal; 				// all palettes
	int			_palettes;			// number of palettes
	private int	_cur_pal;			// current palette
	boolean		_alpha;				// has transparency ?
//	int			_flags;				// transparency, etc.

	// Graphics data (for each module)...
	short 		_data_format;
	byte[][]	_modules_data;		// image data (encoded)
//	int[][]		_modules_data2;		// cashe image data (decoded)
	Image[][]	_modules_image;		// cache image for each module / with each palette
//	Image[]		_modules_image_fx;	// cache image for each module (flipped horiz.)
//	Image[]		_modules_image_fy;	// cache image for each module (flipped vert.)

////////////////////////////////////////////////////////////////////////////////////////////////////

	cSprite()
	{
	//	_map = null;
	//	_mappings = 0;
	//	_cur_map = -1;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void Load(byte[] file, int offset)
	{
try
{
		if (DEF.bDbgS) System.out.println("Sprite.Load("+file.length+" bytes, "+offset+")...");

		System.gc();

		short bs_version = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
		if (DEF.bDbgS) System.out.println("bs_version = 0x" + Integer.toHexString(bs_version));
		if (DEF.bErr && (bs_version != BSPRITE_v003))
			System.out.println("ERROR: Invalid BSprite version !");

		int bs_flags =  ((file[offset++]&0xFF)    ) +
						((file[offset++]&0xFF)<< 8) +
						((file[offset++]&0xFF)<<16) +
						((file[offset++]&0xFF)<<24);
		if (DEF.bDbgS) System.out.println("bs_flags = 0x" + Integer.toHexString(bs_flags));
		if (DEF.bErr && (bs_flags != BS_DEFAULT_MIDP2))
			System.out.println("ERROR: Invalid BSprite flags !");

		//////////////////////////////

		// Modules...
		short nModules = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
		if (DEF.bDbgS) System.out.println("nModules = " + nModules);
		if (nModules > 0)
		{
		/*	if ((bs_flags & BS_MODULES_XY) != 0)
			{
				_modules_x  = new byte[nModules];
				_modules_y  = new byte[nModules];
				_modules_w  = new byte[nModules];
				_modules_h  = new byte[nModules];
				for (int i = 0; i < nModules; i++)
				{
					_modules_x[i] = file[offset++];
					_modules_y[i] = file[offset++];
					_modules_w[i] = file[offset++];
					_modules_h[i] = file[offset++];
				}
			}
			else
		*/	{
				_modules = new byte[nModules<<1]; // only w and h
				System.arraycopy(file, offset, _modules, 0, _modules.length);
				offset += _modules.length;
			}
		}

		//////////////////////////////

		// FModules...
		short nFModules = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
		if (DEF.bDbgS) System.out.println("nFModules = " + nFModules);
		if (nFModules > 0)
		{
			_fmodules = new byte[nFModules<<2];
			System.arraycopy(file, offset, _fmodules, 0, _fmodules.length);
			offset += _fmodules.length;
		}

		// Frames...
		short nFrames = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
		if (DEF.bDbgS) System.out.println("nFrames = " + nFrames);
		if (nFrames > 0)
		{
		//	_frames          = new short[nFrames<<1];
			_frames_nfm      = new  byte[nFrames];
		//	_frames_nfm      = new short[nFrames];
			_frames_fm_start = new short[nFrames];
			for (int i = 0; i < nFrames; i++)
			{
			//	_frames[i<<1]     = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
			//	_frames[(i<<1)+1] = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
				_frames_nfm[i]      = file[offset++]; offset++;
			//	_frames_nfm[i]      = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
				_frames_fm_start[i] = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
			}

			// Bound rect for each frame...
			int nFrames4 = nFrames<<2;
			_frames_rc = new byte[nFrames4];
			for (int i = 0; i < nFrames4; i++)
				_frames_rc[i] = file[offset++];
		//	_frames_x = new byte[nFrames];
		//	_frames_y = new byte[nFrames];
		//	_frames_w = new byte[nFrames];
		//	_frames_h = new byte[nFrames];
		//	for (int i = 0; i < nFrames; i++)
		//	{
		//		_frames_x[i] = file[offset++];
		//		_frames_y[i] = file[offset++];
		//		_frames_w[i] = file[offset++];
		//		_frames_h[i] = file[offset++];
		//	}
		}

		//////////////////////////////

		// AFrames...
		short nAFrames = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
		if (DEF.bDbgS) System.out.println("nAFrames = " + nAFrames);
		if (nAFrames > 0)
		{
			_aframes = new byte[nAFrames*5];
			System.arraycopy(file, offset, _aframes, 0, _aframes.length);
			offset += _aframes.length;
		}

		// Anims...
		short nAnims = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
		if (DEF.bDbgS) System.out.println("nAnims = " + nAnims);
		if (nAnims > 0)
		{
		//	_anims          = new short[nAnims<<1];
			_anims_naf      = new  byte[nAnims];
		//	_anims_naf      = new short[nAnims];
			_anims_af_start = new short[nAnims];
			for (int i = 0; i < nAnims; i++)
			{
			//	_anims[i<<1]       = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
			//	_anims[(i<<1)+1]   = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
				_anims_naf[i]      = file[offset++]; offset++;
			//	_anims_naf[i]      = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
				_anims_af_start[i] = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
			}
		}

		//////////////////////////////

		if (nModules <= 0)
		{
			if (DEF.bErr) System.out.println("WARNING: sprite with num modules = "+nModules);
			System.gc();
			return;
		}

		//////////////////////////////

		// Pixel format (must be one of SPRITE_FORMAT_8888, _4444)...
		short _pixel_format = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
		if (DEF.bDbgS) System.out.println("_pixel_format = 0x" + Integer.toHexString(_pixel_format));

		// Number of palettes...
		_palettes = file[offset++]&0xFF;
		if (DEF.bDbgS) System.out.println("_palettes = " + _palettes);

		// Number of colors...
		int colors = file[offset++]&0xFF;
		if (DEF.bDbgS) System.out.println("colors = " + colors);

		// Palettes...
		_pal = new int[MAX_SPRITE_PALETTES][];
		for (int p = 0; p < _palettes; p++)
		{
		  	_pal[p] = new int[colors];
		  	switch (_pixel_format)
		  	{
		  		case PIXEL_FORMAT_8888:
		  			for (int c = 0; c < colors; c++)
		  			{
			  			int _8888  = ((file[offset++]&0xFF)    );
			  			 	_8888 += ((file[offset++]&0xFF)<< 8);
			  			 	_8888 += ((file[offset++]&0xFF)<<16);
			  			 	_8888 += ((file[offset++]&0xFF)<<24);
						if ((_8888 & 0xFF000000) != 0xFF000000)
							_alpha = true;
						_pal[p][c] = _8888;
		  			}
		  			break;

		  		case PIXEL_FORMAT_4444:
		  			for (int c = 0; c < colors; c++)
					{
						// 4444 -> 8888
						int _4444 = (file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8);
						if ((_4444 & 0xF000) != 0xF000)
							_alpha = true;
						_pal[p][c] = ((_4444 & 0xF000) << 16) | ((_4444 & 0xF000) << 12) |
									 ((_4444 & 0x0F00) << 12) | ((_4444 & 0x0F00) <<  8) |
									 ((_4444 & 0x00F0) <<  8) | ((_4444 & 0x00F0) <<  4) |
									 ((_4444 & 0x000F) <<  4) | ((_4444 & 0x000F)      );
					}
					break;
		  	}
		}

		//////////////////////////////

		// Data format (must be one of ENCODE_FORMAT_I2, _I4, _I16, _I256, _I127RLE)...
		_data_format = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
		if (DEF.bDbgS) System.out.println("_data_format = 0x" + Integer.toHexString(_data_format));

		// Graphics data...
		if (nModules > 0)
		{
			_modules_data = new byte[nModules][];
			for (int m = 0; m < nModules; m++)
			{
				// Image data for the module...
				short size = (short)((file[offset++]&0xFF) + ((file[offset++]&0xFF)<<8));
				if (DEF.bDbgS) System.out.println("frame["+m+"] size = " + size);
				_modules_data[m] = new byte[size];
				System.arraycopy(file, offset, _modules_data[m], 0, size);
				offset += size;
			}
		}

		//////////////////////////////
		// module mappings

	//	_mappings = 0;
		_map = new int[MAX_SPRITE_MAPPINGS][];
		_cur_map = -1;

		//////////////////////////////

		if (DEF.bDbgS) System.out.println("--- ok");
		System.gc();

	/*	// Used to adjust the size of temp[]...
		int max = 0, max_w = 0, max_h = 0, max_m = 0;
		for (int m = 0; m < nModules; m++)
		{
			int w = (_modules[(m<<1)  ] & 0xFF);
			int h = (_modules[(m<<1)+1] & 0xFF);
			if (w <= 0 || h <= 0) continue;
			if (w * h > max)
			{
				max_w = w;
				max_h = h;
				max_m = m;
				max = w * h;
			}
		}
		if (max > temp_max_size)
		{
			temp_max_size = max;
			System.out.println("temp_max_size = " + temp_max_size + " (" + max_w + "x" + max_h + ")" +  " module = " + (max_m+1) + "/" + nModules);
		}
	*/
}
catch (Exception e)
{
	if (DEF.bErr) DBG.CatchException(e, "cSprite.Load()");
}
	}

//	static int temp_max_size = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////
// pal = palette to be initailized
// m1 = first module
// m2 = last module (-1 -> to end)
// pal_copy = mapping to another palette (-1 -> build)

	void BuildCacheImages(int pal, int m1, int m2, int pal_copy)
	{
		if (_modules == null) return;

		if (m2 == -1)
			m2 = (_modules.length>>1) - 1;

		if (_modules_image == null)
			_modules_image = new Image[_palettes][];

		if (_modules_image[pal] == null)
			_modules_image[pal] = new Image[_modules.length>>1];

		if (pal_copy >= 0)
		{
			for (int i = m1; i <= m2; i++)
				_modules_image[pal][i] = _modules_image[pal_copy][i];
		}
		else
		{
			int old_pal = _cur_pal;
			_cur_pal = pal;
			int total_area, total_size;
			long mem;
			if (DEF.bDbgO) total_area = 0;
			if (DEF.bDbgO) total_size = 0;
			System.gc();
			if (DEF.bDbgO) mem = Runtime.getRuntime().freeMemory();
			for (int i = m1; i <= m2; i++)
			{
				int m = i << 1;
				int sizeX = _modules[m  ]&0xFF;
				int sizeY = _modules[m+1]&0xFF;
				if (sizeX <= 0 || sizeY <= 0) continue;

				int[] image_data = DecodeImage(i, 0);
				if (image_data == null) continue;

				boolean bAlpha = false;
				int size = sizeX * sizeY;
				if (DEF.bDbgO) total_area += size;
				for (int ii = 0; ii < size; ii++)
				{
					if ((image_data[ii] & 0xFF000000) != 0xFF000000)
					{
						bAlpha = true;
						break;
					}
				}
				if (DEF.bDbgO) total_size += ((bAlpha & DEF.bEmu) ? (size*3) : (size*2));
				_modules_image[pal][i] = Image.createRGBImage(image_data, sizeX, sizeY, bAlpha);
				image_data = null;

			//	_modules_image[pal][i] = DirectUtils.createImage(sizeX, sizeY, 0x00FF00FF);
			//	if (_modules_image[pal][i] != null)
			//		PaintModule(_modules_image[pal][i].getGraphics(), i, 0, 0, 0);
			}
			System.gc();
			if (DEF.bDbgI) mem -= Runtime.getRuntime().freeMemory();
			if (DEF.bDbgI) System.out.println(" area = " + total_area + " pixels");
			if (DEF.bDbgI) System.out.println(" size = " + total_size + " bytes");
			if (DEF.bDbgI) System.out.println(" mem used = " + mem + " bytes");
			if (DEF.bDbgI) System.out.println(" images = " + (m2 - m1 + 1));
			if (DEF.bDbgI) System.out.println(" total overhead = " + (mem - total_size) + " bytes");
			if (DEF.bDbgI) System.out.println(" image overhead = " + ((mem - total_size) / (m2 - m1 + 1)) + " bytes");
			_cur_pal = old_pal;
		}
		System.gc();
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void SetModuleMapping(int map, byte[] mmp)
	{
	//	ASSERT(map >= 0 && map < _mappings);
		if (_map[map] == null)
		{
			int modules = _modules.length>>1;
			_map[map] = new int[modules];
			for (int i = 0; i < modules; i++)
				_map[map][i] = i;
		}
		if (mmp == null) return;
		int off = 0;
		while (off < mmp.length)
		{
			int i1 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
			int i2 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
			_map[map][i1] = i2;
		}
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void ApplyModuleMapping(int dst_pal, int src_pal, byte[] mmp)
	{
		int off = 0;
		while (off < mmp.length)
		{
			int i1 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
			int i2 = ((mmp[off++] & 0xFF) + ((mmp[off++] & 0xFF) << 8));
			_modules_image[dst_pal][i1] = _modules_image[src_pal][i2];
		}
		System.gc();
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	int GetAFrameTime(int anim, int aframe)
	{
	//	int af = (_anims_af_start[anim] + aframe);
	//	return _aframes[((af<<2) + af + 1)] & 0xFF;
		return _aframes[(_anims_af_start[anim] + aframe) * 5 + 1] & 0xFF;
	//	return _aframes[(_anims[(anim<<1)+1] + aframe) * 5 + 1] & 0xFF;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	int GetAFrames(int anim)
	{
		return _anims_naf[anim]&0xFF;
	//	return _anims_naf[anim];
	//	return _anims[anim<<1];
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	int GetFModules(int frame)
	{
		return _frames_nfm[frame]&0xFF;
	//	return _frames_nfm[frame];
	//	return _frames[frame<<1];
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void GetAFrameRect(int[] rc, int anim, int aframe, int posX, int posY, int flags, int hx, int hy)
	{
	//	System.out.println("GetAFrameRect(rc, "+anim+", "+aframe+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
		int off = (_anims_af_start[anim] + aframe) * 5;
	//	int off = (_anims[(anim<<1)+1] + aframe) * 5;
		int frame = _aframes[off]&0xFF;
		if (USE_INDEX_EX_AFRAMES)
			frame |= ((_aframes[off+4]&FLAG_INDEX_EX_MASK)<<INDEX_EX_SHIFT);
		if ((flags & FLAG_OFFSET_AF) != 0)
		{
			if ((flags & FLAG_FLIP_X) != 0)	hx += _aframes[off+2];
			else							hx -= _aframes[off+2];
			if ((flags & FLAG_FLIP_Y) != 0)	hy += _aframes[off+3];
			else							hy -= _aframes[off+3];
		}
	//	if ((flags & FLAG_FLIP_X) != 0)	hx += _frames_w[frame]&0xFF;
	//	if ((flags & FLAG_FLIP_Y) != 0)	hy += _frames_h[frame]&0xFF;
		GetFrameRect(rc, frame, posX, posY, flags ^ (_aframes[off+4]&0x0F), hx, hy);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void GetFrameRect(int[] rc, int frame, int posX, int posY, int flags, int hx, int hy)
	{
	//	System.out.println("GetFrameRect(rc, "+frame+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
	//	int fx = _frames_x[frame];
	//	int fy = _frames_y[frame];
	//	int fw = _frames_w[frame]&0xFF;
	//	int fh = _frames_h[frame]&0xFF;
		int frame4 = frame<<2;
		int fx = _frames_rc[frame4++];
		int fy = _frames_rc[frame4++];
		int fw = _frames_rc[frame4++]&0xFF;
		int fh = _frames_rc[frame4++]&0xFF;
		if ((flags & FLAG_FLIP_X) != 0)	hx += fx + fw;
		else							hx -= fx;
		if ((flags & FLAG_FLIP_Y) != 0)	hy += fy + fh;
		else							hy -= fy;
		rc[0] = posX - (hx<<8);
		rc[1] = posY - (hy<<8);
		rc[2] = rc[0] + (fw<<8);
		rc[3] = rc[1] + (fh<<8);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void GetModuleRect(int[] rc, int module, int posX, int posY, int flags)
	{
	//	System.out.println("GetModuleRect(rc, "+module+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+")");
		int m = (module<<1);
		rc[0] = posX;
		rc[1] = posY;
		rc[2] = posX + ((_modules[m  ]&0xFF)<<8);
		rc[3] = posY + ((_modules[m+1]&0xFF)<<8);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void PaintAFrame(Graphics g, int anim, int aframe, int posX, int posY, int flags, int hx, int hy)
	{
	//	System.out.println("PaintAFrame(g, "+anim+", "+aframe+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
		int off = (_anims_af_start[anim] + aframe) * 5;
	//	int off = (_anims[(anim<<1)+1] + aframe) * 5;
		int frame = _aframes[off]&0xFF;
		if (USE_INDEX_EX_AFRAMES)
			frame |= ((_aframes[off+4]&FLAG_INDEX_EX_MASK)<<INDEX_EX_SHIFT);
		if ((flags & FLAG_OFFSET_AF) != 0)
		{
			if ((flags & FLAG_FLIP_X) != 0)	hx += _aframes[off+2];
			else							hx -= _aframes[off+2];
			if ((flags & FLAG_FLIP_Y) != 0)	hy += _aframes[off+3];
			else							hy -= _aframes[off+3];
		}
	//	if ((flags & FLAG_FLIP_X) != 0)	hx += _frames_w[frame]&0xFF;
	//	if ((flags & FLAG_FLIP_Y) != 0)	hy += _frames_h[frame]&0xFF;
		PaintFrame(g, frame, posX-hx, posY-hy, flags ^ (_aframes[off+4]&0x0F), hx, hy);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void PaintFrame(Graphics g, int frame, int posX, int posY, int flags, int hx, int hy)
	{
	//	System.out.println("PaintFrame(g, "+frame+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
		int nFModules = _frames_nfm[frame]&0xFF;
	//	int nFModules = _frames_nfm[frame];
	//	int nFModules = _frames[frame<<1];
		for (int fmodule = 0; fmodule < nFModules; fmodule++)
			PaintFModule(g, frame, fmodule, posX, posY, flags, hx, hy);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void PaintFModule(Graphics g, int frame, int fmodule, int posX, int posY, int flags, int hx, int hy)
	{
	//	System.out.println("PaintFModule(g, "+frame+", "+fmodule+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+", "+hx+", "+hy+")");
		int off = (_frames_fm_start[frame] + fmodule) << 2;
	//	int off = (_frames[(frame<<1)+1] + fmodule) << 2;

		int fm_flags = _fmodules[off+3]&0xFF;
		int index = _fmodules[off]&0xFF;
		if (USE_INDEX_EX_FMODULES)
			index |= ((fm_flags&FLAG_INDEX_EX_MASK)<<INDEX_EX_SHIFT);

	//	if ((flags & FLAG_OFFSET_FM) != 0)
		{
			if ((flags & FLAG_FLIP_X) != 0)	posX -= _fmodules[off+1];
			else							posX += _fmodules[off+1];
			if ((flags & FLAG_FLIP_Y) != 0)	posY -= _fmodules[off+2];
			else							posY += _fmodules[off+2];
		}

		if ((fm_flags & FLAG_HYPER_FM) != 0)
		{
		//	if ((flags & FLAG_FLIP_X) != 0)	posX -= _frames[(index<<?)  ]&0xFF; // pF->w
		//	if ((flags & FLAG_FLIP_Y) != 0)	posY -= _frames[(index<<?)+1]&0xFF; // pF->h

			PaintFrame(g, index, posX, posY, flags ^ (fm_flags&0x0F), hx, hy);
		}
		else
		{
			if ((flags & FLAG_FLIP_X) != 0)	posX -= _modules[(index<<1)  ]&0xFF;
			if ((flags & FLAG_FLIP_Y) != 0)	posY -= _modules[(index<<1)+1]&0xFF;

			PaintModule(g, index, posX, posY, flags ^ (fm_flags&0x0F));
		}
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void PaintModule(Graphics g, int module, int posX, int posY, int flags)
	{
	//	System.out.println("PaintModule(g, "+module+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+")");
	//	System.out.println("PaintModule(module = "+module+", _cur_pal = "+_cur_pal+")...");

		// Apply current module mapping...
		if (_cur_map >= 0)
		{
		//	if (DEF.bASSERT) DBG.ASSERT(_cur_map < _mappings);
		//	if (DEF.bASSERT) DBG.ASSERT(_map[_cur_map] != null);
			module = _map[_cur_map][module];
		//	System.out.println("module -> "+module);
		}

	//	if (DEF.bASSERT) DBG.ASSERT(module >= 0);
		int m = (module<<1);
		int sizeX = _modules[m  ]&0xFF;
		int sizeY = _modules[m+1]&0xFF;
		if (sizeX <= 0 || sizeY <= 0) return;
/*
		int cx = g.getClipX();
		int cy = g.getClipY();
		int cw = g.getClipWidth();
		int ch = g.getClipHeight();

		// Fast visibility test...
		if (posX + sizeX < cx ||
			posY + sizeY < cy ||
			posX >= cx + cw ||
			posY >= cy + ch)
		{
		//	System.out.println("outside clip rect");
			return;
		}
*/
		Image img = null;

		// Try to use cached images...
		if ((_modules_image != null) &&
			(_cur_pal < _modules_image.length) &&
			(_modules_image[_cur_pal] != null))
			img = _modules_image[_cur_pal][module];

	//	DirectGraphics dg = DirectUtils.getDirectGraphics(g);

	//	int manipulation = (((flags & FLAG_FLIP_X) != 0) ? DirectGraphics.FLIP_HORIZONTAL : 0) +
	//					   (((flags & FLAG_FLIP_Y) != 0) ? DirectGraphics.FLIP_VERTICAL   : 0);

		// Build RGB image...
		if (img == null)
		{
			int[] image_data = DecodeImage(module, flags);
			if (image_data == null)
			{
				if (DEF.bErr) System.out.println("DecodeImage() FAILED !");
				return;
			}
		//	g.drawRGB(image_data, 0, sizeX, posX, posY, sizeX, sizeY, _alpha);
			img = Image.createRGBImage(image_data, sizeX, sizeY, _alpha);
		//	dg.drawPixels(image_data, _alpha, 0, sizeX, posX, posY, sizeX, sizeY, manipulation, DirectGraphics.TYPE_USHORT_4444_ARGB);
		}
	//	else
	//		dg.drawImage(img, posX, posY, 0, manipulation);

		sizeX = img.getWidth();
		sizeY = img.getHeight();

		int x = 0;
		int y = 0;
		if (posY < cy)			{ y = cy - posY; sizeY -= y; posY = cy; }
		if (posY+sizeY > cy+ch)	{ sizeY = cy+ch - posY; }

		// Draw...
		if ((flags & FLAG_FLIP_X) != 0)
		{
			if ((flags & FLAG_FLIP_Y) != 0)
			{
				// TODO: clip...
				g.drawRegion(img, x, y, sizeX, sizeY, Sprite.TRANS_ROT180, posX, posY, 0);
			}
			else
			{
			//	if (posX < cx)			{ sizeX -= cx - posX; posX = cx; }
			//	if (posX+sizeX > cx+cw)	{ x = cx+cw - posX; sizeX -= x; }
				g.drawRegion(img, x, y, sizeX, sizeY, Sprite.TRANS_MIRROR, posX, posY, 0);
			}
		}
		else if ((flags & FLAG_FLIP_Y) != 0)
		{
			// TODO: clip...
			g.drawRegion(img, x, y, sizeX, sizeY, Sprite.TRANS_MIRROR_ROT180, posX, posY, 0);
		}
		else
		{
		//	if (posX < cx)			{ x = cx - posX; sizeX -= x; posX = cx; }
		//	if (posX+sizeX > cx+cw)	{ sizeX = cx+cw - posX; }
			g.drawRegion(img, x, y, sizeX, sizeY, Sprite.TRANS_NONE, posX, posY, 0);

		//	g.drawRegion(img, 0, 0, sizeX, sizeY, Sprite.TRANS_NONE, posX, posY, 0);
		//	g.drawImage(img, posX, posY, 0);
		}

	//	System.out.println("...PaintModule(_cur_pal = "+_cur_pal+")");
	//	System.out.println("...PaintModule(g, "+module+", "+posX+", "+posY+", 0x"+Integer.toHexString(flags)+")");
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	private int[] DecodeImage(int module, int flags)
	{
	//	System.out.println("DecodeImage("+module+", 0x"+Integer.toHexString(flags)+")...");

		if (_modules_data == null ||
			_modules_data[module] == null) return null;

		int m = (module<<1);
		int sizeX = _modules[m  ]& 0xFF;
		int sizeY = _modules[m+1]& 0xFF;
	//	if (sizeX <= 0 || sizeY <= 0) return null;

		int[] img_data = temp;
	//	if (flags == 1)
	//		img_data = new short[sizeX * sizeY + 7];

		// Choose palette...
		int[] pal = _pal[_cur_pal];
		if (pal == null) return null;

		// Build displayable...
		if (_data_format == ENCODE_FORMAT_I2)
		{
			// 8 pixels/byte, max 2 colors...
			byte[] image = _modules_data[module];
			int si = 0;
			int di = 0;
			int ds = sizeX * sizeY;
			while (di < ds)
			{
				img_data[di++] = pal[(image[si] >> 7) & 0x01];
				img_data[di++] = pal[(image[si] >> 6) & 0x01];
				img_data[di++] = pal[(image[si] >> 5) & 0x01];
				img_data[di++] = pal[(image[si] >> 4) & 0x01];
				img_data[di++] = pal[(image[si] >> 3) & 0x01];
				img_data[di++] = pal[(image[si] >> 2) & 0x01];
				img_data[di++] = pal[(image[si] >> 1) & 0x01];
				img_data[di++] = pal[(image[si]     ) & 0x01];
				si++;
			}
		}
		else if (_data_format == ENCODE_FORMAT_I4)
		{
			// 4 pixels/byte, max 4 colors...
			byte[] image = _modules_data[module];
			int si = 0;
			int di = 0;
			int ds = sizeX * sizeY;
			while (di < ds)
			{
				img_data[di++] = pal[(image[si] >> 6) & 0x03];
				img_data[di++] = pal[(image[si] >> 4) & 0x03];
				img_data[di++] = pal[(image[si] >> 2) & 0x03];
				img_data[di++] = pal[(image[si]     ) & 0x03];
				si++;
			}
		}
		else if (_data_format == ENCODE_FORMAT_I16)
		{
			// 2 pixels/byte, max 16 colors...
			byte[] image = _modules_data[module];
			int si = 0;
			int di = 0;
			int ds = sizeX * sizeY;
			while (di < ds)
			{
				img_data[di++] = pal[(image[si] >> 4) & 0x0F];
				img_data[di++] = pal[(image[si]     ) & 0x0F];
				si++;
			}
		}
		else if (_data_format == ENCODE_FORMAT_I256)
		{
			// 1 pixel/byte, max 256 colors...
			byte[] image = _modules_data[module];
		//	int si = 0;
		//	int di = 0;
		//	int ds = sizeX * sizeY;
		//	while (di < ds)
		//		img_data[di++] = pal[image[si++]&0xFF];
			for (int ii = sizeX * sizeY - 1; ii >= 0; ii--)
				img_data[ii] = pal[image[ii]&0xFF];
		}
		else if (_data_format == ENCODE_FORMAT_I127RLE)
		{
			// RLE compression, max 127 colors...
			byte[] image = _modules_data[module];
			int si = 0;
			int di = 0;
			int ds = sizeX * sizeY;
			while (di < ds)
			{
				int c = image[si++]&0xFF;
			//	System.out.println("--- c = " + c);
				if (c > 127)
				{
					int c2 = image[si++]&0xFF;
				//	System.out.println("--- c2 = " + c2);
					int clr = pal[c2];
					c -= 128;
					while (c-- > 0)
						img_data[di++] = clr;
				}
				else
					img_data[di++] = pal[c];
			}
		}

	//	System.out.println("...DecodeImage("+module+", 0x"+Integer.toHexString(flags)+")");
		return img_data;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void SetCurrentMMapping(int map)	{ _cur_map = map; }
	int GetCurrentMMapping()			{ return _cur_map; }

////////////////////////////////////////////////////////////////////////////////////////////////////

	void SetCurrentPalette(int pal)		{ _cur_pal = pal; }
	int GetCurrentPalette()				{ return _cur_pal; }

////////////////////////////////////////////////////////////////////////////////////////////////////
// Draw String System...
////////////////////////////////////////////////////////////////////////////////////////////////////

	//	_modules[0] -> w  -> width of the space character (' ')
	//	_modules[1] -> h  -> height of a text line
	//	_fmodules[0*4+1] -> ox -> space between two adiacent chars
	//	_fmodules[0*4+2] -> oy -> base line offset

	// Used to gather dimensions of a string...
	// (call UpdateStringSize() to update these values)
	static int _text_w;
	static int _text_h;

////////////////////////////////////////////////////////////////////////////////////////////////////
// Space between two lines of text...

	private int _line_spacing = 0;

	int  GetLineSpacing()				{ return _line_spacing; }
	void SetLineSpacing(int spacing)	{ _line_spacing = spacing; }
	void SetLineSpacingToDefault()		{ _line_spacing = ((_modules[1]&0xFF) >> 1); }

////////////////////////////////////////////////////////////////////////////////////////////////////

	static int _index1 = -1;
	static int _index2 = -1;

	void SetSubString(int i1, int i2)
	{
		_index1 = i1;
		_index2 = i2;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void UpdateStringSize(String s)
	{
		_text_w = 0;
		_text_h = (_modules[1]&0xFF);
		int tw = 0;

		int index1 = ((_index1 >= 0) ? _index1 : 0);
		int index2 = ((_index2 >= 0) ? _index2 : s.length());

		for (int i = index1; i < index2; i++)
		{
			int c = s.charAt(i);
			if (c == ' ')
			{
				tw += (_modules[0]&0xFF) + _fmodules[1];
				continue;
			}
			else if (c == '\n')
			{
				if (tw > _text_w) _text_w = tw;
				tw = 0;
				_text_h += _line_spacing + (_modules[1]&0xFF);
				continue;
			}
			else if (c < 32)
			{
				if (c == '\u0001') // auto change current palette
				{
					i++;
				//	_cur_pal = s.charAt(i);
					continue;
				}
				else if (c == '\u0002') // select fmodule
				{
					i++;
					c = s.charAt(i);
				}
				else continue;
			}
			else
				c = Char2Frame(c);

			if (c >= GetFModules(0))
			{
				if (DEF.bErr) System.out.println("Character not available: c = "+c);
				c = 0;
			}

			int m = (_fmodules[c<<2]&0xFF)<<1;

			if (m >= _modules.length)
			{
				if (DEF.bErr) System.out.println("Character module not available: c = "+c+"  m = "+(m>>1));
				m = 0;
				c = 0;
			}

			tw += (_modules[m]&0xFF) - _fmodules[(c<<2)+1] + _fmodules[1];
		}
		if (tw > _text_w) _text_w = tw;
		if (_text_w > 0) _text_w -= _fmodules[1];
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

	void DrawString(Graphics g, String s, int x, int y, int anchor)
	{
		y -= _fmodules[2];

		if ((anchor & (Graphics.RIGHT | Graphics.HCENTER | Graphics.BOTTOM | Graphics.VCENTER)) != 0)
		{
			UpdateStringSize(s);
				 if ((anchor & Graphics.RIGHT)   != 0)	x -= _text_w;
			else if ((anchor & Graphics.HCENTER) != 0)	x -= _text_w>>1;
				 if ((anchor & Graphics.BOTTOM)  != 0)	y -= _text_h;
			else if ((anchor & Graphics.VCENTER) != 0)	y -= _text_h>>1;
		}

		int xx = x;
		int yy = y;

		int old_pal = _cur_pal;

		int index1 = ((_index1 >= 0) ? _index1 : 0);
		int index2 = ((_index2 >= 0) ? _index2 : s.length());

		for (int i = index1; i < index2; i++)
		{
			int c = s.charAt(i);
			if (c == ' ')
			{
				xx += (_modules[0]&0xFF) + _fmodules[1];
				continue;
			}
			else if (c == '\n')
			{
				xx = x;
				yy += _line_spacing + (_modules[1]&0xFF);
				continue;
			}
			else if (c < 32)
			{
				if (c == '\u0001') // auto change current palette
				{
					i++;
					_cur_pal = s.charAt(i);
					continue;
				}
				else if (c == '\u0002') // select fmodule
				{
					i++;
					c = s.charAt(i);
				}
				else continue;
			}
			else // c > 32
			{
				c = Char2Frame(c);
			}

			if (c >= GetFModules(0))
			{
				if (DEF.bErr) System.out.println("Character not available: c = "+c);
				c = 0;
			}

			int m = (_fmodules[c<<2]&0xFF)<<1;

			if (m >= _modules.length)
			{
				if (DEF.bErr) System.out.println("Character module not available: c = "+c+"  m = "+(m>>1));
				m = 0;
				c = 0;
			}

			PaintFModule(g, 0, c, xx, yy, 0, 0, 0);
			xx += (_modules[m]&0xFF) - _fmodules[(c<<2)+1] + _fmodules[1];
		}

		_cur_pal = old_pal;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////
// maps an ASCII char to a sprite FModule

	static byte[] _map_char;// = new byte[256];

	private static int Char2Frame(int c)
	{
		if (DEF.bErr)
		{
			if (c > 255)
			{
				System.out.println("Unknown char: " + c);
				return 0;
			}
		}
		return _map_char[c]&0xFF;
	}
/*
		if (c < 32) // 0x00 - 0x20
		{
			return 0;
		}
		else if (c < 128) // 0x20 - 0xC0
		{
		//	if (c >= 'a' && c <= 'z')
		//		c = c - 'a' + 'A';
			return c - 32;
		}
		else if (c < 256) // // 0xC0 - 0xFF
		{
		//	if (c >= 0xC0 && c <= 0xDD)
		//		c += 0x20;
			// C0 - DF: ��������������������������������
			// E0 - FF: ��������������������������������
			return _map_char[c]&0xFF;
		}
		else
		{
			return 0;
		}
*/
////////////////////////////////////////////////////////////////////////////////////////////////////

	void DrawPage(Graphics g, String s, int x, int y, int anchor)
	{
		// Count lines...
		int lines = 0;
		int len = s.length();
		int[] off = new int[100];
		for (int i = 0; i < len; i++)
			if (s.charAt(i) == '\n')
				off[lines++] = i;
		off[lines++] = len;

		int th = _line_spacing + (_modules[1]&0xFF);

			 if ((anchor & Graphics.BOTTOM)  != 0)	y -= (th * (lines-1));
		else if ((anchor & Graphics.VCENTER) != 0)	y -= (th * (lines-1)) >> 1;

		// Draw each line...
		for (int j = 0; j < lines; j++)
		{
			_index1 = (j > 0) ? off[j-1]+1 : 0;
			_index2 = off[j];
			DrawString(g, s, x, y + j * th, anchor);
		}

		// Disable substring...
		_index1 = -1;
		_index2 = -1;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////
// Sprite lib...
////////////////////////////////////////////////////////////////////////////////////////////////////
/*
	static cSprite[] _sprites;

////////////////////////////////////////////////////////////////////////////////////////////////////

	static cSprite Lib_GetSprite(int index)
	{
		if (index < 0 || index >= _sprites.length)
			return null;
		return _sprites[index];
	}
*/
////////////////////////////////////////////////////////////////////////////////////////////////////
// Palette generation based on other palette...

	// -1 - original colors
	//  0 - invisible (the sprite will be hidden)
	//  1 - red-yellow
	//  2 - blue-cyan
	//  3 - green
	//  4 - grey

	static int[] GenPalette(int type, int pal[])
	{
		if (type <  0) return pal;	// original
		if (type == 0) return null; // invisible

		int[] new_pal = new int[pal.length];
		switch (type)
		{
			case 1: // red - yellow
				for (int i = 0; i < pal.length; i++)
					new_pal[i] = (pal[i] | 0x00FF3300) & 0xFFFFFF00;
				break;

			case 2: // blue - cyan
				for (int i = 0; i < pal.length; i++)
					new_pal[i] = (pal[i] | 0x000033FF) & 0xFF00FFFF;
				break;

			case 3: // green
				for (int i = 0; i < pal.length; i++)
					new_pal[i] = (pal[i] | 0x00000000) & 0xFF00FF00;
				break;

			case 4: // grey
				for (int i = 0; i < pal.length; i++)
				{
					int a = (pal[i] & 0xFF000000);
					int r = (pal[i] & 0x00FF0000) >> 16;
					int g = (pal[i] & 0x0000FF00) >> 8;
					int b = (pal[i] & 0x000000FF);
					int l = ((r + b + g) / 3) & 0x000000FF;
					new_pal[i] = ((l << 16) | (l << 8) | l | a);
				}
				break;
		
			case 5: // blend with black 50%
				for (int i = 0; i < pal.length; i++)
				{
					int a = (pal[i] & 0xFF000000);
					int r = (pal[i] & 0x00FC0000) >> 2;
					int g = (pal[i] & 0x0000FC00) >> 2;
					int b = (pal[i] & 0x000000FC) >> 2;
					new_pal[i] = (a | r | g | b);
				}
				break;
		}

		return new_pal;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////

}; // class cSprite

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
